# Memória Institucional Navegável — pacote de retomada

Este pacote reúne o material recuperável do projeto originalmente iniciado a
partir do Diário Oficial do Distrito Federal (DODF). Ele foi preparado para
retomar o trabalho com o Codex sem misturar arquivos efetivamente recuperados
com decisões reconstruídas do histórico.

## Ideia central

O domínio é a Administração Pública do Distrito Federal. O DODF é uma fonte
privilegiada de observação, não o domínio inteiro.

```text
documento original imutável
  -> estrutura documental rastreável
  -> afirmações com proveniência
  -> entidades e eventos
  -> relações
  -> estado institucional temporal
  -> projeções de busca, grafo e análise
```

Regra central: **documento primeiro, interpretação depois**.

## Onde começar

1. Leia `AGENTS.md` para as regras de trabalho.
2. Leia `docs/PROJECT_STATE.md` para saber exatamente o que existe e o que falta.
3. Leia `recovered/readme_original.md`, `recovered/DOMAIN_original.md` e
   `recovered/ROADMAP_original.md`.
4. Consulte as pesquisas em `research/` antes de escolher arquitetura ou
   ontologia.
5. Use `samples/` para reconstruir e testar o pipeline.

## Conteúdo do pacote

- `recovered/`: documentos originais recuperados.
- `research/`: duas pesquisas aprofundadas, em Markdown e no JSON original.
- `samples/`: texto da edição piloto do DODF.
- `docs/`: estado consolidado, proveniência e inventário de recuperação.
- `src/`, `scripts/`, `db/`, `tests/`: estrutura vazia para reconstrução segura.

## Atenção

O piloto anterior foi registrado como funcional, mas seus scripts, JSON
estrutural, manifestos, extrações e migração SQL não foram recuperados neste
pacote. Seus nomes, resultados e comportamento esperado estão documentados em
`docs/PROJECT_STATE.md`. Eles devem ser reconstruídos e validados; não devem ser
tratados como arquivos existentes.

