<!-- pagina 1 -->

### ANO LV EDIÇÃO Nº 112 BRASÍLIA - DF, SEGUNDA-FEIRA, 22 DE JUNHO DE 2026

### SUMÁRIO SEÇÃO I

# SEÇÃO II

# SEÇÃO III

PAG.

PAG.

PAG.

Poder Legislativo....................................................... 50

Poder Executivo......................................................... 31

Casa Civil................................................................... 31 50

Secretaria de Estado de Governo............................... 1 31 50

Secretaria de Estado de Governança Digital e Integração.................................................................... 2

Secretaria de Estado de Economia.............................. 4 31 51

Secretaria de Estado de Saúde.................................... 9 33 57

Secretaria de Estado de Educação.............................. 12 36 62

Universidade do Distrito Federal Professor Jorge Amaury Maia Nunes................................................... 39

Secretaria de Estado de Segurança Pública................ 13 39 63

Secretaria de Estado de Administração Penitenciária. 22 44 67

Secretaria de Estado de Transporte e Mobilidade....... 22 45 67

Secretaria de Estado de Justiça e Cidadania............... 45

Secretaria Extraordinária do Consumidor................... 45 68

Secretaria de Estado de Obras e Infraestrutura........... 24 45 68

Secretaria de Estado da Agricultura, Abastecimento e Desenvolvimento Rural............................................ 46 70

Secretaria de Estado de Ciência, Tecnologia e Inovação...................................................................... 70

Secretaria de Estado de Cultura e Economia Criativa 24 46 74

Secretaria de Estado de Desenvolvimento Social....... 75

Secretaria de Estado de Desenvolvimento Urbano e Habitação.................................................................... 25 46 76

Secretaria de Estado de Esporte e Lazer..................... 25 78

Secretaria de Estado do Meio Ambiente..................... 28 46 78

Secretaria Extraordinária de Proteção Animal............ 48

Secretaria de Estado de Turismo................................. 83

Secretaria de Estado de Desenvolvimento Econômico, Trabalho e Renda.................................... 30 48 83

Controladoria-Geral.................................................... 30

Defensoria Pública...................................................... 48

Procuradoria-Geral...................................................... 49 85

Ineditorial.................................................................... 85

# SEÇÃO I

## SECRETARIA DE ESTADO DE GOVERNO

### SECRETARIA EXECUTIVA DAS CIDADES

ORDEM DE SERVIÇO Nº 89, DE 16 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DAS CIDADES, DA SECRETARIA DE ESTADO DE GOVERNO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pelo inciso VII, Artigo 18, da Portaria nº 60, de 08 de fevereiro de 2022, resolve: Art. 1º Revogar, por interesse público, conforme Ofício Nº 234/2026 - RA-SCIA/GAB (204982714), o Termo de Permissão de Uso Não-Qualificado nº 456/2011 e Termo Aditivo nº 01/2013, constante no Processo Administrativo nº 0306-000029/2009, em

nome de JOSÉ ANTÔNIO CORREIA, CPF nº ***.269.723-**, referente ao mobiliário urbano do tipo Quiosque localizado na Quadra 10, Conjunto 2, Lote 9A, na Região Administrativa do Scia e Estrutural/DF. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

SUELY MARIA DE SOUSA

ORDEM DE SERVIÇO Nº 90, DE 17 DE JUNHO DE 2026. A SECRETÁRIA EXECUTIVA DAS CIDADES, DA SECRETARIA DE ESTADO DE GOVERNO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pelo inciso VII, Artigo 18, da Portaria nº 60, de 08 de fevereiro de 2022, resolve: Art. 1º Revogar, a pedido da interessada, conforme requerimento (195902301), datado de 26 de fevereiro de 2026, Permissão de Uso Qualificado nº 27/2021, constante no Processo Administrativo nº (04018-00001552/2021-01), em nome de JULIANA LOURENÇO DA SILVA, CPF nº ***.267.881-**, referente ao mobiliário urbano do tipo box de feira nº 66, localizado na Feira Permanente do Riacho Fundo II, tendo seus efeitos suspensos conforme data do requerimento. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

SUELY MARIA DE SOUSA

ADMINISTRAÇÃO REGIONAL DE TAGUATINGA

ORDEM DE SERVIÇO Nº 113, DE 18 DE JUNHO DE 2026 O ADMINISTRADOR REGIONAL DE TAGUATINGA DO DISTRITO FEDERAL, no uso da competência que lhe é atribuída pelo Artigo 42, do Decreto nº 38.094, de 28 de março de 2017, combinado com Decreto nº 39.690, de 28 de fevereiro de 2019, resolve: Art. 1º Em cumprimento ao disposto no caput do Artigo 7º do Decreto nº 39.690, de 28/02/2019, comunicar e dar conhecimento público da proposta de cooperação apresentada por JOSE MARCELINO DA SILVA , CPF nº 398***.***-91, para a promoção de benfeitorias a serem exercidas na área pública na QNL 1/3, Taguatinga Norte, Brasília - DF, apresentada por Instituto Academia de Futebol Unibras, para os fins do que estabelecem o §1º e o §2º desse mesmo artigo, conforme consta no Processo SEI-GDF nº 04003- 00000071/2026-53. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

EZEQUIAS PEREIRA DA SILVA

ADMINISTRAÇÃO REGIONAL DO ITAPOÃ

ORDEM DE SERVIÇO Nº 26, DE 17 DE JUNHO DE 2026 O ADMINISTRADOR REGIONAL DO ITAPOÃ DO DISTRITO FEDERAL, no uso das atribuições conferidas pelo art. 42 do Regimento Interno aprovado pelo Decreto nº 38.094, de 28 de março de 2017, tendo em vista o Decreto nº 16.109, de 1º de dezembro de 1994, que disciplina a administração e o controle dos bens patrimoniais do Distrito Federal, e a Recomendação Conjunta nº 3/2026 – PROREGs/MPDFT, constante do Processo SEI nº 04018-00000977/2026-08, que trata da utilização e do empréstimo de bens públicos móveis no âmbito das Administrações Regionais, resolve: Art. 1º Os bens patrimoniais móveis sob a responsabilidade da Administração Regional do Itapoã destinam-se ao uso exclusivo em serviço, sendo vedada sua utilização para fins particulares. Art. 2º Os bens patrimoniais móveis não poderão ser retirados dos respectivos setores usuários, salvo quando necessários à realização de atividades externas ordinárias ou excepcionais, ao uso individual do servidor, ou por motivo de transferência, recolhimento ou reparo. Art. 3º Para os fins desta Ordem de Serviço, consideram-se: I – atividades externas ordinárias: tarefas, ações e rotinas realizadas habitualmente no exercício das competências institucionais da Administração Regional do Itapoã, incluindose atividades envolvendo órgãos e entidades da Administração Pública; II – atividades externas não ordinárias ou excepcionais: aquelas não realizadas habitualmente no exercício das competências institucionais da Administração Regional do Itapoã. Art. 4º A utilização de bens para atividades externas não ordinárias ou excepcionais somente será admitida quando vinculada a atividade oficial, programa, ação ou evento do qual a Administração Regional do Itapoã participe institucionalmente, seja como promotora, apoiadora ou coorganizadora, devendo ser formalizada em processo próprio, aberto no Sistema Eletrônico de Informações — SEI/GDF, pela unidade responsável pela atividade.

<!-- pagina 2 -->

Art. 5º O processo de que trata o artigo anterior deverá ser instruído com: I – objeto da solicitação; II – finalidade; III – local, data, hora de início e de término; IV – justificativa para a utilização do bem; V – identificação dos interessados, parceiros, apoiadores e coorganizadores, quando houver; VI – descrição do interesse público a ser atendido; VII – documentação comprobatória pertinente; VIII – relação individualizada dos bens a serem utilizados, contendo identificação, número de tombamento e estado de conservação; IX – outras informações relevantes. Art. 6º Instruído o processo, o setor responsável o encaminhará ao Gabinete, que o remeterá à Assessoria Técnica — ASTEC. Parágrafo único. A ASTEC manifestar-se-á acerca da legalidade, da regularidade procedimental e da conformidade da solicitação com a legislação e os normativos aplicáveis, no prazo de até 10 (dez) dias úteis, prorrogável por igual período, mediante justificativa. Art. 7º Após o pronunciamento da ASTEC, os autos retornarão ao Gabinete para decisão. Art. 8º A utilização de bens patrimoniais da Administração Regional do Itapoã para atividades externas não ordinárias ou excepcionais será autorizada pelo(a) Administrador(a) Regional ou por seu substituto legal. Art. 9º O uso de bens patrimoniais da Administração Regional do Itapoã por terceiros somente poderá ocorrer mediante instrumento jurídico formal adequado, observada a legislação vigente, os requisitos estabelecidos nesta Ordem de Serviço e a demonstração do interesse público. Art. 10. A mera relevância social, cultural, esportiva, comunitária ou religiosa de evento promovido por terceiro não constitui, por si só, fundamento jurídico suficiente para autorizar a cessão, o empréstimo ou a disponibilização de bens móveis da Administração Regional do Itapoã, na ausência de participação institucional direta. Art. 11. Fica vedado o empréstimo, a cessão, a disponibilização ou a autorização de uso da sala de reuniões da Administração Regional do Itapoã a terceiros, pessoas físicas ou jurídicas, entidades privadas, associações, organizações religiosas, partidos políticos, grupos comunitários ou quaisquer interessados externos, para a realização de reuniões, eventos, assembleias, encontros, treinamentos, celebrações ou atividades de interesse particular ou institucional de terceiros. § 1º A vedação prevista no caput não impede o uso da sala de reuniões para atividades internas da Administração Regional do Itapoã ou para reuniões institucionais oficiais por ela convocadas, promovidas, conduzidas ou formalmente integradas, no exercício de suas competências administrativas. § 2º Também não se considera empréstimo, para os fins deste artigo, a utilização da sala de reuniões em atividades oficiais realizadas em articulação com órgãos e entidades da Administração Pública, desde que haja participação institucional direta da Administração Regional do Itapoã e registro administrativo da finalidade, data, horário, responsáveis e participantes. § 3º É vedada a utilização da sala de reuniões para fins particulares, comerciais, políticopartidários, religiosos, associativos, eleitorais ou para atividades sem vinculação direta com o interesse público institucional da Administração Regional do Itapoã. Art. 12. Quando da lavratura do instrumento autorizativo adequado, o setor responsável pela atividade indicará os servidores que atuarão e ficarão responsáveis pela guarda, transporte, uso adequado e integridade dos bens durante a utilização, até a devolução ao setor detentor de sua guarda. Art. 13. Após a designação dos servidores responsáveis, o processo será encaminhado à Coordenação de Administração Geral para emissão da “Autorização de Saída e de Entrada de Bens”, documento que deverá ser apresentado ao responsável pelo controle de acesso de bens da Administração Regional para registro. Art. 14. Findada a utilização, os bens retornarão à Administração Regional do Itapoã, onde serão conferidos pelo responsável por sua guarda. Art. 15. Qualquer irregularidade, extravio, dano, avaria ou divergência identificada no momento da conferência deverá ser registrada nos autos do processo para adoção das providências cabíveis.

## DIÁRIO OFICIAL DO DISTRITO FEDERAL

### Redação, Administração e Editoração: Anexo do Palácio do Buriti, Sala 102, Térreo. CEP: 70075-900, Brasília/DF. Telefones: (0XX61) 3961-4503 - 3961-4596

Art. 16. Os casos omissos serão submetidos à apreciação do Gabinete da Administração Regional do Itapoã, ouvida a Assessoria Técnica, quando necessário. Art. 17. Esta Ordem de Serviço entra em vigor na data de sua publicação. Art. 18. Revogam-se as disposições em contrário.

DILSON BULHÕES DO NASCIMENTO

ORDEM DE SERVIÇO Nº 27, DE 17 DE JUNHO DE 2026 O ADMINISTRADOR REGIONAL DO ITAPOÃ DO DISTRITO FEDERAL, no uso das atribuições conferidas pelo Artigo 42, do Decreto n° 38.094, de 28 de março de 2017, que aprova o Regimento Interno das Administrações Regionais, com alicerce no Decreto Distrital nº 30.634, de 30 de julho de 2009 e, pelo que consta no Processo SEI 00308- 00000671/2026-63, resolve: Art. 1º Dispensar o pagamento do preço público correspondente à utilização da Quadra Coberta - Projeto social ENCONTRO DE MULHERES, para realizar encontros sociais e comunitários, voltado ao público feminino da Região Administrativa do Itapoã e adjacências. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

DILSON BULHÕES DO NASCIMENTO

## SECRETARIA DE ESTADO DE GOVERNANÇA

## DIGITAL E INTEGRAÇÃO

PORTARIA Nº 21, DE 19 DE JUNHO DE 2026 Institui a Equipe de Elaboração do Plano Diretor de Tecnologia da Informação e Comunicação (PDTIC) da Secretaria de Estado de Governança Digital e Integração do Distrito Federal para o período de 2026 a 2029. O SECRETÁRIO DE ESTADO DE GOVERNANÇA DIGITAL E INTEGRAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, inciso III, da Lei Orgânica do Distrito Federal, e o Decreto nº 48.502, de 18 de abril de 2026, RESOLVE: CONSIDERANDO a competência da SGDI para formular, coordenar e executar a política de tecnologia da informação, governança digital, inteligência artificial, dados e segurança da informação no âmbito do Distrito Federal, atuando como órgão central dessas matérias; CONSIDERANDO que o Plano Diretor de TIC da SGDI integra os instrumentos de planejamento e governança geridos pela Secretaria, nos termos do Decreto nº 48.502, de 18 de abril de 2026; CONSIDERANDO que o PDTIC é condição obrigatória para a realização de aquisições e contratações de TIC e deve estar alinhado ao PETIC/DF e à EGD/DF vigentes, bem como à Lei nº 14.133/2021; CONSIDERANDO as orientações metodológicas do Guia de PDTIC do SISP (Portaria SGD/ME nº 778/2019), adotado como referência para a elaboração do plano; e RESOLVE: Art. 1º Fica instituída a Comissão de Elaboração do Plano Diretor de Tecnologia da Informação e Comunicação (CEPDTIC), responsável pela condução das atividades de elaboração do Plano Diretor de Tecnologia da Informação e Comunicação (PDTIC) da Secretaria de Estado de Governança Digital e Integração do Distrito Federal para o período de 2026 a 2029. Parágrafo único. O PDTIC constitui instrumento de planejamento e governança de tecnologia da informação e comunicação da SGDI, devendo observar as diretrizes estratégicas institucionais, a Estratégia de Governança Digital do Distrito Federal, o Plano Estratégico de Tecnologia da Informação e Comunicação do Distrito Federal – PETIC/DF, a Lei nº 14.133, de 1º de abril de 2021, e demais normativos aplicáveis. Art. 2º A CEPDTIC será composta pelos seguintes membros:

Membro Unidade Papel

Adriana Christina Pinto

Rodrigues Subsecretaria de Governança Digital — SUBGD Coordenadora

Daniel Costa Andrade Unidade de Governança de TIC — UGTIC Coordenador-

Adjunto

Ana Caroline Alcântara da

Diretoria de Gestão de Projetos, Processos e

Coordenadora-

Costa

Serviços de TIC

Adjunta

CELINA LEÃO

Governadora

RAIMUNDO DIAS IRMÃO JÚNIOR Secretário de Estado Chefe da Casa Civil - Interino

RAIANA DO EGITO MOURA Secretária Executiva de Atos Oficiais

ANTÔNIO DE PÁDUA CANAVIEIRA Subsecretário de Tecnologia da Informação

<!-- pagina 3 -->

Matheus Rogério Liberato Secretaria Executiva de TIC Membro

Ivan Carlos de Oliveira Subsecretaria de Sistemas da Informação — SUBSIS Membro

Lenimar Ferreira de Lima Subsecretaria de Infraestrutura e Rede Corporativa —

SUBINFRA Membro

Cinthia Nunes Mendes de

Sousa Subsecretaria de Administração Geral — SUAG Membro

Ana Gabriela de Oliveira

Unidade de Planejamento, Contratação e Licitação —

UPCL Membro

Barreto

§ 1º A composição da CEPDTIC foi definida de modo a assegurar a participação de representantes das áreas de negócio, tecnologia da informação, governança, planejamento, contratações e administração, observando-se a multidisciplinaridade necessária à elaboração do PDTIC. § 2º Os membros poderão indicar servidores de suas respectivas unidades para apoiar a execução de atividades específicas relacionadas à elaboração do PDTIC, mediante comunicação prévia à Coordenação. § 3º A participação na CEPDTIC será considerada prestação de serviço público relevante, não ensejando remuneração adicional. Art. 3º Compete à Coordenação da CEPDTIC: I - definir e conduzir a metodologia de elaboração do PDTIC; II - coordenar a execução das atividades previstas no Plano de Trabalho do PDTIC; III - consolidar os documentos de referência institucionais e normativos; IV - identificar as estratégias da organização e os princípios e diretrizes do plano; V - elaborar o Plano de Trabalho do PDTIC e submetê-lo à aprovação do Comitê de Governança Digital; VI - consolidar a minuta do PDTIC para deliberação do Comitê de Governança Digital e aprovação da autoridade máxima; VII - especificar os papéis e responsabilidades dos integrantes da equipe, conduzir as reuniões, gerir o cronograma e reportar o andamento ao Comitê de Governança Digital. Parágrafo único. Em seus impedimentos, a Coordenadora será substituída pelo Coordenador-Adjunto. Art. 4º Compete à CEPDTIC, em conjunto: I – realizar o diagnóstico da situação atual da tecnologia da informação e comunicação no âmbito da SGDI; II – identificar e analisar as necessidades de negócio, serviços, soluções e recursos de TIC; III – levantar demandas relacionadas à infraestrutura tecnológica, sistemas, dados, segurança da informação, governança digital e transformação digital; IV – identificar os fatores críticos de sucesso para o alcance dos objetivos estratégicos institucionais relacionados à TIC; V – propor objetivos, metas, indicadores e iniciativas estratégicas de TIC; VI – elaborar o plano de investimentos e o plano de contratações de TIC necessários à execução do PDTIC; VII – identificar, avaliar e propor medidas de tratamento dos riscos relacionados à implementação do PDTIC; VIII – elaborar a minuta do PDTIC e os documentos complementares necessários à sua aprovação; IX – promover a articulação com as unidades administrativas da SGDI para obtenção das informações necessárias à elaboração do plano. Art. 5º Os trabalhos da CEPDTIC observarão o cronograma constante do Plano de Trabalho do PDTIC. Art. 6º As unidades administrativas da SGDI deverão prestar apoio técnico e fornecer as informações necessárias ao desenvolvimento dos trabalhos da CEPDTIC, quando solicitadas pela Coordenação. Art. 7º As propostas de aquisições e contratações de tecnologia da informação e comunicação deverão observar as diretrizes, necessidades, prioridades e iniciativas previstas no PDTIC, em consonância com os instrumentos de planejamento institucional vigentes. Art. 9º Os casos omissos e as situações excepcionais relacionadas aos trabalhos da CEPDTIC serão dirimidos pela Coordenação. Art. 10. Revoga-se a Portaria nº 19, de 18 de junho de 2026. Art. 11. Esta Portaria entra em vigor na data de sua publicação.

CLEMILTON OLIVEIRA RODRIGUES JUNIOR

PORTARIA Nº 22, DE 19 DE JUNHO DE 2026 O SECRETÁRIO DE ESTADO DE GOVERNANÇA DIGITAL E INTEGRAÇÃO DO DISTRITO FEDERAL, no uso da atribuição que lhe confere o art. 105, parágrafo único, incisos I e III da Lei Orgânica do Distrito Federal, RESOLVE: Art. 1º Instituir o Comitê Interno de Avanço Digital (CIAD), da Secretaria de Estado de Governança Digital e Integração do Distrito Federal (SGDI), órgão colegiado deliberativo e consultivo, responsável pela gestão e governança de Tecnologia da Informação e Comunicação, governança digital, transformação digital, inteligência artificial, segurança da informação e governança de dados no âmbito da Secretaria de Estado de Governança Digital e Integração. Parágrafo único. O CIAD/SGDI exercerá as atribuições do Subcomitê Gestor de Transformação Digital e do Subcomitê Gestor de TIC, ambos previstos na Política de Governança Digital e na Política de Governança de TIC, respectivamente. Art. 2º Vincula-se ao Comitê Interno de Avanço Digital da Secretaria de Estado de Governança Digital e Integração do Distrito Federal (CGD/SGDI), o Subcomitê Técnico de Segurança da Informação (STSI), com a finalidade de assessorar o CIAD em matérias

específicas relacionadas ao estabelecimento, manutenção e evolução do Sistema de Gestão de Segurança da Informação (SGSI), que compreende a segurança da informação, proteção de dados, gestão de riscos cibernéticos e conformidade normativa. Parágrafo único. Para fins desta Portaria, o Sistema de Gestão de Segurança da Informação – SGSI consiste no conjunto de políticas, processos, normas e controles adotados para proteger as informações institucionais, com base na gestão de riscos, assegurando a confidencialidade, a integridade e a disponibilidade da informação.

Das Competências do CIAD Art. 3º Compete ao Comitê Interno de Avanço Digital da Secretaria de Estado de Governança Digital e Integração do Distrito Federal (CIAD/SGDI): I – propor políticas, estratégias, diretrizes e instrumentos de governança relacionados à Tecnologia da Informação e Comunicação, governança digital, transformação digital, governança de dados, inovação e segurança da informação, em consonância com o planejamento estratégico institucional e com as diretrizes do Governo do Distrito Federal; II – analisar, supervisionar, priorizar e acompanhar a execução de projetos, ações, investimentos, contratações, aquisições e prestações de serviços de Tecnologia da Informação e Comunicação, observados os objetivos estratégicos da Secretaria; III – estabelecer diretrizes para elaboração, acompanhamento, revisão e aprovação do Plano Diretor de Tecnologia da Informação e Comunicação – PDTIC e do Plano de Transformação Digital – PTD da Secretaria; IV – acompanhar e avaliar, periodicamente, os resultados das iniciativas de governança digital, transformação digital, segurança da informação, inovação tecnológica e governança de dados, com base em indicadores, metas e instrumentos de planejamento institucional; V – promover a transformação digital institucional, incentivando: a) a simplificação e digitalização de serviços públicos; b) a melhoria da experiência do usuário; c) a interoperabilidade entre sistemas; d) a integração de soluções digitais; e) a racionalização de processos e recursos tecnológicos; f) o compartilhamento seguro de informações entre unidades administrativas; VI – estabelecer diretrizes para a governança de dados, observando: a) a gestão estratégica dos dados institucionais; b) a qualidade, integridade, disponibilidade e interoperabilidade dos dados; c) a catalogação, classificação e gestão do ciclo de vida dos dados; d) a transparência e o compartilhamento seguro de informações; e) a proteção de dados pessoais e o cumprimento da legislação aplicável; f) o uso ético, responsável e estratégico de dados e inteligência artificial; VII – propor diretrizes, mecanismos e instrumentos para a adoção responsável de inteligência artificial, analytics, automação e demais tecnologias emergentes, observados os princípios da segurança da informação, proteção de dados pessoais, transparência, ética, governança e eficiência administrativa, com vistas ao fortalecimento da tomada de decisão, da modernização institucional e da melhoria dos serviços públicos; VIII – coordenar, acompanhar e deliberar sobre atividades, planos, normas, procedimentos e propostas relacionadas à Segurança da Informação e Comunicação, elaboradas pelo Subcomitê Técnico de Segurança da Informação, observadas as diretrizes da Política de Segurança da Informação e Comunicação do Distrito Federal – POSIC e demais normas aplicáveis; IX – aprovar o Regimento Interno, planos de trabalho, propostas de aperfeiçoamento e demais instrumentos de governança relacionados às atividades do Comitê e de seus subcomitês; X – promover a adoção de boas práticas, modelos de governança, padrões técnicos e recomendações de órgãos de controle relacionados à governança digital, segurança da informação, gestão de riscos, governança de dados e transformação digital; XI – fomentar parcerias e iniciativas de cooperação com órgãos e entidades públicas ou privadas voltadas à inovação, pesquisa, transferência de tecnologia e modernização da gestão pública; XII – opinar e deliberar sobre outros temas estratégicos relacionados às competências do Comitê.

Das Competências do STSI Art. 4º Compete ao Subcomitê Técnico de Segurança da Informação (STSI): I – estabelecer, manter, orientar e coordenar o Sistema de Gestão de Segurança da Informação (SGSI), promovendo sua atualização de maneira contínua e padronizada; II – elaborar e atualizar as Normas de Segurança da Informação e Comunicação e Procedimentos de Segurança da Informação e Comunicação da Secretaria, em conformidade com a Política de Segurança da Informação e Comunicação do Distrito Federal – POSIC e Norma de Segurança da Informação e Comunicação - NOSIC do GDF, leis e regulamentos pertinentes; III – alinhar o gerenciamento de riscos relacionados à I&T com a estratégia geral de gerenciamento de riscos da organização; IV - garantir que os investimentos na mitigação de riscos sejam proporcionais aos benefícios obtidos; V – implementar um modelo de gerenciamento de riscos, incluindo painéis de monitoramento de riscos; VI – estabelecer priorização no conjunto de riscos e orientar ações para mitigação dos riscos prioritários; VII – desenvolver e acompanhar o Plano de Continuidade de Negócios (PCN), assegurando a realização de testes periódicos do plano e procedimentos associados;

<!-- pagina 4 -->

VIII – avaliar o resultado dos testes do Plano de Continuidade de Negócios e recomendar ajustes e melhorias do plano; IX – instituir grupos de trabalho específicos relacionados à segurança da informação, quando necessário; X – estabelecer mecanismos de registro, monitoramento e controle de não conformidades relativas à Política de Segurança da Informação e Comunicação do GDF, às normas e aos procedimentos aplicáveis; XI – elaborar, propor melhorias, e manter atualizado o Regimento Interno do Subcomitê Técnico de Segurança da Informação, observadas as diretrizes estabelecidas pelo CGD/SGDI; XII – propor ao CIAD/SGDI ajustes, revisões e aperfeiçoamentos no modelo de governança de segurança da informação da Secretaria; XIII – fomentar a conscientização sobre segurança da informação no âmbito da SGDI; XIV – fomentar a adoção de modelos, normas e recomendações de órgãos de controle no que tange à gestão de riscos; XV – atuar na orientação e interface junto ao CSIRT (Computer Security Incident Response Team) da SGDI no que tange à aderência a boas práticas, governança e controles. Parágrafo único. O Subcomitê Técnico de Segurança da Informação possui caráter técnico e consultivo, cabendo ao Comitê a deliberação final sobre suas propostas.

Da Composição do CIAD Art. 5º O Comitê Interno de Avanço Digital da Secretaria de Estado de Governança Digital e Integração do Distrito Federal (CIAD/SGDI) será composto: I – Chefe de Gabinete da Secretaria de Estado de Governança Digital e Integração; II – Titulares das Subsecretarias da Secretaria de Estado de Governança Digital e Integração. III – Chefe da Unidade de Governança de TIC IV – Chefe da Unidade de Transformação Digital § 1º O Comitê será presidido pelo Secretário Executivo de Tecnologia da Secretaria de Estado de Governança Digital e Integração, e poderá ser substituído pelo Subsecretário de Governança Digital, que assumirá todas as prerrogativas do Presidente conferidas por esta Portaria. § 2º Os suplentes serão aqueles que, nos termos da organização administrativa vigente, substituem formalmente os titulares em suas ausências e impedimentos, a contar da publicação desta Portaria.

Da Composição do STSI Art. 6º O Subcomitê Técnico de Segurança da Informação será composto por representantes das seguintes unidades: I – Representante da Unidade de Gestão de Pessoas da Subsecretaria de Administração Geral da SGDI (SUAG); II – Representante da Unidade de Segurança, Centro de Dados e Mensageria da Subsecretaria de Infraestrutura e Rede Corporativa da SGDI (SUBINFRA); III – Representante da Unidade de Gestão de Serviços Digitais da Subsecretaria de Governança Digital da SGDI (SUBGD); IV – Representante da Unidade de Sistemas Administrativos da Subsecretaria de Sistemas da Informação da SGDI (SUBSIS); § 1º. Os integrantes do Subcomitê Técnico de Segurança da Informação e seus respectivos suplentes serão indicados pelos titulares das unidades representadas. § 2º. Os representantes indicados deverão deter notório saber e experiência nas matérias afetas à segurança da informação, gestão de riscos cibernéticos, proteção de dados ou temas correlatos ao escopo de atuação do Subcomitê. § 3º. O Subcomitê Técnico de Segurança da Informação terá caráter técnico e consultivo, e suas deliberações e propostas deverão ser submetidas à apreciação do CGD/SGDI.

Das Disposições Finais Art. 7º A participação no CIAD e no STSI não será remunerada. Art. 8º Poderão participar das reuniões, na qualidade de ouvintes ou colaboradores, representantes de qualquer Unidade Organizacional da Secretaria de Estado de Governança Digital e Integração. Art. 9º A Subsecretaria de Governança Digital exercerá a coordenação técnicoadministrativa do CIAD, fornecendo subsídios para a tomada de decisões, e atuando exclusivamente em demandas relacionadas às competências do Comitê. Art. 10. Revoga-se a Portaria nº 18, de 18 de junho de 2026. Art. 11. Esta Portaria entra em vigor na data de sua publicação.

CLEMILTON RODRIGUES DE OLIVEIRA JUNIOR

## SECRETARIA DE ESTADO DE ECONOMIA

PORTARIA Nº 433, DE 18 DE JUNHO DE 2026 O SECRETÁRIO DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso das atribuições que lhe conferem os incisos I e III do Parágrafo único do art. 105 da Lei Orgânica do Distrito Federal e o art. 2º do Decreto nº 39.663, de 7 de fevereiro de 2019, e considerando as possíveis solicitações de revisão de teto orçamentário encaminhadas pelas unidades orçamentárias durante o processo de elaboração do Projeto de Lei Orçamentária Anual para o exercício de 2027, resolve: Art. 1º Estabelecer procedimento para solicitação de revisão do teto orçamentário, a ser observado pelas unidades orçamentárias durante o processo de elaboração do Projeto de

Lei Orçamentária Anual – PLOA para o exercício de 2027, na forma do Anexo Único desta Portaria. § 1º A solicitação de revisão do teto orçamentário deverá ser: I - detalhada por Tipo de Detalhamento da Despesa e Ação Orçamentária; II – justificada, com base em documentos ou em informações que possam comprovar as justificativas do pedido; III - encaminhada, no modelo do formulário a que se refere o Anexo Único, também, em formato editável para o endereço eletrônico coger.suop@economia.df.gov.br; e IV - encaminhada no Sistema Eletrônico de Informação – SEI/GDF pela autoridade máxima do órgão ou entidade no período de 6 a 16 de agosto de 2026. § 2º Somente serão apreciadas as solicitações que se adequarem ao disposto nesta Portaria. Art. 2º As solicitações de revisão encaminhadas pelas unidades orçamentárias serão apreciadas pela Secretaria de Estado de Economia, que deliberará pelo deferimento total ou parcial ou pelo indeferimento do pleito. § 1º A apreciação da solicitação de revisão de teto orçamentário considerará a alocação dos recursos disponibilizados para a Unidade Orçamentária para o atendimento prioritário das seguintes despesas: I - obrigatórias; II - necessárias ao funcionamento da unidade orçamentária; III – de conservação do Patrimônio Público; e IV - discricionárias. Art. 3º No caso de deferimento total ou parcial da solicitação, o Órgão Central de Planejamento e Orçamento alterará a proposta orçamentária da Unidade Orçamentária contemplada no âmbito do Sistema Integrado de Gestão Governamental – SIGGo-WEB. Art. 4º As ações orçamentárias cujas solicitações de revisão do teto orçamentário forem indeferidas ou não apreciadas, nos termos desta Portaria, poderão ser objeto de créditos adicionais no decorrer do exercício financeiro de 2027. Art. 5º As dúvidas e os casos omissos referentes aos procedimentos definidos nesta Portaria serão esclarecidos e resolvidos pela Subsecretaria de Orçamento Público da Secretaria de Estado de Economia. Art. 6º Esta Portaria entra em vigor na data de sua publicação.

VALDIVINO JOSÉ DE OLIVEIRA

ANEXO ÚNICO PROCEDIMENTO PARA SOLICITAÇÃO DE REVISÃO

DO TETO ORÇAMENTÁRIO – PLOA 2027

ITEM PROCEDIMENTO

1 Acessar o sítio eletrônico da Secretaria de Estado de Economia, no endereço: https://www.economia.df.gov.br/ploa-2027.

2 Clicar no link “Formulário de Solicitação de Revisão do Teto Orçamentário”, para baixar o formulário em formato Excel.

Realizar o filtro por Unidade Orçamentária e preencher os campos por Tipo de Detalhamento da Despesa e Ação Orçamentária, conforme orientação do “Manual de Solicitação de Revisão do Teto Orçamentário”, disponível no endereço: https://www.economia.df.gov.br/ploa-2027.

Enviar o formulário preenchido via Processo SEI/GDF para a Coordenação-Geral da Proposta Orçamentária Anual – SEEC/SEFIN/SUOP/UPROMO/COGER da Secretaria de Estado de Economia no período de 6 a 16 de agosto de 2026.

5 Enviar o formulário preenchido, em formato Excel, também, para o endereço eletrônico coger.suop@economia.df.gov.br.

### SECRETARIA EXECUTIVA DA RECEITA

DECLARAÇÃO DE CAPACIDADE DE FINANCIAMENTO

(Processo SEI-GDF nº 00220-00007016/2026-23) O Secretário-Executivo da Receita, no uso de suas atribuições legais, com fundamento no § 4º do art. 2º da Portaria Conjunta SEEC/SEL nº 9, de 21 de outubro de 2024, e nos termos do Processo SEI-GDF nº 00220-00007016/2026-23: DECLARA que o incentivador esportivo AMBEV S.A, CF/DF: 07.652.229/003-50 e CNPJ: 07.526.557/0032-06, dispõe, no exercício de 2026, do limite R$ 2.570.599,37 para incentivar projetos esportivos no âmbito do ICMS. AUTORIZA o citado incentivador esportivo a apropriar-se do crédito, de acordo com o montante do repasse de incentivo esportivo efetivado, respeitados os limites estabelecidos no art. 1º da Portaria nº 332, de 08 de maio de 2026, e nos incisos I e II do § 4º do art. 2º da Portaria Conjunta SEEC/SEL nº 9, de 21 de outubro de 2024.

CLIDIOMAR PEREIRA SOARES

<!-- pagina 5 -->

DECLARAÇÃO DE CAPACIDADE DE FINANCIAMENTO

(Processo SEI-GDF nº 00220-00007017/2026-78) O Secretário-Executivo da Receita, no uso de suas atribuições legais, com fundamento no § 4º do art. 2º da Portaria Conjunta SEEC/SEL nº 9, de 21 de outubro de 2024, e nos termos do Processo SEI-GDF nº 00220-00007017/2026-78: DECLARA que o incentivador esportivo AMBEV S.A, CF/DF: 07.652.229/002-79 e CNPJ: 07.526.557/0031-25, dispõe, no exercício de 2026, do limite R$ 2.839.616,43 para incentivar projetos esportivos no âmbito do ICMS. AUTORIZA o citado incentivador esportivo a apropriar-se do crédito, de acordo com o montante do repasse de incentivo esportivo efetivado, respeitados os limites estabelecidos no art. 1º da Portaria nº 332, de 08 de maio de 2026, e nos incisos I e II do § 4º do art. 2º da Portaria Conjunta SEEC/SEL nº 9, de 21 de outubro de 2024.

CLIDIOMAR PEREIRA SOARES

ATO DECLARATÓRIO SERT Nº 02, DE 19 DE JUNHO DE 2026 Credencia as instituições financeiras de que trata para prestação de serviços de arrecadação de tributos e demais receitas públicas do Distrito Federal, nos termos do Decreto nº 39.972/2019. O SECRETÁRIO-EXECUTIVO DA RECEITA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso das competências e atribuições previstas, respectivamente, no art. 3º, § 1º, do Decreto nº 48.726, de 03 de junho de 2026 e na Portaria nº 544, de 11 de julho de 2025; e, com fundamento no art. 8º do Decreto nº 39.972/2019, de 22 de julho de 2019, declara: Art. 1º A empresa PRONTO PAGUEI GESTÃO FINANCEIRA S.A, inscrita no CNPJ nº 33.595.865/0001-05, fica credenciada para prestação de serviços de arrecadação de tributos e demais receitas públicas do Distrito Federal conforme Processo SEI nº 04044- 00006495/2026-54. Art. 2º Este Ato Declaratório entra em vigor na data de sua publicação. Art. 3º Fica revogado o Ato Declaratório SUREC nº 04, de 11 de maio de 2026.

CLIDIOMAR PEREIRA SOARES

SUBSECRETARIA DE TRIBUTAÇÃO E DO JULGAMENTO

DO CONTENCIOSO ADMINISTRATIVO-FISCAL

ORDEM DE SERVIÇO Nº 06, DE 18 DE JUNHO DE 2026 Subdelega competências no âmbito da Subsecretaria de Tributação e do Julgamento do Contencioso Administrativo Fiscal, com fundamento na Ordem de Serviço SERT nº 11, de 17 de junho de 2026, e dá outras providências. O SUBSECRETÁRIO DE TRIBUTAÇÃO E DO JULGAMENTO DO CONTENCIOSO ADMINISTRATIVO-FISCAL, DA SECRETARIA EXECUTIVA DA RECEITA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso das atribuições que lhe conferem o inciso IV do art. 1º e os §§ 2º, 3º, 4º e 5º do art. 1º da Ordem de Serviço SERT nº 11, de 17 de junho de 2026, c/c o art. 3º, §§ 1º e 6º, do Decreto nº 48.726, de 3 de junho de 2026, e tendo em vista o disposto no art. 14 da Lei federal nº 9.784, de 29 de janeiro de 1999, aplicável ao Distrito Federal por força da Lei nº 2.834, de 7 de dezembro de 2001, resolve: Art. 1º Fica subdelegada ao Coordenador de Tributação a competência para: I - expedir Declaração de Inadmissibilidade de Consulta, especificando o motivo que lhe tenha dado causa; II - expedir Declaração de Ineficácia de Consulta, especificando o motivo que lhe tenha dado causa; III - decidir, em primeira instância, sobre a consulta eficaz, por meio de Solução de Consulta. § 1º As competências de que trata este artigo podem ser subdelegadas, no todo ou em parte, por meio de ordem de serviço, a servidor ocupante de cargo comissionado no âmbito da Coordenação de Tributação, sem prejuízo de sua avocação. § 2º As competências específicas do servidor a que se refere o § 1º podem ser subdelegadas, no todo ou em parte, por meio de ordem de serviço, a ocupante de cargo comissionado a ele subordinado, sem prejuízo de sua avocação. § 3º No caso de vacância, impedimento legal, afastamento ou licença do titular da Coordenação de Tributação, a competência de que trata o caput será exercida pelo seu substituto legal. Art. 2º Fica subdelegada ao Coordenador de Tratamentos Tributários Diferenciados a competência para: I - decidir, em primeira instância, sobre a concessão de benefício fiscal de caráter não geral de tributos; II - reconhecer, independentemente de requerimento, os benefícios fiscais de que trata o inciso I, com fundamento em dados cadastrais da Secretaria de Estado de Economia do Distrito Federal - SEEC/DF ou disponibilizados por outros órgãos ou entidades da Administração Pública; III - decidir, em primeira instância, sobre o reconhecimento de imunidade subjetiva e não incidência de tributos, inclusive aqueles que envolvam o atendimento dos requisitos previstos no art. 14 do Código Tributário Nacional; IV - decidir, em primeira instância, sobre a adoção de regime especial de emissão e escrituração de documentos fiscais e de apuração e recolhimento de obrigação tributária que dependa de requerimento do interessado, exceto os autorizados sob o amparo do Decreto nº 39.803, de 2 de maio de 2019; V - decidir, em primeira instância, sobre o pedido de atribuição da condição de substituto tributário, nos termos do Decreto nº 34.063, de 19 de dezembro de 2012;

VI - decidir, em primeira instância, sobre a concessão dos incentivos fiscais de que trata o art. 21 do Decreto nº 21.500, de 11 de setembro de 2000, que regulamenta a Lei nº 2.499, de 7 de dezembro de 1999 - PRÓ-RURAL/DF-RIDE. § 1º As competências de que trata este artigo podem ser subdelegadas, no todo ou em parte, por meio de ordem de serviço, a servidor ocupante de cargo comissionado no âmbito da Coordenação de Tratamentos Tributários Diferenciados, sem prejuízo de sua avocação. § 2º As competências específicas do servidor a que se refere o § 1º podem ser subdelegadas, no todo ou em parte, por meio de ordem de serviço, a ocupante de cargo comissionado a ele subordinado, sem prejuízo de sua avocação. § 3º No caso de vacância, impedimento legal, afastamento ou licença do titular da Coordenação de Tratamentos Tributários Diferenciados, a competência de que trata o caput será exercida pelo seu substituto legal. Art. 3º Fica subdelegada ao Coordenador de Julgamento do Contencioso Administrativo- Fiscal a competência para decidir, em primeira instância, os processos administrativos fiscais de exigência de créditos tributários sujeitos à jurisdição contenciosa. § 1º Fica vedada ao titular da Coordenação de Julgamento do Contencioso Administrativo- Fiscal a subdelegação da competência de que trata o caput a qualquer outra autoridade, servidor ou ocupante de cargo comissionado. § 2º No caso de vacância, impedimento legal, afastamento ou licença do titular da Coordenação de Julgamento do Contencioso Administrativo-Fiscal, a competência de que trata o caput será exercida pelo seu substituto legal e, na ausência ou impossibilidade deste, diretamente pelo Subsecretário de Tributação e do Julgamento do Contencioso Administrativo-Fiscal, independentemente de ato formal de avocação. § 3º A competência de que trata o caput poderá ser avocada, a qualquer tempo, pelo Subsecretário de Tributação e do Julgamento do Contencioso Administrativo-Fiscal, sem prejuízo da validade dos atos praticados no regular exercício da subdelegação. Art. 4º Fica revogada a Ordem de Serviço nº 8, de 9 de setembro de 2025, da Coordenação de Tributação, sem prejuízo da validade dos atos praticados sob sua vigência. Art. 5º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ZENÓBIO FARIAS BRAGA SOBRINHO

SUBSECRETARIA DE COBRANÇA, NEGOCIAÇÃO

E GESTÃO DO CRÉDITO TRIBUTÁRIO

ORDEM DE SERVIÇO Nº 04, DE 19 DE JUNHO DE 2026 O SUBSECRETÁRIO DE COBRANÇA, NEGOCIAÇÃO E GESTÃO DO CRÉDITO TRIBUTÁRIO, DA SECRETARIA EXECUTIVA DA RECEITA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso de suas atribuições e nos termos do § 2º, do art. 1º, da Ordem de Serviço SERT nº 11, de 17 de junho de 2026, resolve: Art. 1º Fica subdelegada às autoridades abaixo relacionadas, sem prejuízo de sua avocação, a competência para a prática dos atos administrativos previstos no inciso II, do art. 1º, da Ordem de Serviço SERT nº 11, de 17 de junho de 2026, a seguir especificados: I - Ao Gerente da Gerência de Restituição de Tributos Diretos, da Coordenação de Controle da Arrecadação e do Cadastro da Dívida Ativa - GERDI/CODAT/SUBRAT, para: a) decidir sobre pedidos de restituição e compensação de tributos diretos, ISS Autônomo e ICMS Simples Candango; b) em única instância, decidir sobre restituição e compensação referentes a tributos indiretos requeridos por missões diplomáticas, repartições consulares e representações de organismos internacionais. II – Ao Coordenador da Coordenação de Negociação e Recuperação de Créditos Tributários - COREN/SUBRAT, para, em única instância, decidir sobre processos de parcelamento de débitos geridos pela Secretaria Executiva da Receita e sobre o contencioso administrativo deles oriundo, consoante Portaria nº 34, de 23 de janeiro de 2002. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação. Art. 3º Revoga-se a Ordem de Serviço CBRAT nº 02, de 28 de fevereiro de 2025.

WENDEL CARRIJO CARVALHO

### SECRETARIA EXECUTIVA DE FINANÇAS,

### ORÇAMENTO E PLANEJAMENTO CONTADORIA GERAL DO DISTRITO FEDERAL

INSTRUÇÃO NORMATIVA Nº 06, DE 17 DE JUNHO DE 2026 Altera a Portaria nº 1.026 de 23 de dezembro de 2025, que dispõe sobre a Classificação Econômica da Despesa e aprova a Tabela para Classificação das Despesas quanto à sua natureza. O CONTADOR-GERAL DO DISTRITO FEDERAL, DA SECRETARIA EXECUTIVA DE FINANÇAS, ORÇAMENTO E PLANEJAMENTO, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso das competências previstas no Regimento Interno da Secretaria de Estado de Economia do Distrito Federal, nos incisos I, II, VII, X e XXII do artigo 22 do Anexo Único da Portaria/SEEC nº 544, de 11 de julho de 2025; CONSIDERANDO a necessidade de promover a uniformização dos procedimentos de execução orçamentária no âmbito da União, dos Estados, do Distrito Federal e dos Municípios, para viabilizar a consolidação das Contas Públicas Nacionais, em obediência

<!-- pagina 6 -->

ao disposto no Art. 51 da Lei Complementar nº 101, de 04 de maio de 2000 (Lei de Responsabilidade Fiscal); CONSIDERANDO a competência atribuída ao titular da então Subsecretaria de Contabilidade, na forma prevista no Art. 6º da Portaria nº 1.026 de 23 de dezembro de 2025, para promover alterações necessárias na codificação constante do ANEXO ÚNICO da citada Portaria; CONSIDERANDO a necessidade de promover adequações no Anexo Único da Portaria nº 1.026 de 23 de dezembro de 2025, no que se refere à criação e a definição de conceitos de subelementos de despesa, com o objetivo de melhor classificar as despesas executadas no âmbito do Governo do Distrito Federal, CONSIDERANDO a necessidade de evidenciar a execução de despesa com benefícios sociais que não são compatíveis com nenhum outro subelemento constante da Portaria nº 1.026 de 23 de dezembro de 2025, resolve: Art. 1º Incluir na Alínea D - ELEMENTOS DE DESPESA, constante do ANEXO ÚNICO da Portaria nº 1.026 de 23 de dezembro de 2025, os seguintes subelementos, ambos do Elemento de Despesa 94 - INDENIZAÇÕES E RESTITUIÇÕES TRABALHISTAS: "

Gratificação de Proteção à Primeira Infância e à Maternidade

Despesas com pagamento de gratificação de proteção à primeira infância e à maternidade (Resolução Conjunta CNJ/CNMP nº 14/2026).

94.10

Parcela de Valorização por Tempo de Antiguidade na Carreira - PVTAC

Despesas com pagamento de parcela de valorização por tempo de antiguidade na carreira - PVTAC (Resolução Conjunta CNJ/CNMP nº 14/2026).

94.11

" Art. 2º Esta Instrução Normativa entra em vigor da data de sua publicação.

HELVIO FERREIRA

### TRIBUNAL ADMINISTRATIVO DE RECURSOS FISCAIS

RECURSO EXTRAORDINÁRIO Nº 35/2026 Recorrente: TAIS APARECIDA SOUSA SOARES Advogado(a): ALBERTO EMANUEL ALBERTIN MALTA - OAB/DF 46.056 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Origem da decisão: 1ª CÂMARA DO TRIBUNAL ADMINISTRATIVO DE RECURSOS FISCAIS Processo SEI: 00040-00030088/2021-88 TAIS APARECIDA SOUSA SOARES, irresignado(a) com a decisão da 1ª Câmara deste egrégio Tribunal Administrativo de Recursos Fiscais, no julgamento do Reexame Necessário nº 47/2025 e Recurso Voluntário nº 84/2025 (Acórdão n° 61/2026 - doc. SEI 200634303), interpôs, via procurador habilitado (mandato incluso doc. SEI 204980541), Recurso Extraordinário ao Pleno, em 05/06/2026 (doc. SEI 204980535 e doc. SEI 204980536 ). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268, de 18 de outubro de 2011, e, ainda, no art. 97, da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2. Audiência prévia da douta Representação Fazendária. 3. Publique-se e distribua-se.

Brasília/DF, 08 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 59/2026 Recorrente : MELHOR COMERCIO VAREJISTA E ATACADISTA DE PRODUTOS ALIMENTICIOS LTDA Procuradora: PRISCILA RIBEIRO PEREIRA Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00058992/2025-57 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc. SEI nº 205149859. 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 11 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 62/2026 Recorrente : MELHOR COMERCIO VAREJISTA E ATACADISTA DE PRODUTOS ALIMENTICIOS LTDA Procuradora: PRISCILA RIBEIRO PEREIRA Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00058987/2025-44 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de

Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc. SEI nº 205149824. 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 11 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO VOLUNTÁRIO Nº 63/2026 Recorrente: DIMACO PRODUTOS METALÚRGICOS LTDA Advogado: DÉBORA MORETTI DELLAMÉA OAB/DF 28.408 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Origem da decisão: COORDENAÇÃO DE JULGAMENTO DO CONTENCIOSO ADMINISTRATIVO-FISCAL Processo SEI: 04034-00001941/2023-29 DIMACO PRODUTOS METALÚRGICOS LTDA, irresignado(a) com a decisão de primeira instância proferida (doc. SEI 192825167), pertinente ao Auto de Infração nº 818/2023, interpôs, via procurador habilitado (mandato incluso doc. SEI 205290381), recurso a este egrégio Tribunal Administrativo de Recursos Fiscais, em 31/03/2026 (doc. SEI 199163796 e doc. SEI 205290509 ). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268, de 18 de outubro de 2011, e, ainda, no art. 51 da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2. Audiência prévia da douta Representação Fazendária. 3. Publique-se e distribua-se.

Brasília/DF, 10 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO VOLUNTÁRIO Nº 90/2026 Recorrente: VIAÇÃO PIONEIRA LTDA Advogado: VALERIO ALVARENGA MONTEIRO DE CASTRO OAB/DF 13.398 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Origem da decisão: COORDENAÇÃO DE JULGAMENTO DO CONTENCIOSO ADMINISTRATIVO-FISCAL Processo SEI: 04044-00022016/2024-85 VIAÇÃO PIONEIRA LTDA, irresignado(a) com a decisão de primeira instância proferida (doc. SEI 198618681), pertinente ao Auto de Infração nº 26178/2024, interpôs, via procurador habilitado (mandato incluso doc. SEI 204055995), recurso a este egrégio Tribunal Administrativo de Recursos Fiscais, em 26/05/2026 (doc. SEI 204055992 e doc. SEI 205262355). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268, de 18 de outubro de 2011, e, ainda, no art. 51 da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2. Audiência prévia da douta Representação Fazendária. 3. Publique-se e distribua-se.

Brasília/DF, 10 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 128/2026 Recorrente: ALPHA ADMINISTRAÇÃO DE BENS LTDA Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00065546/2025-07 Origem da decisão: COORDENAÇÃO DE TRIBUTAÇÃO - COTRI A autoridade de primeira instância, ao não reconsiderar a decisão que indeferiu o pedido de RECONHECIMENTO DE REMISSÃO DE CRÉDITOS DE ICMS (doc. SEI nº 203710407), encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, com as razões aduzidas pelo contribuinte (doc. SEI nº 199344557).1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, nos artigos 9° e 70 e seu parágrafo único, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2. Publique-se e distribua-se.

Brasília/DF, 10 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 134/2026 Recorrente: FACIL COMERCIO ATACADISTA DE PRODUTOS DE HIGIENE LTDA Advogado: JONISVALDO JOSE DA CONCEICAO OAB/DF Nº: 47.975 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00010537/2026-51 Origem da decisão: SUBSECRETARIA DA RECEITA - SUREC A autoridade de primeira instância ao não reconsiderar a exclusão do Regime Especial que permitia ao contribuinte adotar a sistemática de apuração prevista na Lei nº 5.005/2012 (doc. 196483444), encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pela recorrente (doc. SEI nº 203205492), por meio de procurador habilitado, conforme doc. SEI nº 203205503.

<!-- pagina 7 -->

1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011, e ainda nos artigos 9º c/c com art. 74, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade, EM SEU EFEITO SUSPENSIVO, com amparo no parágrafo único do art. 74 da Lei nº 4.567/2011, por ser a decisão suscetível de causar lesão grave e de difícil reparação ao contribuinte. 2. Publique-se e distribua-se.

Brasília/DF, 11 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 135/2026 Recorrente: FACIL COMERCIO ATACADISTA DE PRODUTOS DE HIGIENE LTDA Advogado: JONISVALDO JOSE DA CONCEICAO OAB/DF Nº: 47.975 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00010780/2026-70 Origem da decisão: SUBSECRETARIA DA RECEITA - SUREC A autoridade de primeira instância ao não reconsiderar a exclusão do Regime Especial que permitia ao contribuinte adotar a sistemática de apuração prevista no Decreto nº 39.753/2019 (doc. 196481746), encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pela recorrente (doc. SEI nº 203202592), por meio de procurador habilitado, conforme doc. SEI nº 203202642. 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011, e ainda nos artigos 9º c/c com art. 74, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade, EM SEU EFEITO SUSPENSIVO, com amparo no parágrafo único do art. 74 da Lei nº 4.567/2011, por ser a decisão suscetível de causar lesão grave e de difícil reparação ao contribuinte. 2. Publique-se e distribua-se.

Brasília/DF, 11 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 140/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019377/2026-14 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200053183 e 205636186), por meio de procurador habilitado (doc. SEI nº 205353674). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 141/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019376/2026-61 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200053097 e 205635793), por meio de procurador habilitado (doc. SEI nº 205353670). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 142/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019365/2026-81 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de

Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052644 e 205635195), por meio de procurador habilitado (doc. SEI nº 205354234). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 143/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019363/2026-92 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052579 e 205635087), por meio de procurador habilitado (doc. SEI nº 205354229). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 144/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019362/2026-48 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI 200052542 nº(s) e 205634977), por meio de procurador habilitado (doc. SEI nº 205354226). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 145/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019361/2026-01 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052500 e 205634856), por meio de procurador habilitado (doc. SEI nº 205354224). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 146/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019360/2026-59 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de

<!-- pagina 8 -->

Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052458 e 205634704), por meio de procurador habilitado (doc. SEI nº 205354219). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 147/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019359/2026-24 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052402 e 205634561), por meio de procurador habilitado (doc. SEI nº 205354215). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 148/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019358/2026-80 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200052350 e 205634418), por meio de procurador habilitado (doc. SEI nº 205354212). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 169/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019323/2026-41 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200043937 e 205631003), por meio de procurador habilitado (doc. SEI nº 205354123). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 171/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019320/2026-15 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de

Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200043528 e 205630745), por meio de procurador habilitado (doc. SEI nº 205354115). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 174/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019314/2026-50 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200042731 e 205630307), por meio de procurador habilitado (doc. SEI nº 205354100). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 175/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019312/2026-61 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200042266 e 205630155), por meio de procurador habilitado (doc. SEI nº 205354098). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO DE JURISDIÇÃO VOLUNTÁRIA Nº 176/2026 Recorrente : AUDAX COMERCIO ATACADISTA E VAREJISTA DE PRODUTOS Advogado: IDELCIO RAMOS MAGALHÃES FILHO OAB/DF Nº: 32.129 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Processo SEI: 04044-00019272/2026-57 Origem da decisão: Gerência de Análise de Processos de Restituição e Ressarcimento de Tributos Indiretos - GEARE A autoridade de primeira instância, ao não reconsiderar a decisão que INDEFERIU O PEDIDO DE RESTITUIÇÃO - ICMS, encaminha, por meio do Sistema Eletrônico de Informações – SEI/DF, o recurso de jurisdição voluntária ao Tribunal Administrativo de Recursos Fiscais, nos termos do artigo 109 da Lei nº 4.567, de 9 de maio de 2011, para apreciação em segunda instância, acompanhado das razões aduzidas pelo contribuinte, conforme doc.(s) SEI nº(s) 200013534 e 205629509), por meio de procurador habilitado (doc. SEI nº 205354093). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268/2011 e, ainda, no art. 9° c/c com o §2º do art. 84, ambos da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2 . Publique-se e distribua-se.

Brasília/DF, 16 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

RECURSO EXTRAORDINÁRIO Nº 28/2026 Recorrente: DIAGNÓSTICOS DA AMÉRICA S.A. Advogado(a): ELAYNE LOPES LOURENÇO - OAB/DF Nº 28.478 Recorrida: FAZENDA PÚBLICA DO DISTRITO FEDERAL Origem da decisão: 1ª CÂMARA DO TRIBUNAL ADMINISTRATIVO DE RECURSOS FISCAIS Processo SEI: 04034-00014325/2023-38 DIAGNÓSTICOS DA AMÉRICA S.A., irresignado(a) com a decisão da 1ª Câmara deste egrégio Tribunal Administrativo de Recursos Fiscais, no julgamento do Recurso

<!-- pagina 9 -->

Voluntário nº 3/2025 (Acórdão n° 33/2026 - doc. SEI 195116189), interpôs, via procurador habilitado (mandato incluso doc. SEI 201152840 fl. 6), Recurso Extraordinário ao Pleno, em 24/04/2026 (doc. SEI 201152831 e doc. SEI 201152833). 1. RECEBO O RECURSO, com suporte no artigo 10, inciso XIV, do Decreto nº 33.268, de 18 de outubro de 2011, e, ainda, no art. 97, da Lei nº 4.567/2011, uma vez constatada sua tempestividade. 2. Audiência prévia da douta Representação Fazendária. 3. Publique-se e distribua-se.

Brasília/DF, 05 de junho de 2026 VÂNIA NASCIMENTO DE CASTRO

Presidente

### INSTITUTO DE ASSISTÊNCIA

### A SAÚDE DOS SERVIDORES

DESPACHO DO DIRETOR-PRESIDENTE

Em 19 de junho de 2026 TORNAR SEM EFEITO o RECONHECIMENTO DE DÍVIDA, cujo Interessado figura a empresa OFTALMOCLINIC SS LTDA, CNPJ Nº 01.241.695/0001-66, no valor de R$13.555,00 (treze mil quinhentos e cinquenta e cinco reais), publicado no DODF nº 100, de 02 de junho de 2026, página 71.

PABLO VIEIRA DE CASTRO

## SECRETARIA DE ESTADO DE SAÚDE

### CONTROLADORIA SETORIAL DA SAÚDE

PORTARIA Nº 595, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 2ª Comissão de Processo Disciplina, relativos ao Processo 00060-00414812/2024-09 (PAD 044/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 596, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 3ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00541008/2024-93 (PAD 045/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 597, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 6ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00230197/2020-48 (PAD 347/2020), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 598, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 10ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00351254/2024-55 (PAD 046/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 599, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 11ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00564475/2025-72 (PAD 047/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 600, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 12ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00084762/2025-01 (PAD 048/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 601, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 21ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00423721/2025-37 (PAD 049/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 602, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 23ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00211458/2024-54 (PAD 042/2026), a contar de 22 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 603, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 24ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00218630/2024-09 (PAD 043/2026), a contar de 22 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 604, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 33ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00034989/2022-55 (PAD 221/2022), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

<!-- pagina 10 -->

PORTARIA Nº 605, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 37ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00014878/2025-75 (PAD 050/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 606, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 38ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00383565/2024-83 (PAD 051/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 607, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 39ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00409202/2025-66 (PAD 052/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 608, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 40ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00016844/2025-15 (PAD 053/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 609, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 43ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00381175/2024-79 (PAD 054/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 610, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 44ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00185309/2025-11 (PAD 056/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 611, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar por 60 (sessenta) dias os trabalhos da 45ª Comissão de Processo Disciplinar, relativos ao Processo 00060-00467205/2025-14 (PAD 055/2026), a contar de 29 de junho de 2026. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 612, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 1ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00243932/2025-98 (PAD 011/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 613, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 7ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00108585/2024-77 (PAD 019/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 614, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 9ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00230363/2024-30 (PAD 014/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 615, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 13ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 342, de 13 de abril de 2026, publicada no DODF nº 68, de 14 de abril de 2026, o Processo 00060-00083903/2025-61 (PAD 012/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas.

<!-- pagina 11 -->

Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 616, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 14ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 342, de 13 de abril de 2026, publicada no DODF nº 68, de 14 de abril de 2026, o Processo 00060-00253906/2024-97 (PAD 115/2025), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 617, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 15ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00116369/2024-03 (PAD 020/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 618, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 16ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00573995/2023-12 (PAD 024/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 619, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 18ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00331490/2025-36 (PAD 015/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 620, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 19ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00165300/2025-86 (PAD 017/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 621, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 26ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00197387/2024-70 (PAD 025/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 622, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 27ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00538253/2025-02 (PAD 018/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 623, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 28ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00096112/2026-81 (PAD 021/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 624, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve:

<!-- pagina 12 -->

Art. 1º Reconduzir para a 29ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00096074/2026-67 (PAD 022/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 625, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 37ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00241085/2025-27 (PAD 013/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 626, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 42ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, o Processo 00060-00094750/2026-68 (PAD 023/2026), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 627, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 4ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 342, de 13 de abril de 2026, publicada no DODF nº 68, de 14 de abril de 2026, o Processo 00060-00428189/2022-00 (SIND 011/2023), com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas. Art. 2º Fixar o prazo de 30 (trinta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 628, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 27ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, as seguintes Sindicâncias, com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas: I - Processo 00060-00513864/2023-78 (SIND 008/2024); II - Processo 00060-00521183/2023-83 (SIND 002/2025).

Art. 2º Fixar o prazo de 30 (trinta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 629, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 29ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, as seguintes Sindicâncias, com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas: I - Processo 00060-00397214/2022-98 (SIND 019/2022); II - Processo 00060-00062737/2022-16 (SIND 015/2023); III - Processo 00060-00487185/2022-55 (SIND 002/2024); IV - Processo 00060-00295586/2024-42 (SIND 005/2025). Art. 2º Fixar o prazo de 30 (trinta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação

BRUNO ARAÚJO LOPES

PORTARIA Nº 630, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso III, da Portaria Conjunta nº 24, de 11 de outubro de 2017, publicada no DODF nº 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal, considerando o disposto no artigo 211 e seguintes, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Reconduzir para a 30ª Comissão de Processo Disciplinar, de caráter permanente, instituída pela Portaria nº 52, de 22 de janeiro de 2026, publicada no DODF nº 15, de 23 de janeiro de 2026, as seguintes Sindicâncias, com a finalidade de dar continuidade aos trabalhos de apuração de eventuais responsabilidades administrativas: I - Processo 00060-00466500/2023-91 (SIND 006/2024); II - Processo 00060-00101050/2022-11 (SIND 003/2025); III - Processo 00060-00543442/2024-16 (SIND 004/2025); IV - Processo 00060-00296208/2025-67 (SIND 001/2026). Art. 2º Fixar o prazo de 30 (trinta) dias para a conclusão dos trabalhos, admitida a prorrogação por igual período, quando as circunstâncias assim o exigirem e desde que devidamente justificado. Art. 3º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

## SECRETARIA DE ESTADO DE EDUCAÇÃO

RETIFICAÇÃO Na Portaria nº 291, de 11 de junho de 2026, publicada no DODF nº 106, em 12 de junho de 2026, página 68, ONDE SE LÊ: "…com ônus parcial para o Distrito Federal...", LEIA-SE: "…com ônus total para o Distrito Federal...".

No Termo de Homologação referente ao Parecer nº 64/2024-CEDF e na Portaria nº 242, de 14 de março de 2024, publicados no DODF nº 52, de 15 de março de 2024, página 25, ONDE SE LÊ: "…registrado no CNPJ sob o nº 01.701.830/0001-32...", LEIA-SE: "... registrado no CNPJ sob o nº 44.274.541/0001-83...".

### CORREGEDORIA

ORDEM DE SERVIÇO N° 530, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, c/c com o Art. 20, Inciso III, do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, e consoante o Art. 214, §2º, da Lei Complementar n° 840/2011, resolve: Art. 1º Prorrogar o prazo dos Processos Sindicantes 00080.00185594/2026-79, 00080.00186069/2026-71, 00080.00155574/2026-06, por 30 (trinta) dias, a contar de 20 de junho de 2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

<!-- pagina 13 -->

ORDEM DE SERVIÇO N° 531, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, c/c com o Art. 20, inciso III, do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, e conforme Art. 217, §1º da Lei Complementar n° 840/2011, resolve: Art. 1º Prorrogar o prazo dos Processos Administrativos Disciplinares 00080.00148522/2026-41, 00080.00148564/2026-81 e 00080.00148568/2026-60, por 60 (sessenta) dias, a contar de 14 de junho de 2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO N° 532, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, c/c com o Art. 20, inciso III, do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, e conforme Art. 217, §1º da Lei Complementar n° 840/2011, resolve: Art. 1º Prorrogar o prazo dos Processos Administrativos Disciplinares 00080.00132845/2026-12, 00080.00133298/2026-92, 00080.00326046/2025-24 e 00080.00148547/2026-44, por 60 (sessenta) dias, a contar de 15 de junho de 2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO N° 533, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no Art. 20, inciso III , alínea "d", do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, resolve: Art. 1º Reconduzir a Comissão Sindicante instituída por meio da Ordem de Serviço n° 199, de 18 de março de 2026, publicada no DODF n° 52, de 19 de março de 2026, p. 18, para prosseguir na apuração das irregularidades constantes no Processo Sindicante n° 00080- 00111070/2026.-41, no prazo de 30 (trinta) dias, a contar de 18 de junho de 2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO N° 534, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no Art. 20, incisos V e VI, do Decreto n° 38.631, de 20 de novembro de 2017, resolve: Art. 1º Reconduzir a Comissão Processante instituída por meio da Ordem de Serviço n° 117, de 20 de março de 2025, publicada no DODF n° 55, de 21 de março de 2025, p. 42, para prosseguir na apuração das irregularidades constantes no Processo Administrativo Disciplinar n° 00080-00079338/2025-62, no prazo de 60 (sessenta) dias, a contar de 19 de junho de 2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 535, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria-Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Dispensar a 10ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares referentes aos programas PDAF e PDDE, instituída pela Portaria n° 241, de 24 de abril de 2026, publicada no DODF n° 75, de 27 de abril de 2026, pp. 32/33, da Secretaria de Estado de Educação do Distrito Federal, ara a apuração dos fatos constantes do Processo Administrativo Disciplinar n° 00080-00220609/2026-52. Art. 2º Designar a 11ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares referentes aos programas PDAF e PDDE, instituída pela Portaria n° 244, de 24 de abril de 2026, publicada no DODF n° 75, de 27 de abril de 2026, pp. 33, da Secretaria de Estado de Educação do Distrito Federal. Art. 3º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 536, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF nº 143, de 29 de julho de 2024, p. 38, c/c com o disposto no artigo 20, inciso III, do Regimento Interno da Secretaria de Estado do Distrito Federal, resolve:

Art. 1º Acolher o Relatório Final da Comissão Processante designada para apuração dos fatos constantes no Processo Administrativo Disciplinar nº 00080-00151586/2025-48. Art. 2° Arquivar os autos, nos termos do Art. 8º, § 1º, da Instrução Normativa nº 01, de 12 de março de 2021, da Controladoria-Geral do Distrito Federal. Art. 3º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 537, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF nº 143, de 29 de julho de 2024, p. 38, c/c com o disposto no artigo 20, inciso III, do Regimento Interno da Secretaria de Estado do Distrito Federal, resolve: Art. 1º Acolher o Relatório Final da Comissão Processante designada para apuração dos fatos constantes no Processo Administrativo Disciplinar nº 00080-00204833/2025-16. Art. 2° Arquivar os autos com fundamento no Art. 244, §1º, inciso I c/c Art. 257, da Lei Complementar nº 840/2011. Art. 3º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

## SECRETARIA DE ESTADO DE SEGURANÇA PÚBLICA

### CONSELHO DISTRITAL DE SEGURANÇA PÚBLICA

RESOLUÇÃO Nº 06, DE 16 DE JUNHO DE 2026 Propõe aos órgãos integrantes da segurança pública do Distrito Federal diretrizes para a formulação, articulação, monitoramento e avaliação da política de segurança pública voltada à promoção da prevenção e repressão da violência e da criminalidade em face da população em situação de rua. O CONSELHO DISTRITAL DE SEGURANÇA PÚBLICA - CONDISP, no uso das atribuições que lhe confere o art.2º, incisos I, II e V da Lei distrital nº 6.430, de 19 de dezembro de 2019, e o disposto no art. 26, inciso I, e art. 28 do seu Regimento Interno, aprovado pelo Decreto nº 42.895, de 03 de janeiro de 2022; CONSIDERANDO o disposto no Decreto nº 7.053, de 23 de dezembro de 2009, que institui a a Política Nacional para a População em Situação de Rua e seu Comitê Intersetorial de Acompanhamento e Monitoramento, na Lei distrital nº 6.691, de 1º de outubro de 2020, que institui a Política Distrital para a População em Situação de Rua no Distrito Federal, e no Decreto nº 33.779, de 06 de julho de 2012, que institui a Política para Inclusão Social da População em Situação de Rua do Distrito Federal; CONSIDERANDO a Medida Cautelar adotada pelo Supremo Tribunal Federal na Arguição de Descumprimento de Preceito Fundamental nº 976, referendada em 22 de agosto de 2023, a qual determinou aos entes federados que adotem medidas para garantir direitos à População em Situação de Rua - PSR, incluindo medidas que garantam a segurança pessoal e dos bens dentro dos abrigos institucionais existentes, proibindo o recolhimento forçado de bens e pertences, a remoção e o transporte compulsório e o emprego de técnicas de arquitetura hostil contra essa população; CONSIDERANDO que o STF reconheceu em 2024, em sede de Repercussão Geral, tema nº 857, que "o art. 19 da Lei de Contravenções penais permanece válido e é aplicável ao porte de arma branca, cuja potencialidade lesiva deve ser aferida com base nas circunstâncias do caso concreto, tendo em conta, inclusive, o elemento subjetivo do agente"; CONSIDERANDO o Plano de Ação e Monitoramento para Efetivação da Política Distrital para População em Situação de Rua, no Distrito Federal, o qual reconhece que o enfrentamento dos desafios vivenciados pela população em situação de rua no Distrito Federal demanda uma estratégia abrangente, que transcenda soluções isoladas para abordar as diversas necessidades dessa comunidade; CONSIDERANDO a Recomendação nº 03/2021, do Ministério Público do Distrito Federal e Territórios - MPDFT, que versa sobre as abordagens realizadas pelas Forças de Segurança Pública do Distrito Federal à População em Situação de Rua (PSR), dispondo em seus itens II, III, V, VI, VII, VIII e IX sobre os critérios legais para a abordagem policial dispostos na legislação em vigor e na jurisprudência do Superior Tribunal de Justiça - STJ e do Supremo Tribunal Federal - STF; CONSIDERANDO que os estudos técnicos da Secretaria de Estado de Segurança Pública do Distrito Federal - SSP/DF, referente aos anos de 2019 à 2025, identificaram o aumento significativo do envolvimento de PSR nos casos de homicídios ocorridos no Distrito Federal, tanto na condição de vítima, como na de autor, sendo que em 64% (sessenta e quatro por cento) dos casos o crime foi cometido com o uso de arma branca; CONSIDERANDO que nos anos de 2023 e 2024, na região central de Brasília, 73% (setenta e três por cento) dos homicídios consumados envolveram PSR na condição de vítima e 60% (sessenta por cento) na condição de autor; CONSIDERANDO a necessidade de reduzir a situação de extrema vulnerabilidade social do referido grupo social, garantindo o direito fundamental à segurança pública para a preservação da ordem pública, da incolumidade das pessoas e do patrimônio público ou particular da própria PSR e do restante da população do Distrito Federal; CONSIDERANDO o disposto na Portaria Conjunta nº 01, de 11 de fevereiro de 2026, firmada entre a Secretaria de Estado de Segurança Pública do Distrito Federal e a Polícia

<!-- pagina 14 -->

Militar do Distrito Federal, que dispõe sobre critério objetivo, apto a respaldar a fundada suspeita, nos termos do art. 244 do Código de Processo Penal; CONSIDERANDO que a Política Distrital de Segurança Pública, criada pela Lei distrital nº 6.456, de 26 de dezembro de 2019, e o Plano Distrital de Segurança Pública e Defesa Social - PDISP: 2022-2031, aprovado pelo Decreto nº 42.831, de 17 de dezembro de 2021, não possuem dimensões, objetivos, metas e iniciativas voltados para a segurança da População em Situação de Rua; CONSIDERANDO o disposto no Relatório Final da 1ª Conferência Distrital de Segurança Pública, no qual a População em Situação de Rua foi debatido como tema de nº 06, com 11 iniciativas, com destaque para a qualificação do atendimento nos diversos órgãos de proteção social e a priorização da emissão de documentação civil, sendo um dos assuntos priorizados pelos participantes da Conferência; CONSIDERANDO a competência do Condisp para propor diretrizes e acompanhar a execução da Política Distrital de Segurança Pública e Defesa Social, bem como de propor aprimoramentos das normas de segurança pública, conforme previsto no art. 3º, incisos I, II e V da Lei distrital nº 6.430, de 19 de dezembro de 2019; CONSIDERANDO as reuniões realizadas pelo Conselho Distrital de Segurança Pública - Condisp com a colaboração de todos os Conselheiros, nas quais a segurança e ordem pública envolvendo a PSR foram debatidos em busca de soluções integradas a respeito do tema, resolve: Art. 1º Esta Resolução propõe aos órgãos integrantes da segurança pública do Distrito Federal, nos termos do art. 2º da Lei distrital nº 6.456, de 26 de dezembro de 2019, diretrizes para a formulação, articulação, monitoramento e avaliação da política de segurança pública voltada à promoção da prevenção e repressão da violência e da criminalidade em face da população em situação de rua, a serem consideradas em seus planejamentos e ações. Parágrafo único. O disposto nesta Resolução não substitui protocolos operacionais específicos, atos de comando, procedimentos correcionais ou normas técnico-operacionais próprias dos órgãos e corporações competentes. Art. 2º As diretrizes dispostas nesta Resolução terão como fundamento o reconhecimento da população em situação de rua como sujeito de direitos e destinatária de políticas públicas intersetoriais, em atenção ao disposto nos seguintes atos normativos: I — Decreto nº 7.053, de 23 de dezembro de 2009, que institui a Política Nacional para a População em Situação de Rua; II — Lei nº 6.691, de 1º de outubro de 2020, que institui a Política Distrital para a População em Situação de Rua no Distrito Federal; III — Decreto nº 33.779, de 6 de julho de 2012, que institui a Política para Inclusão Social da População em Situação de Rua do Distrito Federal. Parágrafo único. As diretrizes dispostas nesta Resolução são voltadas à Política Distrital de Segurança Pública e Defesa Social no Distrito Federal, instituída pela Lei nº 6.456, de 26 de dezembro de 2019, e ao Plano Distrital de Segurança Pública e Defesa Social - PDISP, aprovado pelo Decreto nº 42.831, de 17 de dezembro de 2021, em atenção às competências do Conselho Distrital de Segurança Pública, dispostas na Lei nº 6.430, de 19 de dezembro de 2019. Art. 3ª Para os fins desta Resolução considera-se: I — população em situação de rua (PSR): grupo populacional heterogêneo que possui em comum a pobreza extrema, os vínculos familiares interrompidos ou fragilizados e inexistência de moradia convencional regular, e que utiliza os logradouros públicos e as áreas degradadas como espaço de moradia e de sustento, de forma temporária ou permanente, bem como as unidades de acolhimento para pernoite temporário ou como moradia provisória; II — fundada suspeita: juízo baseado em critérios objetivos, concretos, descritíveis e verificáveis, preexistentes à abordagem, que indiquem probabilidade de posse de arma proibida, objeto, instrumento, produto ou prova de crime, nos termos do arts. 240, § 2º e 244 do Código de Processo Penal - CPP; III — agente do mesmo gênero: servidor cuja identidade de gênero corresponda à da pessoa abordada, considerada a autodeclaração da pessoa abordada, assegurado o respeito estrito à sua autodeclaração, independentemente de registro civil ou alteração fenotípica. IV — interface com a população em situação de rua: situação institucional, territorial ou de atendimento em que haja repercussão relevante, direta ou indireta, sobre pessoas em situação de rua, exigindo análise, monitoramento, articulação ou encaminhamento no âmbito das políticas públicas, tais como ocorrências com vítimas ou autores PSR, ações planejadas em territórios com concentração de PSR e operações de segurança pública que resultem em encaminhamento à rede socioassistencial; V — fluxo de atendimento (FA): conjunto de procedimentos intersetoriais previamente definidos e articulados entre os órgãos de segurança pública, de assistência social e de saúde, destinado a assegurar atendimento ágil, desburocratizado e colaborativo às pessoas em situação de rua envolvidas em ocorrências policiais — seja na condição de vítimas ou de autoras de infração penal — visando o encaminhamento aos tratamentos adequados pela rede de proteção social e de saúde pública. Art. 4º As ações de que trata esta Resolução terão como referência: I — a ação dos órgãos integrantes da segurança pública como papel auxiliar, e não como protagonista, em relação às demandas da PSR; II — a legalidade, a necessidade, a razoabilidade e a proporcionalidade; III — o respeito à dignidade da pessoa humana, vedada revitimização e a discriminação por condição social, raça, gênero, idade, orientação sexual, identidade de gênero ou qualquer outra; IV — a não criminalização da pobreza;

V — a proteção de dados pessoais e transparência do tratamento de informações, nos termos da LGPD, quando aplicável. Art. 5º A busca pessoal em pessoas integrantes do grupo vulnerável PSR, quando necessárias para a preservação da ordem pública e da incolumidade das pessoas e do patrimônio, ocorrerão nos casos de prisão ou quando houver fundada suspeita, respaldada em critérios objetivos, no termos do art. 2º, inciso II desta Resolução e legislação processual penal em vigor. Art. 6º São exemplos de critérios objetivos aptos a fundamentar a fundada suspeita para a realização de abordagem, busca pessoal ou apreensão: I — o porte ostensivo de arma de fogo ou branca, ou objeto com evidente potencial ofensivo; II — indícios objetivos de porte velado de arma de fogo ou arma branca ou objeto com evidente potencial ofensivo, tais como saliência compatível nas vestimentas ou em objetos, relatos minimamente corroborados, verificações de inteligência policial ou outras circunstâncias objetivas do caso concreto que ensejem a fundada suspeita, nos termos do art. 2º, inciso II desta Resolução; III — a constatação de comportamento objetivamente agressivo ou ameaçador, com risco concreto à incolumidade das pessoas ou ao patrimônio, podendo estar associado a sinais de alteração psicomotora, desde que o elemento determinante seja a conduta de risco e não a condição de uso de substâncias em si, em especial nas proximidades de parques, espaços de atividades e lazer destinados às crianças ou idosos e escolas e locais de grande circulação de pessoas; IV — a verificação em situação de flagrante pelo profissional da segurança pública, a informação oriunda de populares ou informações de inteligência policial previamente checados sobre o cometimento ou possível cometimento de crime ou contravenção penal ou sobre o porte de arma de fogo, arma branca ou de objeto produto de crime; V — situações de conflitos interpessoais com agressões verbais ou físicas ou grave ameaça entre a própria PSR ou entre pessoas pertencentes a esse grupo e outras pessoas; VI — outras situações em que elementos objetivos, concretos, individualizados e cronologicamente anteriores à abordagem permitam inferir, de forma descritível e verificável, a prática de infração penal específica pela pessoa abordada, sendo expressamente vedado invocar, como fundamento único ou principal, a condição de vulnerabilidade social ou situação de rua, a raça, cor, aparência ou vestimenta, o local de concentração ou procedência territorial, o histórico de passagens policiais ou antecedentes criminais, o nervosismo ou a fuga ao perceber a presença policial e a denúncia anônima desacompanhada de elemento concreto. Art. 7º A PSR que for abordada pelos órgãos de segurança pública e não possuir documento de identificação civil será orientada sobre os locais, horários e gratuidade para o registro e emissão do documento. Art. 8º A situação de rua, por si só, não configura fundada suspeita para justificar a abordagem e a busca pessoal. § 1º As buscas pessoais em PSR devem ser realizadas apenas nos casos em que sejam identificados os critérios objetivos que justifiquem a fundada suspeita. § 2º As buscas pessoais, quando indispensáveis para a preservação da ordem pública, da incolumidade das pessoas e do patrimônio público ou particular da própria PSR e das demais pessoas da população, devem ser realizadas por agentes do mesmo gênero da pessoa abordada, salvo em situações de urgência ou perigo iminente devidamente justificadas no registro da ocorrência. Art. 9º As abordagens, buscas pessoais e apreensões deverão ser filmadas, quando disponíveis câmeras operacionais portáteis. § 1º Os registros audiovisuais devem ser guardados em sistema digital seguro, observando-se os procedimentos de cadeia de custódia para garantir a integridade e a autenticidade das evidências, conforme o disposto nos arts. 158-A a 158-F do Código de Processo Penal.§ 2º Em caso de divulgação de registros audiovisuais para finalidades diversas da instrução processual, deverão ser obrigatoriamente adotadas medidas de anonimização ou supressão de elementos identificadores da pessoa abordada, de modo a resguardar sua dignidade e privacidade. Art. 10. Os bens e objetos apreendidos, com fundamento do art. 240, § 2º do CPP, deverão ser identificados em auto de apreensão, no qual será identificada o fundamento legal da apreensão. § 1º As apreensões deverão se atentar à cadeia de custódia, conforme disposto nos arts. 158-A a 158-F do Código de Processo Penal. § 2º É vedada a apreensão de bens pessoais de natureza existencial que não guardem relação com infração penal apurada no caso concreto, tais como cobertores, documentos pessoais e itens de subsistência. Art. 11. O critério objetivo que justificou a fundada suspeita para a abordagem, busca pessoal ou apreensão, os elementos de prova e as medidas de preservação de prova adotados serão relatados durante o registro da ocorrência policial. Art. 12. Recomenda-se que os sistemas de registro de ocorrências dos órgãos integrantes da segurança pública do Distrito Federal adotem campo próprio para assinalar de forma objetiva o envolvimento de pessoa em situação de rua, na condição de vítima ou de autor, no prazo de 120 (cento e vinte) dias, contados da publicação desta Resolução. § 1º Os dados sobre o envolvimento de PSR em ocorrências, de que trata o § 1º do caput, poderão ser utilizados para o monitoramento e avaliação da política de segurança pública voltada à promoção da prevenção e repressão da violência e da criminalidade em face da população em situação de rua.

<!-- pagina 15 -->

§ 2º Para fins de monitoramento e avaliação da política pública, recomenda-se que os órgãos integrantes da segurança pública do Distrito Federal, entre outros, os seguintes eixos informacionais: I — atendimentos, ocorrências e ações com interface com a população em situação de rua; II — dados de vitimização e letalidade violenta envolvendo população em situação de rua, na condição de vítima ou de autor, quando disponíveis e metodologicamente confiáveis; III — encaminhamentos realizados à rede socioassistencial, de saúde e demais serviços públicos; IV — registros institucionais de reclamações, notícias de abuso, tratamento discriminatório ou conflito na prestação do serviço público; V — dados sobre criança, adolescente, gestante ou núcleo familiar com criança ou adolescente em situação de rua, observadas as regras de proteção integral e sigilo; VI — indicadores de capacidade institucional, cobertura territorial e resposta integrada. Art. 13. Nas situações em que a atuação dos órgãos de segurança pública envolver criança, adolescente, gestante ou núcleo familiar com criança ou adolescente em situação de rua, deverão ser observadas, além das disposições desta Resolução, a proteção integral e a prioridade absoluta asseguradas pela Constituição Federal, pelo Estatuto da Criança e do Adolescente e pelos normativos que o regulamentam, entre as quais as Resoluções CNJ nº 425/2021, 470/2022, 485/2023 e 585/2024 e a Lei nº 12.594/2012 (SINASE). § 1º A situação de rua, por si só, não constitui fundamento suficiente para o afastamento do convívio familiar, devendo ser priorizadas soluções protetivas, intersetoriais e não discriminatórias. § 2º Sempre que identificada situação de risco pessoal ou social envolvendo criação ou adolescente em contexto de rua, incluindo risco de exploração e trabalho infantil, deverá ser acionada a rede de proteção competente, especialmente o Conselho Tutelar e, conforme o caso, os serviços de assistência social, saúde e demais órgãos do Sistema de Garantia e Direitos da Criança e do Adolescente. § 3º Nas ocorrências que envolvam gestantes, puérperas ou famílias com crianças e adolescentes em situação de rua, a atuação dos órgãos de segurança pública observará abordagem prioritária, humanizada e personalizada, evitando revitimização, estigmatização e práticas que reforcem a ruptura indevida de vínculos familiares e comunitários. § 4º A gestante ou mãe em situação de rua que manifeste interesse em entregar seu filho para adoção deverá ser informada das possibilidades de atendimento pela rede de saúde e assistência social, assim como o direito à entrega protegida, com acompanhamento pela Vara da Infância e Juventude. § 5º As crianças e adolescentes em situação de rua desacompanhadas de responsáveis devem receber especial atenção para proteção de sua integridade física, moral e mental, com acolhimento e atendimento por equipe multidisciplinar especializada. § 6º Os órgãos de segurança pública buscarão, em articulação com os órgãos competentes, fluxos de acesso às políticas públicas, consideração do histórico de atendimento pela rede, garantia do direito de participação das crianças e adolescentes no processo decisório quanto aos encaminhamentos a serem realizados e comunicação institucional para proteção integral de crianças adolescentes e suas famílias em situação de rua. § 7º Quando a atuação dos órgãos de segurança pública envolver adolescente em situação de rua que tenha praticado ou esteja sob suspeita de ato infracional, a atuação deverá priorizar soluções que articulem segurança pública, saúde, assistência social, políticas de prevenção à infância e juventude e o sistema socioeducativo, evitando respostas exclusivamente repressivas e favorecendo o encaminhamento do adolescente à rede de proteção e às medidas socioeducativas cabíveis. § 8º A condição de situação de rua, por si só, não caracteriza envolvimento em ato infracional nem autoriza a aplicação de medidas ou procedimentos próprios da política socioeducativa, devendo, nesses casos, prevalecer a adoção de medidas de proteção e o acionamento da rede de garantia de direitos da criança e do adolescente, nos termos do Estatuto da Criança e do Adolescente. Art. 14. Deverão ser observadas as seguintes regras para grupos especiais em situação de rua: I — mulheres em situação de violência doméstica: abordagem com acolhimento, preferencialmente por servidoras mulheres e pronto encaminhamento conforme fluxos e protocolos estabelecidos pela Rede Distrital de Proteção à Mulher, conforme disposto no Decreto nº 42.808, de 14 de dezembro de 2021. II — idosos: abordagem prioritária, humanizada e encaminhamento à rede de proteção, em consonância com o Estatuto do Idoso, disposto na Lei nº 10.741, de 1º de outubro de 2003 e na Lei distrital nº 1.57, de 11 de julho de 1997; III — pessoas com deficiência: abordagem com comunicação adaptada e outras situações em consonância com o disposto na Lei nº 12.146, de 6 de julho de 2015, e na Lei distrital nº 6.637, de 20 de julho de 2020; IV — pessoas em condição migratória: abordagem com atenção aos direitos dos imigrantes, em especial a acolhida humanitária e repúdio e prevenção à xenofobia, ao racismo e outras formas de discriminação, em atenção ao disposto na Lei nº 13.445, de 24 de maio de 2017, e na Lei Distrital nº 7.540, de 19 de julho de 2024; V — pessoas LGBTQIA+: observar o uso do nome social independentemente de retificação civil, o respeito ao gênero autodeclarado, a vedação de perguntas vexatórias sobre identidade e encaminhamento adequado, em atenção ao disposto no Decreto nº 37.982, de 30 de janeiro de 2017;

Art. 15. Recomenda-se aos órgãos integrantes da segurança pública do Distrito Federal que, no âmbito de suas competências e observados os instrumentos de governança e monitoramento já previstos na legislação distrital de segurança pública: I — promovam a incorporação do tema da população em situação de rua em seus instrumentos de planejamento institucional, especialmente para: a) diagnóstico de problemas públicos com recorte territorial e intersetorial; b) identificação de fatores de risco, vulnerabilidades e padrões de vitimização; c) desenvolvimento de ações preventivas e de solução de problemas; d) aperfeiçoamento do atendimento ao cidadão e da resposta institucional em contextos de alta vulnerabilidade social; II — divulguem esta Resolução aos seus servidores e insiram seu conteúdo em cursos de formação, aperfeiçoamento, protocolos operacionais e em regulamentos internos; II — orientem os seus servidores quanto à preservação de prova e cadeia de custódia; III — alinhem os fluxos com a rede de assistência social e de saúde do Distrito Federal para o encaminhamento da PSR aos serviços competentes, quando for o caso; IV — informem ao Conselho Distrital de Segurança Pública eventuais ações adotadas a partir da presente Resolução. Art. 16. Os cursos de formação, capacitação e de aperfeiçoamento dos servidores integrantes da segurança pública do Distrito Federal abordarão aspectos de qualificação dos agentes públicos para atuação em contextos que envolvam a população em situação de rua, tais como: I — fundamentos de direitos humanos, com ênfase na dignidade da pessoa humana, não discriminação e não criminalização da pobreza; II — limites legais da atuação policial, especialmente no que se refere à exigência de fundada suspeita e à vedação de abordagens baseadas em critérios genéricos os estigmatizantes; III — técnicas de abordagem qualificada e mediação de conflitos; IV — compreensão das dinâmicas específicas da população em situação de rua, incluindo fatores relacionados à vulnerabilidade social, saúde mental e uso de substâncias psicoativas; V — identificação de situações de risco e de violação de direitos, com orientação para atuação protetiva e encaminhamento adequado aos serviços competentes. § 1º O nível de qualificação dos agentes públicos levará em consideração as competências legais do respectivo cargo em face da população em situação de rua. § 2º Recomenda-se aos órgãos integrantes da segurança pública do Distrito Federal que estabeleçam mecanismos de monitoramento e avaliação das atividades formativas, assegurando sua efetividade prática. Art. 17. A Secretaria de Estado de Segurança Pública do Distrito Federal promoverá o diálogo institucional com o Ministério Público e o Poder Judiciário para acompanhar a evolução do tema e atualização de fluxos de trabalho, mantendo os órgãos vinculados informados sobre possíveis alterações e atualizações. Art. 18. O Conselho Distrital de Segurança Pública - Condisp promoverá a articulação institucional com os órgãos de assistência social e saúde do Distrito Federal objetivando estimular a atuação intersetorial da Política Distrital de Segurança Pública relacionada à PSR. § 1º A articulação institucional terá por objetivo o estabelecimento de fluxos de atendimento (FA) às pessoas em situação de rua que se envolverem, na condição de vítimas ou de autores, em ocorrências policiais para a apuração de infrações penais. § 2º Os FAs a serem estabelecidos prezarão pela agilidade, desburocratização e colaboração mútua entre os servidores públicos dos órgãos de segurança pública, de assistência social e de saúde envolvidos. § 3º Os FAs estabelecidos serão enumerados em ordem crescente e publicados no Diário Oficial do Distrito Federal como anexos da presente Resolução e encaminhados aos órgãos envolvidos para conhecimento e análise quanto a sua implantação, sendo recomendado que o primeiro FA seja publicado em até 90 (noventa) dias após a pública desta Resolução. Art. 19. Nas ações de segurança pública planejadas com potencial impacto relevante sobre a população em situação de rua, recomenda-se a articulação prévia com a rede pública de assistência social e de saúde, com vistas à disponibilização de serviços especializados e à mitigação de riscos sociais e institucionais. Parágrafo único. A atuação intersetorial de que trata este artigo deverá priorizar soluções coordenadas, socialmente responsáveis e compatíveis com os direitos humanos, vedadas práticas de caráter discriminatório, segregador ou de remoção generalizada desprovida de fundamento legal e social adequado. Art. 20. O Condisp poderá solicitar à Secretaria de Estado de Segurança Pública do Distrito Federal – SSP/DF subsídios periódicos sobre a interface entre segurança pública e população em situação de rua, com a finalidade de subsidiar suas atividades de monitoramento, avaliação e formulação de recomendações. Parágrafo único. Os subsídios de que trata o caput poderão conter, sempre que possível: I — panorama estatístico e territorial dos dados disponíveis; II — análise de tendências, variações e fatores críticos; III — informações sobre articulação intersetorial e fluxos de encaminhamento; IV — identificação de lacunas normativas, institucionais ou de gestão; V — indicação de boas práticas, riscos recorrentes e oportunidades de aperfeiçoamento; VI — elementos úteis à revisão de estratégias, metas, iniciativas e indicadores da Política Distrital de Segurança Pública e Defesa Social e do Plano Distrital de Segurança Pública e Defesa Social – PDISP, quando pertinente.

<!-- pagina 16 -->

Art. 21. Com base nas informações recebidas e nos subsídios consolidados, o Condisp poderá: I — formular recomendações aos órgãos e autoridades competentes; II — propor estudos, ações e medidas de aperfeiçoamento institucional; III — implementar ou reformular FPAs; IV — recomendar prioridades de capacitação e formação continuada; V — propor o aprimoramento das normas de segurança pública. Art. 22. Compete ao Condisp zelar pela efetividade das deliberações adotadas durante a 1ª Conferência Distrital de Segurança Pública, acompanhando a implementação de dimensões, objetivos, metas e iniciativas voltados para a segurança da População em Situação de Rua durante a atualização do Plano Distrital de Segurança Pública e Defesa Social - PDISP. Art. 23. Esta Resolução deverá ser avaliada no prazo de 12 (doze) meses, contado da data de sua publicação, à luz dos dados produzidos pelos órgãos de segurança pública, de assistência social de de saúde sobre as medidas implementadas, os resultados observados, com a participação de representantes da PSR e de organizações da sociedade civil. Art. 24. Esta Resolução entra em vigor na data de sua publicação no Diário Oficial do Distrito Federal e será encaminhada: I — ao Conselho Gestor do Plano Distrital de Segurança Pública e Defesa Social - CGPDISP, instituído pelo Decreto nº 42.831, de 17 de dezembro de 2021, para fins de deliberação quanto à alteração do Plano Distrital de Segurança Pública e Defesa Social - PDISP para a inclusão das diretrizes destinadas à população em situação de rua; II — aos órgão integrantes da segurança pública do Distrito Federal para conhecimento e análise quanto à inclusão em seus instrumentos de planejamento e ações; III — à Secretaria de Estado de Segurança Pública do Distrito Federal, à Secretaria de Estado de Saúde do Distrito Federal e à Secretaria de Estado de Desenvolvimento Social do Distrito Federal para amplo conhecimento aos seus servidores, em especial ao disposto no art. 18.

ALEXANDRE RABELO PATURY Secretário de Estado de Segurança Pública do Distrito Federal

Presidente do Condisp

### CONSELHO DE TRÂNSITO

ATA- SSP/CONTRANDIFE 2ª REUNIÃO ORDINÁRIA | MANDATO 2026–2028

DATA: 5 de maio de 2026. HORÁRIO: 19h00 às 23h00.

LOCAL: Reunião realizada por videoconferência, por meio da plataforma Microsoft Teams.

ATO: Decreto n.º 35.948, de 29 de outubro de 2014, aprova o Regimento Interno do CONTRANDIFE.

CONSELHEIROS PRESENTES

NOME ÓRGÃO FUNÇÃO MATRÍCULA

1. THIAGO GOMES NASCIMENTO SSP/DF PRESIDENTE 1.707-611-7

2. ARTHUR HENRIQUE ASSUNÇÃO MAGALHÃES SSP/DF VICE- PRESIDENTE 1.707-658-7

NOTÓRIO SABER

3. ANDRÉ LUIZ CALDAS PM/DF TITULAR 1.707-636-6

4. WAGNER PEREIRA LIMA DE BRITO DER/DF TITULAR 1.730.220-X

5. GRAZIELA DE SOUSA PORTELA DER/DF TITULAR 1.730-295-1

6. BRUNA PACHECO GONÇALVES DE MEDEIROS DETRAN/DF TITULAR 1.718.775-3

7. MARCUS AURÉLIO DE SOUZA MARINHO DETRAN/DF TITULAR 1.730.331-1

8. DIEISON BORGES DOS SANTOS PRF TITULAR 1.727.225-4

9. TATIANE LOPES DOS SANTOS SITTRATER/DF TITULAR 1.730.326-5

10. LEANDRO OLIVEIRA CARAÍBAS SETRANSP/DF SUPLENTE 1.718.913-6

11. RAPHAEL BARROS DORNELES RODAS DA PAZ TITULAR 1.712.510-0

12. SAMUEL MORGAN TEIXEIRA COSTA ONSV TITULAR 1.712.355-0

13. WESLEY FERRO NOGUEIRA MDT TITULAR 1.712.360-7

14. FRANCISCO VIEIRA GARONCE INPROTRAN TITULAR 1.725.777-8

15. ALEXANDRE RAMOS CAIADO FILHO MEDICINA TITULAR 1.731.611-1

16. JOANA PRISCILA SILVA NUNES DE CARVALHO PSICOLOGIA TITULAR 1.731.612-X

17. JOESLEY DOURADO BASTOS MEIO AMBIENTE TITULAR 1.731.553-0

1. Abertura 1.1. O Presidente, Sr. Thiago Gomes Nascimento, após verificação de quórum regimental, declarou abertos os trabalhos da 2ª Reunião Ordinária do Conselho de Trânsito do Distrito Federal – CONTRANDIFE, referente ao mandato 2026–2028, em 5 de maio de 2026, às 19h, realizada por videoconferência, por meio da plataforma Microsoft Teams.

2. Apresentação dos Conselheiros 2.1. O Vice-Presidente procedeu à acolhida institucional dos novos conselheiros ingressantes por meio de chamamento público, destacando a inovação do processo seletivo e a valorização de critérios técnicos e meritocráticos na composição do colegiado, conforme disposto na Resolução nº 15, de 23 de fevereiro de 2026. 2.2. Procedeu-se à apresentação dos novos conselheiros da área de medicina, psicologia e meio ambiente, com conhecimento na área de trânsito, ocasião em que os membros destacaram sua trajetória profissional, experiências institucionais e expectativas quanto à atuação no novo mandato, promovendo a integração entre conselheiros reconduzidos e novos membros. 2.3. Foram formalmente apresentados os seguintes conselheiros: Alexandre, representando a área de medicina de tráfego; Joesley Dourado, da área de meio ambiente; e Joana Carvalho, da área de psicologia. 3. Atuação institucional do CONTRANDIFE 3.1. O vice-presidente apresentou atuação institucional em curso referente à Portaria Conjunta nº 03, de 25 de março de 2026, que dispõe sobre o desfazimento de local de sinistro de trânsito com vítima nas vias pública do Distrito Federal, editada em conjunto pela Secretaria de Estado de Segurança Pública do Distrito Federal - SSP/DF, Polícia Militar do Distrito Federal, Corpo de Bombeiros Militar do Distrito Federal, Polícia Civil do Distrito Federal, Departamento de Trânsito do Distrito Federal e Departamento de Estradas de Rodagem do Distrito Federal. 3.2. Foi informado que o Conselho solicitou participação na elaboração do protocolo operacional padrão, demanda que foi atendida pelo Gabinete da SSP/DF. Assim, o CONTRANDIFE assumiu o papel de colaborador técnico no processo de construção normativa. 3.3. Uma minuta em desenvolvimento foi apresentada, contendo contribuições técnicas referentes a: definição de sinistro de trânsito, padronização de procedimentos operacionais, integração de bases de dados e alinhamento com o Pnatrans e demais normas técnicas, a qual será submetida posteriormente à análise e deliberação em reunião extraordinária deste colegiado. 4. Metodologia de julgamento 4.1. A prática foi intensificada nas seguintes áreas: julgamento colegiado com possibilidade de ajustes realizados durante as sessões, revisão de decisões a partir de debates técnicos, utilização de diligências como ferramenta para aprimorar a qualidade das decisões e condução de diligências complementares, incluindo a emissão de ofícios para a obtenção de informações técnicas adicionais. 5. Campanha Maio Amarelo 5.1. O CONTRANDIFE recebeu o convite para participar das ações do movimento Maio Amarelo, que serão realizadas no Campus Darcy Ribeiro no dia 20 de maio, objetivando a conscientização da comunidade universitária sobre a importância da segurança viária. 6. Julgamento de Processos Administrativos 6.1. O colegiado procedeu à relatoria e julgamento de processos administrativos de trânsito, abrangendo penalidades de multa, suspensão e cassação do direito de dirigir, com manifestações dos conselheiros relatores. 6.2. Foram julgados os seguintes processos:

DECISÃO

Nº PROCESSO RECORRENTE AUTO DE INFRAÇÃO

00113- 00021616/2024-31

DEPARTAMENTO DE ESTRADA DE RODAGEM DF GE01335580 NEGAR PROVIMENTO

0055-004695/2018 ADRIANA URBANO SAMARTINI COELHO S002639692 NEGAR PROVIMENTO

00113- 00001630/2023-38 ADRIANO GUEDES PEREIRA FC00134592 NEGAR PROVIMENTO

00113- 00015915/2023-56

AERTON SANDRO DOS S. CARVALHO GE01286994 NEGAR PROVIMENTO

00113- 00015914/2023-10

AERTON SANDRO DOS SANTOS CARVALHO GE01286987 NEGAR PROVIMENTO

00055- 00050345/2022-19

ALESSANDRO DE SANTANNA CARDOSO SA02974514 DILIGÊNCIA

00055- 00029587/2022-35

ALEXANDRE DE REZENDE NICOLAIDIS S003204608 NEGAR PROVIMENTO

00055- 00063785/2022-28 ALIOMAR ALMADA SA03178636 NEGAR PROVIMENTO

00113- 00015783/2022-81

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01869300 NEGAR PROVIMENTO

00113- 00005281/2023-23

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE02073296 DAR PROVIMENTO

00113- 00012579/2019-11

ANDERSON DE JESUS OLIVEIRA Y001675069 NÃO CONHECER

00055- 00045297/2019-33 ANDERSON NERES RIBEIRO CP00772701 NEGAR PROVIMENTO

<!-- pagina 17 -->

00055- 00035987/2023-61 ANDRE CANDIDO DO NASCIMENTO SA03242007 NEGAR PROVIMENTO

00055- 00035991/2023-29 ANDRE CANDIDO DO NASCIMENTO SA03242008 DAR PROVIMENTO

00055- 00023452/2019-61 ANDRE LUIZ AGUIAR CUNHA SANTOS S003048133 NÃO CONHECER

00055- 00041961/2019-75 ANDRE RICARDO DE PINHO RONZANI S003047896 NÃO CONHECER

00113- 00020268/2024-85 ANNA GABRIELLY XAVIER DA SILVA YE02397626 DILIGÊNCIA

00055- 00043264/2019-59 ARTUR HENRIQUE CASTRO DE ANDRADE S002179875 NEGAR PROVIMENTO

00055- 00045479/2024-71 BRUNNA MEDEITROS BRITO FULBER SA03952175 NEGAR PROVIMENTO

00055- 00044737/2022-31 DEPARTAMENTO DE TRÂNSITO DO DF SA02856040 DAR PROVIMENTO

00055- 00042187/2023-04 AYLLON DIAS CONRADO SA03547134 NÃO CONHECER

00055- 00102037/2022-78 BENEDITO LUIZARI FILHO FT00449127 NEGAR PROVIMENTO

00055- 00123803/2023-19 BENHUR BORBA FREITAS SA03726491 DILIGÊNCIA

00055- 00039601/2023-90 BRUNO ARAUJO DE MELLO SA03360319 NÃO CONHECER

00055- 00032363/2022-19 BRUNO BRZEZOWSKI SA02591205 NÃO CONHECER

00055- 00041959/2023-82 CAMILA DA SILVA BARREIRO SA02893541 NEGAR PROVIMENTO

00113- 00022569/2024-43 CAMILA DE SOUZA BORGES YE02369459 NEGAR PROVIMENTO

00113- 00003818/2024-00

CAMILLA BARRETO RODRIGUES COCHIA CAETANO YE02237437 NEGAR PROVIMENTO

00055- 00072022/2022-78

CARLOS ALBERTO PONGELUPPI E NICOLE MELO DIAS SA03142317 DILIGÊNCIA

00113- 00002578/2024-18 CARLOS EDUARDO SILVA VIDAL YE02220637 NEGAR PROVIMENTO

00055- 00115202/2018-75 CARLOS ROBERTO TRIGUEIRO S002746913 NÃO CONHECER

00055- 00067233/2023-70

CELIA MOREIRA ALVES E FABIANO EUSTAQUIO ZICA SILVA SA03373789 NEGAR PROVIMENTO

00113- 00016033/2023-16 CHRISTINE COSTA DOS SANTOS YE02215765 NEGAR PROVIMENTO

00055- 00028060/2023-74 DEBORA DA SILVA BUZZIN SA03337541 NÃO CONHECER

00113- 00009688/2018-62 DENILSON DE SOUZA FERREIRA Y001136101 NEGAR PROVIMENTO

00055- 00114142/2018-73 DIEGO EMILIO ROMERO ROVARIS S002919496 NEGAR PROVIMENTO

00055- 00054955/2022-83 EDSON JOSÉ VIEIRA E DETRAN/DF SA02623137 NEGAR PROVIMENTO

00055- 00127231/2023-47 EDSON JUNIO PIRES MAIA SA03612392 NEGAR PROVIMENTO

00113- 00011300/2022-70

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01887839 DAR PROVIMENTO

00055- 00074849/2021-35 DEPARTAMENTO DE TRÂNSITO DO DF CP00838035 DILIGÊNCIA

00055- 00074852/2021-59 DEPARTAMENTO DE TRÂNSITO DO DF CP00861256 DAR PROVIMENTO

00055- 00074856/2021-37 DEPARTAMENTO DE TRÂNSITO DO DF CP00861391 DILIGÊNCIA

00113- 00008768/2022-87

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01892915 NEGAR PROVIMENTO

00113- 00003496/2018-42 EMANUEL INÁCIO BEZERRA PINHEIRO Y001340251 NEGAR PROVIMENTO

00055- 00109314/2023-54 FABIO ANTONIO DA SILVA KK00616565 NEGAR PROVIMENTO

00113- 00013742/2023-31 FABIO BRUNO ANTONIO ALVES DE MOURA GE01291033 DAR PROVIMENTO

00055- 00010363/2023-31 FABIO DA SILVA DE OLIVEIRA SA03195529 NEGAR PROVIMENTO

00055- 00068777/2020-14 FABIO HENRIQUE MACHADO DE OLIVEIRA SA02071426 NEGAR PROVIMENTO

00055- 00037389/2023-26 FELIPE ADJUTO DE MELO SA03292611 NEGAR PROVIMENTO

00055- 00022843/2023-44 FELIPE DE ARAUJO LIMA SA03320480 NEGAR PROVIMENTO

00113- 00004457/2019-43 FELIPE FIGUEIREDO DA SILVA MOREIRA G000525755 DAR PROVIMENTO

00055- 00088416/2023-29 FELIPE YUKI YAMAMOTO TSUNO SA03638966 NEGAR PROVIMENTO

00055- 00169215/2018-64

FERNANDO ALBERTO BOTELHO DE SOUSA SA01699886 NEGAR PROVIMENTO

00055- 00102312/2025-04 FERNANDO ANTONIO NERES FERRAZ SA04513599 NEGAR PROVIMENTO

00055- 00024967/2019-88 FLADEMIR SOUSA SARDEIRO S002910575 NEGAR PROVIMENTO

00055- 00079530/2019-81 FRANCILEIDE GALENO MIRANDA SA02031669 NEGAR PROVIMENTO

00055- 00080505/2023-27 FRANCINALDO MIGUEL DA SILVA SA02590382 NEGAR PROVIMENTO

00113- 00014254/2023-41

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE02154789 DAR PROVIMENTO

00055- 00025258/2023-04

GABRIEL LEITE MEDEIROS E LUIZA LEAL MITCHELL SA03217922 NEGAR PROVIMENTO

00055- 00024037/2023-19 GESICA PAULA OLIVEIRA DA ROSA S003243183 NEGAR PROVIMENTO

00113- 00006841/2024-48 GISLYEL VICENTE LIMA DA SILVA YE02324869 NEGAR PROVIMENTO

00113- 00013035/2023-45

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE02150394 DAR PROVIMENTO

00055- 00064597/2020-55 GUSTAVO MATOS DE MENEZES SA01954281 NEGAR PROVIMENTO

00055- 00078872/2019-84 HERMANO FRANCISCO DE PAIVA MELO SA02009367 NEGAR PROVIMENTO

00113- 00001607/2024-24

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE02192105 DAR PROVIMENTO

00055- 00063991/2023-19 INDY FERREIRA DE LIMA LABRES SA03374512 NEGAR PROVIMENTO

00055- 00010427/2023-01 ITALO PATRICK OLIVEIRA COSTA KK00105209 NEGAR PROVIMENTO

00055- 00010430/2023-17 ITALO PATRICK OLIVEIRA COSTA KK00078079 NEGAR PROVIMENTO

00055- 00010434/2023-03 ITALO PATRICK OLIVEIRA COSTA KK00181129 NEGAR PROVIMENTO

00055- 00010435/2023-40 ITALO PATRICK OLIVEIRA COSTA KK00036084 NEGAR PROVIMENTO

00055- 00010436/2023-94 ITALO PATRICK OLIVEIRA COSTA KK00102867 NEGAR PROVIMENTO

00055- 00010440/2023-52 ITALO PATRICK OLIVEIRA COSTA KK00112513 NEGAR PROVIMENTO

00055- 00010442/2023-41 ITALO PATRICK OLIVEIRA COSTA KK00105125 NEGAR PROVIMENTO

00055- 00010443/2023-96 ITALO PATRICK OLIVEIRA COSTA KK00039886 DILIGÊNCIA

00055- 00010445/2023-85 ITALO PATRICK OLIVEIRA COSTA KK00074885 DILIGÊNCIA

00055- 00010446/2023-20 ITALO PATRICK OLIVEIRA COSTA KK00105210 DILIGÊNCIA

00055- 00010448/2023-19 ITALO PATRICK OLIVEIRA COSTA KK00040292 DILIGÊNCIA

00055- 00010456/2023-65 ITALO PATRICK OLIVEIRA COSTA KK00125451 NÃO CONHECER

00055- 00010457/2023-18 ITALO PATRICK OLIVEIRA COSTA KK00117193 NEGAR PROVIMENTO

00055- 00010458/2023-54 ITALO PATRICK OLIVEIRA COSTA KK00112691 DILIGÊNCIA

00055- 00010460/2023-23 ITALO PATRICK OLIVEIRA COSTA KK00108396 DILIGÊNCIA

0055-021266/2017 ITAMAR BARBOSA GARCEZ SA01416931 DILIGÊNCIA

00055- 00073477/2019-13 JACINTO DO EGITO SILVA SA01661815 NEGAR PROVIMENTO

00113- 00006097/2024-81 JAILTON PEREIRA LOPES YE02286236 NEGAR PROVIMENTO

00055- 00080199/2019-42 JAIRO DE AGUIAR NUNES S002988677 NEGAR PROVIMENTO

00055- 00003591/2019-78 JANAINA SANTOS RIBEIRO S002940337 NEGAR PROVIMENTO

<!-- pagina 18 -->

00113- 00011186/2023-69 JARBAS MARTINS SILVEIRA GE01269736 NÃO CONHECER

00113- 00005571/2023-77 JESSYCA ALVES DE SOUZA SILVA YE02084025 NEGAR PROVIMENTO

00055- 00028268/2019-15 JESUS SOARES COELHO S002985845 NEGAR PROVIMENTO

00055- 00147392/2018-90 JOÃO CARLOS COSTA SANTOS JUNIOR S002884518 NÃO CONHECER

00113- 00010699/2025-14 JOÃO CLAUDIO PEREIRA GE01357629 NÃO CONHECER

00055- 00024228/2023-72

JOÃO MATEUS CORDEIRO ESTRELA DE ANDRADE PINTO FT00439906 DILIGÊNCIA

00055- 00024229/2023-17

JOÃO MATEUS CORDEIRO ESTRELA DE ANDRADE PINTO FT00495215 DILIGÊNCIA

00055- 00024230/2023-41

JOÃO MATEUS CORDEIRO ESTRELA DE ANDRADE PINTO FT00513937 DILIGÊNCIA

00055- 00024232/2023-31

JOÃO MATEUS CORDEIRO ESTRELA DE ANDRADE PINTO CC00050222 DILIGÊNCIA

00113- 00004488/2024-61 JOÃO PAULO BIAGE TEIXEIRA YE02285129 NEGAR PROVIMENTO

00055- 00032760/2019-87 JOAQUIM DOS SANTOS S003030899 NEGAR PROVIMENTO

00055- 00014866/2024-66 JONATHAN SAMPAIO SOUZA SA03579632 NEGAR PROVIMENTO

00055- 00036709/2019-44 JOSAFA CARNEIRO DAS NEVES S002452998 NEGAR PROVIMENTO

00113- 00006910/2023-32 JOSE MARIA DE AGUIAR FILHO CJ03218301 NÃO CONHECER

00113- 00011739/2022-01

KAIO RODRIGUES DE MOURA RODRIGUES FIGUEIREDO CJ01071940 NÃO CONHECER

00055- 00042317/2022-10 KENNEDY SAMPAIO GOMES DE MORAIS SA03050421 NÃO CONHECER

00055- 00095603/2022-88 KLEBER MELO E SILVA SA03280472 NEGAR PROVIMENTO

00055- 00029511/2023-91 LARISSA REGIS VIEIRA SA03272292 DILIGÊNCIA

00055- 00074257/2021-13 LINDOMAR ROCHA DA SILVA CP01193083 DILIGÊNCIA

0055-006749/2010 LIVIA COUTAS DE OLIVEIRA ASSIS S000836099 NEGAR PROVIMENTO

00113- 00004028/2023-52 LOCALIZA RENT A CAR S.A. CJ02901668 DILIGÊNCIA

00055- 00090247/2022-14 LUCAS RODRIGUES DE SOUSA CARVALHO FT00449104 NEGAR PROVIMENTO

00055- 00021558/2023-14 LUCIANA PESSOA RAMOS S003629827 NEGAR PROVIMENTO

00055- 00127177/2023-30 LUIZ CARLOS HELENA PONTUAL MACHADO SA03549335 NÃO CONHECER

00055- 00037278/2023-10 LUIZ FELIPE MENDES SILVA SA03454488 NEGAR PROVIMENTO

00055- 00127083/2023-61 LUIZ IGOR LIMA DE SOUZA SA03556286 NEGAR PROVIMENTO

00055- 00023716/2019-86 LUIZA MOREIRA MALLMANN SA01851261 NEGAR PROVIMENTO

00055- 00033051/2023-03 MARCELA FAVARINI NUNES SA03169899 NÃO CONHECER

00113- 00011285/2023-41

DEPARTAMENTO DE ESTRADA DE RODAGEM DF FC00290962 NEGAR PROVIMENTO

00055- 00021189/2023-51 MARCO ANTONIO MENEZES DE OLIVEIRA SA03462099 NEGAR PROVIMENTO

00055- 00041114/2023-97

MARCO TÚLIO DE CARVALHO CANDIDO DE PAULA S003109708 DILIGÊNCIA

00055- 00027275/2022-97 MARCOS AURELIO DE JESUS S003361349 NEGAR PROVIMENTO

00113- 00026424/2024-11 MARCOS DANIEL PEREIRA DO O YE02360639 NEGAR PROVIMENTO

00113- 00006287/2020-75 MARCOS JOSÉ DE CASTRO Y001521166 NÃO CONHECER

00055- 00103223/2023-13 MARGARIDA CHRISTINA DE AQUINO FT00615740 RESTITUÍDO

00055- 00096290/2021-02

MARIA ALICE GOMES E PAMELA FLAVIA PEREIRA TRIGUEIRO SILVA CP01050124 DAR PROVIMENTO

00055- 00030060/2022-53 MARIANA URBANO SAMARTINI COELHO SA02700057 NÃO CONHECER

00055- 00030753/2023-27 MARLUCE SAMPAIO DUARTE FT00499181 NÃO CONHECER

00113- 00015843/2023-47 MAURICIO RIBEIRO DE OLIVEIRA YE02123884 NEGAR PROVIMENTO

00055- 00074952/2023-47 MAYKE DA SILVA GONÇALVES S003513366 NEGAR PROVIMENTO

00113- 00017362/2023-76

MELISSA BEVILAQUA SAMPAIO CONTREIRAS YE02198527 NEGAR PROVIMENTO

00055- 00059809/2023-25 MIRYAN RODRIGUES BARBOSA DE SOUZA SA03402222 NEGAR PROVIMENTO

00055- 00096679/2024-92 MISLENE ALVES DOS REIS SALES SA04121755 NEGAR PROVIMENTO

00055- 00164028/2018-94 NAIARA CREAO DA COSTA S003528361 NEGAR PROVIMENTO

00113- 00014898/2022-59 NATAN BRANDAO BERNARDES MUNIZ YE01886015 NEGAR PROVIMENTO

00055- 00002796/2022-31 DEPARTAMENTO DE TRÂNSITO DO DF SA02692933 DAR PROVIMENTO

00055- 00104073/2022-76 NERISVAN NOVAIS DE ALCANTARA S003490408 NÃO CONHECER

00055- 00031179/2022-43 NIADIAN GOMES GONCALVES SA02855653 NEGAR PROVIMENTO

00055- 00089268/2023-60 NIVEA BRITO DA SILVA KK00334876 NEGAR PROVIMENTO

00055- 00089272/2023-28 NIVEA BRITO DA SILVA KK00317896 NEGAR PROVIMENTO

00055- 00065747/2022-18 NUBIA BATISTA DE SOUZA SA02721369 NEGAR PROVIMENTO

00055- 00006404/2019-16 OSCAR FERREIRA SILVA S002328728 NEGAR PROVIMENTO

00055- 00006547/2023-04 OSEIAS DE ANDRADE KK00193760 NEGAR PROVIMENTO

00055- 00052034/2022-86 PABLO ARNALDO SEIXO COSTA S003437901 DAR PROVIMENTO

00113- 00011738/2022-58

PAULO REGIS DE ALMEIDA E THALISSON SOUSA TRAJANO CJ01047036 NÃO CONHECER

00113- 00011740/2022-27

PAULO REGIS DE ALMEIDA E THALISSON SOUSA TRAJANO CJ01082532 NÃO CONHECER

00113- 00004084/2024-78 PEDRO HENRIQUE DE MORAES CICERO YE02199223 NEGAR PROVIMENTO

00055- 00037036/2019-40 PEDRO SOUZA SANTOS S003174939 NÃO CONHECER

00113- 00005690/2019-43 PETRUCIO MONTEIRO SILVA Y001477670 NEGAR PROVIMENTO

00055- 00048849/2021-80 RAFAEL DE CARVALHO PANIAGO SA02563152 DAR PROVIMENTO

00113- 00010522/2023-56 RAFAEL FERREIRA SILVA YE02129076 NEGAR PROVIMENTO

00055- 00071056/2023-26 RAIBATAN FELIPE GONÇALVES NEIVA SA03240925 NÃO CONHECER

00055- 00145169/2018-16 RAIMUNDO SOUZA DOS SANTOS SA01704946 NÃO CONHECER

00055- 00029002/2023-68 RICKSON FELIPE ALVES CORREIA S003263557 NEGAR PROVIMENTO

00055- 00070828/2019-26 ROBERTO CHAVES ROSA SA01954296 NEGAR PROVIMENTO

00055- 00016052/2019-07 ROBERTO JOSÉ DE ARAÚJO JÚNIOR ST01322431 NEGAR PROVIMENTO

00113- 00005323/2023-26

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE02084158 NEGAR PROVIMENTO

00055- 00052348/2023-60 RUAN VINICIUS BORGES PEREIRA KK00037305 NÃO CONHECER

00055- 00052755/2023-77 RUAN VINICIUS BORGES PEREIRA KK00045052 NEGAR PROVIMENTO

00055- 00052757/2023-66 RUAN VINICIUS BORGES PEREIRA KK00029240 NEGAR PROVIMENTO

00055- 00052759/2023-55 RUAN VINICIUS BORGES PEREIRA KK00033387 NÃO CONHECER

00055- 00052763/2023-13 RUAN VINICIUS BORGES PEREIRA KK00101198 NEGAR PROVIMENTO

00055- 00052766/2023-57 RUAN VINICIUS BORGES PEREIRA KK00052482 NEGAR PROVIMENTO

00055- 00052767/2023-00 RUAN VINICIUS BORGES PEREIRA KK00095573 NEGAR PROVIMENTO

00055- 00052771/2023-60 RUAN VINICIUS BORGES PEREIRA KK00052469 NÃO CONHECER

<!-- pagina 19 -->

00055- 00052772/2023-12 RUAN VINICIUS BORGES PEREIRA KK00033563 NEGAR PROVIMENTO

00055- 00052775/2023-48 RUAN VINICIUS BORGES PEREIRA KK00015630 NEGAR PROVIMENTO

00055- 00052776/2023-92 RUAN VINICIUS BORGES PEREIRA KK00027100 NEGAR PROVIMENTO

00055- 00052951/2023-41 RUAN VINICIUS BORGES PEREIRA KK00022161 NEGAR PROVIMENTO

0055-019068/2015 SANDRO DUARTE DE OLIVEIRA SUSPENSÃO CNH

NEGAR PROVIMENTO

00055- 00017754/2023-86 SEBASTIAO ERINEU DE MOURA SA03394528 DAR PROVIMENTO

00055- 00064085/2022-51

SERAFIM JONNATHAN RODRIGUES MEDEIROS S003393930 NEGAR PROVIMENTO

00113- 00010292/2023-25

SERGIO LEONARDO M. DE BRAGANÇA SAAD YE02166595 NÃO CONHECER

00113- 00003965/2024-71

SILVIO ALVES DE ARAUJO E SITRATTER-DF FC00488932 DAR PROVIMENTO

00055- 00084426/2022-12 DEPARTAMENTO DE TRÂNSITO DO DF SA03171820 DAR PROVIMENTO

00055- 00054775/2023-82 STELA DALVA ABRITTA SA03164488 NEGAR PROVIMENTO

00113- 00009055/2023-11 THAIZ DOS SANTOS BRITO YE02140927 NEGAR PROVIMENTO

00113- 00000484/2024-12 THALISSON MENESES PASSOS YE02247329 NEGAR PROVIMENTO

00055- 00049936/2022-35 THAYNA MARQUES DE LIMA SA03124258 NEGAR PROVIMENTO

00113- 00014331/2022-82

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01840068 DAR PROVIMENTO

00113- 00014335/2022-61

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01619003 DAR PROVIMENTO

00113- 00014336/2022-13

DEPARTAMENTO DE ESTRADA DE RODAGEM DF YE01619004 DAR PROVIMENTO

00113- 00021616/2024-31 TIAGO MATIAS LINO Y001459665 NEGAR PROVIMENTO

0055-004695/2018 VANIA MARIA DE LIMA BARBOSA SA03386385 NÃO CONHECER

00113- 00001630/2023-38 VIRGILIO REIS SARMENTO SA03392044 NEGAR PROVIMENTO

00113- 00015915/2023-56 WADYR OLINTO MELO CHAIB SA04283307 NEGAR PROVIMENTO

00113- 00033067/2019-81 WESLEY COSTA PEREIRA Y001521206 NÃO CONHECER

7. Deliberações 7.1. Conforme item 3.2, deliberou-se pela participação institucional do CONTRANDIFE na elaboração do protocolo sobre atendimento a sinistros de trânsito no DF. 7.2. Conforme item 7, procederam-se aos julgamentos de processos administrativos, com decisões de provimento, não provimento e diligência. 8. Encerramento 8.1.Nada mais havendo a tratar, o Presidente declarou encerrada a reunião. 8.2. Eu, FRANCISCO OLIVEIRA MELO, Secretário Administrativo do Conselho de Trânsito do Distrito Federal – CONTRANDIFE, lavrei a presente Ata, com base na gravação e transcrição integral da reunião realizada por videoconferência, que, após lida e aprovada, será juntada aos autos e publicada no Diário Oficial do Distrito Federal.

THIAGO GOMES NASCIMENTO

Presidente do CONTRANDIFE

### POLÍCIA MILITAR DO DISTRITO FEDERAL DEPARTAMENTO DE SAÚDE E ASSISTÊNCIA AO PESSOAL

EXTRATO DE DECISÃO Após assegurado o direito à ampla defesa e ao contraditório, e, exaurida a fase recursal no Processo SEI nº 00054-00120141/2025-15 ficou caracterizada a infração contratual no descumprimento do item 11.2.1.4. e 11.2.1.6 do Edital de Credenciamento Nº 01/2024, pela empresa credenciada ASSOCIAÇÃO DOS MÉDICOS DE HOSPITAIS PRIVADOS DO DF (Nome Fantasia: AMHРDF), CNPJ: 00.735.860/0001-73.

Nos exatos motivos da Decisão 24 (196650524) e Decisão 43 (203928916), pela referida infração contratual apurada no Processo SEI nº 00054-00120141/2025-15, APLICO a sanção de MULTA nos termos da lei (art. 156, inciso II, § 1º e § 3º, da Lei nº 14.133, de 1º de abril de 2021.) e FIXO o percentual de 0,5% (cinco décimos por cento) sobre os valores pagos à empresa ASSOCIAÇÃO DOS MÉDICOS DE HOSPITAIS PRIVADOS DO DF (Nome Fantasia: AMHРDF), CNPJ: 00.735.860/0001-73 realizados no exercício financeiro

de 2024 (época da ocorrência do descumprimento contratual), referentes ao Edital de Credenciamento Nº 1/2024 - DSAP/PMDF (181320467). Desta forma, fica cominado o valor aplicado à sanção de R$ 41.949,46 (quarenta e um mil novecentos e quarenta e nove reais e quarenta e seis centavos) a empresa contratada ASSOCIAÇÃO

DOS MÉDICOS DE HOSPITAIS PRIVADOS DO DF (Nome Fantasia: AMHРDF),

CNPJ: 00.735.860/0001-73 pela quebra contratual. Ao Diretor da DPGC/DSAP para: adotar as providências em efetivar a decisão na gestão e execução do contrato. Publique-se DODF.

SINESIO SILVA SOUZA - CEL QOPM

Chefe

### DEPARTAMENTO DE TRÂNSITO

INSTRUÇÃO Nº 201, DE 08 DE JUNHO DE 2026 O DIRETOR-GERAL DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso da atribuição que lhe confere os incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto n° 27.784, de 16 de março de 2007, resolve:

TÍTULO I DAS DISPOSIÇÕES GERAIS Art. 1º Esta Instrução estabelece os procedimentos e normas internas para a comprovação anual da compatibilidade de horários entre os vínculos, obrigatória aos servidores que acumulam licitamente cargos públicos, nos termos do § 3º do Art. 46 da Lei Complementar nº 840/2011, devendo ser efetuada no prazo de 30 (trinta) dias corridos, após o início de cada ano. Art. 2º O servidor que acumular licitamente cargo público fica obrigado a comprovar anualmente, em processo único, a compatibilidade de horários conforme os procedimentos abaixo: I - iniciar, ou reabrir no caso de quem já possui processo de acumulação, processo do tipo Pessoal: Acumulação de Cargos no Sistema Eletrônico de Informações (SEI); II - criar o documento, utilizando o modelo Declaração Anual de Acúmulo, de Cargos, disponibilizado em formato digital no Sistema Eletrônico de Informações (SEI), preencher e assinar. Parágrafo único. Caso o servidor público tenha sua escala de trabalho alterada no decorrer do ano, em quaisquer dos órgãos que tenha vínculo, deverá apresentar novas Declarações para comprovar a compatibilidade. Art. 3º Para os efeitos dos Arts. 1º e 2º, da Lei Complementar nº 840, de 23 de dezembro de 2011, servidor público é a pessoa legalmente investida em cargo público e o cargo público é conjunto de atribuições e responsabilidades previstas na estrutura organizacional e acometidas a um servidor público. § 1º Em consonância ao Art. 46, da Lei Complementar nº 840, de 23 de dezembro de 2011, é proibida a acumulação remunerada de cargos públicos, exceto quando houver compatibilidade de horários para: I - dois cargos de professor; II - a de um cargo de professor com outro de qualquer natureza, em consonância Art. 37, inciso XVI, alínea b) - (Redação dada pela Emenda Constitucional nº 138, de 2025); III - dois cargos ou empregos privativos de profissionais de saúde, com profissões regulamentadas. § 2º A Comissão Permanente de Acumulação de Cargos (CPAC) para análise, administração e emissão de pareceres em processos de acumulação de cargos em que incidem os servidores públicos do Detran/DF foi instituída pela INSTRUÇÃO Nº 943, DE 16 DE DEZEMBRO DE 2025 da Diretoria de Administração Geral do Departamento de Trânsito do Distrito Federal. Art. 4º As dúvidas e os casos omissos na aplicação das Normas Internas serão dirimidos pela Gerência de Gestão de Pessoas em conjunto com a Comissão Permanente de Acumulação de Cargos (Detran/DF) do Detran/DF.

TÍTULO II DA ACUMULAÇÃO LÍCITA DE CARGOS PÚBLICOS NO DEPARTAMENTO

DE TRÂNSITO DO DISTRITO FEDERAL

CAPÍTULO I DAS DISPOSIÇÕES PRELIMINARES Art. 5º. A comprovação da compatibilidade de horários de que trata esta Instrução será efetuada por meio de Declarações Anuais de Acúmulo de Cargos atualizadas dos 02 (dois) vínculos e/ou matrículas, digitalizadas ou criadas de forma que seja permitida a consulta de seus conteúdos de maneira clara, objetiva e devidamente autenticadas por servidor público, por meio do Sistema Eletrônico de Informações (SEI), constando, de forma inequívoca, os seguintes dados: I - cargo ocupado e, se for o caso, especialidade; II - carga horária e jornada de trabalho; III - horário de entrada e saída de cada jornada de trabalho. § 1º As Declarações Anuais de Acúmulo, de Cargos de que tratam o caput, referentes aos 02 (dois) vínculos, devem estar datadas e subscritas, com identificação legível, admitindose assinatura eletrônica ou digital, pela chefia imediata e/ou responsável pela unidade de gestão de pessoas, que solidariamente se responsabilizam pela veracidade das informações prestadas/declaradas.

CAPÍTULO II DA POSSE COM ACÚMULO DE CARGOS Art. 6º No ano em que for admitido, o servidor público que for acumular cargo com outro Órgão deverá iniciar processo no Sistema Eletrônico de Informações (SEI) e preencher a Declaração Anual de Acúmulo, de Cargos e remeter à Comissão Permanente de Acumulação de Cargos (CPAC) até 30 (trinta) dias corridos após entrar em exercício. Art. 7º Ao ingressar em novo vínculo público, o servidor público deverá incluir a Declaração Anual de Acúmulo, de Cargos, atualizada, em no máximo 30 (trinta) dias

<!-- pagina 20 -->

corridos após a entrada em exercício, salvo quando o servidor público entrar em afastamento legal por período superior a 30 (trinta) dias, que deverá ser incluída imediatamente após o retorno no Sistema Eletrônico de Informações (SEI). Art. 8º Caso o servidor público acumule cargo em outro órgão público, deverá ser inserido no Processo SEI a “Declaração Funcional / Ficha Cadastral” (Pessoal: Emissão de Certidões e Declarações) do outro vínculo, devidamente emitida pela unidade de gestão de pessoas do outro órgão, contendo os dados pessoais e funcionais do servidor público: I - matrícula; II - nome completo do servidor público; III - número do CPF; IV - número de identidade; V - data de nascimento; VI - endereço residencial; VII - naturalidade; VIII - estado civil; IX - cargo origem; X - lotação; XI - endereço da lotação; XII - cargo em comissão, caso houver; XIII - data exercício / admissão; XIV - situação funcional; XV - horas base semanal (carga horária semanal); XVI - horário de entrada e saída; XVII - status; XVIII - classe-padrão / referência. Art. 9º Na hipótese de acumulação lícita de cargos, o Estágio Probatório é cumprido em relação a cada cargo em cujo exercício esteja o servidor público, vedado o aproveitamento de prazo ou pontuação, conforme Art. 23, da Lei Complementar nº 840, de 23 de dezembro de 2011.

CAPÍTULO III DO SERVIDOR PÚBLICO ATIVO QUE ACUMULA CARGOS Art. 10. Caberá, obrigatoriamente, ao servidor público ativo que acumular cargos: I - fazer constar, mensalmente, no Processo de Acumulação de Cargos, criado no Sistema Eletrônico de Informações (SEI), as Folhas de Frequência do Órgão diverso a esta Autarquia, autenticadas eletronicamente pela Unidade responsável pelo controle de frequência, exceto frequência emitida por meio de ponto eletrônico, assinadas pelo próprio servidor público e pela respectiva chefia imediata, contendo a matrícula e o cargo desta, conforme o inciso I, do art. 2º desta Instrução; II - preencher e assinar a Declaração de Acumulação de Cargos e Proventos, pelo modelo disponibilizado no Sistema Eletrônico de Informações (SEI), além de inserir os documentos que comprovam o cumprimento da jornada de trabalho nos dois vínculos, conforme Art. 8º e incisos, desta Instrução. Parágrafo único. O prazo para envio à CPAC é até o dia 15 do mês subsequente, prorrogável para o próximo dia útil caso a data recaia em final de semana ou feriado. Art. 11. Toda e qualquer análise sobre acumulação de cargos, bem como as comunicações com o(a) servidor(a) público(a) interessado(a), devem ser realizadas no respectivo Processo que trata da análise de Acumulação de Cargos. Parágrafo único. Todas as solicitações do servidor público a respeito de sua Acumulação de Cargos deverão ser realizadas no referido Processo, onde também serão analisadas e devidamente respondidas. Art. 12. Os Processos abertos e os já existentes, mediante anexação das Declarações Anuais de Acúmulo de Cargos previstas no Art. 1º, desta Instrução, devem ser enviados à CPAC, por meio do Sistema Eletrônico de Informações (SEI). Art. 13. Aos servidores públicos responsáveis pelo cumprimento e operacionalização destas normas, caso não sejam cumpridas, serão aplicadas, no que couber, as sanções disciplinares previstas na Lei Complementar nº 840, de 23 de dezembro de 2011. Parágrafo único. Havendo incompatibilidade de horários entre os vínculos, o servidor público deverá, imediatamente, providenciar a adequação das jornadas de trabalho, de acordo com a legislação vigente, sob pena de ser considerada ilícita a acumulação de cargos.

CAPÍTULO IV DA COMPATIBILIDADE DE HORÁRIO E DESLOCAMENTO Art. 14. São consideradas compatíveis, para a análise objeto desta instrução, as jornadas de trabalho que apresentem, no mínimo, o tempo de deslocamento entre um vínculo e outro, conforme tempo estipulado pela ferramenta virtual Google Maps ou similar, comprovadas anualmente. Art. 15. O servidor público que acumular licitamente dois cargos efetivos deverá cumprir a jornada de trabalho respectiva a cada cargo. Art. 16. O servidor público que acumula licitamente dois cargos efetivos, quando nomeado para um cargo comissionado, deverá respeitar o contido nos §§1º a 4º do art. 156, da Lei Complementar nº 840, de 23 de dezembro de 2011. Art. 17. O servidor público que exerce dois cargos públicos somente poderá ser empossado no cargo em comissão após o exercício dos cargos efetivos terem sido considerados lícitos.

CAPÍTULO V DOS CARGOS EM COMISSÃO Art. 18. Nos termos do art. 156, da Lei Complementar nº 840, de 23 de dezembro de 2011, a investidura em cargo em comissão de servidor público ocupante de 02 (dois) cargos efetivos, acumuláveis na forma da Constituição Federal, será sujeita ao

afastamento dos cargos efetivos, com a suspensão das correspondentes remunerações, observadas, contudo, estas outras possibilidades: § 1º Ao servidor público será facultado optar pela remuneração integral do cargo em comissão ou pela remuneração do referido cargo efetivo, acrescida de 80% (oitenta por cento) dos vencimentos ou subsídio do cargo em comissão por ele exercido, salvo disposição legal em contrário; § 2º Caso haja compatibilidade de horários, ao servidor público optante pela remuneração do referido cargo efetivo, nos termos da proposição anterior, será permitida a acumulação da remuneração do outro cargo efetivo, que continuará sendo exercido, respeitada a natureza de “acumulatividade” das funções do cargo em comissão com esse cargo efetivo, na forma estatuída na Constituição Federal; § 3º Também será permitida a acumulação da remuneração dos 02 (dois) cargos efetivos, mesmo sem a contraprestação do serviço, desde que a soma das horas de trabalho dos cargos em regime de acumulação lícita não supere 44 (quarenta e quatro) horas semanais e não tenha o servidor público feito a opção pelo valor integral do cargo em comissão. Art. 19. O servidor público ocupante de cargo efetivo, quando nomeado para cargo em comissão, faz jus à percepção de seu vencimento básico calculado com base na carga horária de 40 (quarenta) horas semanais, somente em relação ao cargo efetivo ao qual estiver atrelado o cargo em comissão. Art. 20. O servidor público quando exonerado do cargo comissionado deverá retornar às funções dos cargos ou cargo do qual se encontra afastado, imediatamente. Art. 21. O servidor público investido em cargo efetivo e cargo comissionado deverá exercer as atribuições inerentes ao cargo para o qual foi nomeado. Parágrafo único. Se constatado o exercício de atribuições divergentes ao cargo para o qual o servidor público foi nomeado, a chefia imediata será responsabilizada administrativamente por meio do devido Procedimento Administrativo Disciplinar.

CAPÍTULO VI DO SETORIAL DE GESTÃO DE PESSOAS DO DETRAN/DF Art. 22. Quanto aos Processos de Acumulação de Cargos, caberá ao Núcleo de Registro Funcional - Nuref, do Detran/DF: I - disponibilizar as folhas de frequência conferidas dos servidores que acumulam cargo à Comissão Permanente de Acumulação de Cargos - CPAC, mediante solicitação da Comissão; II - efetuar o acompanhamento e controle das folhas de frequência que contenham inconsistências de registro.

CAPÍTULO VII DAS CHEFIAS IMEDIATAS Art. 23. Caberá às chefias imediatas: I - monitorar o correto preenchimento das Folhas de Frequência dos servidores públicos que acumulam cargos, de acordo com a legislação vigente; II - informar ao Núcleo de Registro Funcional do Detran/DF de correção efetuada na Folha de Frequência, quando identificada inconsistência, fazendo constar no despacho de encaminhamento o fato de se tratar de servidor que acumula cargos; III - tomar ciência, junto ao servidor público e ao setorial de gestão de pessoas do Detran/DF, das notificações emitidas pela Comissão Permanente de Acumulação de Cargos (CPAC), em relação ao cumprimento desta Instrução; IV - solicitar ao Núcleo de Registro Funcional - Nuref, o ajuste na Folha de Frequência do servidor público imediatamente após a notificação pela Comissão Permanente de Acumulação de Cargos (CPAC). Parágrafo único. O acompanhamento e controle da situação funcional será de responsabilidade da chefia imediata e do Núcleo de Registro Funcional do Detran/DF.

CAPÍTULO VIII DO SERVIDOR PÚBLICO CEDIDO QUE ACUMULA CARGOS Art. 24. Caberá ao servidor público cedido que acumula cargos e não possui acesso ao Sistema Eletrônico de Informações (SEI) enviar ao setorial de gestão de pessoas, do respectivo órgão, as Folhas de Frequência, referente às 02 (duas) matrículas assinadas pelo servidor público e respectivas chefias imediatas. O prazo para envio à CPAC é até o dia 15 do mês subsequente, prorrogável para o próximo dia útil caso a data recaia em final de semana ou feriado. § 1º O servidor público que estiver cedido a outro órgão e que possua acesso ao Sistema Eletrônico de Informações (SEI), deverá proceder a abertura do Processo, e inclusão da Declaração de Acumulação de Cargos, e das Folhas de Frequência dos 02 (dois) vínculos devidamente preenchidos pelo servidor público, e assinadas pelas respectivas chefias imediatas. § 2º As Declarações de que trata o § 1º devem estar datadas, subscritas e autenticadas, com identificação legível, pelo responsável da unidade de gestão de pessoas do órgão ou entidade, que solidariamente se responsabilizam pela veracidade das informações prestadas/declaradas. § 3º A documentação mencionada nos §§ 1º e 2º poderá ser digitalizada de forma que seja permitida a consulta de seu conteúdo de maneira clara e objetiva e devidamente autenticada por servidor público, por meio do Sistema Eletrônico de Informações - SEI.

CAPÍTULO IX DOS AFASTAMENTOS Art. 25. O processo de autorização do afastamento de cargo baseado no Art. 156, da Lei Complementar nº 840, de 23 de dezembro de 2011, e na Decisão do TCDF nº 462, de 21 de fevereiro de 2014, deverá ser previamente instruído com a análise de compatibilidade horária e comprovação da licitude da acumulação. § 1º A formalização do afastamento do cargo se dará a partir da sua publicação. § 2º Preenchidos os requisitos necessários para a autorização, o processo deverá ser submetido à autoridade competente para determinação do afastamento, surtindo seus efeitos após publicação.

<!-- pagina 21 -->

§ 3º Concluídas todas as fases para autorização do afastamento de cargos, deverá ser providenciada a análise de compatibilidade de horários entre o cargo efetivo e o cargo em comissão, caso o servidor público opte por vincular o cargo comissionado a um cargo efetivo e exercer as atividades do outro cargo.

CAPÍTULO X DAS PROIBIÇÕES Art. 26. Conforme o § 2º do Art. 46 da Lei Complementar nº 840, de 23 de dezembro de 2011, a proibição de acumular estende-se: I - a empregos e funções, e abrange autarquias, fundações, empresas públicas, sociedades de economia mista, suas subsidiárias e sociedades controladas direta ou indiretamente pelo poder público; II - aos proventos de aposentadoria pagos por regime próprio de previdência social do Distrito Federal, da União, de Estado ou Município, ressalvados os proventos decorrentes de cargo acumulável na forma deste artigo. Art. 27. Ressalvados os casos de interinidade e substituição, o servidor público não pode: I - exercer mais de um cargo em comissão ou função de confiança; II - acumular cargo em comissão com função de confiança. Art. 28. Nos termos do Art. 48, da Lei Complementar nº 840, de 23 de dezembro de 2011, verificada, a qualquer tempo, a acumulação ilegal de cargos, empregos, funções públicas ou proventos de aposentadoria, o servidor público deve ser notificado para apresentar opção no prazo improrrogável de 10 (dez) dias, contados da data da ciência da notificação. § 1º Em decorrência da opção, o servidor público deve ser exonerado do cargo, emprego ou função por que não mais tenha interesse. § 2º Com a opção pela renúncia aos proventos de aposentadoria, o seu pagamento cessa imediatamente. § 3º Se o servidor público não fizer a opção no prazo deste artigo, o setorial de gestão de pessoas da repartição deve solicitar à autoridade competente a instauração de Processo Disciplinar para apuração e regularização imediata. § 4º Instaurado o Processo Disciplinar, se o servidor público, até o último dia de prazo para defesa escrita, fizer a opção de que trata este artigo, o processo deve ser arquivado, sem julgamento do mérito. § 5º O disposto no § 4º não se aplica se houver Declaração falsa feita pelo servidor público sobre acumulação de cargos. § 6º Caracterizada no Processo Disciplinar a acumulação ilegal, a administração pública deve observar o seguinte: I - reconhecida a boa-fé, exonerar o servidor público do cargo vinculado ao órgão, autarquia ou fundação onde o processo foi instaurado; II - provada a má-fé, aplicar a sanção de demissão, destituição ou cassação de aposentadoria ou disponibilidade em relação aos cargos ou empregos em regime de acumulação ilegal, hipótese em que os órgãos ou entidades de vinculação devem ser comunicados. Art. 29. De acordo com o Art. 49, da Lei Complementar nº 840, de 23 de dezembro de 2011, é vedada a participação de servidor público, salvo na condição de Secretário de Estado, ainda que suplente, em mais de um conselho, comissão, comitê, órgão de deliberação coletiva ou assemelhado, na administração direta, autárquica ou fundacional do Distrito Federal. § 1º É vedada a remuneração pela participação em mais de um conselho. § 2º É permitida, observado o disposto no § 1º, a participação remunerada de servidor público em conselho de administração ou conselho fiscal de empresa pública ou sociedade de economia mista em que o Distrito Federal detenha, direta ou indiretamente, participação no capital social.

CAPÍTULO XI DA ANÁLISE DOS PROCESSOS Art. 30. Cabe à Comissão Permanente de Acumulação de Cargos (CPAC) do Detran/DF concluir, em primeira instância, sobre a legalidade da acumulação de cargos dos servidores públicos. Art. 30-A. A Comissão Permanente de Acumulação de Cargos (CPAC) terá o prazo de 30 (trinta) dias úteis, contados a partir do recebimento do processo devidamente instruído e com toda a documentação comprobatória necessária, para emitir o Despacho mensal deferindo ou indeferindo a acumulação daquele mês de que se trata. Art. 30-B. A Comissão Permanente de Acumulação de Cargos (CPAC) terá o prazo de 30 (trinta) dias úteis, contados a partir da emissão do último Despacho mensal para emitir o Parecer conclusivo de que trata o Art. 32. § 1º Caso as Folhas de Frequência, diligências e demais documentos estejam em acordo com a legislação em vigor e com as normas do Detran/DF, em especial esta Instrução, a conclusão será pela compatibilidade de horários entre os vínculos. § 2º Caso as jornadas de trabalho, diligências e demais documentos estejam em desacordo com a legislação em vigor e com as normas do Detran/DF, em especial esta Instrução, a conclusão será pela incompatibilidade de horários entre os vínculos. Art. 30-C A Comissão Permanente de Acumulação de Cargos (CPAC) fará a análise de compatibilidade mensalmente a partir das folhas de frequência, emitindo um Despacho referente a cada mês onde atestará a compatibilidade ou não. Art. 31. Após a decisão, será anexado Parecer conclusivo no processo do(a) respectivo(a) servidor(a) público(a), que deve tomar ciência do mesmo. Art. 32. A Comissão Permanente de Acumulação de Cargos (CPAC) encaminhará o Quadro de Compatibilidade Anual à Gerência de Gestão de Pessoas - Gerpes para conhecimento.

CAPÍTULO XII DO PARECER CONCLUSIVO Art. 33. Os pareceres conclusivos da Comissão Permanente de Acumulação de Cargos (CPAC) do Detran/DF podem ter 03 (três) conclusões: I - compatibilidade de horários total, quando as jornadas atenderem a todos os requisitos expostos na presente Instrução, ou quando o forem aceitas as justificativas do servidor público; II - compatibilidade de horários parcial, quando forem verificados não cumprimentos, especialmente os recorrentes, dos requisitos nesta Instrução, mas que possam ser corrigidos, com ou sem necessidade de reposição ao erário; III - incompatibilidade de horários, quando for verificado que as escalas não podem ser combinadas de forma a atender os requisitos desta Instrução. § 1º No caso do Inciso II, a Comissão Permanente de Acumulação de Cargos (CPAC) solicitará diligências do servidor público para adequar, junto às suas chefias, suas escalas aos requisitos desta Portaria. § 2º No caso do Inciso II de forma recorrente, ou da ocorrência do Inciso III, a Comissão Permanente de Acumulação de Cargos (CPAC) enviará os pareceres conclusivos para conhecimento da autoridade máxima do órgão. § 3º Ainda no caso dos Incisos II e III, o parecer conclusivo poderá recomendar instauração de Processo Administrativo Disciplinar por Comissão Disciplinar, a fim de identificar possíveis infrações de servidor público e/ou danos ao erário. § 4º Considera-se recorrente o descumprimento sanável dos requisitos desta Instrução em 03 (três) ocorrências ou mais no intervalo de 03 (três) meses, referentes aos parágrafos anteriores.

CAPÍTULO XIII DA RECONSIDERAÇÃO Art. 34. O servidor público pode requerer reconsideração da conclusão da Comissão Permanente de Acumulação de Cargos (CPAC), no prazo máximo de 10 (dez) dias, a contar da ciência da mesma. Parágrafo único. O requerimento de reconsideração será analisado na reunião da Comissão Permanente de Acumulação de Cargos (CPAC) convocada especialmente para este fim. Art. 35. Após a análise do pedido de reconsideração, o servidor público pode, ainda, requerer reconsideração junto ao dirigente máximo do Detran/DF, em caráter de recurso. Parágrafo único. A decisão do dirigente máximo será definitiva e final, não cabendo mais requerimentos de recursos na esfera administrativa.

CAPÍTULO XIV DO ENCERRAMENTO DO PROCESSO Art. 36. O Processo SEI de Acumulação de Cargos deve ser encerrado nas seguintes situações: I - exoneração ou demissão de qualquer dos vínculos funcionais; II - aposentadoria; III - falecimento. § 1º Nos casos dos incisos I e II, o servidor público deve primeiramente remeter o processo de acumulação do período imediatamente anterior à exoneração ou aposentadoria, para análise da compatibilidade. § 2º Nos casos dos incisos I e II, o servidor público deve anexar ao processo pedido de arquivamento do mesmo, motivado pela “perda de objeto”, acompanhado de documento comprobatório do desligamento funcional e publicação oficial, quando for o caso. § 3º A fim de manter o histórico de vínculos profissionais do servidor público, o mesmo processo deve ser reaberto caso o servidor público venha novamente a acumular cargos públicos nos termos da Lei.

CAPÍTULO XV DAS DISPOSIÇÕES FINAIS Art. 37. Todos os atos e notificações ao(à) servidor(a) público(a), relativos à sua acumulação de cargos, serão anexados ao seu respectivo Processo Eletrônico no Sistema Eletrônico de Informações (SEI). I - é de responsabilidade do(a) servidor(a) público(a) acompanhar o trâmite de seu Processo SEI, bem como realizar as diligências definidas pela Comissão Permanente de Acumulação de Cargos (CPAC) no prazo improrrogável de 10 (dez) dias, contados da ciência da notificação; II - considerando o disposto no parágrafo anterior, o(a) servidor(a) público(a) não pode, em hipótese alguma, alegar desconhecimento de fatos, decisões e prazos acerca de sua acumulação de cargos. Art. 38. O servidor público sempre deve apor a marca de ciente nos documentos emitidos pela Comissão Permanente de Acumulação de Cargos (CPAC) do Detran/DF e anexados ao seu Processo Eletrônico no Sistema Eletrônico de Informações (SEI). I - Considerar-se-á notificado todo documento anexado pela Comissão Permanente de Acumulação de Cargos (CPAC) do Detran/DF, no prazo máximo de 05 (cinco) dias úteis da sua anexação, independentemente do registro de ciência do servidor público; II - O prazo determinado no parágrafo anterior, bem como outros que vierem a ser definidos, serão suspensos nos casos de afastamentos e licenças do servidor público. Art. 39. Nos casos de cessão a outros órgãos e entidades, bem como de afastamentos superiores a 01 (um) mês, o processo de acumulação será suspenso pelo mesmo período que durar o afastamento do servidor público.

<!-- pagina 22 -->

Art. 40. Servidores que acumulam legalmente cargos e empregos públicos, e que se encontram cedidos ao Detran/DF, também terão as análises de sua acumulação de cargos gerenciadas pela Comissão Permanente de Acumulação de Cargos (CPAC) do Detran/DF, nos termos desta Instrução. Art. 41. Esta Instrução entra em vigor na data de sua publicação. Art. 42. Revogam-se as disposições em contrário.

MARCU ANTÔNIO DE SOUZA BELLINI

## SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA

PORTARIA Nº 117, DE 16 DE JUNHO DE 2026 Altera a Portaria 80, de 15 de março de 2023. O SECRETÁRIO DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL, no exercício das atribuições que lhe são conferidas pelo artigo 105, parágrafo único, inciso III, da Lei Orgânica do Distrito Federal e Decreto nº 40.833, de 26 de maio de 2020, resolve: Art. 1º O artigo 11º, § 1º, inciso III, da Portaria nº 80, de 15 de março de 2023, passa a vigorar com a seguinte redação: “Art. 11º................................. III - 01 (uma) embalagem lacrada, no modelo de refil plástico, com creme corporal, com volume máximo de 400 (quatrocentos) mililitros;” Art. 2º Esta Portaria entra em vigor na data de sua publicação.

WENDERSON SOUZA E TELES

### COORDENAÇÃO DO SISTEMA PRISIONAL

GERÊNCIA CORREICIONAL

ORDEM DE SERVIÇO Nº 119, DE 18 DE JUNHO DE 2026 O GERENTE CORREICIONAL, DA SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL, no uso de suas atribuições legais conferidas pelo art. 214, § 2º da Lei Complementar Distrital nº 840/2011; e conforme Portaria nº 114, de 09 de abril de 2024, publicada no DODF Nº 69, de 11 de abril de 2024, pg. 6, resolve: Art. 1º Reconduzir a Comissão da Sindicância nº 220250016/2025-SEAPE, (04026- 00033019/2025-43), instaurada pela Portaria nº 161, de 24/07/2025, publicada no DODF Nº 139, de 28/07/2025, pg. 92/93, consoante o que dispõe o art. 214, § 2º da lei Complementar nº 840/2011. Art. 2º A Comissão Sindicante deverá promover as comunicações necessárias, bem como, prosseguir na apuração até a efetiva conclusão, no prazo estabelecido; Art. 3º As diligências até então realizadas na Sindicância em tela estão convalidadas e instruem os respectivos autos. Art. 4º Conceder prazo de 30 (trinta) dias para a conclusão dos trabalhos, a contar de 25/06/2026, prorrogáveis por igual período, conforme justificativa (206184565). Art. 5º Esta Ordem de Serviço entra em vigor na data de sua publicação.

LEANDRO JORGE BERTOLOTO

## SECRETARIA DE ESTADO DE TRANSPORTE E MOBILIDADE

### JUNTA ADMINISTRATIVA DE RECURSOS DE INFRAÇÕES

ATA - SEMOB/JARI PRIMEIRA CÂMARA Aos dezessete dias do mês de junho do ano de dois mil e vinte e seis, às quinze horas, realizou-se, por videoconferência, sessão de julgamento da Junta Administrativa de Recursos de Infrações da Secretaria de Estado de Transporte e Mobilidade do Distrito Federal – JARI/SEMOB, no exercício das competências previstas no art. 37 da Lei nº 3.106, de 27 de dezembro de 2002, no art. 75, parágrafo único, da Lei nº 5.323, de 17 de março de 2014 e no Decreto Nº 46.721, de 03 de Janeiro de 2025. A reunião contou com a presença do Presidente em Substituição Roberto Neri Dias, juntamente com os membros: Aliete Maia Rezende, Suellen Gonçalves Brandãoe Tiago Luiz Messias. Abertos os trabalhos, foram relatados, discutidos, analisados e postos em julgamento os processos discriminados por operador e por número, relacionados a seguir, aos quais, por maioria, foi negado provimento: EXPRESSO SÃO JOSÉ 00090-00017179/2023-11, EXPRESSO SÃO JOSÉ 00090-00018179/2023-21, EXPRESSO SÃO JOSÉ 00090-00019559/2023-82, EXPRESSO SÃO JOSÉ 00090-00020315/2023-42, XPRESSO SÃO JOSÉ 00090- 00016698/2023-54, EXPRESSO SÃO JOSÉ 00090-00015297/2023-87, EXPRESSO SÃO JOSÉ 00090-00013321/2023-43, EXPRESSO SÃO JOSÉ 00090-00010991/2023-16, EXPRESSO SÃO JOSÉ 00090-00009022/2023-12, EXPRESSO SÃO JOSÉ 00090- 00009000/2023-44, EXPRESSO SÃO JOSÉ 00090-00005925/2023-16, EXPRESSO SÃO JOSÉ 00090-00024413/2023-59, EXPRESSO SÃO JOSÉ 00090-00022286/2023-53, EXPRESSO SÃO JOSÉ 00090-00020250/2023-35, EXPRESSO SÃO JOSÉ 00090- 00019256/2023-60, EXPRESSO SÃO JOSÉ 00090-00017645/2023-51, EXPRESSO

SÃO JOSÉ 00090-00016359/2023-78, EXPRESSO SÃO JOSÉ 00090-00014965/2023-59, EXPRESSO SÃO JOSÉ 00090-00014651/2023-56, EXPRESSO SÃO JOSÉ 00090- 00014624/2023-83, EXPRESSO SÃO JOSÉ 00090-00011506/2023-13, EXPRESSO SÃO JOSÉ 00090-00006812/2023-38, EXPRESSO SÃO JOSÉ 00090-00006722/2023-47, EXPRESSO SÃO JOSÉ 00090-00021208/2023-31, EXPRESSO SÃO JOSÉ 00090- 00021850/2023-11, EXPRESSO SÃO JOSÉ 00090-00023252/2023-86, EXPRESSO SÃO JOSÉ 00090-00024046/2023-93, EXPRESSO SÃO JOSÉ 00090-00008065/2023-72, EXPRESSO SÃO JOSÉ 00090-00012148/2023-66, EXPRESSO SÃO JOSÉ 00090- 00024685/2023-59, EXPRESSO SÃO JOSÉ 00090-00002596/2023-51, EXPRESSO SÃO JOSÉ 00090-00003128/2023-02, EXPRESSO SÃO JOSÉ 00090-00003698/2023-94, EXPRESSO SÃO JOSÉ 00090-00005527/2023-08. Os processos a seguir, listados por operador e por número, foram retirados de pauta: EXPRESSO SÃO JOSÉ 00090- 00020679/2023-22, EXPRESSO SÃO JOSÉ 00090-00021387/2023-15, EXPRESSO SÃO JOSÉ 00090-00003566/2023-62, EXPRESSO SÃO JOSÉ 00090-00001180/2023-16, EXPRESSO SÃO JOSÉ 00090-00009003/2023-88, EXPRESSO SÃO JOSÉ 00090- 00010352/2023-42, EXPRESSO SÃO JOSÉ 00090-00010076/2023-12, EXPRESSO SÃO JOSÉ 00090-00012616/2023-01, EXPRESSO SÃO JOSÉ 00090-00002592/2023-73, EXPRESSO SÃO JOSÉ 00090-00003120/2023-38, EXPRESSO SÃO JOSÉ 00090- 00010264/2023-41, EXPRESSO SÃO JOSÉ 00090-00022290/2023-11, EXPRESSO SÃO JOSÉ 00090-00017767/2023-47, EXPRESSO SÃO JOSÉ 00090-00017648/2023-94, EXPRESSO SÃO JOSÉ 00090-00016700/2023-95, EXPRESSO SÃO JOSÉ 00090- 00012624/2023-49. Por fim, foram distribuídos os processos discriminados por operador e por número, relacionados a seguir, para análise e julgamento no dia primeiro do mês de julho do ano de dois mil e vinte e seis: URBI - MOBILID. URBANA 00090- 00007219/2023-17, URBI - MOBILID. URBANA 00090-00023088/2023-15, URBI - MOBILID. URBANA 00090-00023087/2023-62, URBI - MOBILID. URBANA 00090- 00019166/2023-79, URBI - MOBILID. URBANA 00090-00017636/2023-60, URBI - MOBILID. URBANA 00090-00017635/2023-15, URBI - MOBILID. URBANA 00090- 00017518/2023-51, URBI - MOBILID. URBANA 00090-00021006/2023-90, URBI - MOBILID. URBANA 00090-00020353/2023-03, URBI - MOBILID. URBANA 00090- 00019747/2023-19, URBI - MOBILID. URBANA 00090-00015035/2023-12, URBI - MOBILID. URBANA 00090-00015369/2023-96, URBI - MOBILID. URBANA 00090- 00003724/2023-84, URBI - MOBILID. URBANA 00090-00015057/2023-82, URBI - MOBILID. URBANA 00090-00014702/2023-40, URBI - MOBILID. URBANA 00090- 00008076/2023-52, URBI - MOBILID. URBANA 00090-00008052/2023-01, URBI - MOBILID. URBANA 00090-00006183/2023-46, URBI - MOBILID. URBANA 00090- 00023134/2023-78, URBI - MOBILID. URBANA 00090-00016857/2023-11, URBI - MOBILID. URBANA 00090-00013439/2023-71, URBI - MOBILID. URBANA 00090- 00016961/2023-13, URBI - MOBILID. URBANA 00090-00013603/2023-41, URBI - MOBILID. URBANA 00090-00017235/2023-18, URBI - MOBILID. URBANA 00090- 00014538/2023-71, URBI - MOBILID. URBANA 00090-00015937/2023-59, URBI - MOBILID. URBANA 00090-00022308/2023-85, URBI - MOBILID. URBANA 00090- 00016124/2023-86, URBI - MOBILID. URBANA 00090-00022305/2023-41, URBI - MOBILID. URBANA 00090-00022303/2023-52, URBI - MOBILID. URBANA 00090- 00015808/2023-61, URBI - MOBILID. URBANA 00090-00022281/2023-21, URBI - MOBILID. URBANA 00090-00015807/2023-16, URBI - MOBILID. URBANA 00090- 00022221/2023-16. A reunião foi encerrada às quinze horas e quarenta a cinco minutos.

PRESIDENTE SUBSTITUTO:

ROBERTO NERI DIAS

MEMBROS: ALIETE MAIA REZENDE, SUELLEN GONÇALVES

BRANDÃO E TIAGO LUIZ MESSIAS.

ATA - SEMOB/JARI SEGUNDA CÂMARA Aos dezessete dias do mês de junho do ano de dois mil e vinte e seis, às quinze horas, realizou-se, por videoconferência, sessão de julgamento da Junta Administrativa de Recursos de Infrações da Secretaria de Estado de Transporte e Mobilidade do Distrito Federal – JARI/SEMOB, no exercício das competências previstas no art. 37 da Lei nº 3.106, de 27 de dezembro de 2002, no art. 75, parágrafo único, da Lei nº 5.323, de 17 de março de 2014 e no Decreto Nº 46.721, de 03 de Janeiro de 2025. A reunião contou com a presença do Presidente em Substituição Roberto Neri Dias, juntamente com os membros: Aliete Maia Rezende, Polyana Costa Barboza Fazendeiro, José Luiz Barbosa Hermogenes e Suely Rodrigues Loureiro. Abertos os trabalhos, foram relatados, discutidos, analisados e postos em julgamento os processos discriminados por operador e por número, relacionados a seguir, aos quais, por maioria, foi negado provimento: EXPRESSO SÃO JOSÉ 00090-00006595/2023-86, EXPRESSO SÃO JOSÉ 00090-00001179/2023-91, EXPRESSO SÃO JOSÉ 00090-00001241/2023-45, EXPRESSO SÃO JOSÉ 00090- 00009327/2023-16, EXPRESSO SÃO JOSÉ 00090-00009001/2023-99, EXPRESSO SÃO JOSÉ 00090-00012639/2023-15, EXPRESSO SÃO JOSÉ 00090-00013781/2023- 71, EXPRESSO SÃO JOSÉ 00090-00014127/2023-85, EXPRESSO SÃO JOSÉ 00090- 00014610/2023-60, EXPRESSO SÃO JOSÉ 00090-00014999/2023-43, EXPRESSO SÃO JOSÉ 00090-00014952/2023-80, EXPRESSO SÃO JOSÉ 00090-00001238/2023- 21, EXPRESSO SÃO JOSÉ 00090-00024397/2023-02, EXPRESSO SÃO JOSÉ 00090- 00015490/2023-18, EXPRESSO SÃO JOSÉ 00090-00015308/2023-29, EXPRESSO SÃO JOSÉ 00090-00012952/2023-45, EXPRESSO SÃO JOSÉ 00090-00012712/2023- 41, EXPRESSO SÃO JOSÉ 00090-00017771/2023-13, EXPRESSO SÃO JOSÉ 00090- 00018197/2023-11, EXPRESSO SÃO JOSÉ 00090-00018959/2023-71, EXPRESSO

<!-- pagina 23 -->

SÃO JOSÉ 00090-00021878/2023-58, EXPRESSO SÃO JOSÉ 00090-00013811/2023-40, EXPRESSO SÃO JOSÉ 00090-00014921/2023-29, EXPRESSO SÃO JOSÉ 00090- 00016241/2023-40, EXPRESSO SÃO JOSÉ 00090-00009344/2023-53, EXPRESSO SÃO JOSÉ 00090-00009644/2023-32, EXPRESSO SÃO JOSÉ 00090-00010767/2023-16, EXPRESSO SÃO JOSÉ 00090-00009765/2023-84, EXPRESSO SÃO JOSÉ 00090- 00009715/2023-05, EXPRESSO SÃO JOSÉ 00090-00009712/2023-63, EXPRESSO SÃO JOSÉ 00090-00017588/2023-18, EXPRESSO SÃO JOSÉ 00090-00014923/2023-18, EXPRESSO SÃO JOSÉ 00090-00000243/2023-17, EXPRESSO SÃO JOSÉ 00090- 00014635/2023-63, EXPRESSO SÃO JOSÉ 00090-00014879/2023-46, EXPRESSO SÃO JOSÉ 00090-00014880/2023-71, EXPRESSO SÃO JOSÉ 00090-00014890/2023-14, EXPRESSO SÃO JOSÉ 00090-00016247/2023-17, EXPRESSO SÃO JOSÉ 00090- 00016248/2023-61, EXPRESSO SÃO JOSÉ 00090-00016362/2023-91, EXPRESSO SÃO JOSÉ 00090-00016249/2023-14, EXPRESSO SÃO JOSÉ 00090-00017182/2023-27, EXPRESSO SÃO JOSÉ 00090-00017554/2023-15, EXPRESSO SÃO JOSÉ 00090- 00017590/2023-89, EXPRESSO SÃO JOSÉ 00090-00017593/2023-12, EXPRESSO SÃO JOSÉ 00090-00017595/2023-10, EXPRESSO SÃO JOSÉ 00090-00017761/2023-70, EXPRESSO SÃO JOSÉ 00090-00017762/2023-14. Após análise, foi dado provimento, por unanimidade, ao recurso constante do processo EXPRESSO SÃO JOSÉ 00090- 00008304/2023-94, anulando-se os autos de infração vinculados ao mesmo. Por fim, foram distribuídos os processos discriminados por operador e por número, relacionados a seguir, para análise e julgamento no dia primeiro do mês de julho do ano de dois mil e vinte e seis: URBI - MOBILID. URBANA 00090-00019164/2023-80, URBI - MOBILID. URBANA 00090-00019041/2023-49, URBI - MOBILID. URBANA 00090-00022381/2023-57, URBI - MOBILID. URBANA 00090-00019040/2023-02, URBI - MOBILID. URBANA 00090- 00015806/2023-71, URBI - MOBILID. URBANA 00090-00020928/2023-80, URBI - MOBILID. URBANA 00090-00020921/2023-68, URBI - MOBILID. URBANA 00090- 00015805/2023-27, URBI - MOBILID. URBANA 00090-00015804/2023-82, URBI - MOBILID. URBANA 00090-00015803/2023-38, URBI - MOBILID. URBANA 00090- 00015802/2023-93, URBI - MOBILID. URBANA 00090-00015801/2023-49, URBI - MOBILID. URBANA 00090-00015764/2023-79, URBI - MOBILID. URBANA 00090- 00015763/2023-24, URBI - MOBILID. URBANA 00090-00020920/2023-13, URBI - MOBILID. URBANA 00090-00014991/2023-87, URBI - MOBILID. URBANA 00090- 00019571/2023-97, URBI - MOBILID. URBANA 00090-00014951/2023-35, URBI - MOBILID. URBANA 00090-00023417/2023-10, URBI - MOBILID. URBANA 00090- 00014950/2023-91, URBI - MOBILID. URBANA 00090-00014949/2023-66, URBI - MOBILID. URBANA 00090-00014948/2023-11, URBI - MOBILID. URBANA 00090- 00014847/2023-41, URBI - MOBILID. URBANA 00090-00014845/2023-51, URBI - MOBILID. URBANA 00090-00021940/2023-10, URBI - MOBILID. URBANA 00090- 00014574/2023-34, URBI - MOBILID. URBANA 00090-00021642/2023-11, URBI - MOBILID. URBANA 00090-00014552/2023-74, URBI - MOBILID. URBANA 00090- 00014550/2023-85, URBI - MOBILID. URBANA 00090-00021641/2023-77, URBI - MOBILID. URBANA 00090-00023130/2023-90, URBI - MOBILID. URBANA 00090- 00014347/2023-17, URBI - MOBILID. URBANA 00090-00023119/2023-20, URBI - MOBILID. URBANA 00090-00014000/2023-66, URBI - MOBILID. URBANA 00090- 00023091/2023-21, URBI - MOBILID. URBANA 00090-00013952/2023-62, URBI - MOBILID. URBANA 00090-00023090/2023-86, URBI - MOBILID. URBANA 00090- 00013577/2023-51, URBI - MOBILID. URBANA 00090-00016939/2023-65, URBI - MOBILID. URBANA 00090-00020377/2023-54, URBI - MOBILID. URBANA 00090- 00013576/2023-14, URBI - MOBILID. URBANA 00090-00020379/2023-43, URBI - MOBILID. URBANA 00090-00020380/2023-78, URBI - MOBILID. URBANA 00090- 00020762/2023-00, URBI - MOBILID. URBANA 00090-00021974/2023-04, URBI - MOBILID. URBANA 00090-00013492/2023-72, URBI - MOBILID. URBANA 00090- 00016075/2023-81, URBI - MOBILID. URBANA 00090-00012915/2023-37, URBI - MOBILID. URBANA 00090-00016599/2023-72. A reunião foi encerrada às quinze horas e quarenta e cinco minutos.

PRESIDENTE SUBSTITUTO:

ROBERTO NERI DIAS

MEMBROS: ALIETE MAIA REZENDE, POLYANA COSTA BARBOZA FAZENDEIRO, JOSÉ LUIZ

BARBOSA HERMOGENES E SUELY RODRIGUES LOUREIRO.

ATA - SEMOB/JARI SESSÃO EXTRAORDINÁRIA Aos dezessete dias do mês de junho do ano de dois mil e vinte e seis, às quinze horas e trinta minutos, realizou-se, por videoconferência, sessão de julgamento da Junta Administrativa de Recursos de Infrações da Secretaria de Estado de Transporte e Mobilidade do Distrito Federal – JARI/SEMOB, no exercício das competências previstas no art. 37 da Lei nº 3.106, de 27 de dezembro de 2002, no art. 75, parágrafo único, da Lei nº 5.323, de 17 de março de 2014 e no Decreto Nº 46.721, de 03 de Janeiro de 2025. A reunião contou com a presença do Presidente em Substituição Roberto Neri Dias, juntamente com os membros: Aliete Maia Rezende, Ricardo Carvalho Silva, Alixandre Abel Alvarenga e Viviane Aparecida Silva Barros. Abertos os trabalhos, foram relatados, discutidos, analisados e postos em julgamento os processos discriminados por operador e por número, relacionados a seguir, aos quais, por maioria, foi negado provimento: EXPRESSO SÃO JOSÉ 00090-00016432/2023-10, EXPRESSO SÃO JOSÉ 00090- 00016600/2023-69, EXPRESSO SÃO JOSÉ 00090-00016868/2023-09, EXPRESSO SÃO JOSÉ 00090-00017765/2023-58, EXPRESSO SÃO JOSÉ 00090-00017766/2023- 01, EXPRESSO SÃO JOSÉ 00090-00021250/2023-52, EXPRESSO SÃO JOSÉ

00090-00021175/2023-20, EXPRESSO SÃO JOSÉ 00090-00020063/2023-51, EXPRESSO SÃO JOSÉ 00090-00010182/2024-87, EXPRESSO SÃO JOSÉ 00090- 00021340/2024-24, EXPRESSO SÃO JOSÉ 00090-00020936/2024-15, EXPRESSO SÃO JOSÉ 00090-00015237/2024-45, EXPRESSO SÃO JOSÉ 00090-00012174/2024-75, EXPRESSO SÃO JOSÉ 00090-00009994/2024-80, EXPRESSO SÃO JOSÉ 00090- 00009993/2024-35, EXPRESSO SÃO JOSÉ 00090-00009425/2024-34, EXPRESSO SÃO JOSÉ 00090-00005078/2024-71, EXPRESSO SÃO JOSÉ 00090-00002927/2024-34, EXPRESSO SÃO JOSÉ 00090-00001646/2024-64, EXPRESSO SÃO JOSÉ 00090- 00000907/2024-29, EXPRESSO SÃO JOSÉ 00090-00021505/2024-68, EXPRESSO SÃO JOSÉ 00090-00018199/2024-82, EXPRESSO SÃO JOSÉ 00090-00020944/2024-53, EXPRESSO SÃO JOSÉ 00090-00010180/2024-98, EXPRESSO SÃO JOSÉ 00090- 00010178/2024-19, EXPRESSO SÃO JOSÉ 00090-00010167/2024-39, EXPRESSO SÃO JOSÉ 00090-00010103/2024-38, EXPRESSO SÃO JOSÉ 00090-00009988/2024-22, EXPRESSO SÃO JOSÉ 00090-00007387/2024-85, EXPRESSO SÃO JOSÉ 00090- 00007388/2024-20, EXPRESSO SÃO JOSÉ 00090-00007391/2024-43, EXPRESSO SÃO JOSÉ 00090-00009974/2024-17, EXPRESSO SÃO JOSÉ 00090-00009976/2024-06, EXPRESSO SÃO JOSÉ 00090-00010181/2024-32, EXPRESSO SÃO JOSÉ 00090- 00010183/2024-21, EXPRESSO SÃO JOSÉ 00090-00010185/2024-11, EXPRESSO SÃO JOSÉ 00090-00011986/2024-01, EXPRESSO SÃO JOSÉ 00090-00012179/2024-06, EXPRESSO SÃO JOSÉ 00090-00012181/2024-77, EXPRESSO SÃO JOSÉ 00090- 00015238/2024-90, EXPRESSO SÃO JOSÉ 00090-00004833/2024-08, EXPRESSO SÃO JOSÉ 00090-00004836/2024-33, EXPRESSO SÃO JOSÉ 00090-00011905/2024-65, EXPRESSO SÃO JOSÉ 00090-00013963/2024-23, EXPRESSO SÃO JOSÉ 00090- 00013434/2024-20. Após análise, foi dado provimento, por unanimidade, aos recursos constantes dos processos: EXPRESSO SÃO JOSÉ 00090-00005404/2024-40 e EXPRESSO SÃO JOSÉ 00090-00014627/2023-17, anulando-se os autos de infração vinculados aos mesmos. Por fim, foram distribuídos os processos discriminados por operador e por número, relacionados a seguir, para análise e julgamento no dia primeiro do mês de julho do ano de dois mil e vinte e seis: URBI - MOBILID. URBANA 00090- 00022312/2023-43, URBI - MOBILID. URBANA 00090-00017639/2023-01, URBI - MOBILID. URBANA 00090-00021183/2023-76, URBI - MOBILID. URBANA 00090- 00015525/2023-19, URBI - MOBILID. URBANA 00090-00014968/2023-92, URBI - MOBILID. URBANA 00090-00014835/2023-16, URBI - MOBILID. URBANA 00090- 00014278/2023-33, URBI - MOBILID. URBANA 00090-00014192/2023-19, URBI - MOBILID. URBANA 00090-00014126/2023-31, URBI - MOBILID. URBANA 00090- 00014027/2023-59, URBI - MOBILID. URBANA 00090-00014025/2023-60, URBI - MOBILID. URBANA 00090-00013778/2023-58, URBI - MOBILID. URBANA 00090- 00013235/2023-31, URBI - MOBILID. URBANA 00090-00013073/2023-31, URBI - MOBILID. URBANA 00090-00013070/2023-05, URBI - MOBILID. URBANA 00090- 00013039/2023-66, URBI - MOBILID. URBANA 00090-00013037/2023-77, URBI - MOBILID. URBANA 00090-00012595/2023-15, URBI - MOBILID. URBANA 00090- 00012594/2023-71, URBI - MOBILID. URBANA 00090-00012592/2023-81, URBI - MOBILID. URBANA 00090-00012591/2023-37, URBI - MOBILID. URBANA 00090- 00018956/2024-18, URBI - MOBILID. URBANA 00090-00018954/2024-29, URBI - MOBILID. URBANA 00090-00009420/2024-10, URBI - MOBILID. URBANA 00090- 00008948/2024-63, URBI - MOBILID. URBANA 00090-00012805/2024-56, URBI - MOBILID. URBANA 00090-00018948/2024-71, URBI - MOBILID. URBANA 00090- 00020610/2024-80, URBI - MOBILID. URBANA 00090-00022682/2024-61, URBI - MOBILID. URBANA 00090-00018949/2024-16, URBI - MOBILID. URBANA 00090- 00021447/2024-72, URBI - MOBILID. URBANA 00090-00013902/2024-66, URBI - MOBILID. URBANA 00090-00013897/2024-91, URBI - MOBILID. URBANA 00090- 00013897/2024-91, URBI - MOBILID. URBANA 00090-00022095/2024-72, URBI - MOBILID. URBANA 00090-00015023/2024-79, URBI - MOBILID. URBANA 00090- 00013381/2024-47, URBI - MOBILID. URBANA 00090-00008949/2024-16, URBI - MOBILID. URBANA 00090-00002708/2024-55, URBI - MOBILID. URBANA 00090- 00023297/2024-31, URBI - MOBILID. URBANA 00090-00022103/2024-81, URBI - MOBILID. URBANA 00090-00018107/2024-64, URBI - MOBILID. URBANA 00090- 00020018/2024-88, URBI - MOBILID. URBANA 00090-00020046/2024-03, URBI - MOBILID. URBANA 00090-00021136/2024-11, URBI - MOBILID. URBANA 00090- 00021820/2024-95, URBI - MOBILID. URBANA 00090-00021913/2024-10, URBI - MOBILID. URBANA 00090-00022363/2024-56. A reunião foi encerrada às dezesseis horas e quarenta e cinco minutos.

PRESIDENTE SUBSTITUTO:

ROBERTO NERI DIAS

MEMBROS: ALIETE MAIA REZENDE, RICARDO CARVALHO SILVA, ALIXANDRE ABEL

ALVARENGA E VIVIANE APARECIDA SILVA BARR

ATA - SEMOB/JARI TERCEIRA CÂMARA Aos dezessete dias do mês de junho do ano de dois mil e vinte e seis, às quinze horas e quarenta e cinco minutos, realizou-se, por videoconferência, sessão de julgamento da Junta Administrativa de Recursos de Infrações da Secretaria de Estado de Transporte e Mobilidade do Distrito Federal – JARI/SEMOB, no exercício das competências previstas no art. 37 da Lei nº 3.106, de 27 de dezembro de 2002, no art. 75, parágrafo único, da Lei nº 5.323, de 17 de março de 2014 e no Decreto Nº 46.721, de 03 de Janeiro de 2025. A reunião contou com a presença do Presidente em Substituição Roberto Neri Dias, juntamente com os membros: Aliete Maia Rezende, Ana Cristina Lopes Afonso, Patrícia

<!-- pagina 24 -->

César Ribeiro Dunshe Fiod e Alan da Silva Maniçoba. Abertos os trabalhos, foram relatados, discutidos, analisados e postos em julgamento os processos discriminados por operador e por número, relacionados a seguir, aos quais, por maioria, foi negado provimento: EXPRESSO SÃO JOSÉ 00090-00019254/2023-71, EXPRESSO SÃO JOSÉ 00090-00014612/2023-59, EXPRESSO SÃO JOSÉ 00090-00015883/2023-21, EXPRESSO SÃO JOSÉ 00090-00016361/2023-47, URBI - MOBILID. URBANA 00090- 00022643/2023-83, URBI - MOBILID. URBANA 00090-00023139/2023-09, URBI - MOBILID. URBANA 00090-00016543/2023-18, URBI - MOBILID. URBANA 00090- 00020659/2023-51, URBI - MOBILID. URBANA 00090-00020299/2023-98, URBI - MOBILID. URBANA 00090-00019628/2023-58, URBI - MOBILID. URBANA 00090- 00021995/2023-11, URBI - MOBILID. URBANA 00090-00021994/2023-77, URBI - MOBILID. URBANA 00090-00020381/2023-12, URBI - MOBILID. URBANA 00090- 00020354/2023-40, URBI - MOBILID. URBANA 00090-00020088/2023-55, URBI - MOBILID. URBANA 00090-00019750/2023-24, URBI - MOBILID. URBANA 00090- 00020352/2023-51, URBI - MOBILID. URBANA 00090-00020089/2023-08, URBI - MOBILID. URBANA 00090-00020091/2023-79, URBI - MOBILID. URBANA 00090- 00019629/2023-01, URBI - MOBILID. URBANA 00090-00019632/2023-16, URBI - MOBILID. URBANA 00090-00019633/2023-61, URBI - MOBILID. URBANA 00090- 00020788/2023-40, URBI - MOBILID. URBANA 00090-00020790/2023-19, URBI - MOBILID. URBANA 00090-00020855/2023-26, URBI - MOBILID. URBANA 00090- 00021294/2023-82, URBI - MOBILID. URBANA 00090-00021442/2023-69, URBI - MOBILID. URBANA 00090-00022198/2023-51, URBI - MOBILID. URBANA 00090- 00022717/2023-81, URBI - MOBILID. URBANA 00090-00022719/2023-71, URBI - MOBILID. URBANA 00090-00022732/2023-20, URBI - MOBILID. URBANA 00090- 00022735/2023-63, URBI - MOBILID. URBANA 00090-00022737/2023-52, URBI - MOBILID. URBANA 00090-00023231/2023-61, URBI - MOBILID. URBANA 00090- 00024637/2023-61, URBI - MOBILID. URBANA 00090-00023085/2023-73, URBI - MOBILID. URBANA 00090-00023084/2023-29, URBI - MOBILID. URBANA 00090- 00023081/2023-95, URBI - MOBILID. URBANA 00090-00023079/2023-16, URBI - MOBILID. URBANA 00090-00023122/2023-43, URBI - MOBILID. URBANA 00090- 00022309/2023-20, URBI - MOBILID. URBANA 00090-00022080/2023-23, URBI - MOBILID. URBANA 00090-00021937/2023-98, URBI - MOBILID. URBANA 00090- 00010567/2023-63, URBI - MOBILID. URBANA 00090-00008369/2023-30, URBI - MOBILID. URBANA 00090-00007090/2023-39, URBI - MOBILID. URBANA 00090- 00007091/2023-83, URBI - MOBILID. URBANA 00090-00007183/2023-63, URBI - MOBILID. URBANA 00090-00011959/2023-40. Por fim, foram distribuídos os processos discriminados por operador e por número, relacionados a seguir, para análise e julgamento no dia primeiro do mês de julho do ano de dois mil e vinte e seis: URBI - MOBILID. URBANA 00090-00022373/2023-19, URBI - MOBILID. URBANA 00090- 00019023/2023-67, URBI - MOBILID. URBANA 00090-00022372/2023-66, URBI - MOBILID. URBANA 00090-00017734/2023-05, URBI - MOBILID. URBANA 00090- 00019085/2023-79, URBI - MOBILID. URBANA 00090-00012637/2023-18, URBI - MOBILID. URBANA 00090-00019087/2023-68, URBI - MOBILID. URBANA 00090- 00019096/2023-59, URBI - MOBILID. URBANA 00090-00012611/2023-70, URBI - MOBILID. URBANA 00090-00019455/2023-78, URBI - MOBILID. URBANA 00090- 00019752/2023-13, URBI - MOBILID. URBANA 00090-00011668/2023-51, URBI - MOBILID. URBANA 00090-00020491/2023-84, URBI - MOBILID. URBANA 00090- 00020512/2023-61, URBI - MOBILID. URBANA 00090-00011395/2023-45, URBI - MOBILID. URBANA 00090-00016673/2023-51, URBI - MOBILID. URBANA 00090- 00011028/2023-41, URBI - MOBILID. URBANA 00090-00016070/2023-59, URBI - MOBILID. URBANA 00090-00015924/2023-80, URBI - MOBILID. URBANA 00090- 00021945/2023-34, URBI - MOBILID. URBANA 00090-00020356/2023-39, URBI - MOBILID. URBANA 00090-00020689/2023-68, URBI - MOBILID. URBANA 00090- 00020668/2023-42, URBI - MOBILID. URBANA 00090-00020271/2023-51, URBI - MOBILID. URBANA 00090-00020857/2023-15, URBI - MOBILID. URBANA 00090- 00020871/2023-19, URBI - MOBILID. URBANA 00090-00020883/2023-43, URBI - MOBILID. URBANA 00090-00020887/2023-21, URBI - MOBILID. URBANA 00090- 00021936/2023-43, URBI - MOBILID. URBANA 00090-00022639/2023-15, URBI - MOBILID. URBANA 00090-00024720/2023-30, URBI - MOBILID. URBANA 00090- 00022720/2023-03, URBI - MOBILID. URBANA 00090-00024687/2023-48, URBI - MOBILID. URBANA 00090-00009706/2023-14, URBI - MOBILID. URBANA 00090- 00015800/2023-02, URBI - MOBILID. URBANA 00090-00019854/2023-39, URBI - MOBILID. URBANA 00090-00019748/2023-55, URBI - MOBILID. URBANA 00090- 00019251/2023-37, URBI - MOBILID. URBANA 00090-00019250/2023-92, URBI - MOBILID. URBANA 00090-00019249/2023-68, URBI - MOBILID. URBANA 00090- 00017975/2023-46, URBI - MOBILID. URBANA 00090-00019073/2023-44, URBI - MOBILID. URBANA 00090-00015528/2023-52, URBI - MOBILID. URBANA 00090- 00015814/2023-18, URBI - MOBILID. URBANA 00090-00015817/2023-51, URBI - MOBILID. URBANA 00090-00015815/2023-62, URBI - MOBILID. URBANA 00090- 00015816/2023-15, URBI - MOBILID. URBANA 00090-00015527/2023-16, URBI - MOBILID. URBANA 00090-00015526/2023-63. A reunião foi encerrada às dezesseis horas e quarenta e cinco minutos.

PRESIDENTE SUBSTITUTO:

ROBERTO NERI DIAS

MEMBROS: ALIETE MAIA REZENDE, ANA CRISTINA LOPES AFONSO, PATRÍCIA CÉSAR

RIBEIRO DUNSHE FIOD E ALAN DA SILVA MANIÇOBA

## SECRETARIA DE ESTADO DE

## OBRAS E INFRAESTRUTURA

### DEPARTAMENTO DE ESTRADAS DE RODAGEM

DESPACHO DO PRESIDENTE

Em 18 de junho de 2026 Processo SEI: 00113-00006267/2025-17. Interessado: LK CONSTRUÇÕES E TERRAPLENAGEM LTDA, CNPJ/MF sob o nº 15.449.462/0001-68. Assunto: pagamento de despesa com o Contrato Nº 011/2025 Doc. SEI/GDF (166072425), firmado entre o DER/DF e a Empresa LK CONSTRUÇÕES E TERRAPLENAGEM LTDA, tendo como objeto a contratação de serviços comuns de locação de motoniveladora, sob demanda, para fins de atendimento às demandas do Departamento de Estradas de Rodagem - DER/DF, referente ao exercício de 2025. Reconhecimento de Dívida, no valor de R$ 18.739,79 (dezoito mil setecentos e trinta e nove reais e setenta e nove centavos). O Presidente do DER/DF à vista do que consta do processo acima epigrafado, conforme previsto no parágrafo primeiro, artigos 86 e 87, do Decreto 32.598, de 15 de dezembro de 2010, com a redação dada pelas alterações constantes do Decreto 39.014/2018, que incorporaram os dispositivos do Decreto 37.594/2016, reconhece a dívida, e usando de suas atribuições previstas no Art. 7º, inciso XXII do Regimento aprovado pelo Decreto nº 48.239 de 04 de fevereiro de 2026, autoriza o reconhecimento da dívida, a emissão de nota de empenho, liquidação e pagamento da despesa no valor acima discriminado em favor do interessado.

FAUZI NACFUR JÚNIOR

SUPERINTENDÊNCIA ADMINISTRATIVA E FINANCEIRA

DESPACHO DO SUPERINTENDENTE

Em 18 de junho de 2026 TORNAR SEM EFEITO a Instrução de 15 de Julho de 2014, publicada no DODF N° 146 de 18/07/2014, pg. 54. Motivo: incorreção na matéria. TORNAR SEM EFEITO a retificação da Instrução de 15 de Julho de 2014, publicada no DODF N° 90 de 19/05/2026, pg. 31. Motivo: duplicidade de matéria.

MAURICIO THEODOSIO MATTOS MARQUES

## SECRETARIA DE ESTADO DE CULTURA

## E ECONOMIA CRIATIVA

PORTARIA CONJUNTA Nº 05, DE 18 DE JUNHO DE 2026 O SECRETÁRIO DE ESTADO DE CULTURA E ECONOMIA CRIATIVA DO DISTRITO FEDERAL E O SECRETÁRIO DE ESTADO DE TURISMO DO DISTRITO FEDERAL, no uso de suas atribuições, consoante o que estabelecem a Lei nº 7.842, de 30 de dezembro de 2025, que aprovou a Lei Orçamentária Anual do Distrito Federal para o exercício de 2026, e o Decreto n.º 37.427, de 22 de junho de 2016, alterado parcialmente pelo Decreto nº 37.471, de 08 de julho de 2016, que dispõe sobre a descentralização de execução de créditos orçamentários, resolvem: Art. 1º Descentralizar a execução do crédito orçamentário, na forma a seguir especificada: De: UO: 16.101 - SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA DO DISTRITO FEDERAL; UG: 230.101 - SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA DO DISTRITO FEDERAL; Para: UO: 27.101 - SECRETARIA DE ESTADO DE TURISMO DO DISTRITO FEDERAL; UG: 310.101 - SECRETARIA DE ESTADO DE TURISMO DO DISTRITO FEDERAL. I - OBJETO: Realizar o projeto "METROPOLES ENDURANCE TRIATLO", conforme Ofício Eletrônico SISCONEP n.º 20.859, Deputado Hermeto II - VIGÊNCIA: data de início: 15/07/2026 término: 03/08/2026 III - PT: 13.392.6219.9075.0393 - Apoio à Cultura em Todo o DF h

Natureza da Despesa Fonte Valor

3.3.50.41 100 500.000,00

Art. 2º Esta Portaria Conjunta entra em vigor na data de sua publicação. Art. 3º Revogam-se as disposições em contrário.

FERNANDO MODESTO Secretário de Estado de Cultura e Economia Criativa do DF

Titular da Unidade Gestora Concedente

BERNADO CARVALHO ANTUNES Secretário de Estado de Turismo do DF

Titular da Unidade Gestora Executante

DESPACHO DO SECRETÁRIO

Em 18 de junho de 2026 A SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA DO DISTRITO FEDERAL autoriza o AGENTE CULTURAL Instituto Pop Art, inscrito no Cadastro Nacional de Pessoa Jurídica (CNPJ) sob o nº 51.905.721/0001-81 e no Cadastro

<!-- pagina 25 -->

de Ente e Agente Cultural (CEAC) sob o nº 13840, representado legalmente pela Sr. MATHEUS MAIA CURVELO, CPF nº 022.***.***-33, a captar o montante de R$ 369.230,00 (trezentos e sessenta e nove mil duzentos e trinta reais) na proporção de 99% (noventa e nove por cento) para renúncia fiscal e 1% (um por cento) de investimento da Incentivadora Cultural, para financiar a realização do projeto cultural EU AMO PAGODE, inscrito sob o processo nº 00150-00004619/2026-16, no âmbito do Programa de Incentivo Fiscal regido pela Lei Complementar nº 934, de 07 de dezembro de 2017.

FERNANDO MODESTO MAGALHÃES VIEIRA

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO

PORTARIA Nº 94, DE 15 DE JUNHO DE 2026 Aprova o Projeto de Sistema Viário – SIV 008/2021 e o respectivo Memorial Descritivo – MDE 008/2021, referentes ao Projeto de Rota Acessível de Ligação da Via N2 a Avenida Rabelo - Vila Planalto, localizado na Região Administrativa do Plano Piloto - RA I. O SECRETÁRIO DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, incisos III e V, da Lei Orgânica do Distrito Federal, combinado com a Lei Complementar nº 803, de 25 de abril de 2009, atualizada pela Lei Complementar nº 854, de 15 de outubro de 2012, a Lei Complementar nº 1.041, de 12 de agosto de 2024, o Decreto nº 38.047, de 09 de março de 2017, combinado com o Decreto nº 38.247, de 1º de junho de 2017, e tendo em vista o que dispõe o Processo SEI nº 00390- 00004061/2020-33, resolve: Art. 1º Aprovar o Projeto de Sistema Viário – SIV 008/2021 e o respectivo Memorial Descritivo – MDE 008/2021, referente ao Projeto de Rota Acessível de Ligação da Via N2 a Avenida Rabelo - Vila Planalto, localizado na Região Administrativa do Plano Piloto - RA I. Art. 2º Autorizar a inclusão de Nota referente às alterações no projeto URB 90/90 e respectivo registro no Processo SEI nº 00390-00003045/2026-19, com a seguinte redação: “Nota: Este projeto foi alterado e complementado pelo projeto composto por: Projeto de Sistema Viário - SIV/MDE 008/2021, no que se refere à criação Rota Acessível de Ligação da Via N2 a Avenida Rabelo - Vila Planalto, localizada na Região Administrativa do Plano Piloto - RA I, conforme processo SEI-GDF nº 00390-00004061/2020-33.” Art. 3º Autorizar a inclusão de Nota referente às alterações no projeto URB 91/86 e respectivo registro no Processo SEI nº 00390-00003046/2026-63, com a seguinte redação: “Nota: Este projeto foi alterado e complementado pelo projeto composto por: Projeto de Sistema Viário - SIV/MDE 008/2021, no que se refere à criação Rota Acessível de Ligação da Via N2 a Avenida Rabelo - Vila Planalto, localizada na Região Administrativa do Plano Piloto - RA I, conforme processo SEI-GDF nº 00390-00004061/2020-33.” Art. 4º Autorizar a inclusão de Nota referente às alterações no projeto URB 200/1 e respectivo registro no Processo SEI nº 00390-00002164/2026-54, com a seguinte redação: “Nota: Este projeto foi alterado e complementado pelo projeto composto por: Projeto de Sistema Viário - SIV/MDE 008/2021, no que se refere à criação Rota Acessível de Ligação da Via N2 a Avenida Rabelo - Vila Planalto, localizada na Região Administrativa do Plano Piloto - RA I, conforme processo SEI-GDF nº 00390-00004061/2020-33.” Art. 5º Os documentos urbanísticos relacionados ao presente ato devem estar disponíveis no endereço eletrônico http://www.sisduc.seduh.df.gov.br/, no prazo máximo de 7 dias, contados a partir da publicação no Diário Oficial do Distrito Federal - DODF, nos termos determinados no art. 4º da Portaria 95, de 21 de outubro de 2021, e a inclusão do Formulário de Alteração de Projeto de Urbanismo no Sisduc deverá ser efetuada pela unidade responsável pelo arquivamento no prazo máximo de 5 dias úteis, contados a partir da entrada do documento de comprovação do registro imobiliário, quando for o caso, conforme determina o art. 5º da Portaria n.º 87, de 27 de setembro de 2024, ambas da Secretaria de Estado de Desenvolvimento Urbano e Habitação - Seduh. Art. 6º Esta portaria entra em vigor na data de sua publicação.

MARCELO VAZ MEIRA DA SILVA

PORTARIA Nº 96, DE 18 DE JUNHO DE 2026 Aprova a retificação e ajustes do projeto urbanístico registrado referente aos Lotes nºs 23 e 25, da Quadra 03, Conjunto 09, Parque do Mirante, localizado no Setor Habitacional Tororó, na Região Administrativa do Jardim Botânico - RA XXVII. O SECRETÁRIO DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, incisos III e V, da Lei Orgânica do Distrito Federal, combinado com o Decreto nº 39.610, de 1º de janeiro de 2019, com fundamento na Lei Complementar nº 803, de 25 de abril de 2009, atualizada pela Lei Complementar nº 854, de 15 de outubro de 2012, na Lei Complementar nº 948, de 16 de janeiro de 2019, alterada pela Lei Complementar n.º 1.007, de 28 de abril de 2022, na Lei Complementar nº 1.027, de 28 de novembro de 2023, regulamentada pelo Decreto nº 46.143, de 19 de agosto de 2024, e tendo em vista o que dispõe o Processo SEI nº 00307-00000328/2022-13, resolve: Art. 1º Aprovar a retificação e ajustes do Projeto de Urbanismo de Regularização de Parcelamento - URB-RP 151/2010 e Memorial Descritivo de Regularização de Parcelamento - MDE-RP 151/2010, referente aos Lotes nºs 23 e 25, da Quadra 03, Conjunto 09, do Parque do Mirante, localizado no Setor Habitacional Tororó, na Região Administrativa do Jardim Botânico - RA XXVII, conforme Planta de Urbanismo de Retificação e Ajustes - URB 001/2026 e Memorial Descritivo - MDE 001/2026.

Art. 2º Autorizar a inclusão de Nota no MDE-RP 151/2010, e o seu respectivo registro no Processo SEI nº 00390-00001350/2025-95, com a seguinte redação: "Nota: Este projeto foi alterado pelo Memorial Descritivo - MDE 001/2026 e Planta de Urbanismo de Retificação e Ajustes - URB 001/2026, no que se refere à retificação e ajustes de projeto urbanístico registrado referente aos Lotes nºs 23 e 25, da Quadra 03, Conjunto 09, do Parque do Mirante, localizado no Setor Habitacional Tororó, na Região Administrativa do Jardim Botânico - RA XXVII, conforme Processo SEI nº 00307- 00000328/2022-13." Art. 3º Os documentos urbanísticos relacionados ao presente ato devem estar disponíveis no endereço eletrônico http://www.sisduc.seduh.df.gov.br/, no prazo máximo de 7 dias, contados a partir da publicação no Diário Oficial do Distrito Federal - DODF, nos termos determinados no art. 4º da Portaria nº 95, de 21 de outubro de 2021, e a inclusão do Formulário de Alteração de Projeto de Urbanismo no Sistema de Documentação Urbanística e Cartográfica - Sisduc deverá ser efetuada pela unidade responsável pelo arquivamento no prazo máximo de 5 dias úteis, contados a partir da entrada do documento de comprovação do registro imobiliário, quando for o caso, conforme determina o art. 5º da Portaria nº 87, de 27 de setembro de 2024, ambas da Secretaria de Estado de Desenvolvimento Urbano e Habitação - Seduh. Art. 4º Esta Portaria entra em vigor na data de sua publicação.

MARCELO VAZ MEIRA DA SILVA

### SECRETARIA ADJUNTA DE DESENVOLVIMENTO

### URBANO E HABITAÇÃO CENTRAL DE APROVAÇÃO DE PROJETOS

ORDEM DE SERVIÇO Nº 77, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DA CENTRAL DE APROVAÇÃO DE PROJETOS, DA SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso das atribuições conferidas pelo art. 49, III, da Portaria n.º 227, de 11 de julho de 2022, bem como com base no Princípio da Publicidade disposto no artigo 37 da Constituição Federal e no artigo 19 da Lei Orgânica do Distrito Federal, resolve: REVOGAR A PEDIDO o ALVARÁ DE CONSTRUÇÃO Nº 702/2026, emitido em 15 de junho de 2026, para o endereço: SHI/NORTE, CA-06, CONJUNTO 05, NÚMERO 01 - LAGO NORTE/DF, tendo por proprietário PAULO SERGIO NÓBREGA DE OLIVEIRA, autora do projeto de arquitetura RACHEL FECHINA GOMES DE OLIVEIRA processo n.º 00390-00003138/2026-43, expedido por esta Central de Aprovação de Projetos, em atendimento à solicitação do autor do projeto de arquitetura, em conformidade com o disposto no artigo 53 da Lei nº 6.138/2018.

MARIANA ALVES DE PAULA

### COMPANHIA DE DESENVOLVIMENTO HABITACIONAL

DIRETORIA DE ADMINISTRAÇÃO E GESTÃO

DESPACHO DO DIRETOR

Em 19 de junho de 2026 A COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL – CODHAB/DF torna sem efeito a publicação do EXTRATO DO SEGUNDO TERMO ADITIVO DO CONTRATO Nº 012/2024, referente ao Processo nº 00392- 00008979/2024-29, publicado no Diário Oficial do Distrito Federal nº 106, de 12 de junho de 2026, página 95, Seção II.

JOSÉ ANTONIO MARTINS JÚNIOR

## SECRETARIA DE ESTADO DE ESPORTE E LAZER

### FUNDO DE APOIO AO ESPORTE

CONSELHO DE ADMINISTRAÇÃO

ATA DA 135ª REUNIÃO ORDINÁRIA DO CONSELHO DE ADMINISTRAÇÃO

DO FUNDO DE APOIO AO ESPORTE DO DISTRITO FEDERAL - CONFAE No nono dia do mês de junho do ano de dois mil e vinte e seis (09.06.2026), foi realizada presencialmente, 135ª Reunião Ordinária do Conselho de Administração do Fundo de Apoio ao Esporte do Distrito Federal - CONFAE, no Gabinete da Secretaria de Esporte e Lazer do Distrito Federal com a presença dos seguintes membros: Sr. Renato Junqueira, Presidente e Secretário de Estado de Esporte e Lazer; Sr. Paulo Eduardo da Silva, Conselheiro Titular, representante da Secretaria de Estado de Economia; Sr. Marcelo Magalhães Silva, Conselheiro Titular, representante da Secretaria de Estado de Educação; Sra. Tatiana Weysfield Mendes, Conselheira Titular, representante do Esporte Universitário; Sra. Carla Ribeiro Testa, Conselheira Titular, representante dos Atletas do Distrito Federal; Sr. Luiz Carlos de Sousa, Conselheiro Titular, representante da Secretaria de Estado de Economia; Sr. Christiano de Almeida Nunes, Conselheiro Titular, representante da Secretaria de Estado de Esporte e Lazer e o Sr. José Antônio Soares Silva, Conselheiro Titular, representante das Associações das Federações do Distrito Federal. O Sr. Presidente Renato Junqueira, às 14h43 iniciou agradecendo a presença de todos e seguiu com: I. Abertura da 135ª Reunião Ordinária; II. Verificou o quórum como suficiente; III. A Presidência apresentou a pauta que fora encaminhada previamente.O Conselheiro José Antônio solicitou a inclusão de pauta do Proc. SEI Nº

<!-- pagina 26 -->

00220-00003059/2026-30 - Minuta de Projeto de Lei Complementar, onde foi aprovada a inserção. O Conselheiro José Antônio solicitou também uma inversão da ordem da pauta do item solicitação de recurso da SUAG para ser o primeiro a ser deliberado, solicitação que foi acatada pelo presidente. Sem demais acréscimos de novas pautas, prosseguiu com à análise ordinária dos assuntos pautados: IV. Proc. SEI Nº 00220-00005782/2025-72 – Solicitação de Recurso SUAG - móveis (R$1.798.200,00) – Fernanda Alvarenga; À sra. Fernanda, representante da SUAG, cedida a palavra, esclareceu que o valor solicitado para pagamento corresponde ao montante aprovado pelo Conselho em setembro do ano anterior. Ressaltou que, embora o recurso estivesse disponível à época, a liquidação da despesa estava condicionada à efetiva entrega e montagem do mobiliário. Explicou ainda que, devido a atrasos logísticos do fornecedor no período de final de ano, a entrega e a instalação foram concluídas apenas recentemente, sendo necessária a regularização do débito no presente exercício. Reforçou que a quitação é condição indispensável para a retenção definitiva dos itens e regularização contratual. Por fim, considerando que os bens já foram recebidos, montados e distribuídos às unidades, submeteu a solicitação de pagamento à deliberação deste Conselho. Aberta a discussão, a Conselheira Tatiana solicitou a palavra e indagou sobre a disponibilidade orçamentária no QDD. A diretora Yara confirmou a existência de R$2.000.000,00 na natureza de despesa de bens permanentes. Na sequência, a conselheira questionou se o contrato permanecia ativo, ao que a Sra. Fernanda respondeu que o referido contrato foi renovado e encontra-se em vigor. Finalizando sua fala, a Conselheira Tatiana registrou observação referente à aprovação anterior desta matéria. Recordou que, à época, foi discutida a possibilidade de a SEL apoiar a destinação dos móveis substituídos a organizações da sociedade civil (OSCs) interessadas em recebê-los por meio de doação. Destacou que a legislação vigente admite a doação de bens móveis para fins de interesse social, inclusive em favor de organizações da sociedade civil sem fins lucrativos, conforme previsto na Lei nº 14.133/2021, que estabelece que a doação de bens móveis (como equipamentos, móveis de escritório ou veículos) é permitida para fins e uso de interesse social, bem como em normas que regulamentam a destinação de bens públicos inservíveis. Tal prática, segundo observou, é adotada por diversos órgãos da Administração Pública. Ressaltou, ainda, que algumas entidades manifestaram interesse em receber os referidos bens, porém a medida não chegou a ser implementada. Por fim, registrou que as solicitações apresentadas pelas OSCs não receberam resposta oficial da administração, situação que considera importante consignar em ata para fins de acompanhamento e transparência. Sem demais manifestações, o plenário deliberou e de forma unânime aprovou a disponibilização do valor de R$1.798.200,00 para a efetivação de pagamento da aquisição de mobiliários. Programa Trabalho 27.812.6206.4091.5844 APOIO A PROJETOS-FUNDO DE APOIO AO ESPORTE - DISTRITO FEDERAL / Natureza de Despesa: 449052. V. Proc. SEI Nº 00220-00000687/2026-63 – Solicitação de Recurso ASOINFRA (R$24.569.988,75) – Chefe da ASOINFRA Guilherme França; O Sr. Guilherme apresentou uma série de solicitações de recursos para as demandas da ASOINFRA. Após consenso do plenário, a pauta foi dividida nos seguintes tópicos: 1) Solicitação de R$11.500.000,00 (R$6.500.000,00 para manutenção predial em curso e R$5.000.000,00 para renovação contratual até dezembro dos Centros Olímpicos. Aberto a discussão, houve questionamento sobre o valor de R$6.500.000,00 para ações executadas em curto prazo. O Sr. Guilherme explicou que são manutenções pesadas (pintura PU, elétrica, hidráulica) e atendimento a demandas de ouvidoria para evitar interrupção de atividades. A Conselheira Tatiana perguntou se o valor era para pagamento de dívida ou retroativo, questionando a organização administrativa, sendo respondida que o pagamento era para contrato ainda vigente. Após debate, o plenário deliberou e aprovou a matéria por maioria dos votos, registrando-se a abstenção da Conselheira Tatiana, em razão de ponderações decorrentes da ausência de alteração da legislação pertinente, o valor de R$11.500.000,00 sendo R$6.500.000,00 para manutenção predial em curso e R$5.000.000,00 para renovação contratual até dezembro de 2026. Programa Trabalho 27.812.6206.4170.0009 MANUTENÇÃO DE ESPAÇOS ESPORTIVOS - FUNDO DE APOIO AO ESPORTE - DISTRITO FEDERAL / Natureza de Despesa: 339039. 2) Solicitação de R$7.700.00,00 (R$3.900.000,00 para continuidade e R$3.800.000,00 para renovação). A solicitação tem foco na manutenção dos seis estádios e adequação para a Copa do Mundo Feminina, atendendo às exigências da FIFA para os centros de treinamento. O Sr. Guilherme mencionou a importância da conservação do Parque da Cidade, incluindo reformas de banheiros e segurança. Após debate, o plenário deliberou e aprovou com a abstenção da Conselheira Tatiana, o valor de R$7.700.00,00 (R$3.900.000,00 para continuidade e R$3.800.000,00 para renovação) Programa Trabalho 27.812.6206.4170.0009 MANUTENÇÃO DE ESPAÇOS ESPORTIVOS-FUNDO DE APOIO AO ESPORTE - DISTRITO FEDERAL / Natureza de Despesa: 339039. 3) Solicitação de R$90.000,00 para suplementação da reforma da Pista de Atletismo do Estádio Augustinho Lima. O Sr. Guilherme explicou que o valor é devido a uma necessidade que ao iniciar a execução da obra, na etapa de retirada do material que estava degradado na pista, foram identificados alguns pontos que necessitarão de correção de nível para atingir os parâmetros técnicos exigidos pela World Athletics. Após debate, o plenário deliberou e aprovou de forma unânime o valor de R$90.000,00 suplementação da reforma da Pista de Atletismo do Estádio Augustinho Lima. Programa Trabalho 27.812.6206.1079.0026 CONSTRUÇÃO DE ESPAÇOS ESPORTIVOS - FUNDO DE APOIO AO ESPORTE-DISTRITO

FEDERAL / Natureza de Despesa: 449051. 4) Solicitação de R$1.049.988,75 visando a suplementação para a continuação de contrato para Manutenção de alambrados. O serviço prevê a manutenção de alambrado em áreas determinadas, visando a segurança e a organização das dependências de interesse da SEL/DF. Após debate, o plenário conferiu o valor disponível no QDD e aprovou com a abstenção da Conselheira Tatiana, o valor de R$1.021.624,91 Programa Trabalho 27.812.6206.4170.0009 MANUTENÇÃO DE ESPAÇOS ESPORTIVOS-FUNDO DE APOIO AO ESPORTE - DISTRITO FEDERAL / Natureza de Despesa: 339039. 5) Solicitação de R$2.000.000,00 para contratação de empresa para realizar manutenção de grama sintética. O Sr. Guilherme explicou que a ASOINFRA está priorizando a manutenção de campos que apresentam maior desgaste ou perda de funcionalidade, especialmente aqueles onde a base de borracha ou a camada primária de drenagem estão expostas pela ausência total de grama. Nossa estratégia visa restaurar a plena operacionalidade desses espaços. Paralelamente, realizamos manutenções preventivas e reparos pontuais nos demais campos, visando garantir a segurança dos usuários e prevenir lesões. Após debate, o plenário deliberou e aprovou com a abstenção da Conselheira Tatiana, o valor de R$2.000.000,00 para a realização de manutenção de grama sintética. Programa Trabalho 27.812.6206.4091.5844 APOIO A PROJETOS-FUNDO DE APOIO AO ESPORTE - DISTRITO FEDERAL / Natureza de Despesa: 339039. VI. Proc. SEI Nº 00220-00000151/2026-48 – Solicitação de Recurso SUBPEME - 54ª Corrida de Reis - 2027 (R$ 5.000.000,00) – Subsecretário Carlos Pontes; O Subsecretário Carlos Pontes apresentou o planejamento para a Corrida de Reis 2027. Informou que no ano passado, foi solicitado um recurso de R$5 milhões. Para esta 54ª edição — considerando o momento de final de governo e a nossa lógica de planejamento —, projetamos um pequeno ajuste, mas acreditamos que os mesmos R$5 milhões sejam suficientes para a realização do evento. Adiantando o status do processo: incluímos a discussão jurídica para a formalização do evento e o documento já está sob análise da Procuradoria. Esperamos um retorno nos próximos dias para definir se a corrida será viabilizada via termo de fomento/colaboração ou se precisaremos seguir por meio de licitação. Aberto o debate, a conselheira Tatiana pediu a palavra e esclareceu que, em relação aos questionamentos apresentados acerca da contratação para a realização da Corrida de Reis, a Subsecretaria foi orientada, em análise preliminar, a promover procedimento licitatório para a execução do evento. Em razão dessa orientação e considerando a necessidade de segurança jurídica quanto ao modelo de contratação a ser adotado, foi formulada consulta à Procuradoria-Geral do Distrito Federal, com o objetivo de obter manifestação acerca da obrigatoriedade ou não de realização de processo licitatório para a execução da Corrida de Reis. A conselheira ressaltou que o projeto constitui política pública consolidada da Secretaria e que a legislação vigente oferece respaldo para sua execução. Ainda assim, sugeriu que constasse em ata o compromisso da Subsecretaria de observar integralmente o entendimento jurídico a ser emitido pela Procuradoria. Em seguida, o Subsecretário Carlos confirmou que a Subsecretaria adotará integralmente às recomendações, orientações e procedimentos que vierem a ser expressamente indicados pela Procuradoria-Geral do Distrito Federal para a contratação e execução da Corrida de Reis. Sem demais manifestações, o plenário deliberou e aprovou de forma unânime a solicitação de recurso para a 54ª Corrida de Reis - 2027. Programa Trabalho 27.812.6206.4091.5844 APOIO A PROJETOS - FUNDO DE APOIO AO ESPORTE-DISTRITO FEDERAL / Natureza de Despesa: 339039. VII. Proc. SEI Nº 00220-00005401/2026-36 - Apresentação do Parecer de análise do Plano de Trabalho do Instituto Social Carla Ribeiro – ISCR, para o projeto “Formando Campeões – Artes Marciais e Desenvolvimento Social” (R$894.502,00) – Conselheiro Marcelo Magalhães; O Conselheiro Relator submeteu à apreciação o parecer referente à análise do plano de trabalho do Instituto Social Carla Ribeiro (ISCR) para o projeto "Formando Campeões: Arte Marcial no Desenvolvimento Social", cujo montante pleiteado é de R$894.502,00. O relator iniciou esclarecendo que a apresentação deste documento foi postergada na última reunião, por sua solicitação, a fim de garantir que a natureza da proposta estivesse em total consonância com o texto apresentado, evitando interpretações equivocadas ou entraves processuais. Ressaltou que o processo passou por ajustes significativos após apontamentos, resultando na adequação do nome do projeto, bem como na revisão dos valores originalmente solicitados. O projeto possui um caráter híbrido, fundamentando sua inexigibilidade de chamamento público tanto na exclusividade da metodologia "Formando Campeões" para o kickboxing, chancelada pela respectiva federação, quanto na natureza socioassistencial da entidade, que detém as certificações necessárias junto aos órgãos competentes. Embora a fundamentação esportiva esteja clara e lastreada em declaração de exclusividade, reconheço que a vertente assistencial do projeto pode suscitar debates sobre a modalidade de dispensa ou inexigibilidade conforme a legislação vigente, ponto que deixo à reflexão deste conselho. O Instituto encontra-se com o CRC regularizado, sob a presidência de Alessandra Melo Ribeiro de Oliveira, e apresenta uma proposta voltada ao atendimento de cem beneficiários diretos e quatrocentos indiretos, na faixa etária de 9 a 21 anos, na Asa Sul e no Núcleo Rural Lago Oeste. O plano de trabalho prevê atividades contínuas três vezes por semana, incluindo o acompanhamento psicossocial, ações complementares como seminários, torneios, exames de faixa e o clube do livro, além da inclusão expressa de, no mínimo, 10% de vagas destinadas a pessoas com deficiência e transtorno do espectro autista. Cabe destacar que, após minhas ressalvas sobre os custos de recursos humanos, a entidade realizou uma revisão criteriosa da

<!-- pagina 27 -->

planilha orçamentária, ajustando os quantitativos e serviços para garantir a razoabilidade da execução, retirando itens não essenciais e mantendo apenas o indispensável ao funcionamento. Diante do exposto, e considerando que o esporte atua como carro-chefe da metodologia de inclusão social e redução de vulnerabilidade, meu parecer é favorável à aprovação do projeto, reconhecendo a capacidade técnica e o alinhamento da proponente às diretrizes de assistência social e esporte, permanecendo, contudo, à disposição para dirimir dúvidas e promover o debate necessário entre os conselheiros e a representante da instituição aqui presente. Aberto a discussão, a Conselheira Tatiana questionou os locais de execução do projeto e a ampliação das modalidades oferecidas, sendo respondido pela presidente da entidade, que participou da reunião de forma remota, que o projeto prevê a extensão das atividades para dois locais: Asa Sul (que já opera o projeto) e Lago Oeste (novo local) e que a ampliação refere-se especificamente ao kickboxing. A menção ao jiujitsu no plano de trabalho antigo causou confusão, por isso foi retirado esse termo do nome, mas a proponente reiterou que o foco do novo fomento é a oferta de 100 novas vagas voltadas ao kickboxing, mantendo o jiu-jitsu apenas como oferta complementar onde já é realizado. A Conselheira Tatiana continuou pontuando que a Nota Técnica Nº 84/2026 - SEL/SUCOP/UCP atual ainda se refere ao objeto e valores do projeto anterior, divergindo do novo montante e da nova configuração de locais e modalidades. Sobre a estratégia de Busca Ativa, a Conselheira questionou a necessidade de custeio (R$5 mil mensais) para busca ativa de beneficiários, uma vez que a entidade afirmou já possuir 100 beneficiários e uma lista de espera de 150 crianças. A proponente justificou que é para ajudar na triagem socioeconômica, onde trata-se de um termo utilizado na LOAS para fazer as visitas domiciliares com o objetivo de confirmar se os jovens que estão na lista são realmente enquadrados como de vulnerabilidade social, e localizar os que fazem parte da rede de proteção, os mais vulneráveis, e que no máximo, uma assistente social acompanha 70 famílias, daí como são 100 beneficiados é uma ajuda importante, mas a transparência desta contratação foi contestada. Sobre os custos de RH e Limpeza, observou que os salários propostos (ex: Assistente Social) estão acima dos valores de mercado. Além disso, o pagamento de diárias de limpeza foi considerado incompatível com a natureza continuada (12 meses) do projeto. A Conselheira Tatiana ainda discutiu sobre a classificação da iniciativa. Reforçou que, perante a legislação, deve ser classificada como Esporte de Participação, e não como projeto de "assistência social", termo que tem gerado imprecisões técnicas. Concluiu enfatizando que, embora a metodologia "Formando Campeões" possa ter sido desenvolvida pela entidade, isso não confere exclusividade para a execução de escolinhas de artes marciais, não sendo critério suficiente para dispensa de chamamento público (inexigibilidade). A Conselheira Carla solicitou a palavra e esclareceu que a Nota Técnica focou estritamente na questão da inexigibilidade, baseada na metodologia e na exclusividade do projeto "Formando Campeões", e que a exigibilidade é com relação ao kickboxing e não com relação a valores, sendo que a fundamentação utilizou como base a exclusividade reconhecida pela própria Federação de Kickboxing, que acompanha as atividades do projeto há 20 anos; quanto à confusão sobre a inclusão de Jiu-Jitsu e Kickboxing, reforço que a entidade já oferece Jiu-Jitsu como projeto continuado, mas a proposta em análise para o Conselho foca exclusivamente no Kickboxing, de modo que a mudança de nomenclatura do Plano de Trabalho não altera o declarado na Nota Técnica, pois o nome foi alterado devido às dúvidas que suscitaram no relator, mantendo o objeto social inalterado. Sobre a alimentação, o valor apresentado reflete uma pesquisa de mercado regionalizada, e que será conferida quando da análise de preços tratando-se de uma dieta balanceada uma marmita com suco de fruta natural, enquanto a estrutura de custos de pessoal, como o valor de referência de R$ 5.500 para assistentes sociais, está inclusive abaixo dos valores de Brasília, pois trata-se do preço total a ser pago sem os custos com encargos sociais, os quais certamente quase dobrariam o valor, o que justifica a variação orçamentária frente a contratações formais. Esclareço que a "Busca Ativa" é um termo técnico previsto na legislação, especificamente na LOAS, para garantir que os beneficiários estejam em situação de vulnerabilidade, exigindo que a equipe técnica realize visitas domiciliares e perícias sociais para validar a elegibilidade de cada jovem e assegurar o cumprimento dos critérios assistenciais exigidos pelos órgãos de controle. O projeto além de atender os critérios exigidos pelo CONFAE de exclusividade, vide Nota Técnica, também está amparado pelo Art. 30, inciso IV, da Lei 13.019/2014, que faculta à administração pública dispensar o chamamento público para atividades vinculadas a serviços de saúde, educação e assistência, desde que executadas por organizações previamente credenciadas, como é o caso Proponente, que possui títulos de utilidade pública Federal e Distrital e registros no CRAS e no Conselho da Criança e do Adolescente do DF, configurando a dispensa de licitação como uma prerrogativa legal e não uma irregularidade. E encontra amparo legal no Princípio da Supremacia da Assistência Social prevista em Lei, Princípio da Prioridade Absoluta da criança e do adolescente previsto no artigo 227 da Constituição, além de entendimentos dos tribunais. A metodologia "Formando Campeões" é reconhecida e premiada pelo UNICEF, possuindo um histórico de 23 anos de eficácia. Sobre os itens operacionais como diárias de faxina é para manter a limpeza do local, o que sempre foi aprovado aqui no Confae, assim como assessoria contábil, trata-se de obrigações de transparência e manutenção básica que qualquer entidade idônea deve prever, reforçando que a cessão do local de atendimento é uma contrapartida da própria entidade, representando um investimento significativo não incluído no valor total solicitado ao

governo. Por fim, quanto à manifestação verbal de um Conselheiro no Plenário do Confae vinculado a uma Proponente, não há impedimento legal, visto que a vedação legal limitase ao voto e à relatoria em casos de conflito direto de interesse. O Conselheiro Christiano orientou a juntada de documentação comprobatória da metodologia de ensino apresentada, visando à sua validação técnica e ao fortalecimento da capacidade operacional da entidade. Sem demais manifestações, o plenário deliberou e em votação nominal, votaram pela diligência: Conselheiros José Antônio, Christiano, Paulo; Votaram pelo indeferimento: Conselheira Tatiana; Votaram pelo deferimento: Conselheiros Marcelo e Luiz Carlos. Se absteve: Conselheira Carla. Dessa forma, foi aprovada a concessão de até 60 (sessenta) dias corridos, contados a partir da comunicação oficial da DIGEFAE, para que a entidade sane as inconsistências apontadas no parecer técnico e atenda às demais solicitações deste Conselho, conforme segue: a) Correção de erros materiais e inconsistências apontadas no parecer técnico; b) Detalhamento da modalidade esportiva (esporte de participação, rendimento ou educacional), conferindo expressa clareza à natureza do projeto; c) Revisão geral do plano de trabalho para alinhamento com a nova nota técnica a ser emitida pela área técnica da SEL. Concomitantemente, o processo será encaminhado à AJL para manifestação técnica específica quanto aos seguintes quesitos: a) Análise sobre a vinculação (ou não) de certificações externas como a Certificado de Entidade Beneficente de Assistência Social (CEBAS) e o Benefício de Prestação Continuada (BPC), previsto na Lei Orgânica da Assistencia Social (LOAS), ao enquadramento de entidades para fins de celebração de convênios/contratos, nos termos da legislação vigente. b) Parecer jurídico sobre a aplicabilidade de tais certificações como critérios de elegibilidade no âmbito das competências deste Conselho, distinguindo-as das exigências da legislação esportiva específica. A decisão visa sanear dúvidas remanescentes sobre o enquadramento de entidades assistenciais e garantir a segurança jurídica do rito, sem prejuízo da análise meritória do projeto, que será retomada após o cumprimento das diligências. A Conselheira Tatiana manifestou, adicionalmente, preocupação quanto à observância dos princípios constitucionais da administração pública durante esta sessão. Solicitou que a AJL avalie se a defesa direta e não formalizada do projeto, realizada nesta oportunidade pela Conselheira Carla (que está afastada da presidência do Instituto Social Carla Ribeiro), compromete o princípio da impessoalidade e se tal procedimento possui o condão de viciar a presente votação. Nesta oportunidade, a Conselheira Carla pediu a palavra e manifestou-se no sentido de que a Conselheira Tatiana, em diversas ocasiões anteriores neste colegiado, pronunciou-se em defesa de projetos aos quais estava vinculada, incluindo sua própria representação, bem como projetos de Futsal e Jogos Escolares quando foi parceira. Destacou, portanto, que não há obstáculo legal ou regimental que impeça os Conselheiros de se manifestarem em defesa de entidades com as quais possuem vinculação, sob pena de violação do princípio constitucional da igualdade. Ressaltou ainda que sua condição de afastada da presidência do Instituto Social Carla Ribeiro não extingue seu direito de voz como membro deste colegiado, e que a manifestação de conselheiros integra legitimamente o processo deliberativo, não constituindo vício de votação. Em seguida, a Conselheira Tatiana pediu a palavra para esclarecer que, em nenhum momento, nas ocasiões mencionadas, apresentou defesa de projetos vinculados à sua pessoa ou a entidades com as quais mantivesse vínculo direto. Destacou que suas manifestações no âmbito deste colegiado sempre se limitaram a responder questionamentos formulados pelos demais conselheiros, prestar esclarecimentos técnicos ou apresentar considerações pertinentes aos debates em plenário, quando solicitada ou quando entendia necessário para o adequado esclarecimento da matéria em discussão. Ressaltou, ainda, que tais intervenções não se confundem com a defesa direta de projetos específicos, mas constituem contribuições ao processo deliberativo, com o objetivo de subsidiar as discussões e promover a adequada compreensão dos temas submetidos à apreciação do colegiado. Após a deliberação do item anterior, o presidente Renato Junqueira precisou ausentar-se por motivos de força maior. O vice-presidente, Conselheiro José Antônio, assumiu a presidência da reunião e deu continuidade aos demais itens da pauta. VIII. Proc. SEI Nº 00220-00004896/2026-86 - Apresentação do Parecer de análise de Solicitação de CRC da Unidade Nacional de Acessibilidade - UNA – Conselheira Tatiana Mendes; A Relatora apresentou parecer técnico opinativo referente à análise do pedido de CRC da Unidade Nacional de Acessibilidade (UNA). Em sua análise, relatou que a instrução processual encontra-se prejudicada por inconsistências documentais e divergências entre os pleitos apresentados. Inicialmente, a entidade protocolou requerimento de renovação sem a juntada do certificado anteriormente emitido e, na sequência, apresentou requerimento geral autodeclarando-se organização de assistência social, contudo, sem a devida comprovação por meio de documentação pertinente como CEBAS ou CAS. A análise estatutária revelou a presença de três versões distintas do estatuto social nos autos, sem indicação clara de qual instrumento está vigente, observando-se ainda a falta de ata de criação, a omissão de valores em declaração de recursos públicos e o preenchimento incompleto de campos essenciais no formulário administrativo. Tais falhas, somadas à desorganização do acervo probatório, comprometem a segurança jurídica da análise e impedem a verificação dos requisitos regulamentares necessários para a concessão do certificado. Diante do exposto e da impossibilidade de saneamento dos vícios processuais, manifesto-me pelo indeferimento do pedido e pelo arquivamento do feito, ressalvado à entidade o direito de protocolar novo requerimento, desde que devidamente instruído com a documentação

<!-- pagina 28 -->

completa, atualizada e organizada de acordo com as normas vigentes. Aberto a discussão, o Conselheiro José Antônio acrescentou que após sua análise previa, o Estatuto Social não preencheria os formulários I e II, complementando que em sua visão, essa entidade não é assistencial e sim esportiva, tanto que já teve recurso liberado por emenda parlamentar por está secretaria. Submetida a matéria à votação, o Plenário aprovou por unanimidade o indeferimento da solicitação de CRC/CONFAE. Conforme o Decreto 34.522/13, Resolução nº 01/2024 e do Edital de Chamamento nº 01/2024, a entidade dispõe do prazo de 10 (dez) dias corridos para interposição de recurso, contados a partir da publicação oficial no DODF e da devida notificação por parte da DIGEFAE. IX. Proc. SEI Nº 00220- 00006718/2026-90 - Apresentação do Parecer de análise de Solicitação de CRC do Brasília Vôlei Esporte Clube - BVEC – Conselheira Tatiana Mendes. A relatora apresentou seu parecer opinativo onde após análise dos autos, verificou inconsistências documentais que comprometem a segurança jurídica e a instrução processual, notadamente a ausência da página de averbação da ata de eleição e a apresentação de ata de prestação de contas contendo apenas reconhecimento de firma, documento insuficiente para comprovar a regularidade registral do ato. Diante disso, e resguardada a prerrogativa técnica de buscar a verdade material, voto pela realização de diligência para que a entidade apresente a ata de prestação de contas e a ata de eleição devidamente registradas e averbadas pelo cartório competente, bem como certidão simplificada emitida pelo Registro Civil de Pessoas Jurídicas Marcelo Ribas, contendo o histórico e a indicação do Estatuto Social vigente, sob pena de indeferimento e encerramento do processo em caso de descumprimento do prazo estabelecido. Aberto a discussão, o Conselheiro José Antônio, pontuou que a concessão de prazo neste momento seria inócua, dado o histórico de inconsistências constatadas. Em diversos processos análogos, observou a ausência de documentos essenciais, a apresentação de documentos parciais sem o devido registro em cartório e a falta da prestação de contas obrigatória. Além disso, o que se apresenta como 'renovação' não possui tal natureza, configurando um cenário de fragilidade documental. Reforço a importância da autotutela administrativa e da busca pela verdade material — e não apenas a formal. Após análise criteriosa do Estatuto Social, constatei que ele não atende às exigências dos formulários I e II. Portanto, conceder um prazo de 60 dias para diligências seria uma medida protelatória, pois o vício documental persistiria. Diante do exposto, entendo que a medida correta não é o sobrestamento para saneamento, mas sim o indeferimento direto. Tal decisão deve fundamentar-se no descumprimento dos requisitos previstos no artigo 15 da Lei nº 3.452, alínea 'f' (que inclui a prestação de contas). Reitero, conforme estabelece o Código Civil (artigo 1.152), que a documentação, para produzir efeitos perante terceiros, deve estar devidamente registrada no Cartório de Registro de Pessoas Jurídicas ou na Junta Comercial. Após o debate, o plenário deliberou e aprovou por maioria dos votos, com voto pelo indeferimento dos Conselheiros José Antônio e Christiano, o parecer da relatora pela diligência de até 60(sessenta) dias corridos, contados a partir da comunicação oficial pela DIGEFAE, para que a entidade sane as inconsistências e apresente a documentação completa apontada no parecer da relatora, em conformidade com a legislação vigente, sob pena de indeferimento caso não apresente dentro do prazo estabelecido, conforme rege a Resolução nº 01/2024 e o Edital de Chamamento CONFAE 01/2024. X. Proc. SEI Nº 00220-00003059/2026-30 - Minuta de Projeto de Lei Complementar - Conselheiro José Antônio; O Conselheiro José Antônio registrou que a Conselheira relatora, Tatiana, realizará as observações necessárias na proposta da nova lei. Posteriormente, será submetida o texto à comissão para que, em seguida, seja encaminhado diretamente à AJL, otimizando o fluxo de trabalho e evitando pautas desnecessárias no plenário. Vale ressaltar que os ajustes solicitados pela AJL são meramente formais e de adaptação à técnica legislativa — como a organização em capítulos e adequação ao normativo vigente — e não alteram o entendimento ou o mérito da proposta. Já estamos revisando esses pontos e, tão logo finalizamos o 'dever de casa', encaminharemos o material à comissão. XII. Edital de Chamamento - Conselheiro José Antônio; O Conselheiro José Antônio informou que, com o auxílio do Conselheiro Christiano e após a conclusão do curso de IA que está sendo realizado na presente data da reunião, apresentará o Edital de Chamamento em tempo hábil, para apreciação do Conselho. Assim, sem mais nada a tratar o Sr. vice-presidente relembrou que a próxima reunião extraordinária será realizada no dia 23 de junho de 2026, agradeceu a presença de todos, e encerrou a reunião às 17h37, eu Gabriel da Silva Felix, assessor da DIGEFAE, lavrei a presente ata, que vai assinada pelo Presidente do CONFAE e demais Conselheiros. Com efeito, informa-se, que no dia 18 de junho de 2026 foi exonerado o servidor Conselheiro Titular LUIZ CARLOS DE SOUZA, Representante da Secretaria de Estado de Economia, conforme Decreto publicado no Diário Oficial do dia 18 de junho de 2026, Edição Extra, página 1. Por esse motivo, o Senhor LUIZ CARLOS DE SOUZA não assinará a presente Ata. RENATO JUNQUEIRA, Presidente do Conselho, Secretário de Estado de Esporte e Lazer; JOSÉ ANTÔNIO SOARES SILVA, Vice Presidente do Conselho, Conselheiro Titular, Representante das Associações de Federações Desportivas do Distrito Federal; CHRISTIANO DE ALMEIDA NUNES, Conselheiro Titular, Representante da Secretaria de Estado de Esporte e Lazer; PAULO EDUARDO DA SILVA, Conselheiro Titular, Representante da Secretaria de Estado de Economia; MARCELO MAGALHÃES SILVA, Conselheiro Titular, Representante da Secretaria de Estado de Educação; TATIANA WEYSFIELD MENDES, Conselheira Titular, Representante do Esporte Universitário; CARLA RIBEIRO TESTA, Conselheira Titular,

Representante dos Atletas; SANDRA SANTOS RAMOS, Chefe do Núcleo de Administração do Fundo de Apoio ao Esporte; JOSIANNE TARGINE DA SILVA, Chefe do Núcleo de Gestão do Fundo de Apoio ao Esporte; GABRIEL DA SILVA FELIX, Assessor da Diretoria de Gestão do Fundo de Apoio ao Esporte; YARA LOPES CONDE MARTINS, Diretora de Gestão do Fundo de Apoio ao Esporte.

## SECRETARIA DE ESTADO DO MEIO AMBIENTE

EXTRATO DA DECISÃO Nº 106/2026 - SEMA/GAB/AJL Processo nº 00391-00006463/2025-59. Autuado (a): TOME FERNANDES GASTRO BAR LTDA (Bar do Véio Chico – Boteco Véio Chico II). Objeto: Auto de Infração nº 12479/2025. Decisão: CONHECER e NEGAR PROVIMENTO ao recurso interposto, com a manutenção integral da Decisão n.º 223/2026 – IBRAM/PRESI/CIJU/CTIA, que julgou procedente o Auto de Infração Ambiental n.º 12479/2025, lavrado com fundamento nos artigos 2º e 7º da Lei Distrital n.º 4.092/2008, preservando-se a penalidade de ADVERTÊNCIA POR ESCRITO aplicada ao autuado. A penalidade encontra-se prevista no inciso I, art. 16, da Lei Distrital 4092, de 30 de janeiro de 2008. NOTIFICAR a recorrente do julgamento e de sua fundamentação, bem como do prazo de 05 (dias), a contar da data da ciência do presente ato decisório, para a interposição de recurso ao Conselho de Meio Ambiente do Distrito Federal – CONAM/DF, com fulcro no parágrafo único do art. 60 da Lei distrital nº 41/1989.

RAFAEL SANTANA

Secretário de Estado

### CONSELHO DO MEIO AMBIENTE

### DO DISTRITO FEDERAL CÂMARA JULGADORA DE AUTOS DE INFRAÇÃO

JULGAMENTO - SEMA/GAB/ASPOL PROCESSO Nº: 00391-00000981/2024-88. INTERESSADO: Figueiredo e Perrusi Comércio de Veículos Ltda. PROCURADOR: Marisa Tavares Barros Paiva de Moura - OAB/PE 23.647. ASSUNTO: Auto de Infração Ambiental nº AI 10710/2024. RELATOR: Natalia Cristina Chagas Mendes Teixeira – SO/DF. EMENTA: Direito Administrativo e Ambiental. Lei Distrital n° 041/1989. Decreto Distrital n° 37.506/2016. Atividade potencialmente poluidora. Lavagem de veículos sem infraestrutura adequada. Reincidência. Autoria e materialidade comprovadas. Recurso

conhecido еparcialmente provido. Diligência ao IBRAM/DF.

RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido e provido parcialmente o Recurso apresentado, mantendo a penalidade de advertência e reformando a Decisão n.º 81/2025 - SEMA/GAB/AJL (174749292) quanto à multa, fixando-a no valor de R$ 4.881,50 (quatro mil oitocentos e oitenta e um reais e cinquenta centavos), em atenção aos parâmetros de atenuidade e à gravidade da reincidência, pelo enquadramento da autuação na condicionante do § 2º do Art. 49 da Lei nº 41, de 13 de setembro de 1989, por: "Deixar, aquele que tiver o dever legal ou contratual de fazê-lo, de cumprir obrigação de interesse ambiental ao oferecer serviço de lavagem automotiva sem observar o estabelecido nas normas ABNT NBR 14.605 (partes 1, 2, 3, 4, 5 e 6) no que diz respeito à instalação de canaletas e ao Sistema Separador Água e Óleo (SSAO)." Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL PROCESSO Nº: 00391-00001579/2023-30. INTERESSADO: Departamento Nacional de Infraestrutura de Transportes- DNIT. PROCURADOR: Luiz Guilherme Rodrigues de Mello – Diretor. ASSUNTO: Auto de Infração Ambiental nº AI 9559/2023. RELATOR: Lucas Mendonça Takaki – CACI/DF. EMENTA: Direito Ambiental e Administrativo. Auto de Infração nº 09559/2023. Lei Distrital nº 41/1989. Lei Complementar nº 140/2011. Recurso Administrativo ao CONAM/DF. Ausência de fatos ou argumentos novos. Manutenção da decisão de segunda instância. RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo, por atendidos os pressupostos de admissibilidade; e desprovido o recurso, com a manutenção integral da Decisão nº 27/2025-SEMA/GAB/AJL e da Decisão nº

<!-- pagina 29 -->

395/2023-IBRAM/PRESI/CIJU/CTIA, confirmando a procedência do Auto de Infração nº 09559/2023 e preservando as penalidades de advertência e multa no valor de R$ 51.151,45 (equivalente a 101 UPDFs/2023). Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL

PROCESSO Nº: 00391-00002291/2025-44. INTERESSADO: Leomar Cenci. PROCURADOR: o mesmo. ASSUNTO: Auto de Infração Ambiental nº AI 6352/2025. RELATOR: Arildo Ribeiro Jorge – OAB/DF.

EMENTA: Recurso Administrativo. Direito Ambiental Distrital. Lei Distrital nº 041/1989. Decreto Distrital nº 37.506/2016. Descumprimento de condicionantes. Licença Operação nº 167/2022. Instalação e operação de pivô central sem licenciamento específico. Armazenamento inadequado de agrotóxicos e ausência de comprovação de devolução de embalagens e óleos usados. Materialidade e autoria plenamente. Preclusão temporal. Natureza formal e instantânea da Infração Ambiental. A regularização tardia não extingue a punibilidade nem retroage para sanar o ilícito consumado. Manutenção integral das penalidades de advertência e multa simples. Recurso conhecido e, no mérito, improvido.

RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto e, no mérito, não provido, mantendo-se íntegra a Decisão nº 630/2025-IBRAM/PRESI/CIJU/CTIA e as penalidades aplicadas no Auto de Infração nº 06352/2025, com a consequente manutenção da multa no valor de R$ 5.514,00 (cinco mil, quinhentos e catorze reais) - 10 UPDF's 2025. Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL PROCESSO Nº: 00391-00003199/2022-59. INTERESSADO: Emerson Francisco da Silva. PROCURADOR: Marcelo Almeida Alves – OAB/DF Nº 34.265 e Júlio Cézar Prates - OAB/DF Nº 58.766. ASSUNTO: Auto de Infração Ambiental nº AI 04862/2022. RELATOR: Glenda Evellyn Bispo – OAB/DF. EMENTA: Direito Ambiental. Transgressão do inciso XX, do artigo 54 da Lei nº 41/89. Aterro. Poda. Intervenção em Área de Preservação Permanente. Atividade sem autorização ambiental. Recurso conhecido e desprovido. RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido e desprovido o Recurso Administrativo interposto pela Senhor Emerson Francisco da Silva, confirmando integralmente a Decisão n.º 51 (114192617), que confirmou a Decisão n.º 554 (88799318), que julgou procedente o Auto de Infração Ambiental nº 04862/2022 (84112814), mantendo-se as penalidades de advertência a recuperar a área onde foi realizado o aterro nos termos da IN 33/2022 do IBRAM, fixado o prazo de 120 (cento e vinte) dias da ciência da decisão de julgamento para iniciar o procedimento junto ao IBRAM e multa no valor de R$ 48.269,92 (quarenta e oito mil duzentos e sessenta e nove reais e noventa e dois centavos - 101 UPDF's 2022, por transgressão ao art. 54, inciso XX, da Lei Distrital nº 41, de 13 de setembro de 1989. Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL PROCESSO Nº: 00391-00003492/2025-69. INTERESSADO: Lucio Parrode Badauy – Madeireira Itapema Ltda. PROCURADOR: o mesmo. ASSUNTO: Auto de Infração Ambiental nº AI 05678/2025. RELATOR: Rosangela Isolde Fricke – CREA/DF. EMENTA: Direito Ambiental e Direito Administrativo. Produtos Florestais. Sistema DOF e DOF+ rastreabilidade. Divergência entre estoque físico e estoque declarado nos sistemas oficiais de controle. Infração prevista no art. 47 do Decreto Federal nº 6.514/2008. Alegação de ausência de apreciação das atenuantes previstas na Lei Distrital nº 41/1989. Impossibilidade de redução da multa em desconformidade com o regime sancionatório federal aplicável à infração. Autoria e materialidade comprovadas. Recurso conhecido e desprovido. Manutenção da decisão de segunda instância e da penalidade de multa.

RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto por Lúcio Parrode Badauy, representante legal da Madeireira Itapema Ltda., e no mérito, negar-lhe provimento, mantendo integralmente a Decisão nº 199/2025 – SEMA/GAB/AJL e, consequentemente, o Auto de Infração Ambiental nº 05678/2025 e a multa aplicada. Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL PROCESSO Nº: 00391-00004710/2024-00. INTERESSADO: BSB Comercialização de Carnes Nobres e Churrascaria LTDA. PROCURADOR: Thiago de Sousa Barros - OAB/MA 9.839. ASSUNTO: Auto de Infração Ambiental nº AI 11807/2024. RELATOR: Natália Cristina Chagas Mendes Teixeira – SO/DF. EMENTA: Direito Ambiental e Direito Administrativo. Poluição sonora. Transgressão aos artigos 2º e 7º, c/c art. 16, inciso I, da Lei distrital nº 4.092/2008. Recurso conhecido e desprovido. Decisão de primeira e segunda instâncias confirmadas. Manutenção da penalidade de advertência. RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso final interposto e, no mérito, negar-lhe provimento. Ficando mantida integralmente a Decisão nº 32/2025 - SEMA/GAB/AJL (170248951) e, por conseguinte, a penalidade de advertência por escrito aplicada à empresa BSB Comercialização de Carnes Nobres e Churrascaria Ltda. "Perturbar o sossego e o bem estar da população com emissão de sons acima do permitido em lei, foi constatado em 03/05/2024 às 14:23h Laeq de 65,1dB quando o permitido para a área seria de 50dB, digo 55dB (diurno). O ruído é proveniente de sistema de exaustão." Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

JULGAMENTO - SEMA/GAB/ASPOL

PROCESSO Nº: 00391-00012427/2023-62. INTERESSADO: Responsa Bar e Restaurante comercio de alimentos LTDA. PROCURADOR: Eduardo Serra Rossigneux Vieira – OAB/DF 29.370. ASSUNTO: Auto de Infração Ambiental nº AI 5748/2023. RELATOR: Rosangela Isolde Fricke – CREA/DF.

EMENTA: Direito Ambiental e Direito Administrativo. Poluição sonora. Emissão de sons e ruídos acima dos limites legais. Infração aos artigos 2º e 7º da Lei Distrital nº 4.092/2008. Auto de Infração Ambiental. Alegação de nulidade por vícios formais. Questionamento da metodologia de medição e da classificação da área. Aplicação da ABNT NBR 10.151. Autoria e materialidade comprovadas. Presunção de legitimidade dos atos administrativos. Recurso conhecido e desprovido. Manutenção da decisão de segunda instância, da advertência e da multa.

RESULTADO: Acordam os membros da Câmara de Julgamento de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal - CONAM, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto por Responsa Bar e Restaurante Comércio de Alimentos Ltda. e no mérito, negar-lhe provimento, mantendo integralmente a Decisão nº 49/2025 – SEMA/GAB/AJL e, consequentemente, o Auto de Infração Ambiental nº 05748/2023, bem como as penalidades de advertência e multa aplicadas. Publique-se, Notifique-se.

ISRAEL DOURADO GUERRA

Presidente da Câmara

### INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS

### HÍDRICOS - BRASÍLIA AMBIENTAL

SECRETARIA EXECUTIVA

DECISÃO Nº 66/2026 - IBRAM/PRESI O SECRETARIO EXECUTIVO, DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, no uso das atribuições que lhe são conferidas pelo artigo 61 do Decreto nº 39.558, de 20 de dezembro de 2018, e pela delegação de competências prevista na Instrução nº 38, de 11 de fevereiro de 2025, resolve: CANCELAR a Licença de Operação 10/2024 (132918927), para a atividade ENTREPOSTO DE OVOS FÉRTEIS E UNIDADE DE PINTO DE 1 DIA

<!-- pagina 30 -->

(INCUBATÓRIO), realizada na QUADRA 800 LOTE 01 – RECANTO DAS EMAS/DF, de interesse de PLUMA AGROAVÍCOLA LTDA, CNPJ: 04.656.883/0035-92, a pedido do interessado, por decisão de não dar continuidade à atividade, conforme Carta (204001423). Publique-se e notifique-se o interessado.

VALTERSON DA SILVA

SUPERINTENDÊNCIA DE LICENCIAMENTO, CONTROLE E MONITORAMENTO AMBIENTAL

DECISÃO Nº 55/2026 - IBRAM/PRESI/SULAM A SUPERINTENDENTE DE LICENCIAMENTO, CONTROLE E MONITORAMENTO AMBIENTAL, DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, no uso das atribuições que lhe são conferidas pela Instrução Normativa nº 11, de 18 de junho de 2025, e em conformidade com a Resolução CONAMA nº 237/1997, decide: Art. 1º Indeferir o requerimento de Licença de Operação, no processo 00391- 00019633/2017-55, para a atividade de Transporte Rodoviário de Cargas Perigosas, localizado no endereço SHVP rua 01 chácara 25 Quadra, E lote 03 e de interesse de SIGMA LOCAÇÃO DE MAQUINAS E SERVIÇOS DE TERRAPLANAGEM - EIRELI, CNPJ: 20.XXX.XXX/0001-87. Art. 2º Fica garantido efeito suspensivo da presente Decisão junto ao processo de licenciamento, mediante recurso protocolado no prazo estabelecido pela Instrução Normativa nº 11, de 18 de junho de 2025. Art. 3º Esta Decisão entra em vigor na data de sua publicação.

NATHÁLIA ALMEIDA

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO

## ECONÔMICO, TRABALHO E RENDA

### COMPANHIA IMOBILIÁRIA DE BRASÍLIA

AGÊNCIA DE DESENVOLVIMENTO DIRETORIA DE REGULARIZAÇÃO SOCIAL E

DESENVOLVIMENTO ECONÔMICO

ATOS DA DIRETORIA COLEGIADA

SESSÃO: 3943ª; Realizada em: 17/06/2026; Relator: FERNANDO DE ASSIS BONTEMPO - Processo: 0160-001455/2000; Interessado: ALKIMIM & ALKIMIM DEPÓSITO DE BEBIDAS, PESCA E CAMPING LTDA ME - Decisão nº: 483/2026. A Diretoria Colegiada, acolhendo o voto do relator, decide: a) autorizar a celebração de Escritura Pública de Compra e Venda (Definitiva) entre a TERRACAP e a empresa concessionária ALKIMIM & ALKIMIM DEPÓSITO DE BEBIDAS, PESCA E CAMPING LTDA ME - CNPJ nº 03.***.***/****-22 referente ao imóvel nº 507319-7 , denominado Lote 15, Conjunto "I", Setor de Múltiplas Atividades - Gama/DF, no âmbito do Programa de Desenvolvimento Econômico PRÓ/DF II, com desconto de 80% (oitenta por cento) sobre o valor de aquisição, conforme determinado no Atestado de Implantação Definitivo PRÓ/DF II Nº 16/2026 retificado, expedido pela Secretaria de Estado de Desenvolvimento Econômico, Trabalho e Renda do Distrito Federal.

FERNANDO DE ASIS BONTEMPO

Diretor de Regularização Social e Desenvolvimento econômico

ELIZEU ELIEL DA SILVA Gerente de Desenvolvimento Econômico

ATOS DA DIRETORIA COLEGIADA

SESSÃO: 3943ª; Realizada em: 17/06/2026; Relator: FERNANDO DE ASSIS BONTEMPO - Processo: 0160-002170/2000; Interessado: FERREIRA & BEZERRA LTDA ME - Decisão nº: 484/2026. A Diretoria Colegiada, acolhendo o voto do relator, decide: a) autorizar a celebração do Contrato de Concessão de Direito Real de Uso com Opção de Compra (CDRU-C) entre a TERRACAP e a empresa FERREIRA & BEZERRA LTDA ME- CNPJ nº 03.***.***/****-83, tendo por objeto o imóvel nº 507560-2, denominado Lote 08, Conjunto "W", Setor de Múltiplas Atividades - Gama/DF, pelo prazo de 36 meses, em observância ao disposto no art. 6º e art. 7º, inc. I, da Lei Distrital nº 4.269/2008, conforme Resolução nº 425/2002, bem como observado o que dispõem o art. 11 da Lei Distrital nº 6.468/2019, e ainda o disposto na Lei Distrital nº 7.153/2022.

FERNANDO DE ASIS BONTEMPO

Diretor de Regularização Social e Desenvolvimento Econômico

ELIZEU ELIEL DA SILVA Gerente de Desenvolvimento Econômico

## CONTROLADORIA-GERAL

RETIFICAÇÃO Na Portaria nº 197, de 25 de maio de 2026, publicada no DODF nº 99, de 01 de junho de 2026, página 10, da Controladoria-Geral do Distrito Federal, no Art. 4º; ONDE SE LÊ: "…Parágrafo único…", LEIA-SE: "…§3º…".

### SUBCONTROLADORIA DE CORREIÇÃO ADMINISTRATIVA

ORDEM DE SERVIÇO Nº 15, DE 18 DE JUNHO DE 2026 Prorroga os prazos de conclusão de processos disciplinares. A SUBCONTROLADORA DE CORREIÇÃO ADMINISTRATIVA, DA CONTROLADORIA-GERAL DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 56, do Decreto nº 42.830, de 17 de dezembro de 2021, e tendo em vista a delegação de competência conferida pela Portaria nº 71, de 27 de fevereiro de 2019 c/c Portaria nº 212, de 27 de maio de 2019, consoante disposto no art. 217, §1º, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Prorrogar os trabalhos da Comissão Permanente CPROC 1, reconduzidos pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 0480-000506/2013; II - Processo nº 00480-00004986/2025-80; III - Processo nº 00480-00000212/2026-61. Art. 2º Reconduzir os trabalhos da Comissão Permanente CPROC 1, referentes ao Processo Administrativo Disciplinar nº 00480-00001606/2026-36, prorrogados pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026. Art. 3º Prorrogar os trabalhos da Comissão Permanente CPROC 1, referentes ao Processo Administrativo Disciplinar nº 00480-00002448/2026-31, instaurado pela Portaria nº 187, de 15/05/2026, publicada no DODF nº 90, de 19/05/2026. Art. 4º Prorrogar os trabalhos da Comissão Permanente CPROC 3, referentes ao Processo Administrativo Disciplinar nº 00480-00001900/2024-86, reconduzidos pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026. Art. 5º Reconduzir os trabalhos da Comissão Permanente CPROC 3, prorrogados pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 00480-00003845/2025-40; II - Processo nº 00480-00006133/2025-82; e III -Processo nº 00480-00001328/2026-17. Art. 6º Reconduzir os trabalhos da Comissão Permanente CPROC 7, prorrogados pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 00480-00000976/2025-75; II - Processo nº 00480-00003696/2025-19; e III - Processo nº 00480-00001306/2026-57 Art. 7º Prorrogar os trabalhos da Comissão Permanente CPROC 7, reconduzidos pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 00480-00002700/2025-21; e II - Processo nº 00480-00000585/2020-46; e III - Processo nº 00480-00004437/2025-13; Art. 8º Prorrogar os trabalhos da Comissão Permanente CPROC 8, reconduzidos pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 00480-00002075/2021-94; II - Processo nº 00060-00414655/2020-08; III - Processo nº 00480-00005223/2025-56; e IV - Processo nº 00480-00006889/2025-21. Art. 9º Reconduzir os trabalhos da Comissão Permanente CPROC 8, prorrogados pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026, referentes aos seguintes Processos Administrativos Disciplinares: I - Processo nº 00480-00005578/2024-64; e II - Processo nº 00480-00001550/2026-10. Art. 10. Reconduzir os trabalhos da Comissão Permanente CPROC 9, referentes ao Processo Administrativo Disciplinar nº 00480-00000595/2025-96, prorrogados pela Ordem de Serviço nº 10, de 17/04/2026, publicada no DODF nº 73, de 23/04/2026. Art. 11. Fixar o prazo de 60 (sessenta) dias para a conclusão dos trabalhos mencionados nos arts. 1º a 10. Art. 12. Estabelecer o prazo de 15 (quinze) dias para as comissões responsáveis pelos processos mencionados nos artigos 1º a 10: I - elaborarem e encaminharem à Subcontroladoria de Correição Administrativa relatório acerca dos trabalhos realizados no processo até o momento; e II - apresentarem cronograma de atividades a serem desenvolvidas no prazo fixado no art. 11. Art. 13. Esta Ordem de Serviço entra em vigor na data de sua publicação.

ISMARA DE LIMA ROZA GOMES

<!-- pagina 31 -->

# SEÇÃO II

## PODER EXECUTIVO

ORDEM DE SERVIÇO Nº 17, DE 19 DE JUNHO DE 2026 A CHEFE DE GABINETE DA CASA CIVIL DO DISTRITO FEDERAL, no uso de suas atribuições legais e de acordo com a delegação de competência conferida pelo inciso VI, do art. 1º, da Portaria nº 31, de 17 de dezembro de 2020 e, ainda, tendo em vista o Decreto nº 39.002, de 24 de abril de 2018, que regulamentou os artigos 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: DESIGNAR NOÊMIA MARIA DE AZEVEDO OLIVEIRA, matrícula 174.622-7, Assessora Especial, Símbolo CPE-07, da Unidade de Controle de Orçamento e Finanças, da Subsecretaria de Administração Geral, da Casa Civil do Distrito Federal, para substituir, sem acumular vencimentos e sem prejuízo das suas atribuições, ELISÂNGELA CÂNDIDA DOS SANTOS MARTINS, matrícula 174.755-X, Chefe, Símbolo CPE-04, da Unidade de Controle de Orçamento e Finanças, da Subsecretaria de Administração Geral, da Casa Civil do Distrito Federal, no período de 17 a 19/06/2026, por motivo de afastamento regulamentar da titular.

LAÍS BARUFI DE NOVAES

## CASA CIVIL

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 235, DE 17 DE JUNHO DE 2026 A SUBSECRETÁRIA DE ADMINISTRAÇÃO GERAL, DA CASA CIVIL DO DISTRITO FEDERAL, Substituta, no uso das atribuições conferidas pela Portaria nº 31, de 17/12/2020, e considerando o disposto nos art. 7º, § 3º e art. 117 da Lei nº 14.133/2021; no art. 43, do Decreto nº 32.598/2010; nos arts. 21 a 31, do Decreto nº 44.330/2023; e na Portaria nº 29, de 25/2/2004, resolve: Art. 1º Designar DOUGLAS DAMACENO SOUSA, matrícula nº 1.725560-0, para atuar como Gestor da contratação; JOSCIANE JEANE CARDOSO, matrícula nº 1.731.619-7, para atuar como Gestora da contratação substituta; SILVANA DE OLIVEIRA ALVES, matrícula nº 1.727.388-9, para atuar como fiscal técnico: HELLISON MARTINS DA SILVA, matrícula nº 1.730236-6, para atuar como fiscal técnico substituto; a fiscalização administrativa ficará a cargo da equipe da Unidade de Controle e Administração de Contratos (UCAC/SUAG/CACI); para atuação no âmbito do Contrato nº 55024/2025-CACI (180763899), firmado com a empresa DISTRITO CONSTRUTORA LTDA, tendo por objeto a prestação dos serviços de serviços de manutenção preventiva e limpeza contínua da piscina da Residência Oficial de Águas Claras (ROAC), compreendendo os insumos, equipamentos e mão de obra necessários à execução adequada dos serviços. Art. 2º Os agentes públicos de que se trata esta Ordem de Serviço deverão atuar na gestão, supervisão, fiscalização e no acompanhamento da execução, conforme dispostos na Lei nº 14.133/2021, no Decreto nº 32.598/2010, no Decreto nº 44.330/2023 e na Portaria nº 29, de 25/02/2004, bem como na Ordem de Serviço nº 27, de 07 de fevereiro de 2023, publicada no DODF nº 36 de 22 de fevereiro de 2023 e demais legislações vigentes. Art. 3º Para fins do disposto nesta Ordem de Serviço, considera-se: I - gestão de contrato - à coordenação das atividades relacionadas à fiscalização técnica e atos preparatórios à instrução processual e ao encaminhamento da documentação pertinente ao setor de contratos para a formalização dos procedimentos relativos à prorrogação, à alteração, ao reequilíbrio, à eventual proposição de aplicação de sanções e à extinção dos contratos, bem como a indicação dos possíveis fiscais técnico, administrativo e setorial que a contratação pode ensejar, entre outros; II - fiscalização técnica - o acompanhamento do contrato visando avaliar a execução do objeto nos moldes contratados e, se for o caso, aferir se a quantidade, a qualidade, o tempo, o modo da prestação e a execução do objeto estão compatíveis com os indicadores estabelecidos no edital, bem como a elaboração do atesto e do relatório circunstanciado, para fins de pagamento, conforme o resultado pretendido pela administração, com o eventual auxílio da fiscalização administrativa; III - fiscalização administrativa - apoio técnico e operacional ao gestor do contrato, com a realização das tarefas relacionadas ao controle dos prazos relacionados ao contrato e à formalização de apostilamentos e de termos aditivos, ao acompanhamento do empenho e do pagamento e ao acompanhamento de garantias e glosas, dentre outras ações de apoio técnico. Art. 4º. As atividades de gestão e de fiscalização dos contratos deverão ser realizadas de forma preventiva, rotineira e sistemática e exercidas pelos agentes públicos designados, assegurada a distinção das atividades. Art. 5º Tornar sem efeito a Ordem de Serviço 180, de 14 de Maio de 2026. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ELISÂNGELA CÂNDIDA DOS SANTOS MARTINS

## SECRETARIA DE ESTADO DE GOVERNO

### SECRETARIA EXECUTIVA DAS CIDADES ADMINISTRAÇÃO REGIONAL DO JARDIM BOTÂNICO

ORDEM DE SERVIÇO Nº 30, DE 16 DE JUNHO DE 2026 O ADMINISTRADOR REGIONAL DO JARDIM BOTÂNICO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pelo artigo 42, do Regimento Interno, aprovado pelo Decreto nº 38.094, de 28 de março de 2017 e com base no que dispõe o Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, e conforme estabelecido no Processo SEI 00307-00000713/2026-94, resolve: Art. 1º Designar DIMAS MOREIRA JÚNIOR, matrícula 126268-8, ocupante do cargo efetivo de Gestor em Políticas Públicas e Gestão Governamental, para substituir a Diretora, da Diretoria de Desenvolvimento e Ordenamento Territorial, da Coordenação de Desenvolvimento, da Administração Regional do Jardim Botânico, em suas licenças, afastamentos, férias e demais ausências ou impedimentos legais ou regulamentares da titular, e em caso de vacância do cargo. Art. 2º Revogam-se as disposições em contrário. Art. 3º Esta Ordem de Serviço entra em vigor na data de sua publicação.

JOÃO CARLOS COUTO LÓSSIO FILHO

COORDENAÇÃO DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 29, DE 16 DE JUNHO DE 2026 A COORDENADORA DE ADMINISTRAÇÃO GERAL, DA ADMINISTRAÇÃO REGIONAL DO JARDIM BOTÂNICO DO DISTRITO FEDERAL, no uso de suas atribuições legais instituídas através do inciso V, do Artigo 11, do Decreto nº 38.094, de 28 de março de 2017, e conforme processo nº 00307-00000738/2026-98, resolve: Art. 1º Conceder Licença-servidor, nos termos da Lei Complementar nº 840/2011, alterada pela Lei Complementar nº 952/2019, à servidora ALESSANDRA PINTO MARTINS, matrícula 033891-5, 7º quinquênio: 21/04/2021 à 19/04/2026. Art. 2º Esta Ordem de Serviço entra em vigor na data de sua publicação.

DÊNIA MAGNA SANTOS FERNANDES

## SECRETARIA DE ESTADO DE ECONOMIA

PORTARIA Nº 430, DE 17 DE JUNHO DE 2026 (*) Altera a Portaria nº 994, de 20 de dezembro de 2024, que disciplina a formação de Grupo de Trabalho com vistas à elaboração de artefatos e acompanhamento do processo licitatório do novo Sistema Integrado de Gestão Governamental – Novo SIGGO para o Governo do Distrito Federal. O SECRETÁRIO DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, incisos I e III, da Lei Orgânica do Distrito Federal, resolve: Art. 1º A Portaria nº 994, de 20 de dezembro de 2024, passa a vigorar com as seguintes alterações: “Art. 3º [...] I – Pela Secretaria Executiva de Finanças, Orçamento e Planejamento – SEFIN: a) OTÁVIO VERÍSSIMO SOBRINHO, Auditor de Controle Interno, matrícula 0191939-3 (Titular); e b) LUCIANO LIMA GOULART, Auditor de Controle Interno, matrícula 0190026-9 (Suplente); II – Pela Contadoria Geral do Distrito Federal – ContDF/SEFIN: a) LEON DE OLIVEIRA MADEIRA, Auditor de Controle Interno, matrícula 285.789-8 (Titular); e b) JOÃO VITOR SANTANA VIEIRA, Auditor de Controle Interno, matrícula 0285.099-0 (Suplente); III – Pela Subsecretaria de Planejamento Governamental – SUPLAN/SEFIN: a) GABRIEL CARLOS RIBEIRO ANTUNES, Auditor de Controle Interno, matrícula 285.784-7 (Titular); e b) PEDRO AUGUSTO CESAR, Auditor de Controle Interno, matrícula 285.762-6 (Suplente); IV – Pela Subsecretaria de Orçamento Público – SUOP/SEFIN: a) RAFAEL DUARTE DE PAULA SILVA, Auditor de Controle Interno, matrícula 0272467-7 (Titular); e b) ALISSON LIRA DA ROCHA, Auditor de Controle Interno, matrícula 190.047-1 (Suplente); [...] X – Pela Subsecretaria de Tecnologia da Informação – SUTI/SERT: a) EWERTON LUIZ KNEBEL MASERA, Gestor de Políticas Públicas e Gestão Governamental, matrícula 126.832-5 (Titular); e b) KEILLY FRANCIELLY DE ALMEIDA ALVES, matrícula 286.854-7 (Suplente). [...] Art. 4º Designar LEON DE OLIVEIRA MADEIRA, Auditor de Controle Interno, matrícula 285.789-8 (Titular), da Contadoria Geral do Distrito Federal (CONTDF), da

<!-- pagina 32 -->

Secretaria Executiva de Finanças, Orçamento e Planejamento, para exercer a função de presidente deste Grupo de Trabalho, e, nas suas ausências, JOÃO VITOR SANTANA VIEIRA, Auditor de Controle Interno, matrícula 0285.099-0. ” (NR) Art. 2º Esta Portaria entra em vigor na data de sua publicação.

VALDIVINO JOSÉ DE OLIVEIRA ___________________ (*) Republicado por erro de grade, publicado no DODF nº 111, de 19 de junho de 2026, página 31.

### SECRETARIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA

ORDEM DE SERVIÇO Nº 224, DE 18 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da competência delegada pelo art. 2º - A, inciso II, alínea "a", da Portaria nº 235, de 30 de agosto de 2021; com base no art. 3º do Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011; e diante do contido no Processo nº 04044-00035036/2026-88, resolve: DESIGNAR CÍCERO SÉRGIO AMARO LIMA, matrícula nº 287.695-7, para substituir o(a) Chefe, Símbolo CPE-05, da Secretaria do Fundo Pró-Gestão, da Escola de Governo, da Secretaria Executiva de Gestão Administrativa, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais.

ANALICE MOREIRA ALVES BRITO

ORDEM DE SERVIÇO Nº 225, DE 18 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da competência delegada pelo art. 2º - A, inciso II, alínea "a", da Portaria nº 235, de 30 de agosto de 2021; com base no Art. 3º do Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, e diante do contido no Processo nº 04044-00035103/2026-64, resolve: DESIGNAR THAÍS SEVERO DE SOUZA, matrícula nº 282.908-8, para substituir o(a) Chefe, Símbolo CNE-04, da Unidade de Arquitetura, da Subsecretaria de Engenharia, Arquitetura e Manutenção, da Secretaria Executiva de Administração e Logística, da Secretaria de Estado de Economia do Distrito Federal, nos dias 18 e 19 de junho de 2026, por motivo de abono de ponto do(a) titular.

ANALICE MOREIRA ALVES BRITO

ORDEM DE SERVIÇO Nº 226, DE 18 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da competência delegada pelo art. 2º - A, inciso II, alínea "a", da Portaria nº 235, de 30 de agosto de 2021; com base no art. 3º do Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011; e diante do contido no Processo nº 04033-00031999/2023-25, resolve: DESIGNAR CARLOS CÉSAR SOARES, matrícula nº 174.759-2, para substituir o(a) Gerente, Símbolo CPC-08, da Gerência de Administração de Imóveis, da Diretoria de Patrimônio Imobiliário, da Unidade de Gestão Patrimonial, da Subsecretaria de Administração Geral, da Secretaria Executiva de Administração e Logística, da Secretaria de Estado de Economia do Distrito Federal, no período de 27 de julho de 2026 a 05 de agosto de 2026, por motivo de férias regulamentares do(a) titular.

ANALICE MOREIRA ALVES BRITO

ORDEM DE SERVIÇO Nº 227, DE 18 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da competência delegada pelo art. 2º - A, inciso II, alínea "a", da Portaria nº 235, de 30 de agosto de 2021; com base no Art. 3º do Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, e diante do contido no Processo nº 04044-00003793/2026-92, resolve: CESSAR OS EFEITOS na Ordem de Serviço nº 472, de 02 de outubro de 2025, publicada no DODF nº 189 de 06 de outubro de 2025 - página 49, que designou JOÃO VITOR SANTANA VIEIRA, matrícula nº 285.099-0, para substituir o (a) Chefe, Símbolo CPE-05, da Unidade de Procedimentos e de Controle de Sistemas Contábeis, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais. CESSAR OS EFEITOS na Ordem de Serviço nº 607, de 1º de dezembro de 2025, publicada no DODF nº 228, de 03 de dezembro de 2025 - páginas 61/62, que designou SALMA NOGUEIRA FARIA DE MELO, matrícula nº 43.614-3, para substituir o (a) Diretor(a), Símbolo CPE-07, da Diretoria de Empresas Públicas, da Unidade de Orientação, Controle e Análise Contábil da Administração Indireta, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais. CESSAR OS EFEITOS na Ordem de Serviço nº 543, de 04 de novembro de 2025, publicada no DODF nº 211, de 06 de novembro de 2025 - página 25, que designou

MÁRCIO DE REZENDE MARTINHO, matrícula nº 189.852-3, para substituir o (a) Contador Geral, Símbolo CNE-02, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais. DESIGNAR LEON DE OLIVEIRA MADEIRA, matrícula nº 285.789-8, para substituir o(a) Chefe, Símbolo CPE-05, da Unidade de Procedimentos e de Controle de Sistemas Contábeis, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais. DESIGNAR JOÃO BARBOSA FRANÇA, matrícula nº 192.169-X, para substituir o(a) Diretor(a), Símbolo CPE-07, da Diretoria de Empresas Públicas, da Unidade de Orientação, Controle e Análise Contábil da Administração Indireta, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais. DESIGNAR DANIEL DA SILVA MELLO, matrícula nº 190.483-3, para substituir o(a) Contador(a) Geral, Símbolo CNE-02, da Contadoria Geral do Distrito Federal, da Secretaria Executiva de Finanças, Orçamento e Planejamento, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais.

ANALICE MOREIRA ALVES BRITO

ORDEM DE SERVIÇO Nº 228, DE 18 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da competência delegada pelo art. 2º - A, inciso II, alínea "a", da Portaria nº 235, de 30 de agosto de 2021; com base no Art. 3º do Decreto nº 39.002, de 24 de abril de 2018, que regulamenta os arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, e diante do contido no Processo nº 04044-00033927/2026-08, resolve: DESIGNAR EVANEIDE BARBOSA OLIVEIRA, matrícula nº 285.339-6, para substituir o(a) Chefe, Símbolo CPE-05, da Assessoria Especial, da Subsecretaria de Administração da Folha de Pagamento, da Secretaria Executiva de Gestão Administrativa, da Secretaria de Estado de Economia do Distrito Federal, em seus afastamentos ou impedimentos legais.

ANALICE MOREIRA ALVES BRITO

### SECRETARIA EXECUTIVA DE GESTÃO ADMINISTRATIVA

DESPACHO DO SECRETÁRIO EXECUTIVO

Em 18 de junho 2026 PROCESSO: 00138-00003693/2025-85 INTERESSADA: NATHALIE NOBRE PINHEIRO MARTINS ASSUNTO: REVOGAÇÃO DE DISPOSIÇÃO. Considerando a delegação de competência prevista no art. 2º, V, da Portaria nº 235, de 30/08/2021, bem como os termos do Despacho - SEE/SUGEP, de 17/06/2026, REVOGO, a contar de 15/06/2026, a disposição da servidora NATHALIE NOBRE PINHEIRO MARTINS, matrícula 36.104-6, ocupante do Cargo de Professor de Educação Básica, do quadro de pessoal da Secretaria de Estado de Educação do Distrito Federal (SEE), à Administração Regional da Ceilândia (RA-CEIL), autorizada no DODF nº 159, de 25/08/2025, pág. 34. Publique-se e encaminhe-se à SEE para as providências pertinentes.

ÂNGELO RONCALLI DE RAMOS BARROS

DESPACHO DO SECRETÁRIO EXECUTIVO

Em 18 de junho de 2026 PROCESSO: 00001-00020450/2026-38 INTERESSADO: VINICIUS ALVES DE LIMA CASTRO ASSUNTO: CESSÃO DE PESSOAL 1) AUTORIZO, com fundamento na delegação de competência prevista no art. 2º, V, da Portaria nº 235, de 30/08/2021, a cessão, sem a designação para cargo em comissão ou função de confiança, do servidor VINICIUS ALVES DE LIMA CASTRO, matrícula 192.199-1, ocupante do Cargo de Polícia Penal, do quadro de pessoal da Secretaria de Estado de Administração Penitenciária do Distrito Federal (SEAPE), para ter exercício no Gabinete do Deputado Wellington Luiz, da Câmara Legislativa do Distrito Federal (CLDF), nas seguintes condições: A) ÔNUS FINANCEIRO: cedente. B) INÍCIO DO AFASTAMENTO: a contar da entrada em exercício, mediante ofício de apresentação. C) VIGÊNCIA: até 31/12/2026. D) FUNDAMENTO LEGAL: arts. 152, § 1º, I, "b", e 154, parágrafo único, II e III, da Lei Complementar nº 840, de 23/12/2011; e arts. 2º, 5º, 7º, 20, §§ 1º e 2º, e 21, § 4º do Decreto nº 39.009, de 26/04/2018. 2) A cessão encerra-se com o término do prazo fixado neste ato ou com a revogação pela autoridade competente. 3) Publique-se e encaminhe-se à SEAPE, para as providências pertinentes.

ÂNGELO RONCALLI DE RAMOS BARROS

DESPACHO DOSECRETÁRIO EXECUTIVO

Em 18 de junho de 2026 PROCESSO: 00010-00001549/2022-06 INTERESSADA: REGINA MARIA ARAUJO DANTAS ASSUNTO: REVOGAÇÃO DE REQUISIÇÃO. Considerando a delegação de competência prevista no art. 20 do Decreto nº 39.009, de 26/04/2018, bem como os termos do Despacho - SEE/SUGEP, de 17/06/2026, REVOGO, a contar de 15/06/2026, a requisição da servidora REGINA MARIA ARAUJO DANTAS, matrícula 215.322-X, ocupante do Cargo de Técnico de Gestão Educacional, do quadro de

<!-- pagina 33 -->

pessoal da Secretaria de Estado de Educação do Distrito Federal (SEE), para o Tribunal Regional Eleitoral do Distrito Federal (TRE/DF), autorizada no DODF nº 54, de 23/03/2026, pág. 106. Publique-se e encaminhe-se à SEE, para as providências pertinentes.

ÂNGELO RONCALLI DE RAMOS BARROS

SUBSECRETARIA DE GESTÃO DE PESSOAS

ORDEM DE SERVIÇO Nº 16, DE 12 DE JUNHO DE 2026 (*) O SUBSECRETÁRIO DE GESTÃO DE PESSOAS, DA SECRETARIA DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso da atribuição que lhe confere a Portaria nº 18, de 04 de março de 2015, e tendo em vista o disposto no art. 7º do Decreto nº 33.652, de 10 de maio de 2012, combinado com os arts. 145 a 149 da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: SUSPENDER a Licença para o Desempenho de Mandato Classista concedida ao servidor IDAIANO IURI MARQUES DOS SANTOS, matrícula nº 1.434.920-5, ocupante do cargo de Agente Comunitário em Saúde, da Secretaria de Estado de Saúde do Distrito Federal (SES), no Sindicato dos Agentes de Vigilância Ambiental em Saúde e Agentes Comunitários de Saúde do Distrito Federal (SINDIVACS-DF), conforme Processo nº 04044-00033099/2026-08, a contar de 03/07/2026. CONCEDER a Licença para Desempenho de Mandato Classista no Sindicato dos Agentes de Vigilância Ambiental em Saúde e Agentes Comunitários de Saúde do Distrito Federal (SINDIVACS-DF) ao servidor LINDON JOHNSON VIEIRA MONTEIRO, matrícula nº 183.409-6, ocupante do cargo de Agente Comunitário em Saúde, da Secretaria de Estado de Saúde do Distrito Federal (SES), para exercício do cargo de Secretário-Geral, com ônus para o GDF, de acordo com o Processo nº 04044- 00033099/2026-08, de 03/07/2026 a 14/10/2026.

RICARDO ALEXANDRE TRIGUEIRO ____________________ (*) Republicada por ter sido encaminhada com incorreção no original, publicada no DODF nº 108, de 16 de junho de 2026, pág. 33.

### INSTITUTO DE PREVIDÊNCIA DOS SERVIDORES

DIRETORIA DE PREVIDÊNCIA

ORDEM DE SERVIÇO Nº 50, DE 18 DE JUNHO DE 2026 O DIRETOR DE PREVIDÊNCIA, DO INSTITUTO DE PREVIDÊNCIA DOS SERVIDORES DO DISTRITO FEDERAL, Substituto, no uso das atribuições conferidas pelo art. 1º do Decreto nº 38.649, de 27 de novembro de 2017, e pela Portaria nº 33, de 25 de fevereiro de 2019, resolve: CONCEDER, nos termos do artigo 30-A, inciso I, alínea “a”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291 da Lei Complementar nº 840, de 23/12/2011, combinado com o artigo 40, § 7º, inciso I da Constituição da República Federativa do Brasil, com a redação dada pela Emenda Constitucional nº 41, de 19/12/2003, com o artigo 6º-A, Parágrafo Único, da Emenda Constitucional nº 41, de 19/12/2003, com a redação dada pela Emenda Constitucional nº 70, de 29/03/2012 e com os artigos 29, inciso I e 30-B da Lei Complementar nº 769, de 30/06/2008, pensão vitalícia a ENIRA DE CASTRO BARROS, cônjuge do ex-servidor LUIZ CARLOS MARINHO DE BARROS, matrícula nº 38.549-2, Procurador do Distrito Federal - Categoria II, do Quadro de Pessoal do Distrito Federal, a contar de 04/06/2026. Processo SEI nº 00413-00007031/2026-31. CONCEDER, nos termos do artigo 30-A, inciso I, alínea “a”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291 da Lei Complementar nº 840, de 23/12/2011, combinado com o artigo 40, § 7º, inciso I da Constituição da República Federativa do Brasil, com a redação dada pela Emenda Constitucional nº 41, de 19/12/2003, com o artigo 3º, Parágrafo Único da Emenda Constitucional nº 47, de 05/07/2005 e com os artigos 29, inciso I, 30-B da Lei Complementar nº 769, de 30/06/2008, pensão vitalícia a LUIZ CARLOS TORELLI DE SOUZA, cônjuge da ex-servidora MARIA DA CONCEIÇÃO DE OLIVEIRA MONTEIRO, matrícula n.º 102.025-0, Técnico em Desenvolvimento e Assistência Social, Classe Especial I, Padrão V, do Quadro de Pessoal do Distrito Federal, a contar de 12/04/2026. Processo SEI nº 00413-00004911/2026-56. CONCEDER, nos termos do artigo 30-A, inciso I, alínea “a”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291 da Lei Complementar nº 840, de 23/12/2011, combinado com o artigo 40, § 7º, inciso I da Constituição da República Federativa do Brasil, com a redação dada pela Emenda Constitucional nº 41, de 19/12/2003, com o artigo 3º, Parágrafo Único da Emenda Constitucional nº 47, de 05/07/2005 e com os artigos 29, inciso I, 30-B da Lei Complementar nº 769, de 30/06/2008, pensão vitalícia a CLAUDIA MARIA GUIMARÃES ALVARES MARIANO, cônjuge do ex-servidor SAM AUGUSTO MARIANO, matrícula nº 41.979-6, Professor de Educação Básica, Etapa 3, Padrão 25, do Quadro de Pessoal da Secretaria de Estado de Educação do Distrito Federal, a contar de 05/05/2026. Processo SEI nº 00413-00006983/2026-38. CONCEDER, nos termos do artigo 30-A, inciso I, alínea “c”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291 da Lei Complementar nº 840, de 23/12/2011, combinado com o artigo 40, §§ 7º, inciso I e 8º da Constituição da República Federativa do Brasil, com a redação dada pela Emenda Constitucional nº 41, de 19/12/2003, com os artigos 29, inciso I, 30-B e 51 da Lei Complementar nº 769, de 30/06/2008, pensão vitalícia a ZILVANI FRANCISCA NEVES, companheira do

ex-servidor HUGO LAUTERJUNG, matrícula nº 83.451-3, Professor de Educação Básica, Etapa 3, Padrão 25, do Quadro de Pessoal da Secretaria de Estado de Educação do Distrito Federal, a contar de 06/05/2026. Processo SEI nº 00413-00006948/2026-19. CONCEDER, nos termos do artigo 30-A, inciso II, alínea "a", da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291 da Lei Complementar nº 840, de 23/12/2011, combinado com o artigo 40, § 7º, inciso I da Constituição da República Federativa do Brasil, com a redação dada pela Emenda Constitucional nº 41, de 19/12/2003, com o artigo 6º-A, Parágrafo Único, da Emenda Constitucional nº 41, de 19/12/2003, com a redação dada pela Emenda Constitucional nº 70, de 29/03/2012 e com os artigos 29, inciso I e 30-B da Lei Complementar nº 769, de 30/06/2008, pensão temporária a ARIANE DE OLIVEIRA RODRIGUES, filha inválida da ex-servidora NEUSA MARIA DE OLIVEIRA RODRIGUES, matrícula nº 40.665-1, Técnico em Políticas Públicas e Gestão Educacional, Etapa 3, Nível 9, Padrão I, do Quadro de Pessoal da Secretaria de Estado de Educação do Distrito Federal, a contar de 28/03/2018, conforme Decisão Judicial, Processo nº 0711711- 08.2018.8.07.0018. Processo SEI nº 00080-00056125/2018-33. CESSAR OS EFEITOS da pensão temporária, efetivada pela Portaria de 29/04/1992, publicada no DODF nº 86, de 30/04/1992, retificada pela Portaria Coletiva nº 178, de 20/03/2002, publicada no DODF nº 56, de 22/03/2002, concedida a JANE LILIA DE SOUSA DOS SANTOS, filha do ex-servidor JOSE ALVES DOS SANTOS, matrícula nº 60.068-7, Técnico em Políticas Públicas e Gestão Governamental, Classe Única, Padrão II, do Quadro de Pessoal do Distrito Federal. Processo SEI nº 094.000.288/1992. CESSAR OS EFEITOS da pensão temporária, efetivada pela Instrução de 03/12/1992, publicada no DODF nº 249, de 08/12/1992, suplemento, revista pela Instrução Coletiva de 16/03/2000, publicada no DODF nº 53, de 17/03/2000, concedida a TÂNIA SOARES VIANA, filha da ex-servidora JOSEFA SOARES, matrícula nº 55.621-1, Técnico em Políticas Públicas e Gestão Educacional, Etapa 1, Nível 3, Padrão III, do Quadro de Pessoal da Secretaria de Estado de Educação do Distrito Federal. Processo SEI nº 082.007.248/1991. REVER, na Ordem de Serviço coletiva nº 23, de 19/03/2026, publicada no DODF nº 54, de 23/03/2026, o ato que concedeu pensão temporária a ESTER GOMES RAMOS, filha da ex-servidora SARA GOMES DA SILVA, matrícula nº 52.506-5, Analista em Políticas Públicas e Gestão Governamental, 3ª Classe, Padrão IV, do Quadro de Pessoal do Distrito Federal, para incluir em sua fundamentação legal, o artigo 30-A, inciso I, alínea “c”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291, da Lei Complementar nº 840, de 23/12/2011, como beneficiário de pensão vitalícia JOSIMAR RAMOS VENTURA, na qualidade de companheiro da ex-servidora, de acordo como artigo 29, § 6º e 32, Parágrafo Único, da Lei Complementar nº 769, de 30/06/2008, a contar de 24/03/2026. Processo SEI nº 00413-00003414/2026-31. REVER, na Ordem de Serviço coletiva nº 174, de 05/06/2020, publicada no DODF nº 110, de 15/06/2020, o ato que concedeu pensão vitalícia a JOÃO ABADIO RIBEIRO, cônjuge da ex-servidora MARIA DO SOCORRO RIBEIRO DE MOURA, matrícula nº 80.711-7, Professor de Educação Básica, Etapa 3, Padrão 25, do Quadro de Pessoal da Secretaria de Estado de Educação do Distrito Federal, para incluir em sua fundamentação legal, o artigo 30-A, inciso II, alínea “a”, da Lei Complementar nº 769, de 30/06/2008, com a redação dada pelo artigo 291, da Lei Complementar nº 840, de 23/12/2011, como beneficiária de pensão temporária, JANE DE MARIA RIBEIRO DE MOURA, na qualidade de filha inválida da ex-servidora, de acordo com o artigo 29, § 6º e 32, Parágrafo Único, da Lei Complementar nº 769, de 30/06/2008, a contar de 25/12/2020. Processo SEI nº 00080- 00029518/2021-70.

PAULO HENRIQUE DE SOUSA FERREIRA

## SECRETARIA DE ESTADO DE SAÚDE

### SECRETARIA EXECUTIVA DE ASSISTÊNCIA À SAÚDE

ORDEM DE SERVIÇO Nº 10, DE 19 DE JUNHO DE 2026 O SECRETÁRIO EXECUTIVO DE ASSISTÊNCIA À SAÚDE, DA SECRETARIA EXECUTIVA DE ASSISTÊNCIA À SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das suas competências regimentais e atribuições conferidas pelo art. 4º, do Decreto nº 39.546, de 19 de dezembro de 2018, Regimento Interno de Secretaria de Estado de Saúde do Distrito Federal, e; Considerando as disposições da Portaria nº 460, de 02 de outubro de 2024, publicada no DODF nº 191, de 04 de outubro de 2024, resolve: Art. 1º Retificar o art. 15 da Ordem de Serviço nº 07, de 15 de maio de 2026, publicada no DODF nº 089, de 18 de maio de 2026, e o art. 2º da Ordem de Serviço nº 08, de 02 de junho de 2026, publicada no DODF nº, de de junho de 2026, para fazer constar: ONDE SE LÊ: “...DISPENSAR o servidor SYLVIO TORRES DA MOTTA, matrícula 1.710.526-9, Médico, 20h,...” LEIA-SE: “...DISPENSAR o servidor SYLVIO TORRES DA MOTTA, matrícula 1.710.526-9, Médico, 40h...”. Art. 2º Designar o servidor SYLVIO TORRES DA MOTTA, matrícula 1.710.526-9, Médico, 40h, para exercer a função de Médico Supervisor da Comissão Especial de Médicos Supervisores, vinculada à Diretoria de Avaliação e Qualificação da Assistência. Art. 3º Dispensar a servidora TALITA LEITE BRINGEL, matrícula 1.671.386-9, Médica, 40h, da função de Médica Supervisora da Comissão Especial de Médicos Supervisores, vinculada à Diretoria de Avaliação e Qualificação da Assistência.

<!-- pagina 34 -->

Art. 4º Dispensar a servidora ADLA FERNANDA NOGUEIRA RODRIGUES, matrícula 1.659.536-X, Enfermeira, 20h, da função de Gestora da Subcomissão de Fiscalização de Contratos Complementares de Radioterapia e Oncologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 5º Designar a servidora ADLA FERNANDA NOGUEIRA RODRIGUES, matrícula 1.659.536-X, Enfermeira, 20h, para exercer a função de Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Radioterapia e Oncologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 6º Reduzir a carga horária da servidora ÉRICA BATISTA QUEIROZ RODRIGUES, matrícula 1.438.832-4, Enfermeira, de 20 horas semanais para 14 horas semanais, como Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Radioterapia e Oncologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 7º Dispensar a servidora CAROLINE D’ABADIA SOARES DE AZEVEDO, matrícula 1.441.544-5, Médica, 20h, da função de Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Radioterapia e Oncologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 8º Designar a servidora ANA OLÍVIA MANSOLELLI, matrícula 1.684.931-0, Enfermeira, 40h, para exercer a função de Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de UTI, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 9º Designar a servidora MISLEIR DOS SANTOS DE SOUSA, matrícula 1.706.945-9, Técnica em Enfermagem, 20h, para exercer a função de Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de UTI, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 10. Designar a servidora TALITA LEITE BRINGEL, matrícula 1.671.386-9, Médica, 40h, para exercer a função de Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Cirurgias Eletivas, exceto Oftalmologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 11. Dispensar a servidora DANIELLA DE SOUZA VIANA, matrícula 0.198.410-1, Especialista em Saúde - Psicóloga, 10h, das funções de Gestora substituta e Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Internação Compulsória, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 12. Designar a servidora JÉSSICA LEITE RODRIGUES DE OLIVEIRA MAIA, matrícula 1.707.270-0, Enfermeira, 10h, para exercer as funções de Gestora substituta e Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Internação Compulsória, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 13. Ampliar a carga horária da servidora ÉRICA BATISTA QUEIROZ RODRIGUES, matrícula 1.438.832-4, Enfermeira, de 20 horas semanais para 26 horas semanais, como Fiscal Técnica da Subcomissão de Fiscalização de Contratos Complementares de Nefrologia, vinculada à Comissão de Fiscalização de Contratos Assistenciais Complementares. Art. 14. Esta Ordem de Serviço entra em vigor na data de sua publicação.

CARLOS ANTONIO DE BARROS CORREIA JUNIOR

### SECRETARIA EXECUTIVA DE GESTÃO ADMINISTRATIVA SUBSECRETARIA DE GESTÃO DE PESSOAS COORDENAÇÃO DE ADMINISTRAÇÃO DE PROFISSIONAIS

DIRETORIA DE PAGAMENTO DE PESSOAL

ORDEM DE SERVIÇO Nº 39, DE 18 DE JUNHO DE 2026 O DIRETOR DE PAGAMENTO DE PESSOAL, DA COORDENAÇÃO DE ADMINISTRAÇÃO DE PROFISSIONAIS, DA SUBSECRETARIA DE GESTÃO DE PESSOAS, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições regimentais disposta no artigo 11, item II da Portaria nº 708, de 03 de julho de 2018, publicada no DODF nº 125 de 04 de julho de 2018, resolve: CONVERTER EM PECÚNIA 8 (oito) meses de Licença-Prêmio por assiduidade do (a) servidor (a) BEATRIZ SARA COSTA, matrícula: 0180285-2, na carreira de Enfermeiro, no cargo de Enfermeiro, Classe Primeira, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00286278/2026-98. CONVERTER EM PECÚNIA 11 (onze) meses de Licença-Prêmio por assiduidade do (a) servidor (a) MARIA JOSE CONCEICAO PEREIRA, matrícula: 0111141-8, na carreira Gestão e Assistência Pública à Saúde, no cargo de TECNICO ADMINISTRATIVO, Classe Especial, Padrão V, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00206053/2026-66. CONVERTER EM PECÚNIA 6 (seis) meses de Licença-Prêmio por assiduidade do (a) servidor (a) ROSA CELIA ALVES DE SOUSA, matrícula: 0132856-5, na carreira Técnica em Enfermagem, no cargo de Técnico em Enfermagem, Classe Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060- 00286424/2026-85. CONVERTER EM PECÚNIA 2 (dois) meses de Licença-Prêmio por assiduidade do (a) servidor (a) CHRISTIANE DE PAULA GUERRA, matrícula: 0137462-1, na carreira

Técnica em Enfermagem, no cargo de Técnico em Enfermagem, Classe Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00286454/2026-91. CONVERTER EM PECÚNIA 5 (cinco) meses de Licença-Prêmio por assiduidade do (a) servidor (a) IZUMI KURATA, matrícula: 0152645-6, na carreira Médica, no cargo de MEDICO - ACUPUNTURA, Classe Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00254303/2026-74. CONVERTER EM PECÚNIA 8 (oito) meses de Licença-Prêmio por assiduidade do (a) servidor (a) MARILEYDE BORGES DE SOUSA, matrícula: 0183579-3, na carreira de Enfermeiro, no cargo de Enfermeiro, Classe Primeira, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00271272/2026-16. CONVERTER EM PECÚNIA 1 (um) mês de Licença-Prêmio por assiduidade do (a) servidor (a) ELISA RUTH SOLIS DA SILVA, matrícula: 0138505-4, na carreira de Enfermeiro, no cargo de Enfermeiro, Classe Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00271484/2026-01. CONVERTER EM PECÚNIA 9 (nove) meses de Licença-Prêmio por assiduidade do (a) servidor (a) DARCI GOULART DE FREITAS, matrícula: 0136632-7, na carreira Gestão e Assistência Pública à Saúde, no cargo de AOSD - PAT. CLINICA, Classe Única, Padrão XX, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00269463/2026-18. CONVERTER EM PECÚNIA 9 (nove) meses de Licença-Prêmio por assiduidade do (a) servidor (a) LUCI PEREIRA DE OLIVEIRA, matrícula: 0172261-1, na carreira Técnica em Enfermagem, no cargo de Técnico em Enfermagem, Classe Especial, Padrão III, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060- 00284406/2026-69. CONVERTER EM PECÚNIA 9 (nove) meses de Licença-Prêmio por assiduidade do (a) servidor (a) ANA CRISTINA SIQUEIRA FERNANDES, matrícula: 0133543-X, na carreira Técnica em Enfermagem, no cargo de Técnico em Enfermagem, Classe Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, nos termos do artigo 142, da Lei Complementar nº. 840 de 23 de dezembro de 2011, Processo nº. 00060-00284382/2026-48.

WATSON LACERDA DA SILVA

### SECRETARIA EXECUTIVA DE COMPRAS, CONTRATOS E INSTRUMENTOS CONGÊNEROS

ORDEM DE SERVIÇO Nº 213, DE 19 DE JUNHO DE 2026 ALTERA a ORDEM DE SERVIÇO Nº 339, DE 30 DE JULHO DE 2025, que DISPENSA E/OU DESIGNA SERVIDORES DA SES/DF, PARA ATUAREM NO ACOMPANHAMENTO/FISCALIZAÇÃO DO CONTRATO 054492/2025-SES/DF, celebrado com a empresa PIETRA ODONTO IMPORTAÇÃO E DISTRIBUIDORA LTDA, NA FORMA ABAIXO. O SECRETÁRIO EXECUTIVO DE COMPRAS, CONTRATOS E INSTRUMENTOS CONGÊNERES, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, Substituto, no uso das atribuições que lhe confere o artigo 1º da Portaria nº 382, de 15 de maio de 2026, publicada no DODF nº 89, de 18 de maio de 2026, resolve: Art. 1º Dispensar os seguintes servidores do Acompanhamento/fiscalização do Contrato nº. 054492/2025-SES/DF, celebrado com a empresa PIETRA ODONTO IMPORTAÇÃO E DISTRIBUIDORA LTDA, quem tem por objeto o(a) aquisição potencial de APARELHO DE PROFILAXIA COM ULTRASSOM, em sistema de registro de preços, para atender às necessidades da Secretaria de Saúde – DF (Item 1), conforme processo nº 00060- 00586719/2024-97, a saber: § 1º ISABELLA CRISTINA FERNANDES PEIXOTO, matrícula 1697.395-X, lotado(a) no(a) SES/SRSLE/DIRAPS/GAPAPS, como Gestor(a) Titular no âmbito do(a) SES/SRSLE. Art. 2º Designar os servidores abaixo relacionados, consoante processo SEI-GDF 00060- 00528777/2024-04, com a indicação das respectivas funções no Acompanhamento/fiscalização do referido ajuste, a saber: § 1º IVAN FIGUEIRO KOLMOGOROFF, matrícula 141.033-4, lotado(a) no(a) SES/SRSLE/GSAP2-PAR/UBS6-PAR, como Gestor(a) Titular no âmbito do(a) SES/SRSLE. Art. 3º Os servidores, de que trata o artigo 2º, deverão observar o disposto na Lei nº 14.133/21, Decreto nº 44.330/2023; c/c o Inciso II e parágrafo 5º, do artigo 41, do Decreto nº 32.598 de 15 de dezembro de 2010; Portaria nº 29-SGA, de 25 de fevereiro de 2004; Portaria nº 125-SGA, de 30 de abril de 2004; Portaria nº 222-SEPLAG, de 31 de dezembro de 2010; os parágrafos 1º e 2º, do artigo 2º da Portaria nº 057/2011-SES/DF; Portaria nº 005/2025-SES/DF; Portaria nº 126/2019-SES/DF; Portaria nº 1143/2021-SES/DF; Instrução Normativa nº 01/2011-SES/DF e demais legislações correlatas. Art. 4º Esta Ordem de Serviço entra em vigor na data de sua publicação.

FELIPE AUGUSTO LOPES RUELA

<!-- pagina 35 -->

### SUPERINTENDÊNCIA DA REGIÃO

### DE SAÚDE CENTRO-SUL

ORDEM DE SERVIÇO Nº 31, DE 17 DE JUNHO DE 2026 O SUPERINTENDENTE DA REGIÃO DE SAÚDE CENTRO-SUL, DA SECRETARIA DE ESTADO DE SAUDE DO DISTRITO FEDERAL, no uso das atribuições que lhe foi conferida pelo artigo 13º da Portaria nº 396, de 20 de junho de 2022, publicada no DODF nº 114, de 21 de junho de 2022, resolve: CONCEDER Licença Servidor, nos termos da lei Complementar nº 840/2011, alterada pela Lei Complementar nº 952/2019, condicionado o período de gozo aos critérios da Administração, à servidora SHIRLEY EMIDIO GUIMARAES, Matr.01508520, FISIOTERAPEUTA, lotação NSF/GAMAD/HRGU/SRSCS/SES, 4º Qq - 21/04/2021 a 10/05/2026, processo SEI 00060- 00298500/2026-03. FABIOLA ALVES GOMES DUTRA LEAO, Matr.01984160, TECNICO ADMINISTRATIVO, lotação NURI/GAMAD/HRGU/SRSCS/SES, 3º Qq - 04/04/2021 a 04/06/2026, processo SEI 00060-00302336/2026-38. LIVIA ROCHA LEMOS, Matr.16750772, TECNICO EM ENFERMAGEM, lotação NRAD/GAMAD/HRGU/SRSCS/SES, 2º Qq - 03/05/2021 a 05/05/2026, processo SEI 00060-00302445/2026-55. UINDIE ANE LIMA LOPES GRILLO, Matr.16751078, TECNICO EM ENFERMAGEM, lotação NRAD/GAMAD/HRGU/SRSCS/SES, 2º Qq - 06/05/2021 a 30/05/2026, processo SEI 00060- 00302462/2026-92. MORGANA TAYNAN MARQUES CARNEIRO, Matr.16751981, FARMACEUTICO BIOQ. LABORATÓRIO, lotação NUPAC/GAMAD/HRGU/SRSCS/SES, 2º Qq - 04/05/2021 a 07/05/2026, processo SEI 00060-00302466/2026-71. ADRIANA LOPES DOS REIS, Matr.14328291, TECNICO EM ENFERMAGEM, lotação GEMERG/HRGU/SRSCS/SES, 3º Qq - 21/05/2021 a 19/05/2026, processo SEI 00060-00302500/2026-15. MARIA HELENA MAGALHAES DE ARAUJO, Matr.16750039, TECNICO EM ENFERMAGEM, lotação GENF/HRGU/SRSCS/SES, 2º Qq - 15/05/2021 a 13/05/2026, processo SEI 00060- 00302518/2026-17. MARINALVA FLORENCIA LIMA, Matr.1675283X, TECNICO EM ENFERMAGEM, lotação GENF/HRGU/SRSCS/SES, 2º Qq - 03/05/2021 a 01/05/2026, processo SEI 00060-00302539/2026-24. CLAUDINEY RODRIGUES ALVES, Matr.01546457, ENFERMEIRO, lotação GENF/HRGU/SRSCS/SES, 4º Qq - 19/04/2021 a 17/04/2026, processo SEI 00060-00298044/2026-93. IVENIO HELIO LOUZEIRO DE CASTRO, Matr.14341395, TECNICO EM ENFERMAGEM, lotação GENF/HRGU/SRSCS/SES, 3º Qq - 13/05/2021 a 11/05/2026, processo SEI 00060-00296953/2026-97. PEDRO HENRIQUE ALVES DO AMARAL, Matr.16751493, MEDICO - CLINICA MEDICA, lotação GEMERG/HRGU/SRSCS/SES, 2º Qq - 03/05/2021 a 01/05/2026, processo SEI 00060- 00298423/2026-83. ANDRE DE SOUSA SILVA, Matr.16752872, TECNICO EM ENFERMAGEM, lotação GEMERG/HRGU/SRSCS/SES, 2º Qq - 03/05/2021 a 01/05/2026, processo SEI 00060-00298445/2026-43. DIVINO HUGO DA SILVA, Matr.16755103, TECNICO EM ENFERMAGEM, lotação GEMERG/HRGU/SRSCS/SES, 2º Qq - 04/05/2021 a 03/05/2026, processo SEI 00060-00298458/2026-12.

RONAN ARAUJO GARCIA

ORDEM DE SERVIÇO Nº 202, DE 18 DE JUNHO DE 2026 O SUPERINTENDENTE DA REGIÃO DE SAÚDE CENTRO-SUL, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas por meio da Portaria nº 396, de 20 de junho de 2022, art. 13, resolve: AUTORIZAR a dispensa de ponto da servidora CLEONICE RABELO DE SOUZA, Fisioterapeuta, matrícula 1.443.871-2, lotada na Gerência de Serviços de Atenção Primária Nº 2 Do Riacho Fundo II, da Diretoria Regional de Atenção Primária à Saúde, da Superintendência da Região de Saúde Centro-Sul, da Secretaria de Estado de Saúde do Distrito Federal, para participar do Curso de Aperfeiçoamento em Hortos Agroflorestais Medicinais Biodinâmicos - ciclo 2026, promovido pelo (a) Fiocruz, com ônus Limitado para o Distrito Federal (somente remuneração do cargo), que ocorrerá na cidade de Brasília - DF, no período de 15/06/2026 a 09/10/2026, conforme Processo SEI 00060- 00257670/2026-20.

RONAN ARAÚJO GARCIA

### SUPERINTENDÊNCIA DA REGIÃO DE SAÚDE LESTE

ORDEM DE SERVIÇO Nº 371, DE 19 DE JUNHO DE 2026 A SUPERINTENDENTE DA REGIÃO DE SAÚDE LESTE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições Regimentais, conforme o disposto no Decreto nº 39.546, de 20 de dezembro de 2018, publicado no DODF nº 241 de 20/12/2018 e o Art. 13 da Portaria nº 396, de 20 de junho de 2022, publicada no DODF nº 114, de 21 de junho de 2022, resolve: CONCEDER Licença Prêmio por Assiduidade, nos termos da Lei 840/11, art. 139, aos seguintes servidores, listados por nome, matrícula, cargo, quinquênio, período e processo, quando houver, respectivamente: WANESSA ROSA PEREIRA, 14387751, TEC. HIGIENE DENTAL - THD, 2º quinquênio 24/06/2017 a 28/06/2022, 00060- 00143587/2017-83; WALDIR SOARES CORDEIRO, 01389025, MOTORISTA, 2º quinquênio 24/05/2005 a 22/05/2010, WALDIR SOARES CORDEIRO, 01389025, MOTORISTA, 4º quinquênio 05/07/2010 a 16/11/2015, WALDIR SOARES CORDEIRO, 01389025, MOTORISTA, 5º quinquênio 17/11/2015 a 24/02/2021, 00060- 00128854/2018-73; ANA KARLA FIGUEIRA CACAES, 14340429, TECNICO EM ENFERMAGEM, 2º quinquênio 14/05/2016 a 10/03/2026, 00060-00339022/2019-61; NAYARA SANTOS SILVA, 16856945, TECNICO ENFERMAGEM, 1º quinquênio

02/05/2018 a 03/06/2023, 00060-00239369/2024-72; SILVIA FERNANDA SANTANA DO NASCIMENTO, 01555693, AG. COMUNITARIO DE SAUDE, 3º quinquênio 26/09/2016 a 25/09/2021, 00060-00293828/2023-82. CONCEDER Licença Servidor aos servidores abaixo relacionados, nos termos da Lei Complementar nº 840/2011, alterada pela Lei Complementar nº 952/2019, condicionado o período de gozo aos critérios da Administração. Nome, matrícula, cargo, quinquênio, período e processo, quando houver, respectivamente: LUSILENE DE FATIMA BORGES, 01541854, TECNICO EM ENFERMAGEM, 4º quinquênio 21/05/2021 a 21/05/2026; JOCELEA DE LIRA MENDES, 01380192, MEDICO - PEDIATRIA, 5º quinquênio 15/04/2020 a 19/04/2025, 00060-00598787/2024-07; KELY CHRISTINA PEREIRA RAIMUNDO, 01508202, TECNICO EM ENFERMAGEM, 4º quinquênio 28/05/2020 a 26/05/2025, 00060-00272177/2026-30; WALDIR SOARES CORDEIRO, 01389025, MOTORISTA, 6º quinquênio 25/02/2021 a 06/06/2026, 00060-00128854/2018-73; ELIANE PACHECO DE ARAUJO LIMA, 01842625, AG. COMUNITARIO DE SAUDE, 3º quinquênio 24/01/2020 a 21/01/2025; THAIS FONSECA LIMA, 01897144, TERAPEUTA OCUPACIONAL, 3º quinquênio 19/05/2020 a 31/05/2025, 00060- 00280001/2023-17. AUTORIZAR a Dispensa de Ponto dos seguintes servidores, listados por nome, matrícula, cargo, evento, período de dispensa, local do evento e número do processo, quando houver, respectivamente: CAROLINE LOURENCO DE LIMA, 14366533, CIRURGIAO DENTISTA, Curso Maestria em Estética Gengival, 02/08/2026 a 08/08/2026, Curitiba - PR, 00060-00268002/2026-28. RETIFICAR ORDEM DE SERVIÇO Nº 338, DE 19 DE JULHO DE 2022, da Superintendência da Região de Saúde Leste, da Secretaria de Estado de Saúde do Distrito Federal, publicada no DODF Nº 136, DE 21 DE JULHO DE 2022, PÁGINA 46 o ato que concedeu licença prêmio por assiduidade à ELIANE PACHECO DE ARAUJO LIMA, matrícula 01842625, ONDE SE LÊ: "...25/01/2016 22/01/2021...", LEIA-SE: "...25/01/2015 23/01/2020...".

MARIA DE LOURDES CASTELO BRANCO

### SUPERINTENDÊNCIA DA REGIÃO DE SAÚDE SUDOESTE

ORDEM DE SERVIÇO Nº 170, DE 18 DE JUNHO DE 2026 O SUPERINTENDENTE DA REGIÃO DE SAÚDE SUDOESTE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 13 da Portaria n° 396 de 20 de junho de 2022, publicada no DODF nº 114, de 21 de junho de 2022, resolve: CONCEDER Licença Prêmio por Assiduidade nos termos do art. 139 da Lei Complementar nº 840/2011, condicionando o período de gozo aos critérios da Administração e observada a sequência de dados (nome, matrícula, cargo, quinquênio, período aquisitivo e número do processo) aos servidores: MARIA DO SOCORRO DA SILVA ROCHA, 1362208, Técnico em Enfermagem, 4º quinquênio, 11/04/2015 a 22/07/2020, 0271-000129/2001; EDSON DO NASCIMENTO VALE, 1556592, Agente Comunitário de Saúde, 3º quinquênio, 27/07/2016 a 25/07/2021, 00060-00466493/2019-41; VALERIA MIRANDA FRANCA QUEIROZ, 16863879, Cirurgião Dentista, 1º quinquênio, 27/06/2018 a 25/06/2023, 00060- 00025190/2026-00; LUZIA JANAINA MELO DE SOUZA, 0182942-4, Técnico Em Enfermagem, 2º QUINQUÊNIO, 02/11/2014 à 30/12/2019, SEI 00060-00087141/2026-52. CONCEDER Licença Servidor nos termos da Lei Complementar nº 840/2011, alterada pela Lei Complementar nº 952/2019, condicionado o período de gozo aos critérios da Administração e observada a sequência de dados (nome, matrícula, cargo, quinquênio, período aquisitivo e número de processo) aos servidores: VIVIANE SALES OLIVEIRA, 1836870, Agente Comunitário de Saúde, 1º quinquênio, 29/11/2019 a 22/02/2025, 00060-00453617/2025-77; PATRICIA GOMES MAIA, 14326698,Técnica de Enfermagem, 1º quinquênio, 24/03/2021 a 25/03/2026, 00060-00150401/2026-33; IARA PEREIRA DOS SANTOS, 1529404, Técnica de Enfermagem, 1º quinquênio, 30/01/2021 a 07/02/2026, 00060-00112680/2026-37; SUMARA FONTOURA FREIRE, 16714199, Técnico em Enfermagem, 1º Quinquênio, 22/07/2020 a 20/07/2025, 00060-00282465/2026-01; KELMA DE SOUSA COLARES, 14337673, Técnico em Enfermagem, 1º Quinquênio, 17/05/2021 a 15/05/2026, 00060- 00272989/2026-85; LUZIA JANAINA MELO DE SOUZA, 0182942-4, Técnico Em Enfermagem, 1º quinquênio, 31/12/2019 a 28/12/2024, 00060-00087141/2026-52; ZULMAR CARDOZO ARAUJO, 0131321-5, Técnico Administrativo, 1º Quinquênio, 09/05/2021 a 07/05/2026, 00060-00273876/2026-05; ALANA PAULA DA MATTA MAIA, 16750845, Cirurgiã Dentista, 1º quinquênio, 03/05/2021 a 02/05/2026, 00060- 00254349/2026-93. RETIFICAR, na Ordem de Serviço nº 36, de 06 de fevereiro de 2025, publicada no DODF nº 28, de 10.02.2025, pág. 68, o ato que concedeu Licença Servidor para ENEDINO BONFIM DE CARVALHO, ONDE SE LÊ: "... 6º quinquênio, 0.12.19 a 28.11.24, SEI 0061-033949/1999...", LEIA-SE: "...1º quinquênio, 01/12/2019 a 28/11/2024, 00060- 00286751/2026-37...”, ratificando-se as demais informações. TORNAR SEM EFEITO o ato que retificou o período licença servidor de ENEDINO BONFIM DE CARVALHO, matrícula 1352814, na Ordem de Serviço nº 46, de 14/02/2025, publicada no DODF nº 33, de 17/02/2025, página 37, devido incorreção nas informações. AVERBAR O TEMPO DE SERVIÇO E/OU CONTRIBUIÇÃO, prestado pelo (a) servidor (a) abaixo indicado (a), ao órgão e entidade a seguir mencionada (nome, matrícula, cargo, lotação):

<!-- pagina 36 -->

REGINA CLAUDIA MACHADO DO NASCIMENTO, 155.808-0, Agente Comunitário de Saúde, Secretaria de Estado de Saúde do Distrito Federal. 5.081 dias, ou seja, 13 anos, 11 meses e 6 dias, conforme certidão expedida pelo INSS, nos períodos de 1º de dezembro de 1982 a 28 de março de 1983, 1º de julho de 1983 a 30 de abril de 1984, 1º de março de 1985 a 1º de abril de 1987, 03 de abril de 1987 a 1º de julho de 1988, 1º de agosto de 1988 a 08 de março de 1990, 1º de setembro de 1992 a 11 de maio de 1996, 1º de agosto de 1997 a 16 de setembro de 1998, 09 de agosto de 1999 a 22 de novembro de 1999, 1º de fevereiro de 2001 a 19 de março de 2002, 02 de fevereiro de 2004 a 05 de junho de 2004 e 04 de abril de 2005 a 29 de junho de 2006, contados somente para fins de aposentadoria, conforme processo nº 00060-00258113/2026-26. FERNANDA CORDEIRO DE LIMA, 145.354-8, Farmacêutico Bioquímico - Farmácia, Secretaria de Estado de Saúde do Distrito Federal. 397 dias, ou seja, 1 ano, 1 mês e 2 dias, prestados ao Ministério da Defesa, no período de 1º de março de 2002 a 1º de abril de 2003, contados somente para fins de aposentadoria, conforme processo nº 00060-00265697/2026-96. JAQUELINE PEREIRA DA SILVA DE FARIA, 139.745-1, Enfermeiro, Secretaria de Estado de Saúde do Distrito Federal. 1.176 dias, ou seja, 3 anos, 2 meses e 21 dias, conforme certidão expedida pelo INSS, nos períodos de 10 de setembro de 1996 a 22 de dezembro de 1996, 23 de dezembro de 1996 a 31 de março de 1997, 1º de abril de 1997 a 03 de julho de 1997, 04 de julho de 1997 a 31 de dezembro de 1998, 1º de abril de 1999 a 30 de novembro de 1999 e 1º de dezembro de 1999 a 29 de fevereiro de 2000, contados somente para fins de aposentadoria, conforme processo nº 00060-00290125/2026-45.

JOSE HENRIQUE BARBOSA DE ALENCAR

ORDEM DE SERVIÇO Nº 175, DE 19 DE JUNHO DE 2026 O SUPERINTENDENTE DA REGIÃO DE SAÚDE SUDOESTE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 13 da Portaria n° 396 de 20 de junho de 2022, publicada no DODF nº 114, de 21 de junho de 2022, resolve: AUTORIZAR a Dispensa de Ponto do servidor DANILLO LEAL MARINHO VIEIRA, Médico da Família e Comunidade, matrícula 17104882, lotado na SES/SRSSO/DIRAPS/GSAP4-SAM, para participar do XXXIX Congresso do Conselho Nacional de Secretarias Municipais de Saúde (Conasems) a ser realizado em Porto Alegre/RS no período de 12/07/2026 a 15/07/2026 e e afastamento previsto para o mesmo período, conforme processo SEI n.º 00060-00266150/2026-16. AUTORIZAR a Dispensa de Ponto da servidora FERNANDA CAMILA LIMA DE TORRES LUCENA, Enfermeira, matrícula 14352087, lotado na SES/SRSSO/DIRAPS/GAPAPS, para participar do XXXIX Congresso do Conselho Nacional de Secretarias Municipais de Saúde (Conasems) a ser realizado em Porto Alegre/RS no período de 12/07/2026 a 15/07/2026 e afastamento previsto para 11/07/2026 a 16/07/2026, conforme processo SEI n.º 00060-00263833/2026-11. AUTORIZAR a Dispensa de Ponto da servidora LUCIVANE JULIA DE QUEIROZ, Enfermeira, matrícula 1564811, lotado na SES/SRSSO/DIRAPS/GERSO, para participar do XXXIX Congresso do Conselho Nacional de Secretarias Municipais de Saúde (Conasems) a ser realizado em Porto Alegre/RS no período de 12/07/2026 a 15/07/2026 e afastamento previsto para 11/07/2026 a 16/07/2026, conforme processo SEI n.º 00060- 00266301/2026-28. AUTORIZAR a Dispensa de Ponto da servidora JOANNA LIMA COSTA, Cirurgiã Dentista, matrícula 1686302X, lotada na SES/SRSSO/DIRAPS, para participar do XXXIX Congresso do Conselho Nacional de Secretarias Municipais de Saúde (Conasems) a ser realizado em Porto Alegre/RS no período de 12/07/2026 a 15/07/2026 e afastamento previsto para 11/07/2026 a 16/07/2026, conforme processo SEI n.º 00060-00263439/2026-75. AUTORIZAR a Dispensa de Ponto da servidora LETICIA KEIKO MORI, Médico Alergia e Imunologia, matrícula 16753402, lotada na SES/SRSSO/DIRASE/GSAS3, para participar do Type 2 Route - Na rota da dermatologia e Imunologia, a ser realizado em Curitiba/PR em 20/06/2026 e afastamento para o período de 19/06/2026 a 20/06/2026, conforme processo SEI n.º 00060-00203813/2026-83. AUTORIZAR a Dispensa de Ponto da servidora JULIANA FELIX SILVEIRA, Matrícula 01592424, lotada na SES/SRSSO/DIRAPS/GPMA, para participação no XXXIX Congresso do Conselho Nacional de Secretarias Municipais de Saúde CONASEMS 2026 a ser realizado em Porto Alegre-RS, no período de 12/07/2026 a 15/07/2026, com afastamento no período de 13/07/2026 a 16/07/2026, conforme processo SEI nº 00060- 00262312/2026-39.

JOSE HENRIQUE BARBOSA DE ALENCAR

### CONTROLADORIA SETORIAL DA SAÚDE

PORTARIA Nº 631, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 21, inciso IV, da Portaria Conjunta n° 24, de 11 de outubro de 2017, publicada no DODF n° 222, de 21 de novembro de 2017, do Senhor Secretário de Estado de Saúde do Distrito Federal e do Senhor Controlador-Geral do Distrito Federal em conjunto com a Lei Complementar n° 840, de 23 de dezembro de 2011, publicada no DODF n° 246, de 26 de dezembro de 2011, considerando a expressiva quantidade de demandas pendentes e o número insuficiente de servidores para a consecução dessas demandas, bem como os

princípios administrativos da eficiência, da celeridade, da economicidade, da razoabilidade e da proporcionalidade, e diante da premente necessidade de adoção de medidas indispensáveis ao bom andamento dos serviços desta Controladoria, resolve: Art. 1° Convocar as servidoras ANGELA NOLETO ALVES, matrícula nº 0142180-8; e THAIS MARTIELLE AVELAR FERNANDES, matrícula nº 1711012-2; para compor as Comissões subordinadas à Controladoria Setorial da Saúde. Art. 2º As servidoras convocadas por meio desta Portaria ficam condicionadas a exercer suas atividades nesta Controladoria e/ou nas Unidades subordinadas por um período mínimo de 2 (dois) anos. Os casos omissos serão decididos pelo Controlador Setorial da Saúde, conforme sua competência regimental. Art. 3º As servidoras convocadas deverão se apresentar à Controladoria Setorial da Saúde - CONT/SES imediatamente após a entrada em vigor desta Portaria, ressalvado eventual período de afastamento legal, quando a apresentação deverá ocorrer no primeiro dia útil subsequente ao término do afastamento. Art. 4º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

PORTARIA Nº 632, DE 19 DE JUNHO DE 2026 O CONTROLADOR SETORIAL DA SAÚDE, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 38 do Decreto nº 39.546, de 19 de dezembro de 2018, e considerando o artigo 4º, parágrafo único, da Portaria nº 332, de 10 de dezembro de 2019, que estabelece critérios para utilização da resposta complementar e outras medidas para garantir a efetividade da participação popular dos serviços públicos prestados por meio da Secretaria de Estado de Saúde do Distrito Federal, resolve: Art. 1º Designar como interlocutor e suplente para atuar nas Unidades, Subsecretarias, Coordenações, Diretorias, Gerências e Núcleos da Secretaria de Estado de Saúde do Distrito Federal para tratamento das manifestações de Ouvidoria e das demandas da Lei de Acesso à Informação com prioridade em relação às suas outras atribuições, conforme determinação do Decreto nº 39.723, de 19 de março de 2019, a servidora do setor listado a seguir: I - DIRETORIA DO LABORATÓRIO CENTRAL DE SAÚDE PÚBLICA (LACEN): SOLANGE MARIA MARQUES SILVA PEIXOTO FAGUNDES, matrícula nº 1445153-X, como interlocutora suplente, conforme termos do processo SEI nº 00060-00511277/2024-25. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

BRUNO ARAÚJO LOPES

### HOSPITAL SÃO VICENTE DE PAULO

ORDEM DE SERVIÇO Nº 43, DE 19 DE JUNHO DE 2026 O DIRETOR GERAL DO HOSPITAL SÃO VICENTE DE PAULO, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o Regimento Interno da Secretaria de Estado de Saúde do Distrito Federal, aprovado pelo Decreto Nº 38.017, de 21 de fevereiro de 2017, e das que lhe foram delegadas por meio do artigo 13, inciso XI, da Portaria nº 396/2022, publicada no DODF nº 114 de 21 de junho de 2022, páginas 11 e 12, resolve: RETIFICAR, na Ordem de Serviço n° 41 de 08/06/2026, publicada no DODF nº 104, de 10/06/2026, p.39, o ato que concedeu o Abono de Permanência à MARISTELA SOARES DA SILVA, matrícula nº 01586939, do cargo de Enfermeiro, Casse Especial, Padrão IV, do Quadro de Pessoal da Secretaria de Estado de Saúde do Distrito Federal, ONDE SE LÊ: “…

CONCEDER ABONO DE PERMANÊNCIA ESPECIAL…”, LEIA-SE: “...CONCEDER

ABONO DE PERMANÊNCIA...”, ficando ratificados os demais termos. Processo n° 00060-00170993/2026-18.

EULER JUNIO MOREIRA NASCIMENTO

### FUNDAÇÃO HEMOCENTRO DE BRASÍLIA

INSTRUÇÃO Nº 178, DE 19 DE JUNHO DE 2026 O PRESIDENTE DA FUNDAÇÃO HEMOCENTRO DE BRASÍLIA, Substituto, no uso das atribuições que lhe confere o item III, do Artigo 3° do Regimento Interno da Fundação Hemocentro de Brasília, aprovado pelo Decreto nº 43.477, de 24 de junho de 2022, resolve: HOMOLOGAR o afastamento, nos termos do Decreto n° 29.290, de 22 de julho de 2008 e do Decreto n° 39.133, de 15 de junho de 2018, mediante dispensa de ponto, com ônus parcial, do (a) servidor(a) NATHALIA LIMA PEDROSA, Analista de Atividades do Hemocentro, matrícula nº 16822609, para participar do XI Fórum Nacional da Rede de Parcerias, Transferências e Compras Públicas - PARCOM, em Brasília - DF, promovido pelo MINISTÉRIO DA GESTÃO E DA INOVAÇÃO EM SERVIÇOS PÚBLICOS, de 09/06 a 11/06 de 2026. Processo 00063-00002952/2026-15

GILSON MARTINS RIBEIRO

## SECRETARIA DE ESTADO DE EDUCAÇÃO

PORTARIA DE 19 DE JUNHO DE 2026 A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições previstas no inciso V do parágrafo único do artigo 105 da Lei Orgânica do Distrito Federal, resolve: DESIGNAR WASHINGTON TAVARES DA ROCHA, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.307-3, para exercer a Função Gratificada Escolar,

<!-- pagina 37 -->

Símbolo FGE-02, SIGRH 52006640, de Chefe de Secretaria, do Centro de Ensino Médio 02 do Gama, da Coordenação Regional de Ensino do Gama, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00159233/2026-77. DESIGNAR TELMA APOSTOLO EVANGELISTA, Analista em Políticas Públicas e Gestão Educacional, matrícula 249.895-2, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009226, de Supervisor, da Escola Classe 02 do Gama, da Coordenação Regional de Ensino do Gama, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00065032/2026-18. DISPENSAR DENIS AUGUSTO DE FARIA MACEDO, Analista em Políticas Públicas e Gestão Educacional, matrícula 30.871-4, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52005567, de Chefe de Secretaria, da Escola Classe 305 Sul, da Coordenação Regional de Ensino do Plano Piloto, da Secretaria de Estado de Educação do Distrito Federal, a contar de 15 de maio de 2026. Processo 00080-00185725/2026-18. DESIGNAR THAIS DANIELE GONÇALVES LESSA, Analista em Políticas Públicas e Gestão Educacional, matrícula 225.572-3, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52005567, de Chefe de Secretaria, da Escola Classe 305 Sul, da Coordenação Regional de Ensino do Plano Piloto, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00185725/2026-18. DISPENSAR MAGNA PEREIRA DA SILVA, Professor de Educação Básica, matrícula 256.333-9, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009011, de Supervisor, do Centro de Educação Profissional Escola Sabores Oscar, da Coordenação Regional de Ensino do Plano Piloto, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00216968/2026-13. DESIGNAR EVELYN DA SILVA CORDEIRO, Professor de Educação Básica, matrícula 259.802-7, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009011, de Supervisor, do Centro de Educação Profissional Escola Sabores Oscar, da Coordenação Regional de Ensino do Plano Piloto, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00216968/2026-13. DISPENSAR, por motivo de aposentadoria, JOVENILCE PEREIRA DE SOUZA, Analista em Políticas Públicas e Gestão Educacional, matrícula 25.337-5, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52005998, de Chefe de Secretaria, do Centro Interescolar de Línguas de Brazlândia, da Coordenação Regional de Ensino de Brazlândia, da Secretaria de Estado de Educação do Distrito Federal, a contar de 1º de abril de 2026. Processo 00080-00128736/2026-09. DESIGNAR DENISE VIEIRA TAVARES, Analista em Políticas Públicas e Gestão Educacional, matrícula 252.327-2, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52005998, de Chefe de Secretaria, do Centro Interescolar de Línguas de Brazlândia, da Coordenação Regional de Ensino de Brazlândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00128736/2026-09. DISPENSAR, por motivo de aposentadoria, REGINA CERQUEIRA DE BRITO REDONDO, Analista em Políticas Públicas e Gestão Educacional, matrícula 24.526-7, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006301, de Chefe de Secretaria, do Centro de Ensino Especial 01 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal, a contar de 01 de junho de 2026. Processo 00080-00212498/2026-19. DESIGNAR ANA PAULA DE SOUSA, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.262-X, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006301, de Chefe de Secretaria, do Centro de Ensino Especial 01 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00212498/2026-19. DISPENSAR MARIA ELENEUDA GRAÇAS DA SILVA BELO, Técnico em Políticas Públicas e Gestão Educacional, matrícula 210.292-7, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006378, de Chefe de Secretaria, do Centro de Ensino Médio 12 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00342629/2025-01. DESIGNAR WELMA ABADIA CAMPELO DE MIRANDA, Analista em Políticas Públicas e Gestão Educacional, matrícula 23.102-9, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006306, de Chefe de Secretaria, do Centro de Ensino Especial 02 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00140614/2026-82. DESIGNAR CLAUDIA ROSA DOS SANTOS, Analista em Políticas Públicas e Gestão Educacional, matrícula 254.856-9, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006378, de Chefe de Secretaria, do Centro de Ensino Médio 12 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00342629/2025-01. DESIGNAR SULENE DE ANDRADE MATOS, Analista em Políticas Públicas e Gestão Educacional, matrícula 248.248-7, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52006074, de Chefe de Secretaria, da Escola Classe 15 de Ceilândia, da Coordenação Regional de Ensino de Ceilândia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00199351/2026-18. DISPENSAR, a pedido, EMILAINE DE PAULA OLIVEIRA, Analista em Políticas Públicas e Gestão Educacional, matrícula 243.401-6, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52008701, de Chefe de Secretaria, do Centro Interescolar de Línguas do Riacho Fundo II, da Coordenação Regional de Ensino do Núcleo Bandeirante, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00155460/2026-23.

DESIGNAR LUANA DE MELO MACHADO, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.236-0, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52008701, de Chefe de Secretaria, do Centro Interescolar de Línguas do Riacho Fundo II, da Coordenação Regional de Ensino do Núcleo Bandeirante, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00209873/2026-35. DISPENSAR, por estar sendo designada para outra Função Gratificada Escolar, LUANA DE MELO MACHADO, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.236-0, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52010005, de Chefe de Secretaria, do Centro de Educação Infantil Parque do Riacho, da Coordenação Regional de Ensino do Núcleo Bandeirante, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00209873/2026-35. DISPENSAR, por ter sido nomeada para outra Função Gratificada Escolar, ANA LIDIA ALVES ROCHA, Analista em Políticas Públicas e Gestão Educacional, matrícula 213.818- 2, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009521, de Supervisor, da Escola Classe Córrego do Atoleiro, da Coordenação Regional de Ensino de Planaltina, da Secretaria de Estado de Educação do Distrito Federal, a contar de 30 de março de 2026. Processo 00080-00180478/2026-63. DESIGNAR JAQUELINE SUZAMAR ALVES DOS SANTOS, Analista em Políticas Públicas e Gestão Educacional, matrícula 252.470-8, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009521, de Supervisor, da Escola Classe Córrego do Atoleiro, da Coordenação Regional de Ensino de Planaltina, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00180478/2026-63. DISPENSAR, a pedido, ARIELLE PIRES MACIEL, Analista em Políticas Públicas e Gestão Educacional, matrícula 223.912-4, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009505, de Supervisor, do Centro de Ensino Fundamental Juscelino Kubitschek, da Coordenação Regional de Ensino de Planaltina, da Secretaria de Estado de Educação do Distrito Federal, a contar de 16 de junho de 2026. Processo 00080-00211693/2026-13. DESIGNAR LUCIANA MACHADO MAIA, Analista em Políticas Públicas e Gestão Educacional, matrícula 254.850-X, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52009713, de Supervisor, da Escola Classe 425 de Samambaia, da Coordenação Regional de Ensino de Samambaia, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00015317/2026-08. DISPENSAR MAYARA ALVARENGA QUEIROZ, Analista em Políticas Públicas e Gestão Educacional, matrícula 252.988-2, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52008861, de Supervisor, do Centro de Ensino Fundamental 09 de Sobradinho, da Coordenação Regional de Ensino de Sobradinho, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00209909/2026-81. DESIGNAR CHRISTIANNE OLIVEIRA SILVA SANTOS, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.535-1, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52008861, de Supervisor, do Centro de Ensino Fundamental 09 de Sobradinho, da Coordenação Regional de Ensino de Sobradinho, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00209909/2026-81. DISPENSAR, a pedido, LELIANE BARBOSA ARAUJO, Analista em Políticas Públicas e Gestão Educacional, matrícula 213.271-0, da Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52007680, de Chefe de Secretaria, do Centro Educacional 02 de Taguatinga, da Coordenação Regional de Ensino de Taguatinga, da Secretaria de Estado de Educação do Distrito Federal, a contar de 16 de junho de 2026. Processo 00080-00211288/2026-03. DESIGNAR ROSILENE CONCEIÇÃO FERREIRA, Analista em Políticas Públicas e Gestão Educacional, matrícula 253.850-4, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH 52007680, de Chefe de Secretaria, do Centro Educacional 02 de Taguatinga, da Coordenação Regional de Ensino de Taguatinga, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080-00208594/2026-54. TORNAR SEM EFEITO, na Portaria de 31 de março de 2026, publicada no DODF nº 61, em 1º/04/2026, página 73, o ato que designou ANA CLAUDIA TRINDADE BESSA DE SOUSA, Analista em Políticas Públicas e Gestão Educacional, matrícula 22.992-X, para exercer a Função Gratificada Escolar, Símbolo FGE-02, SIGRH nº 52006832, de Chefe de Secretaria, do Centro de Ensino Especial 01 do Guará, da Coordenação Regional de Ensino do Guará, da Secretaria de Estado de Educação do Distrito Federal. Processo 00080- 00062125/2026-82.

IÊDES SOARES BRAGA

PORTARIA Nº 297, DE 19 DE JUNHO DE 2026 Altera a Portaria nº 1.198, de 5 de novembro de 2025, que instituiu a 2ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias. A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições que lhe são conferidas por meio do artigo 105 da Lei Orgânica do Distrito Federal, resolve: Art. 1º Alterar o inciso II do artigo 3º da Portaria nº 1.198, de 5 de novembro de 2025, que instituiu a 2ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias, que passa a vigorar com a seguinte redação: "Art. 3º ........................ (...) II - MATHEUS FERNANDES COUTO, matrícula 253.194-1, Vogal;" (NR) Art. 2º Esta Portaria entra em vigor na data de sua publicação.

IÊDES SOARES BRAGA

<!-- pagina 38 -->

PORTARIA Nº 298, DE 19 DE JUNHO DE 2026 A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições que lhe são conferidas por meio da alínea "f" do inciso II do artigo 1º do Decreto nº 39.133, de 15 de junho de 2018, em atenção ao Decreto nº 45.001, de 26 de setembro de 2023, resolve: Art. 1º Autorizar o afastamento do servidor WALLISON CHAGAS LUCAS, matrícula 215.532-X, para participar do II Encontro Formativo da Rede Nacional de implementação do Programa Pé-de-Meia, em Maceió/AL, no período de 15 a 19 de junho de 2026, com ônus limitado para o Distrito Federal, conforme Processo 00080-00217795/2026-42. Art. 2º Esta Portaria entra em vigor na data de sua publicação.

IÊDES SOARES BRAGA

PORTARIA Nº 299, DE 19 DE JUNHO DE 2026 Altera a Portaria nº 105, de 9 de janeiro de 2026, que instituiu a 3ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias. A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições que lhe são conferidas por meio do artigo 105 da Lei Orgânica do Distrito Federal, resolve: Art. 1º Alterar o inciso I do artigo 3º da Portaria nº 105, de 9 de janeiro de 2026, que instituiu a 3ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias, que passa a vigorar com a seguinte redação: "Art. 3º ........................ I - MATHEUS FERNANDES COUTO, matrícula 253.194-1, Presidente;" (NR) Art. 2º Esta Portaria entra em vigor na data de sua publicação.

IÊDES SOARES BRAGA

PORTARIA Nº 300, DE 19 DE JUNHO DE 2026 Altera a Portaria nº 106, de 9 de janeiro de 2026, que instituiu a 4ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias. A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições que lhe são conferidas por meio do artigo 105 da Lei Orgânica do Distrito Federal, resolve: Art. 1º Alterar o inciso III do artigo 3º da Portaria nº 106, de 9 de janeiro de 2026, que instituiu a 4ª Comissão Especial destinada à apuração de Processos Administrativos Disciplinares e Sindicâncias, que passa a vigorar com a seguinte redação: "Art. 3º ........................ (...) III - MATHEUS FERNANDES COUTO, matrícula 253.194-1, Vogal;" (NR) Art. 2º Esta Portaria entra em vigor na data de sua publicação.

IÊDES SOARES BRAGA

### SUBSECRETARIA DE GESTÃO DE PESSOAS

ORDEM DE SERVIÇO Nº 235, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DE GESTÃO DE PESSOAS, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pela alínea “b” do inciso X do art. 14 da Portaria nº 367, de 21/07/2021, publicada no DODF nº 137, de 22/07/2021, resolve: CONCEDER, nos termos do art. 137 da Lei Complementar nº 840, de 23/12/2011, afastamento em razão da desincompatibilização do agente público, com remuneração, à servidora HÉLVIA MIRIDAN PARANAGUÁ FRAGA, matrícula n.º 300.692-1, no período de 04/07/2026 a 14/10/2026, conforme processo nº 00080-00213415/2026-09. CONCEDER, nos termos do art. 137 da Lei Complementar nº 840, de 23/12/2011, afastamento em razão da desincompatibilização do agente público, com remuneração, servidor CRISTIANO LUZ DA SILVA PINTO, matrícula 32.594-5, no período de 04/07/2026 a 14/10/2026, conforme processo nº 00080-00205107/2026-00. CONCEDER, nos termos do art. 137 da Lei Complementar nº 840, de 23/12/2011, afastamento em razão da desincompatibilização do agente público, com remuneração, servidor NILVAN PEREIRA DE VASCONCELLOS, matrícula n.º 35.573-9, no período de 04/07/2026 a 14/10/2026, conforme processo nº 00080-00209411/2026-18.

ANA PAULA DE OLIVEIRA AGUIAR BASTOS

ORDEM DE SERVIÇO Nº 236, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DE GESTÃO DE PESSOAS, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pela alínea “d” do inciso XI do art. 14 da Portaria nº 367, de 21/07/2021, publicada no DODF nº 137, de 22/07/2021, resolve: CONCEDER, nos termos do art. 162, §1º, item II, da Lei Complementar nº 840, de 23/12/2011, afastamento para frequência no curso de formação, referente ao concurso para o provimento de vagas do Fundo Nacional de Desenvolvimento da Educação, sem remuneração, no período de 22/06/2026 a 10/07/2026, ao servidor JOAO GUILHERME PARANHOS MICELI, matrícula 228.953-9, conforme Processo nº 00080-00203399/2026-38. CONCEDER, nos termos do art. 162, §1º, item II, da Lei Complementar nº 840, de 23/12/2011, afastamento para frequência no curso de formação, referente ao concurso para o provimento de vagas do Fundo Nacional de Desenvolvimento da Educação, sem remuneração, no período de 22/06/2026 a 10/07/2026, ao servidor GESSE CHAVES MACEDO, matrícula 256.269-3, conforme Processo nº 00080-00208539/2026-64.

ANA PAULA DE OLIVEIRA AGUIAR BASTOS

ORDEM DE SERVIÇO Nº 237, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DE GESTÃO DE PESSOAS, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pela alínea “f” do inciso XI do art. 14 da Portaria nº 367, de 21/07/2021, publicada no DODF nº 137, de 22/07/2021, resolve: AUTORIZAR, em caráter de homologação, o afastamento nos termos do Decreto nº 29.290, de 22/07/2008, mediante dispensa de ponto, à servidora GISELLY LINS GOMES, matrícula nº 2001.336-1, para participar do Seminário Internacional sobre financiamento da Educação, em Brasília/DF, nos dias 25/03/2026 e 26/03/2026, conforme Processo nº 00080- 00209619/2026-37. AUTORIZAR, em caráter de homologação, o afastamento nos termos do Decreto nº 29.290, de 22/07/2008, mediante dispensa de ponto, à servidora ALESSANDRA SALOMÃO DE SOUZA ALVES, matrícula nº 20.425-0, para participar do 31º Congresso Internacional ABED de Educação a Distância, em João Pessoas/PB, no período de 26/04/2026 a 30/04/2026, conforme processo nº 00080-00117458/2026-56. AUTORIZAR, em caráter de homologação, o afastamento nos termos do Decreto nº 29.290, de 22/07/2008, mediante dispensa de ponto, ao servidor DANIEL ALVES PEREIRA JUNIOR, matrícula nº 253.823-7, para participar do II Encontro Formativo da Rede Nacional de Implementação do Programa Pé-de-Meia, em Maceió/AL, no período de 15/06/2026 a 19/06/2026, conforme Processo nº 00080-00211732/2026-82. AUTORIZAR afastamento, nos termos do Decreto nº 29.290, de 22/07/2008, mediante dispensa de ponto, à servidora KEILLA CHRISTINA DESIDERIO DA SILVA, matrícula 38.959-5, para participar do X ENEBIO - Encontro Nacional de Ensino de Biologia, em João Pessoa/PB, no período de 24/08/2026 a 28/08/2026, conforme Processo nº 00080-00196903/2026-36. AUTORIZAR o afastamento, nos termos do Decreto nº 29.290, de 22/07/2008, mediante dispensa de ponto, ao servidor WEBERSON CAMPOS FERREIRA, matrícula 223.312-6, para participar do IV Encontro Nacional de Educação Matemática Inclusiva, em Campo Grande/MS, no período de 29/07/2026 a 31/07/2026, conforme Processo nº 00080- 00194692/2026-05.

ANA PAULA DE OLIVEIRA AGUIAR BASTOS

ORDEM DE SERVIÇO Nº 238, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DE GESTÃO DE PESSOAS DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pelo inciso XII do art. 14 da Portaria nº 367, de 21/07/2021, publicada no DODF nº 137, de 22/07/2021, resolve: HOMOLOGAR a opção pelo regime de 40 (quarenta) horas semanais de trabalho da servidora MARIANNA GERMANO GOMES DE BARROS, matrícula nº 219.673-5, ocupante do cargo de Analista de Gestão e Políticas Públicas e Gestão Educacional, conforme disposto no § 2º do art. 8º da Lei nº 5.106, de 03/05/2013, a contar de 25/05/2026, conforme processo nº 00080-00001061/2024-81.

ANA PAULA DE OLIVEIRA AGUIAR BASTOS

### CORREGEDORIA

ORDEM DE SERVIÇO Nº 538, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF nº 143, de 29 de julho de 2024, p. 38, c/c com o disposto no artigo 20, inciso V, do Regimento Interno da Secretaria de Estado do Distrito Federal, resolve: Art. 1º Conhecer e DEFERIR o Pedido de Reconsideração apresentado no Processo Administrativo Disciplinar nº 00080.00236146/2025-60; Art. 2º Reformar o ato de julgamento, fixando-se a penalidade de SUSPENSÃO de 15 (quinze) dias, convertida em multa, ao servidor MAICON DERLAN SALES DOS SANTOS, matrícula 210.760-0, nos termos do Art. 200, § 3º, da Lei Complementar nº 840/2011. Art. 3º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 539, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria-Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Instaurar o Processo Administrativo Disciplinar n° 00080-00221312/2026-12, visando à apuração de supostas irregularidades constantes e referenciadas no Processo n° 00080-00293750/2024-11. Art. 2º Designar JOSÉ MARIA PINHEIRO, matrícula 33.694-7, DANIEL CORREA E CASTRO SOARES, matrícula 214.451-4, e AISHA PAULO FONSECA, matrícula 205.776-X, todos Professores de Educação Básica; para, sob a presidência do primeiro, conduzirem os trabalhos. Art. 3º Designar EMÍLIA DE CASTRO LUNA, matrícula 33.261-5, Professora da Educação Básica, para atuar como substituto eventual nas licenças, afastamentos, férias e demais ausências dos titulares, em consonância com o artigo 229, § 7º, da Lei Complementar n° 840/2011.

<!-- pagina 39 -->

Art. 4º A Comissão Processante deverá dedicar-se integralmente aos trabalhos que lhe forem atribuídos e seus membros dispensados das atividades na repartição de origem, até a entrega do relatório final, nos termos do artigo 233, da Lei Complementar nº 840 de 2011. Art. 5º Estabelecer o prazo de 60 (sessenta) dias para a conclusão dos trabalhos. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 540, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria-Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Instaurar o Processo Administrativo Disciplinar n° 00080-00221364/2026-81, visando à apuração de supostas irregularidades constantes e referenciadas no Processo n° 00080-00290000/2024-89. Art. 2º Designar JOSÉ MARIA PINHEIRO, matrícula 33.694-7, DANIEL CORREA E CASTRO SOARES, matrícula 214.451-4 e AISHA PAULO FONSECA, matrícula 205.776-X, todos Professores de Educação Básica; para, sob a presidência do primeiro, conduzirem os trabalhos. Art. 3º Designar EMÍLIA DE CASTRO LUNA, matrícula 33.261-5, Professora de Educação Básica, para atuar como substituto eventual nas licenças, afastamentos, férias e demais ausências dos titulares, em consonância com o artigo 229, § 7º, da Lei Complementar n° 840/2011. Art. 4ºA Comissão Processante deverá dedicar-se integralmente aos trabalhos que lhe forem atribuídos e seus membros dispensados das atividades na repartição de origem, até a entrega do relatório final, nos termos do artigo 233, da Lei Complementar nº 840 de 2011. Art. 5º Estabelecer o prazo de 60 (sessenta) dias para a conclusão dos trabalhos. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 541, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria-Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Instaurar o Processo Administrativo Disciplinar n° 00080-00221290/2026-82, visando à apuração de supostas irregularidades constantes e referenciadas no Processo n° 00080-00262177/2023-12. Art. 2º Designar JOSÉ MARIA PINHEIRO, matrícula 33.694-7, DANIEL CORREA E CASTRO SOARES, matrícula 214.451-4, e AISHA PAULO FONSECA, matrícula 205.776-X, todos Professores de Educação Básica; para, sob a presidência do primeiro, conduzirem os trabalhos. Art. 3º Designar EMÍLIA DE CASTRO LUNA, matrícula 33.261-5, Professora de Educação Básica, para atuar como substituto eventual nas licenças, afastamentos, férias e demais ausências dos titulares, em consonância com o artigo 229, § 7º, da Lei Complementar n° 840/2011. Art. 4º A Comissão Processante deverá dedicar-se integralmente aos trabalhos que lhe forem atribuídos e seus membros dispensados das atividades na repartição de origem, até a entrega do relatório final, nos termos do artigo 233, da Lei Complementar nº 840 de 2011. Art. 5º Estabelecer o prazo de 60 (sessenta) dias para a conclusão dos trabalhos. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 542, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Instaurar o Processo Administrativo Disciplinar n° 00080-00221247/2026-17, visando à apuração de supostas irregularidades constantes e referenciadas no Processo n° 00080-00047937/2024-36. Art. 2º Designar JOSÉ MARIA PINHEIRO, matrícula 33.694-7, DANIEL CORREA E CASTRO SOARES, matrícula n° 214.451-4 e AISHA PAULO FONSECA, matrícula n° 205.776-X, todos Professor da Educação Básica; para, sob a presidência da primeira, conduzirem os trabalhos.

Art. 3º Designar EMÍLIA DE CASTRO LUNA, matrícula 33.261-5, Professora de Educação Básica, para atuar como substituto eventual nas licenças, afastamentos, férias e demais ausências dos titulares, em consonância com o artigo 229, § 7º, da Lei Complementar n° 840/2011. Art. 4ºA Comissão Processante deverá dedicar-se integralmente aos trabalhos que lhe forem atribuídos e seus membros dispensados das atividades na repartição de origem, até a entrega do relatório final, nos termos do artigo 233, da Lei Complementar nº 840 de 2011. Art. 5º Estabelecer o prazo de 60 (sessenta) dias para a conclusão dos trabalhos. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

ORDEM DE SERVIÇO Nº 543, DE 19 DE JUNHO DE 2026 A CHEFE DA CORREGEDORIA, DA SECRETARIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pela Portaria n° 808, de 26 de julho de 2024, publicada no DODF n° 143, de 29 de julho de 2024, p. 38, consoante o disposto no artigo 20, inciso III, alínea "d" do Regimento Interno da Secretaria de Estado de Educação do Distrito Federal, com fundamento no artigo 8º, inciso II, alínea "b", da Instrução Normativa n° 02, de 19 de outubro de 2021, da Controladoria Geral do Distrito Federal, c/c artigos 211, 212, inciso II, e 217, todos da Lei Complementar n° 840/2011, resolve: Art. 1º Instaurar o Processo Administrativo Disciplinar n° 00080-00221238/2026-26, visando à apuração de supostas irregularidades constantes e referenciadas no Processo n° 00080-00104082/2023-77. Art. 2º Designar JOSÉ MARIA PINHEIRO, matrícula 33.694-7, DANIEL CORREA E CASTRO SOARES, matrícula 214.451-4 e AISHA PAULO FONSECA, matrícula 205.776-X, todos Professores de Educação Básica; para, sob a presidência do primeiro, conduzirem os trabalhos. Art. 3º Designar EMÍLIA DE CASTRO LUNA, matrícula 33.261-5, Professora da Educação Básica, para atuar como substituto eventual nas licenças, afastamentos, férias e demais ausências dos titulares, em consonância com o artigo 229, § 7º, da Lei Complementar n° 840/2011. Art. 4º A Comissão Processante deverá dedicar-se integralmente aos trabalhos que lhe forem atribuídos e seus membros dispensados das atividades na repartição de origem, até a entrega do relatório final, nos termos do artigo 233, da Lei Complementar nº 840 de 2011. Art. 5º Estabelecer o prazo de 60 (sessenta) dias para a conclusão dos trabalhos. Art. 6º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANA PAULA GADELHA MARQUES MEIRA

## UNIVERSIDADE DO DISTRITO FEDERAL PROFESSOR JORGE AMAURY MAIA NUNES

INSTRUÇÃO Nº 24, DE 15 DE JUNHO DE 2026 Altera a composição de membros da Unidade Setorial de Gestão do SEI-GDF no âmbito da Universidade do Distrito Federal Professor Jorge Amaury Maia Nunes-UnDF. A REITORA PRO TEMPORE DA UNIVERSIDADE DO DISTRITO FEDERAL PROFESSOR JORGE AMAURY MAIA NUNES, no uso de suas atribuições legais, conferidas pela Lei Complementar nº 987, de 26 de julho de 2021, e pelo Decreto nº 42.333, de 26 de julho de 2021, resolve: Art. 1º A Unidade Setorial de Gestão do Sistema Eletrônico de Informações - SEI-GDF, instituída pela Instrução nº 10, de 25 de Fevereiro de 2025, e publicada no DODF nº 41, em 27/02/2025, passa a ser composta pelos seguintes membros: I. LARISSA CINTHIA DA SILVA BARRETO LIMA, matrícula nº 255.432-1; II. EDELISE MARIA CARVALHO SILVA, matrícula nº 249.352-7; III. HUGO MARQUES DA ROCHA, matrícula nº 1.723.460-3; IV. LUIZ FERNANDO LEITE DOS SANTOS, matrícula nº 249.318-7; V. YGOR EVILÁSIO DA SILVA OLIVEIRA, matrícula nº 1.726.176-7; VI. FLÁVIO MASCARENHAS RORIZ PEDROSA, matrícula nº 255.699-5. Parágrafo único. A coordenação da Unidade Setorial de Gestão do SEI-GDF no âmbito da UnDF caberá ao primeiro membro indicado e, em sua ausência, será substituído pelo segundo membro. Art. 2º Esta Instrução Normativa entra em vigor na data de sua publicação.

FERNANDA MARSARO DOS SANTOS

## SECRETARIA DE ESTADO DE SEGURANÇA PÚBLICA

### SECRETARIA EXECUTIVA DE GESTÃO INTEGRADA

SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 44, DE 18 DE JUNHO DE 2026 O SUBSECRETÁRIO DE ADMINISTRAÇÃO GERAL, DA SECRETARIA EXECUTIVA DE GESTÃO INTEGRADA, DA SECRETARIA DE ESTADO DE SEGURANÇA PÚBLICA DO DISTRITO FEDERAL, no uso das atribuições que lhe confere a Portaria nº 141, de 30 de junho de 2015, desta Secretaria, cumulado com o artigo 28, XI, do Regimento Interno da Pasta, aprovado pelo Decreto nº 40.079/2019, resolve:

<!-- pagina 40 -->

Art. 1º Designar o servidor VINICIUS FIUZA DUMAS, matrícula nº 1.719.190-4, na função de Gestor; o servidor JONAS CONSULE BENINCÁ, matrícula nº 1.675.165-5, na função de Fiscal Administrativo; e a servidora IZABELA BARBOSA MIGUEL, matrícula nº 1.726.333-6, como fiscal técnico, todos com a finalidade de exercer a supervisão, fiscalização e acompanhamento do Contrato nº 16/2026-FUSP, firmado com a empresa ELO CONSULTORIA EMPRESARIAL E PRODUCAO DE EVENTOS, cujo objeto é a participação em curso presencial de planejamento das contratações, conforme processo SEI nº 00050-00002589/2026-41. Art. 2ª Esta Ordem de Serviço entra em vigor na data de sua publicação.

SILVÉRIO ANTONIO MOITA DE ANDRADE

### CASA MILITAR

PORTARIA Nº 104, DE 18 DE JUNHO DE 2026 (*) O CHEFE DA CASA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe são conferidas pelo Art. 55, incisos II e XII, do Regimento Interno da Casa Militar da Governadoria do Distrito Federal, aprovado pelo Decreto nº 34.258, de 03 de abril de 2013, resolve: Art. 1º Instituir Grupo de Trabalho com a finalidade de realizar estudos técnicos e análise de viabilidade para a implementação de solução tecnológica de controle de acesso no Palácio do Buriti e no Centro Administrativo do Distrito Federal (CAD-GDF), bem como para a criação de Gabinete de Identificação no âmbito da Casa Militar. Art. 2º Ficam designados para compor o Grupo de Trabalho os seguintes militares: I - CEL QOPM JULIANO CARVALHO DE FARIAS , Matrícula GDF 1730907-7 (Coordenador); II - CEL QOBM/Comb. CELSO CARLOS ANTUNES JUNIOR, Matrícula GDF 1727030- 8 (Membro); III - TC QOPM GENILSON FIGUEIREDO DE OLIVEIRA, Matrícula GDF 1729218-2 (Membro); IV - TC QOPM FRANCISCO GUILHERME LIMA MACEDO, Matrícula GDF 1727373- 0 (Membro); V - TC QOPM THIAGO GOMES NASCIMENTO, Matrícula GDF 1727542-3 (Membro); VI - MAJ QOPM GUILHERME MORAIS DE CARVALHO, Matrícula GDF 1727085-5 (Membro). Art. 3º Os estudos deverão contemplar a análise técnica, operacional e de viabilidade relativa à aquisição, implantação e utilização dos seguintes recursos e sistemas de segurança: I - Equipamentos de inspeção por raios X; II - Pórticos de detecção de metais; III - Catracas eletrônicas para controle de acesso; IV - Cartões de identificação funcional e de visitantes; V- Sistemas de reconhecimento facial; e VI - Sistema de Circuito Fechado de Televisão - CFTV. Art. 4º O Grupo de Trabalho deverá apresentar relatório técnico conclusivo à Chefia da Casa Militar no prazo de 30 (trinta) dias, contados da data de publicação desta Portaria, contendo as análises realizadas, conclusões, recomendações e, quando cabível, proposta de implementação da solução tecnológica. Art. 5º Esta Portaria entra em vigor na data de sua publicação.

WESLEY DE ALMEIDA E SANTOS - CEL QOPM ____________________ (*) Republicado por ter sido encaminhado com incorreção no original, publicado no DODF nº 107, de 15 de junho de 2026, página 43.

DESPACHO DO CHEFE

Em 19 de junho de 2026 Processo nº 00428-00001831/2026-71. Interessado: ST QBMG-02 ADRIANO DE ALENCAR LEIRO SANTOS, matr. GDF 1.727.588-1. Assunto: Participação no Curso Preparatório de Oficiais da Administração e Especialistas Bombeiro Militar. No uso da competência prevista no art. 1º, inciso II, alínea 'c' do Decreto 39.133, de 15 de junho de 2018, e em conformidade com a Informação Técnica n.º 211/2026 - CM/AJL (206298633) e o respectivo Despacho de aprovação (206298747), nos termos do art. 2º, inciso II e do art. 20 do Decreto 29.290 de 22 de julho de 2008, RESOLVO: 1. AUTORIZAR o afastamento do ST QBMG-02 ADRIANO DE ALENCAR LEIRO SANTOS, matr. GDF 1.727.588-1, para frequentar o Curso Preparatório de Oficiais da Administração e Especialistas Bombeiro Militar – CPO Turma 14, no período de 12 de junho a 30 de julho de 2026, mediante dispensa de ponto, com ônus limitado para o Distrito Federal. 2. PUBLIQUE-SE e ENCAMINHEM-SE os autos do processo à Subchefia de Gestão Administrativa da Casa Militar.

WESLEY DE ALMEIDA E SANTOS - CEL QOPM

### POLÍCIA MILITAR DO DISTRITO FEDERAL

DEPARTAMENTO DE CONTROLE E CORREIÇÃO

PORTARIA DE 11 DE JUNHO DE 2026 SGC TCE 2026.0622.11.0022 O CHEFE DO DEPARTAMENTO DE CONTROLE E CORREIÇÃO, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no exercício das atribuições conferidas pelo artigo 36, inciso I e artigo 38 inciso V, do Decreto Federal nº 10.443 de 28 de julho de 2020; art. 2º da Portaria PMDF nº 1051, de 10 de julho de 2017; com fulcro no art. 15 da Instrução Normativa TCDF n.º 3 de 15 de dezembro de 2021 e art. 28 da Instrução Normativa CGDF nº 5 de 11 de novembro de 2022, resolve:

Art. 1º Instaurar Tomada de Contas Especial, sob o RITO SUMARÍO, para apuração da responsabilidade civil pelo ressarcimento do prejuízo causado ao Erário Distrital devido ao recebimento indevido de Auxílio Moradia Majorado, conforme os fatos constantes nos autos do processo SEI/GDF n.º 00054-00107505/2023-18; Art. 2º Designar o 2º TEN QOPM TÚLIO GALVÃO DE SOUZA, matrícula: 195.726/0 como Tomador de Contas para a condução dos trabalhos, delegando-lhe para esse fim todas as atribuições pertinentes, com o objetivo de apurar os fatos, identificar o(s) responsável(eis), quantificar o valor do dano, viabilizar o ressarcimento, além de propor medidas saneadoras para a efetiva autotutela administrativa; Art. 3º Conceder ao Tomador de Contas o prazo de 30 (trinta) dias para a conclusão dos trabalhos de acordo com o disposto nas Instruções Normativas n.º 03/2021-TCDF e n.º 05/2022-CGDF, bem como legislação aplicável, elaboração do Relatório Circunstanciado e remessa dos autos à Auditoria da PMDF na Unidade SEI/GDF PMDF/DCC/AUD/STCE/SSTCESP; Art. 4º Incumbir à Auditoria da PMDF o controle dos prazos, o exame de conformidade, a análise dos elementos constitutivos, bem como a adoção das demais providências cabíveis, em conformidade com a legislação vigente; Art. 5º Restituir à Auditoria/PMDF para providenciar publicação no Diário Oficial do Distrito Federal. Art. 6º Esta Portaria entra em vigor na data de sua publicação.

AURÉLIO GALDINO

PORTARIA DE 11 DE JUNHO DE 2026 SGC TCE 2026.0622.11.0023 O CHEFE DO DEPARTAMENTO DE CONTROLE E CORREIÇÃO, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no exercício das atribuições conferidas pelo artigo 36, inciso I e artigo 38 inciso V, do Decreto Federal nº 10.443 de 28 de julho de 2020; art. 2º da Portaria PMDF nº 1051, de 10 de julho de 2017; com fulcro no art. 15 da Instrução Normativa TCDF n.º 3 de 15 de dezembro de 2021 e art. 28 da Instrução Normativa CGDF nº 5 de 11 de novembro de 2022, resolve: Art. 1º Instaurar Tomada de Contas Especial, sob o RITO SUMARÍSSIMO, para apuração da responsabilidade civil pelo ressarcimento do prejuízo causado ao Erário Distrital devido ao recebimento indevido de Auxílio Moradia Majorado, conforme os fatos constantes nos autos do processo SEI/GDF n.º 00054-00181730/2025-70; Art. 2º Designar o 2º TEN QOPM MIQUÉIAS PEREIRA ALVES, matrícula: 735.628/5 como Tomador de Contas para a condução dos trabalhos, delegando-lhe para esse fim todas as atribuições pertinentes, com o objetivo de apurar os fatos, identificar o(s) responsável(eis), quantificar o valor do dano, viabilizar o ressarcimento, além de propor medidas saneadoras para a efetiva autotutela administrativa; Art. 3º Conceder ao Tomador de Contas o prazo de 30 (trinta) dias para a conclusão dos trabalhos de acordo com o disposto nas Instruções Normativas n.º 03/2021-TCDF e n.º 05/2022-CGDF, bem como legislação aplicável, elaboração do Relatório Circunstanciado e remessa dos autos à Auditoria da PMDF na Unidade SEI/GDF PMDF/DCC/AUD/STCE/SSTCESP; Art. 4º Incumbir à Auditoria da PMDF o controle dos prazos, o exame de conformidade, a análise dos elementos constitutivos, bem como a adoção das demais providências cabíveis, em conformidade com a legislação vigente; Art. 5º Restituir à Auditoria/PMDF para providenciar publicação no Diário Oficial do Distrito Federal. Art. 6º Esta Portaria entra em vigor na data de sua publicação.

AURÉLIO GALDINO

DEPARTAMENTO DE GESTÃO DE PESSOAL DIRETORIA DE VETERANOS, PENSIONISTAS E CIVIS

PORTARIA Nº 658, DE 09 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o que consta do processo nº 0054-000819/2015, resolve: REFORMAR, ex officio, a contar de 16 de março de 2026, o 1º SGT PM RR ANTONIO SOARES DE LIMA - Matrícula 12.628/4, da Polícia Militar do Distrito Federal, na mesma graduação, com proventos integrais relativos ao soldo de sua graduação, nos termos dos artigos 87, inciso II; 94, inciso I, alínea “b”, da Lei nº 7.289, de 18 de dezembro de 1984, na redação do artigo 64, da Lei nº 12.086/2009; combinado com o artigo 20, §1º, inciso I, da Lei n.º 10.486/2002; por haver atingido a idade limite de permanência na reserva remunerada.

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 675, DE 15 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o disposto no § 1º do artigo 24 da Lei nº 10.486/2002 e, tendo em vista o teor dos Processos nº 00054-00062218/2026-14 e nº 0054.003.171/86, resolve: REVER os proventos do 3º SGT PM REF CARLOS ANTÔNIO FERREIRA, Matrícula nº 05.183/7, que serão calculados com base no soldo integral de sua graduação, conforme dispõe o artigo 24, parágrafo 3º, da Lei 10486/2002 e REVER o decreto nº 10.103 de 23 de janeiro de 1987, publicada no DODF anexo XI de 23 de janeiro de 1987 para conceder a Isenção do Imposto de Renda a contar da data do diagnóstico (05/09/2023), de acordo

<!-- pagina 41 -->

com o artigo 47 da Lei nº 8.541, de 23 de dezembro de 1992, artigo 30, §2º, da Lei nº 9.250, de 26 de dezembro de 1995, artigo 35, inciso II, alínea “b”, do Decreto nº 9.580 de 22 de novembro de 2018, c/c artigo 6º Caput, inciso XIV, da Lei nº 7.713 de 22 de dezembro de 1988;

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 690, DE 17 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o que consta do Processo SEI GDF nº 0054-002-182/2008, resolve: REFORMAR, ex officio, a contar de 23 de abril de 2022, o 3º SGT PM RR JOVINO EDILSON XAVIER, matrícula nº 09.607/5, da Polícia Militar do Distrito Federal, na mesma graduação, com proventos integrais relativos ao soldo de sua graduação, nos termos dos artigos 87, inciso II; 94, inciso I, alínea “b”, da Lei nº 7.289, de 18 de dezembro de 1984, na redação do artigo 64, da Lei nº 12.086/2009; combinado com o artigo 20, §1º, inciso I, da Lei n.º 10.486/2002; por haver atingido a idade limite de permanência na reserva remunerada.

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 699, DE 18 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o que consta do Processo SEI GDF nº 0054-000-544/2006, resolve: REFORMAR, ex officio, a contar de 03 de abril de 2019, o 1º SGT PM RR FRANCISCO APARECIDO NELSON DA SILVA, matrícula 07.602/3, da Polícia Militar do Distrito Federal, na mesma graduação, com proventos integrais relativos ao soldo de sua graduação, nos termos dos artigos 87, inciso II; 94, inciso I, alínea “b”, da Lei nº 7.289, de 18 de dezembro de 1984, na redação do artigo 64, da Lei nº 12.086/2009; combinado com o artigo 20, §1º, inciso I, da Lei nº 10.486/2002; por haver atingido a idade limite de permanência na reserva remunerada.

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 702, DE 18 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Inciso I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o que consta do Processo SEI GDF nº 0054-000-663/2014, resolve: REFORMAR, ex officio, a contar de 13 de junho de 2025, o CEL PM RR ISMAEL AUGÚSTO SOARES DE BARCELOS, matrícula nº 00.466/9, da Polícia Militar do Distrito Federal, no mesmo posto, com proventos integrais relativos ao soldo de seu posto, nos termos dos artigos 87, inciso II; 94, inciso I, alínea “a”, da Lei nº 7.289, de 18 de dezembro de 1984, na redação do artigo 64, da Lei nº 12.086/2009; combinado com o artigo 20, §1º, inciso I, da Lei nº 10.486/2002; por ter atingindo a idade limite na reserva remunerada.

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 706, DE 19 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o disposto no § 1º do artigo 24 da Lei nº 10.486/2002 e, tendo em vista o teor do Processo nº 00020-00003003/2026-78, resolve: CONCEDER definitivamente isenção do Imposto de Renda ao 2º SGT PM RR ANTONIO VITAL GONÇALVES BESERRA, matrícula nº 13.418-X, em cumprimento à decisão judicial proferida pelo 2º Juizado Especial da Fazenda Pública do Distrito Federal, nos autos do processo nº 0824983-39.2025.8.07.0016.

JOSÉ GABRIEL DE SOUZA JUNIOR

PORTARIA Nº 713, DE 19 DE JUNHO DE 2026 O DIRETOR DE VETERANOS, PENSIONISTAS E CIVIS, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 20, Incisos I e II, do Decreto nº 10.443, de 28 de julho de 2020, e considerando o que consta dos processos nº 054000639/2017 e nº 00054-00007650/2026-34, resolve: REFORMAR, ex officio, o 1º SGT PM RR. SILVIO FERNANDES DA SILVA, matrícula nº 14.475/4, da Polícia Militar do Distrito Federal, na mesma graduação, com proventos integrais relativos ao soldo de sua graduação, CONCEDER a parcela do auxílio-invalidez, nos termos dos artigos 87, inciso II, 94, inciso II, e 96, inciso V, da Lei nº 7.289, de 18 de dezembro de 1984, combinados com os artigos 20, §1º, inciso I e §4º, 24, inciso IV e § 1º, 26, inciso II, da Lei nº 10.486, de 04 de julho de 2002, a contar do dia 28 de abril de 2026 (data da primeira ata) e ISENTÁ-LO do imposto de renda, a contar da data do diagnóstico (16/12/2025), de acordo com o artigo 47 da Lei nº 8.541, de 23 de dezembro de 1992, artigo 30, § 2º, da Lei nº 9.250, de 26 de dezembro de 1995, artigo 35, inciso II, alínea “b”, do Decreto nº 9.580, de 22 de novembro de 2018 c/c o artigo 6º caput, inciso XIV, da Lei nº 7.713, de 22 de dezembro de 1988, por ser portador de moléstia especificada em lei.

JOSÉ GABRIEL DE SOUZA JUNIOR

DEPARTAMENTO DE LOGÍSTICA E FINANÇAS

PORTARIA Nº 198, DE 17 DE ABRIL DE 2026 O CHEFE DO DEPARTAMENTO DE LOGÍSTICA E FINANÇAS, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso da atribuição prevista no artigo 2º, inciso IX, do Regimento Interno do Departamento de Logística e Finanças e no § 4º do artigo 1º da Portaria PMDF n.º 728/2010, observado o previsto na n.º 14.133/2021, resolve: Art. 1º Dispensar, conforme Memorando Nº 153/2026 - PMDF/DITEL/SGTI (200328087), o MAJ QOPM ROBERTO RABELO DE CASTRO, matrícula 50.925/6, da função de Gestor do Contrato e o ST QPPMC ANTONIO MILTON DO NASCIMENTO DE MENEZES, matrícula 19.419-0, da função de Fiscal Requisitante e DESIGNAR, CAP QOPM RODRIGO TEIXEIRA DA SILVA, matrícula 73.126-9, para a função de Gestor do Contrato, e o 2º SGT QPPMC AUGUSTO CEZAR PEREIRA PEDRA, matrícula 195.741- 1, para a função de Fiscal Requisitante. Os policiais militares, abaixo relacionados, comporão a Comissão de Execução do Contrato n.º 59/2025 (186871036), conforme indicado no Memorando Nº 520/2025 - PMDF/DITEL/SGTI (188605673): I - CAP QOPM RODRIGO TEIXEIRA DA SILVA, matrícula 73.126-9, para a função de Gestor do Contrato; II - 2º SGT QPPMC AUGUSTO CEZAR PEREIRA PEDRA, matrícula 195.741- 1, para a função de Fiscal Requisitante; e III - SD QPPMC DAVID LESSA BARBOSA, matrícula 737.061-X, para a função de Fiscal Técnico. Art. 2º Designar o CAP QOPM RODRIGO TEIXEIRA DA SILVA, matrícula 73.126-9, na função de Gestor do Contrato, para receber definitivamente o objeto do Contrato n.º 59/2025 (186871036), conforme preconiza o art. 140 da Lei Federal n.º 14.133/2021 c/c art. 23, inciso IX, do Decreto Distrital n.º 44.330/2023, nos autos do Processo SEI n.º (00054- 00149880/2025-99). Art. 3º Esta Portaria entra em vigor na data de sua publicação.

ROBERTO MENDES CARVALHO DE SOUSA - CEL QOPM

DEPARTAMENTO DE SAÚDE E ASSISTÊNCIA AO PESSOAL

PORTARIA Nº 43, DE 18 DE JUNHO DE 2026 O CHEFE DO DEPARTAMENTO DE SAÚDE E ASSISTÊNCIA AO PESSOAL, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso da atribuição prevista no inc. XVII do art. 1º da Portaria PMDF nº 727, de 15OUT2010, Lei nº 14.133/2021, c/c o art. 41 do Decreto nº 32.598 de 15 de dezembro de 2010, que aprovou as Normas de Execução Orçamentária, Financeira e Contábil do Distrito Federal, resolve: Art. 1º Cessar, os efeitos da Portaria nº 38 de 20 de MAIO de 2026 (203561945). Art. 2º Nomear o2º TEN QOPMSM MURILO DE ALMEIDA CASTRO, MAT. 2293667/1, na função de Fiscal Gestor (CMED), Nomear o ST QPPMC RR ALBERTO FRANÇA DE OLIVEIRA, MAT: 18.108-0, para a função de Primeiro Fiscal Técnico (CMED) e o 1º SGT QPPMC EDSON NASCIMENTO DE SOUZA - Mat. 2.93/2, para a função de Fiscal Setorial, (CMEDVET) pertencente ao Processo nº 00054-00173278/2025- 72, através do Contrato Nº 09/2026, (202015796), celebrado entre o DF/PMDF e a empresa: WF TECNOLOGIA CIENTÍFICA E CONSTRUTORA LTDA. Objeto: contratação de serviços especializados em engenharia clínica, na forma de prestação de serviço de manutenção preventiva e corretiva com reposição de peças ou acessórios em equipamentos médicos, hospitalares, odontológicos e veterinários, com uso de sistema informatizado dedicado de gestão, nas condições estabelecidas nos documentos do n. 1.3 deste contrato de prestação de serviços. Art. 3º Ao Fiscal/Fiscal substituto caberá supervisionar, fiscalizar e acompanhar a execução dos serviços, bem como o controle dos gastos financeiros objetivando evitar que as despesas extrapolem os valores contratuais, em obediência ao disposto no art. 67 e seus parágrafos, da Lei nº 8.666/93, c/c o art. 41, art. 117 da Lei nº 14.133/2021, Inciso II, §§ 3º e 4º e Incisos I, II III e IV do § 5º, tudo do Decreto nº 32.598, de 15 de dezembro de 2010, e o Memorando 02/2022 - PMDF/DSAP/CH (92623530), de 11 de agosto 2022, que dispõe sobre diretrizes para a gestão, o acompanhamento, recebimento de material e a fiscalização da execução de credenciamentos, contratos, convênios, acordos e instrumentos congêneres celebrados pelo Departamento de Saúde e Assistência ao Pessoal.. Art. 4º O na ausência do Fiscal Gestor, o Fiscal Técnico ou Fiscal Setorial deverá atestar todas as notas fiscais dos serviços prestados referentes ao contrato citado no Art. 2º. Art. 5º Nos afastamentos legais, o Fiscal Gestor deverá dar ciência aos demais Fiscal (ou vice versa) para que dê prosseguimento à fiscalização contratual; Art. 6º Nos afastamentos legais, o Fiscal Gestor e os demais Fiscal deverá dar ciência à Subseção de Suporte ao Executor (SSSEC) e à Subseção de Acompanhamento de Liquidações em Contas Médicas (SSALCM) da DPGC, formalmente, para fins de acompanhamento e, caso necessário, realizar a substituição. Art. 7º O Fiscal Gestor e os demais Fiscal estão proibidos de usufruírem afastamentos regulamentares, tais como férias, abonos, dispensas, dentre outros, simultaneamente. Art. 8º O Fiscal Gestor e os demais Fiscal, em caso de não cumprimento de quaisquer das competências estabelecidas nesta Portaria, estarão sujeitos às penalidades previstas na legislação pertinente. Art. 9º À Diretoria de Planejamento e Gestão de Contratos, para conhecimento e providências. Art. 10. Publique-se em DODF. Art. 11. Esta Portaria entra em vigor na data de sua publicação.

SINÉSIO SILVA SOUZA - CEL QOPM

<!-- pagina 42 -->

### CORPO DE BOMBEIROS MILITAR

PORTARIA DE 17 DE JUNHO DE 2026 O COMANDANTE-GERAL DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, no uso da delegação constante do artigo 1º, inciso I, alínea “a”, do Decreto n.º 15.740, de 23 de junho de 1994, e ainda no uso das competências previstas nos incisos, III e VI, do artigo 7º, do Decreto Federal n.º 7.163, de 29 de abril de 2010, que regulamenta o inciso I, do artigo 10-B, da lei n.º 8.255, de 20 de novembro de 1991, que dispõe sobre a organização básica do Corpo de Bombeiros Militar do Distrito Federal, e, observando o que consta do PA n.º 0053-001912/2011 e 0002-000045/2012- CM, resolve: I - REFORMAR o Major BM RRm. MAURO SOARES GONZAGA, matr. 1401657, a contar de 30 de novembro de 2025 com proventos integrais, calculados com base na remuneração correspondente ao cargo efetivo em que se deu o ato de transferência para a inatividade, nos termos do artigo 88, inciso II; 95, inciso I, alínea "a”, do Estatuto dos Bombeiros Militares do Distrito Federal, aprovado pela Lei n.º 7.479, de 02 de junho de 1986, na redação do artigo 110, da Lei n.º 12.086/2009, combinados com o artigo 20, §§ 1º, inciso I, e 4º, da Lei n.º 10.486/2002, e ainda; II - REGISTRAR a concessão da Gratificação de Função Militar publicada no DODF n.º 168, de 15 de agosto de 2013, nos seguintes termos: "CONCEDER ao requerente, nos termos da delegação de competência prevista no Decreto nº 31.617, de 28 de abril de 2010, o pagamento e incorporação, em seus proventos, do valor correspondente à Gratificação de Função Militar de PRIMEIRO-TENENTE - (GFM 08), de que tratavam as Leis nº 186, de 22 de dezembro de 1991 e 2.885, de 09 de janeiro de 2002, a título de Vantagem Pessoal Nominalmente Identificada - VPNI, nos termos do disposto no artigo 2º, da Lei nº 5.007, de 21 de dezembro de 2012, a contar de 07 de março de 2012, data de sua transferência para a reserva remunerada, com base de cálculo INTEGRAL, por ter exercido função militar no âmbito da Casa Militar do Governo do Distrito Federal".

MOISES ALVES BARCELOS

PORTARIA DE 17 DE JUNHO DE 2026 O COMANDANTE-GERAL DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, no uso das atribuições que confere o inciso X, do artigo 7º, do Decreto Federal nº 7.163, de 29 de abril de 2010, que regulamenta o inciso I, do artigo 10-B, da lei nº 8.255, de 20 de novembro de 1991, que dispõe sobre a organização básica do Corpo de Bombeiros Militar do Distrito Federal, resolve: LICENCIAR, ex officio, do serviço ativo do Corpo de Bombeiros Militar do Distrito Federal, e, por conseguinte, excluir da OBM a qual pertence a contar de 26 de maio de 2026, o 3º Sgt. QBMG-1 RAFAEL CARVALHO CRUZ CAIXETA, matr. 1053666, de acordo com os artigos 88 Inciso V; 110, inciso II e art. 111; do Estatuto dos Bombeiros-Militares do Corpo de Bombeiros Militar do Distrito Federal (EBMCBDF/86), aprovado pela Lei nº 7.479, de 2 de junho de 1986; e nos termos da instrução contida no Processo Administrativo SEI nº 00053-00058234/2026-22.

MOISÉS ALVES BARCELOS

PORTARIA DE 17 DE JUNHO DE 2026 O COMANDANTE-GERAL DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, no uso da delegação constante do art. 1º, inciso I, alínea “c”, do Decreto nº 15.740, de 23 de junho de 1994, resolve: AGREGAR ao respectivo Quadro, a contar de 16 de junho de 2026, o 1º Ten. QOBM/Intd. RONAN DE CERQUEIRA LACERDA, matr. 1405825, nos termos do art. 78, § 1º, alínea “a”, §§ 2º, 3º e 7º; e art. 79, do Estatuto dos Bombeiros-Militares do Corpo de Bombeiros do Distrito Federal, aprovado pela Lei nº 7.479, de 2 de junho de 1986, por ter sido nomeado para ocupar o Cargo de Assessor Militar, da Gerência de Gestão de Pessoal Militar, da Coordenação de Gestão de Pessoas, da Subsecretaria de Ensino e Gestão de Pessoas, da Secretaria Executiva de Gestão Integrada, da Secretaria de Estado de Segurança Pública do Distrito Federal, Símbolo GMSP-03, conforme publicação na página 44, do DODF nº 106, de 12 de junho de 2026, Ofício Nº 178/2026 - SSP/SEGI/SUEGEP/COGEP/GGPM, de 16 de junho de 2026 e Processo SEI n.º 00050-00007418/2026-17.

MOISES ALVES BARCELOS

APOSTILAMENTO DE 17 DE JUNHO DE 2026 O COMANDANTE-GERAL DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, no uso das competências previstas nos incisos III e VI, do artigo 7º, do Decreto Federal nº 7.163, de 29 de abril de 2010, que regulamenta o inciso I, do artigo 10-B, da lei nº 8.255, de 20 de novembro de 1991, que dispõe sobre a Organização Básica do Corpo de Bombeiros Militar do Distrito Federal, e, observando o que consta do PA nº 0053-000971/2005-CBMDF, resolve: CONCEDER o pagamento do benefício auxílio invalidez, ao Capitão BM Ref. LUIZ COSTA PEREIRA, matrícula nº 1401285, a contar de 22 de maio de 2026, em conformidade com o artigo 26, inciso II, § 3º, da Lei nº 10.486/2002.

MOISES ALVES BARCELOS

SUBCOMANDO GERAL DEPARTAMENTO DE RECURSOS HUMANOS

DIRETORIA DE INATIVOS E PENSIONISTAS

PORTARIA Nº 57, DE 17 DE JUNHO DE 2026 O DIRETOR DE INATIVOS E PENSIONISTAS, DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, com base nos arts. 26 e 29 do Decreto Federal n° 7.163, de 29 abr. 2010, que regulamenta o art. 10-B, inciso I, da Lei n° 8.255, de 20 de novembro de 1991, que dispõe sobre a organização básica do CBMDF, c/c o art. 142, inciso I, do Regimento Interno do CBMDF, resolve:

CONCEDER pensão militar a MARIA BENICE DA SILVA, ex-esposa pensionada, GLEICE ALESSANDRA SILVA MAGALHAES DE OLIVEIRA e LUCILAYNE SILVA MAGALHÃES LIMA, filhas do ex-2º Sgt. ANTÔNIO ERASMO, matc: 1400578, falecido em 28 de maio de 2026, calculada com base no soldo integral de Segundo Sargento BM, a contar da data do óbito do instituidor, na proporção de 15% (quinze por cento) para a ex-esposa pensionada e 42,50% (quarenta e dois, vírgula cinquênta por cento) para cada uma das filhas, com fundamento no art. 36, §3º, inciso II, art. 39, §3º e art. 53, da Lei nº 10.486/2002 c/c o art. 7, inciso II, da Lei nº 3.765/1960 (redação original), c/c o art. 7, inciso I, alínea "c", da Lei nº 13.954/2019, c/c art. 31, da MP 2.215/2001, c/c o art. 24-B, inciso III, do Decreto-Lei nº 667/69, incluído pela Lei nº 13.954/2019, bem como o art, 42º, § 2º, da Constituição Federal, com redação dada pelo art. 1º, da Emenda Constitucional nº 41, de 19 de dezembro de 2003. Processo SEI nº 00053-00061979/2026-79 - CBMDF.

FABIO ANDRADE RIBEIRO

PORTARIA Nº 58, DE 18 DE JUNHO DE 2026 O DIRETOR DE INATIVOS E PENSIONISTAS, DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, com base nos Arts. 26 e 29 do Decreto Federal n° 7.163, de 29 abr. 2010, que regulamenta o inciso I do Art. 10-B da Lei n° 8.255, de 20 novembro 1991, que dispõe sobre a organização básica do CBMDF, combinado com o inciso II do Art. 144 do Regimento Interno, resolve: CANCELAR a pensão militar que era percebida pela Senhora Thereza Guerra Cardozo, matr. 04221257, ex-companheira, pensionista militar, por motivo de falecimento ocorrido em 7 de maio de 2026, cujo instituidor é o ex-Cabo BM (Ref.) LAURO BLANCO PEREIRA, matr. 1419598, falecido em 07 de abril de 1989. Em consequência, o benefício deverá ser extinto por não haver beneficiários habilitáveis, a contar da data do óbito da ex-pensionista, com fundamento no Art. 24, da Lei nº 3765 de 1960. SEI- 0053-000586/1989 CBMDF.

FABIO ANDRADE RIBEIRO

APOSTILAMENTO Nº 25, DE 15 DE JUNHO DE 2026 O DIRETOR DE INATIVOS E PENSIONISTAS, DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, com base nos Arts. 26 e 29 do Decreto Federal n° 7.163, de 29 abr. 2010, que regulamenta o inciso I do Art. 10-B da Lei n° 8.255, de 20 novembro 1991, que dispõe sobre a organização básica do CBMDF, combinado com o inciso II do Art. 144 do Regimento Interno, resolve: CANCELAR a cota parte da pensão militar de JOÃO PAULO SOARES RODRIGUES, matr.: nº 06056652, filho do ex-1° sargento BM (Ref.) ROGERIO WENDELES RODRIGUES, matr. nº 1403791, falecido em 07 de maio de 2016, por não mais se enquadrar na condição de estudante, com fundamento no art. 37, inciso I, da Lei nº 10.486/2002. Em consequência, o benefício foi redistribuído para as pensionistas: ANGELA SOARES RODRIGUES, viúva, matr. nº 06043763, MARIANA SOARES RODRIGUES, matr. 06056199 e LEONARDO SOARES RODRIGUES, matr.: nº 6056181, alterando de 25% (vinte e cinco) para 33,33 % (trinta e três virgula trinta e três) do benefício para cada um; a contar da data da exclusão do ex-pensionista. Processo de Pensão Militar nº SEI- 00053-00197142/2024-03 CBMDF.

FABIO ANDRADE RIBEIRO

### DEPARTAMENTO DE TRÂNSITO

PORTARIA Nº 144, DE 18 DE JUNHO DE 2026 O DIRETOR-GERAL DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 100 inciso XLI do Regimento Interno aprovado pelo Decreto nº 27.784/2007, e com base na Lei nº 14.133, de 1º de abril de 2021, recepcionada pelo Decreto nº 44.330, de 16 de março de 2023, e com base no Decreto nº 45.422/2024, resolve: Art. 1º Designar como Pregoeiros ALLANN ALVES VIEIRA DE ANDRADE, matrícula 255.469-0; LEONARDO GARCIA ALMEIDA, Matrícula 1.726.832-X, e DÉBORAH LIMA MACIEL, matrícula 1726.153-8, para conduzirem e coordenarem a fase externa da licitação, a sessão pública e executar quaisquer outras atividades necessárias ao bom andamento do certame até a homologação, objetivando a aquisição de bens ou contratação de serviços no âmbito do DETRAN/DF. Art. 2º Os servidores designados no art. 1º: a) Atuarão, em cada caso concreto, com observância ao princípio da segregação de funções. b) Quando da exoneração, vacância ou similares, os indicados deixam de compor a presente Portaria. Art. 3º O nome do Pregoeiro indicado para cada processo, bem como do seu substituto em caso de afastamento ou impedimento legal, constará no Ato de Autorização da autoridade competente para início da fase externa da licitação. Parágrafo Único: Nos casos em que o substituto do Pregoeiro designado também estiver afastado ou legalmente impedido, poderá ser indicado um substituto temporário, dentre os servidores constantes no art. 1º, mediante despacho motivado do Coordenador de Contratações Públicas nos autos do respectivo processo da licitação. Art. 4º Os servidores mencionados no art. 1º atuarão ainda em revezamento como membros da Equipe de Apoio nas licitações em que não figurarem como Pregoeiro. Parágrafo Único: A Equipe de Apoio será composta de, no mínimo, 2 (dois) servidores. Art. 5º Revogar a PORTARIA Nº 273, DE 16 DE OUTUBRO DE 2025, publicada no DODF Nº 198, de 17/10/2025, Pág. 41 Art. 6º Esta Portaria entra em vigor na data de sua publicação.

MARCU ANTÔNIO DE SOUZA BELLINI

<!-- pagina 43 -->

PORTARIA Nº 145, DE 18 DE JUNHO DE 2026 O DIRETOR-GERAL DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 100 inciso XLI do Regimento Interno aprovado pelo Decreto nº 27.784/2007, e com base na Lei nº 14.133, de 1º de abril de 2021, recepcionada pelo Decreto nº 44.330, de 16 de março de 2023, e com base no Decreto nº 45.422/2024, resolve: Art. 1º Designar como Agentes de Contratação: ALLANN ALVES VIEIRA DE ANDRADE, matrícula 255.469-0; LEONARDO GARCIA ALMEIDA, Matrícula 1.726.832-X, e DÉBORAH LIMA MACIEL, matrícula 1726.153-8, para conduzirem e coordenarem a fase de concorrência da licitação, a sessão pública e executar quaisquer outras atividades necessárias ao bom andamento do certame até a homologação, objetivando a aquisição de bens ou contratação de serviços no âmbito do DETRAN/DF. Art. 2º Os servidores designados no art. 1º: a) Atuarão, em cada caso concreto, com observância ao princípio da segregação de funções. b) Quando da exoneração, vacância ou similares, os indicados deixam de compor a presente Portaria. Art. 3º O nome do Agente de Contratação indicado para cada processo, bem como do seu substituto em caso de afastamento ou impedimento legal, constará no Ato de Autorização da autoridade competente para início da fase externa da licitação. Parágrafo Único: Nos casos em que o substituto do Agente de Contratação designado também estiver afastado ou legalmente impedido, poderá ser indicado um substituto temporário, dentre os servidores constantes no art. 1º, mediante despacho motivado do Coordenador de Contratações Públicas nos autos do respectivo processo da licitação. Art. 4º Os servidores mencionados no art. 1º atuarão ainda em revezamento como membros da Equipe de Apoio nas licitações em que não figurarem como Agente de Contratação. Parágrafo Único: A Equipe de Apoio será composta de, no mínimo, 2 (dois) servidores. Art. 5º Revogar a PORTARIA Nº 274, DE 16 DE OUTUBRO DE 2025, publicada no DODF Nº 198, de 17/10/2025, Pág. 41 Art. 6º Esta Portaria entra em vigor na data de sua publicação.

MARCU ANTÔNIO DE SOUZA BELLINI

DIRETORIA DE ADMINISTRAÇÃO GERAL

INSTRUÇÃO Nº 348, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: SUSPENDER as férias do servidor MARCUS AURÉLIO DE SOUZA MARINHO, matrícula nº 1.506-7, Agente de Trânsito, ocupante do Cargo de Natureza Especial, Símbolo CNE-01, de Diretor-Geral Adjunto, do DETRAN/DF, por motivo de necessidade de serviço, relativas aos dias de 18 e 19/06/2026. Fica assegurado ao servidor o gozo de férias pelos dias suspensos em momento oportuno, nos termos do processo SEI 00055- 00112256/2025-16.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 349, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR a servidora CAROLINA COSTA SANTOS, matrícula nº 196.167-5, Técnico em Atividades de Trânsito, para substituir a servidora ALINE GAZOLA ORTIZ, matrícula nº 250.439-1, Analista em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-08, de Gerente, da Gerência de Fiscalização Administrativa e Análise de Recursos de Credenciados (Gerfad), da Diretoria de Credenciamento de Entidades e Profissionais (Dicrep), do Departamento de Trânsito do Distrito Federal (Detran/DF), no período de 07 a 16/07/2026, referente às férias regulamentares da Titular, nos termos do processo 00055-00064098/2025-72.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 350, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR o servidor ZILMAR DANTAS ROCHA, matrícula nº 251.222-X, Analista em Políticas Públicas e Gestão Governamental, para substituir o servidor SANDRO MACHADO LEVI, matrícula nº 196.253-1, Técnico em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-06, de Chefe, do Núcleo de Controle de Cadastro de Veículos (Nuconv), da Gerência de Controle de Cadastro de Veículos (Gervei), do Departamento de Trânsito do Distrito Federal (Detran/DF), no período de 01 a 20/07/2026, referente às férias regulamentares do Titular, nos termos do processo 00055- 00051138/2026-05.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 351, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto n° 27.784, de 16 de março de 2007, resolve: Art. 1º Conceder Licença Prêmio por Assiduidade, nos termos do Artigo nº 130, Inciso V e Artigo nº 139, da Lei Complementar nº 840/2011, aos seguintes servidores: LENI DA CUNHA CHAVES, matrícula 1218-1, referente ao período de 12/07/2019 a 09/07/2024; EDILMAR EDSON DA CONCEICAO SILVA, matrícula 692-0, referente aos períodos de 27/09/1988 a 25/09/1993; de 26/09/1993 a 24/09/1998; de 24/09/2003 a 21/09/2008 e de 20/09/2018 a 18/09/2023; DANIEL FRANCISCO ROSA FILHO, matrícula 194.712- 5, referente ao período de 07/06/2019 a 04/06/2024; VANDERSON GOMES DE FARIAS, matrícula 1.187-8, referente ao período de 23/09/2018 a 21/09/2023; ROBERTO ELOY DE SOUSA JUNIOR, matrícula 250.837-0, referente ao período de 11/05/2019 a 10/05/2024; GLEYCE DA SILVA ALVES CEREIJO, matrícula 250.769-2, referente ao período de 07/05/2014 a 21/08/2019; ANDRÉ SABINO DE OLIVEIRA VÂNDER VELDEN, matrícula 250.943-1, referente ao período de 26/07/2017 a 24/07/2022; JULIANA CRISTINA PAIM, matrícula 182.360-4, referente ao período de 09/12/2016 a 07/12/2021; GUSTAVO HENRIQUE CATTINI BRAGA, matrícula 251.049-9, referente ao período de 28/08/2017 a 26/08/2022, GILDAZIO BARBOSA NASCIMENTO, matrícula 251.073-1, referente ao período de 26/10/2018 a 24/10/2023; PAULO DE TARSO SILVEIRA, matrícula 462-6, referente ao período de 06/08/2015 a 03/08/2020; DJALMA GONCALVES VIANA FILHO, matrícula 65541-4, referente ao período de 14/08/2000 a 12/08/2005. Art. 2º Esta Instrução entra em vigor na data de sua publicação.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 352, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: Art. 1º Alterar a Equipe de Planejamento da Contratação, vinculada à Diretoria de Administração Geral - DETRAN/DG/DIRAG, para elaborar a documentação necessária destinada à contratação de serviço técnico especializado em engenharia e arquitetura, de natureza predominantemente intelectual, para a elaboração de anteprojeto arquitetônico da Nova Sede Administrativa do DETRAN/DF, bem como para a prestação de assessoramento técnico especializado à Administração. Art. 2º A Equipe de Planejamento da Contratação de que trata o artigo anterior, será composta pelos seguintes servidores: I - Integrante Requisitante: SERGIO PEREIRA DA COSTA - matrícula: 1204-1; II- Integrante Técnico: THALITA PEREIRA SALES, matrícula: 1725430-2; e III- Integrante Administrativo: ANA CLAUDIA GNONE DE OLIVEIRA, matrícula: 1725430-2. Art. 3º Esta Instrução entra em vigor na data da sua publicação.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 353, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, e considerando a necessidade manter os sistemas de informação do DETRAN/DF e, consequentemente, o regular atendimento ao cidadão, resolve: Art. 1º Alterar a Equipe de Trabalho vinculada à Diretoria de Tecnologia da Informação e Comunicação (DIRTEC/DG/DETRAN-DF), para no prazo de 60 (sessenta) dias, elaborar Estudo Técnico destinado à contratação empresa especializada na prestação de serviços de Tecnologia da Informação - TI para fornecimento e implementação de uma Solução Integrada para o Desenvolvimento e Orquestração de Agentes de Inteligência Artificial (IA), contemplando recursos de governança de IA, treinamento, avaliação e implantação de modelos de aprendizado de máquina e modelos de linguagem em larga escala (LLMs), integrados a mecanismos de proteção de dados, descoberta e classificação de dados sensíveis, gestão de identidades e acessos e pesquisa indexada inteligente, além da prestação de serviços técnicos especializados para o desenvolvimento, manutenção e suporte operacional dos agentes de IA. Art. 2º A Equipe de Trabalho será composta pelos seguintes servidores: I - Integrante Requisitante: EDUARDO DUTRA, matrícula: 1.725.691-7; GLAUBER SANTOS NAVES PEIXOTO - Mat, 67.261-0; DAYVSON FRANKLIN DE SOUZA - Mat. 1.726.934-2 e DANILO LINO VALÉRIO - Mat. 250.701-3; II - Integrante Técnico: CELSO HENRIQUE SANCHES MEDEIROS - Mat. 1.727.015-4; e III - Integrante Administrativo: AUGUSTO HENRIQUE PARENTE FARAIS - Mat. 1.726.729-3. Art. 3º Esta Instrução entra em vigor na data de sua publicação.

VALDETE AMARAL DIAS

<!-- pagina 44 -->

INSTRUÇÃO Nº 354, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR a servidora RENATA DA MOTA GONÇALVES, matrícula nº 182.357-4, Técnico em Atividades de Trânsito, para substituir o servidor VINÍCIUS FONTENELE GOUVEIA, matrícula nº 1.721.061-5, Técnico em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-08, de Gerente, da Gerência de Habilitação e Controle de Condutor (Gerhab), da Diretoria de Controle de Veículos e Condutores (Dirconv), do Departamento de Trânsito do Distrito Federal (Detran/DF), no dia 22/06/2026, por motivo de abono de ponto, e no período de 23/06 a 03/07/2026, referente às férias regulamentares do Titular, nos termos do processo 00055-00029167/2026-82.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 355, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR a servidora GLAUCINEIA SILVA MORAES, matrícula nº 195.181-5, Técnico em Atividades de Trânsito, para substituir o servidor ROGÉRIO RODRIGUES MOREIRA, matrícula nº 195.167-X, Técnico em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-06, de Chefe, do Núcleo de Atendimento de Habilitação (Nuhab I), da Gerência Regional de Trânsito de Brasília (Gertran I), da Coordenação-Geral de Atendimento ao Usuário (Cgate), da Diretoria de Controle de Veículos e Condutores (Dirconv), do Departamento de Trânsito do Distrito Federal (Detran/DF), no período de 22 a 31/07/2026, referente às férias regulamentares do Titular, nos termos do processo 00055-00008254/2026-04.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 356, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR o servidor DÊNIO KÉLLER DA SILVA, matrícula nº 67.320-X, Agente de Trânsito, para substituir a servidora TATYANE APARECIDA PEREIRA LIMA, matrícula nº 66.054-X, Agente de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-05, de Supervisor de Dia, da Coordenação Regional de Policiamento e Fiscalização de Trânsito Metropolitana (Copol Metropolitana), da Diretoria de Policiamento e Fiscalização de Trânsito (Dirpol), do Departamento de Trânsito do Distrito Federal (Detran/DF), no dia 04/07/2026, referente ao abono de ponto anual da Titular, nos termos do processo 00055-00002165/2026-46.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 357, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR o servidor ENEAS FLÁVIO SOARES RIBEIRO, matrícula nº 251.200-9, Técnico em Políticas Públicas e Gestão Governamental, para substituir a servidora SARA MONTEIRO DE BARROS, matrícula nº 1.270-X, Técnico em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-06, de Chefe, do Núcleo Regional de Trânsito de Planaltina (Nutran II), da Coordenação-Geral de Atendimento ao Usuário (Cgate), da Diretoria de Controle de Veículos e Condutores (Dirconv), do Departamento de Trânsito do Distrito Federal (Detran/DF), no período de 13/07/2026 a 01/08/2026, referente as férias regulamentares da servidora, nos termos do processo 00055-00051069/2026-21.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 358, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR a servidora GABRYELLA CHRISTINA BARRETTO AMÂNCIO DA SILVA, matrícula nº 250.423-5, Técnico em Atividades de Trânsito, para substituir a servidora MARIA DE NAZARÉ XAVIER DE ARAÚJO, matrícula nº 250.442-1, Analista em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-06, de Chefe do Núcleo Regional de Trânsito do Aeroporto (Nutran 1), da Coordenação-Geral de Atendimento ao Usuário (Cgate), da Diretoria de Controle de Veículos e Condutores (Dirconv), do Departamento de Trânsito do Distrito Federal (Detran/DF), no período de 06/07/2026 a 17/07/2026, por motivo de férias regulamentares da titular da titular, nos termos do processo 00055-00047270/2026-12.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 359, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: DESIGNAR a servidora ELIZETE CONCEIÇÃO MACHADO PANTOJA, matrícula nº 1.390-0, Analista em Atividades de Trânsito, para substituir o servidor WANDER DE CASTRO SILVA, matrícula nº 1.110-X, Analista em Atividades de Trânsito, ocupante do Cargo Público em Comissão, Símbolo CPC-08, de Gerente, da Gerência Regional de Trânsito do Gama (Gertran V), da Coordenação-Geral de Atendimento ao Usuário (Cgate), da Diretoria de Controle de Veículos e Condutores (Dirconv), do Departamento de Trânsito do Distrito Federal (Detran/DF), nos dias 13/07/2026, 14/07/2026, 15/07/2016, 16/07/2026 e 17/07/2026, por motivo de abono de ponto anual, e no período de 20/07/2026 a 29/07/2026, referente as férias regulamentares do titular, nos termos do processo 00055- 00003631/2026-19.

VALDETE AMARAL DIAS

INSTRUÇÃO Nº 360, DE 19 DE JUNHO DE 2026 A DIRETORA DE ADMINISTRAÇÃO GERAL, DO DEPARTAMENTO DE TRÂNSITO DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Instrução nº 587, de 22 de setembro de 2022, que delega competência, na forma dos incisos XLI e XLII do Artigo 100, do Regimento Interno, aprovado pelo Decreto nº 27.784, de 16 de março de 2007, resolve: CONCEDER a Gratificação por Habilitação - GH, nos termos do artigo 1º § 1º da Lei nº 7.590, de 04 de dezembro de 2024, regulamentada pela Instrução nº 85, de 05 de fevereiro de 2026, observando-se a seguinte ordem: nome do servidor, matrícula, cargo, título, percentual, data de concessão, processo. LEONARDO DEIVID DE SOUZA, 256.779-2, Técnico em Atividades de Trânsito, Pós-Graduação Lato Sensu, 25%, 22/05/2026, 00055- 00036960/2024-76.

VALDETE AMARAL DIAS

RETIFICAÇÃO Na Instrução nº 314, de 10 de junho de 2026, publicada no DODF nº 105, de 11 de junho de 2026, página 39, referente à substituição por motivo de férias do servidor MARCUS AURÉLIO DE SOUZA MARINHO, matrícula nº 1.506-7, Agente de Trânsito, Diretor- Geral Adjunto, ONDE SE LÊ: “...período de 10/06/2026 a 19/06/2026...”, LEIA-SE: “...período de 10/06/2026 a 17/06/2026...”.

## SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA

### GABINETE

ORDEM DE SERVIÇO Nº 121, DE 18 DE JUNHO DE 2026 O CHEFE DE GABINETE, DA SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL, no exercício das atribuições que lhe são conferidas pelo art. 1º, incisos VIII e IX, da Portaria nº 15, de 22 de julho de 2020, resolve: HOMOLOGAR o afastamento do servidor FABIO MENDES DE OLIVEIRA, Policial Penal, matrícula nº 178.449-8, mediante dispensa de ponto com ônus limitado para o Distrito Federal, nos termos do art. 2º, inciso II, do Decreto nº 29.290, de 22 de julho de 2008, no período de 15/06/2026 a 31/07/2026, para participação no Curso de Motociclista e Batedor da Força Aérea Brasileira, promovido pelo Comando da Aeronáutica, por intermédio do Grupo de Segurança e Defesa da Base Aérea de Brasília (GSD/BR) - Processo SEI nº 04026-00026174/2026-94.

RENATA PEREIRA DE JESUS

ORDEM DE SERVIÇO Nº 124, DE 19 DE JUNHO DE 2026 O CHEFE DE GABINETE, DA SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL, Substituto, no exercício das atribuições que lhe são conferidas pelo art. 1º, incisos VIII e IX, da Portaria nº 15, de 22 de julho de 2020, resolve: HOMOLOGAR o afastamento do servidor DOUGLAS DA CUNHA SETTE, Policial Penal, matrícula nº 1.693.056-8, mediante dispensa de ponto com ônus limitado para o Distrito Federal, nos termos o art. 2º, inciso II, do Decreto nº 29.290, de 22 de julho de 2008, no período de 15/06/2026 a 31/07/2026, para participação no Curso de Motociclista e Batedor da Força Aérea Brasileira, promovido pelo Comando da Aeronáutica, por intermédio do Grupo de Segurança e Defesa da Base Aérea de Brasília (GSD/BR)- Processo SEI nº 04026-00026194/2026-65.

ALEX FERNANDES ROCHA

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

COORDENAÇÃO DE ORÇAMENTO E FINANÇAS

DIRETORIA DE CONTRATOS

ORDEM DE SERVIÇO Nº 119, DE 19 DE JUNHO DE 2026. O DIRETOR DE CONTRATOS, DA COORDENAÇÃO DE ORÇAMENTO E FINANÇAS DA SUBSECRETARIA DE ADMINISTRAÇÃO GERAL, DA SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO

<!-- pagina 45 -->

DISTRITO FEDERAL, com fundamento no artigo 117 da Lei Federal nº 14.133, de 1º de abril de 2021, que trata das Licitações e Contratos Administrativos, no artigo 10 do Decreto nº 44.330, de 16 de março de 2023, que regulamenta a Lei Federal nº 14.133/21 no âmbito da Administração Pública direta, autárquica e fundacional do Distrito Federal, e no artigo 3º-D, inciso I, da Portaria nº 15, de 22 de julho de 2020, publicada no DODF nº 139, de 24 de julho de 2020, que dispõe sobre a delegação de competência a servidores da Secretaria de Estado de Administração Penitenciária, resolve: Art. 1° Designar os servidores que atuarão como Gestor, Gestor Suplente e Fiscais Técnicos da Nota de Empenho 2026NE00580, assinada em 16/06/2026, em favor da empresa N.S.S. COMERCIAL & CONSTRUTORA LTDA, Processo SEI nº 04026-00023255/2026-32, que tem por objeto a aquisição de 164.000 (cento e sessenta e quatro mil), Rolos de Papel Higiênico, Material: Celulose virgem, Comprimento: 30 metros, Largura: 10 CM, tipo: Picotado, Folhas Duplas, cor branca, deve atender a NBR 15464 e a Portaria Inmetro nº 251/2021, além da legislação pertinente. Marca: BOB. item: 7 conforme Autorização de Despesa e Empenho: FILIPE MATHEUS BRAGA DE SOUZA, matrícula nº 1.682.802-X, como Gestor; ANTÔNIO JACKSON SOBREIRA GONÇALVES, matrícula nº 194.948-9, como Gestor Suplente; MAYARA VIANA MATOS, matrícula nº 1.689.149-X, como Fiscal Técnico; MARIANA PEDROSA CASTELO V. GOTTLIEB, matrícula nº 1.693.055-X, como Fiscal Técnico Suplente. Art. 2° Os Gestores e fiscais designados deverão observar as disposições expressas na Portaria nº 29, de 25 de fevereiro de 2004, da Secretaria de Estado de Gestão Administrativa do Distrito Federal - SGA, e, em especial, na Portaria nº 33, de 28 de janeiro de 2026, da Secretaria de Estado de Administração Penitenciária, bem como as disposições da Lei nº 14.133, de 1º de abril de 2021, e do Decreto nº 44.330, de 16 de março de 2023. Art. 3° Ficam convalidados os atos praticados pelos gestores e fiscais ora designados, até a publicação desta Ordem de Serviço. Art. 4° Esta Ordem de Serviço entra em vigor na data de sua publicação.

TIAGO DA SILVA ISAAC

## SECRETARIA DE ESTADO DE TRANSPORTE E MOBILIDADE

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 106, DE 19 DE JUNHO DE 2026 O SUBSECRETÁRIO DE ADMINISTRAÇÃO-GERAL DA SECRETARIA DE ESTADO DE TRANSPORTE E MOBILIDADE DO DISTRITO FEDERAL, no uso das atribuições regimentais previstas no art. 56 da Portaria nº 06, de 17 de outubro de 2022, considerando a delegação de competência conferida pelo art. 3º, inciso VI, da Portaria nº 142, de 5 de junho de 2023, publicada no DODF nº 108, de 12 de junho de 2023, alterada pela Portaria nº 165, de 26 de maio de 2026, publicada no DODF nº 101, de 3 de junho de 2026, e considerando as informações constantes do Processo SEI nº 00090-00008747/2026-28, resolve: AVERBAR o tempo de contribuição prestado pela servidora LUCIANA MUNIZ DE SOUZA, matrícula nº 266383-X, ocupante do cargo de Auditora Fiscal de Atividades Urbanas do Distrito Federal, correspondente a 616 (seiscentos e dezesseis) dias, conforme Declaração de Tempo de Contribuição ao Regime Geral de Previdência Social (RGPS) expedida pela Secretaria de Estado de Educação do Distrito Federal, referente ao exercício da função de professor temporário nos períodos de 26.02.2013 a 19.12.2013 e 07.02.2014 a 22.12.2014, para fins de aposentadoria e concessão de adicionais.

PEDRO HENRIQUE LUZ ARAÚJO

## SECRETARIA DE ESTADO DE

## JUSTIÇA E CIDADANIA

### SUBSECRETARIA DE ASSUNTOS FUNERÁRIOS

ORDEM DE SERVIÇO Nº 04, DE 18 DE JUNHO DE 2026 A SUBSECRETÁRIA DE ASSUNTOS FUNERÁRIOS, DA SECRETARIA DE ESTADO DE JUSTIÇA E CIDADANIA DO DISTRITO FEDERAL, cumprindo mandamento do art. 10 do Decreto nº 34.320/2013, e Considerando os ritos administrativos tratados no Processo Administrativo nº 08190.053732/16-73, em reunião ocorrida em 27 de outubro de 2016; Considerando ainda, o que apregoa o inciso I do art. 20 do Decreto nº 40.569/2020, resolve: Art. 1º Designar os servidores ANA PAULA MARQUES SOUZA, matrícula 1730160-2, MARIANA LARISSA DE ARAÚJO DOS SANTOS, matrícula 1724100-6, REGINALDO MENDONÇA DOS SANTOS, matrícula nº 255.356-2 e WELINTON PEREIRA DA SILVA, matrícula nº 256.797-0 como representantes da Subsecretaria de Assuntos Funerários/Sejus, para supervisionar a execução dos trabalhos de exumação no Cemitério São Francisco de Assis de Taguatinga/DF, dos corpos inumados nas sepulturas relacionadas no art. 3º desta Ordem de Serviço, conforme comunicado publicado por

meio do Jornal de Brasília, em 15/06/2026, de publicidade da Concessionária Campo da Esperança Serviços Ltda., e a publicação efetuada no Diário Oficial do DF n.º 108, terçafeira, de 16/06/2026, das páginas 94 a 100. Art. 2º O escopo do trabalho consiste em verificar o fiel cumprimento dos procedimentos estabelecidos no Plano de Operacionalização apresentado no Processo Administrativo do Ministério Público do Distrito Federal e Territórios sob o número 08190.053732/16-73, insertos nos autos do processo nº 400.000.717/2014, às folhas 527 a 529, bem como os procedimentos insertos às fls. 155 e 156 do processo nº 400.000.505/2017 e fls. 174 e 175 do processo nº 400.000.504/2017. Art. 3º Os corpos a serem exumados estão sepultados no Setor DI, Quadra 103 do Cemitério São Francisco de Assis de Taguatinga/DF. Art. 4º Esta Ordem de Serviço entra em vigor na data de sua publicação.

GILCE SANT ANNA TELES

### COMISSÃO DE ÉTICA E DISCIPLINA

### DOS CONSELHOS TUTELARES

PORTARIA Nº 22, DE 19 DE JUNHO DE 2026 O PRESIDENTE DA COMISSÃO DE ÉTICA E DISCIPLINA DOS CONSELHOS TUTELARES, DA SECRETARIA DE ESTADO DE JUSTIÇA E CIDADANIA DO DISTRITO FEDERAL, no uso das atribuições que lhe conferem o art. 78, parágrafo único, c/c art. 80, § 2º, da Lei nº 5.294, de 13 de fevereiro de 2014, c/c art. 5º, alínea “d”, da Portaria nº 112, de 10 de maio de 2018, publicada no Diário Oficial do Distrito Federal nº 61, de 14 de maio de 2018, e as normas do processo de apuração de infração disciplinar previstas no Título VII, da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: Art. 1º Instaurar Processo Administrativo Disciplinar visando à apuração de supostas irregularidades constantes do Processo nº 00400-00004161/2026-34. Art. 2º Designar, de acordo com o art. 76, da Lei nº 5.294, de 2014, ROGÉRIO MARQUES DA SILVA LIMA, VINICIUS CAVALCANTE FERREIRA e WARLEI MARQUES PONTE, para, sob a presidência do primeiro, comporem a Comissão Processante. Art. 3º Designar como membro suplente, BIANCA ARAUJO DE MORAIS, para substituir os demais membros nas eventuais licenças, afastamentos, férias e outras ausências, conforme previsto no art. 229, §7º, da Lei Complementar nº 840, de 23 de dezembro de 2011. Art. 4º Fixar o prazo de 60 (sessenta) dias para o encerramento dos trabalhos e apresentação de relatório conclusivo, podendo este prazo ser prorrogado por igual período. Art. 5º Esta Portaria entra em vigor na data de sua publicação.

JOSÉ ANTÔNIO DOS SANTOS

## SECRETARIA EXTRAORDINÁRIA DO CONSUMIDOR

### INSTITUTO DE DEFESA DO CONSUMIDOR

PORTARIA Nº 24, DE 18 DE JUNHO DE 2026 O DIRETOR-GERAL, DO INSTITUTO DE DEFESA DO CONSUMIDOR DO DISTRITO FEDERAL, no uso das atribuições de que trata o art. 26, inciso VII, do Regimento Interno do PROCON/DF, Decreto nº 38.927, de 13 de março de 2018, resolve: SUSPENDER, por necessidade de serviço, o usufruto de férias da servidora SOFIA AYRES CARNEIRO MACHADO, matrícula nº 222.043-1, referente ao exercício de 2026, marcada para o período de 08/06/2026 a 25/06/2026, a suspensão é a contar de 22/06/2026 a 25/06/2026, ficando assegurada a fruição de férias no período de 13/10/2026 a 16/10/2026.

JOHNATAN RACHID PIRES FARAJ

## SECRETARIA DE ESTADO DE

## OBRAS E INFRAESTRUTURA

### GABINETE

ORDEM DE SERVIÇO Nº 20, DE 19 DE JUNHO DE 2026 A CHEFE DE GABINETE, DA SECRETARIA DE ESTADO DE OBRAS E INFRAESTRUTURA DO DISTRITO FEDERAL, no uso das atribuições conferidas pela Portaria nº 85, de 15 de maio de 2024, resolve: DESIGNAR a servidora CLEBIANA APARECIDA DA SILVA, matrícula nº 221.642-6, Chefe, Símbolo CPE-04, para substituir o servidor CARLOS EDUARDO DE OLIVEIRA MACIEL, matrícula 284.632-2, Subsecretário, Símbolo CNE-02, da Subsecretaria de Projetos, Orçamento e Planejamento de Obras, da Secretaria Executiva de Obras e Infraestrutura, da Secretaria de Estado de Obras e Infraestrutura, no período de 22 de junho de 2026 a 26 de junho de 2026, por motivo de Participação do titular no 28º ENACOR.

MAGALI TOLEDO KNUPP MIRANDA

<!-- pagina 46 -->

### SECRETARIA EXECUTIVA DE GESTÃO

### ADMINISTRATIVA E ESTRATÉGICA

ORDEM DE SERVIÇO Nº 37, DE 19 DE JUNHO DE 2026 A SECRETÁRIA EXECUTIVA DE GESTÃO ADMINISTRATIVA E ESTRATÉGICA, DA SECRETARIA DE ESTADO DE OBRAS E INFRAESTRUTURA DO DISTRITO FEDERAL, no uso das atribuições que lhe confere as alíneas "c" e "f", do inciso II, do art. 1º, do Decreto nº 39.133, de 15 de junho de 2018, o Decreto nº 29.290, de 22 de julho de 2008, o Decreto nº 45.001, de 26 de setembro de 2023, bem como a Portaria nº 85, de 15 de maio de 2024, resolve: AUTORIZAR O AFASTAMENTO, mediante dispensa de ponto dos servidores CARLOS EDUARDO DE OLIVEIRA MACIEL - matrícula: 284.632-2; BRUNO SOUSA ALMEIDA matrícula: 278.725-3, ANA CLARA DA SILVA LEÃO - matrícula: 285.676-X; MARCELO GALIMBERTI NUNES - matrícula: 973.617-4; ALESSANDRA GUIMARÃES DE OLIVEIRA SANTOS - matrícula: 108.575-1; MARCELO TAKAHASHI DOS SANTOS matrícula: 278.511-0; DÓRIS AKEMI AKAGI - matrícula: 285.172-5, no período de 22 a 26 de junho 2026, para o Município de Goiânia no Estado de Goiás/GO, a fim de participar do 28º Encontro Nacional de Conservação Rodoviária (ENACOR), na 51ª Reunião Anual de Pavimentação (RAPv) e na 7ª Expo ENACOR/RAPv, sem ônus para o Distrito Federal, conforme instrução do Processo SEI nº 00110-00001209/2026-54.

MEIRE LÚCIA GOMES MONTEIRO MOTA COELHO

### DEPARTAMENTO DE ESTRADAS DE RODAGEM SUPERINTENDÊNCIA ADMINISTRATIVA E FINANCEIRA

RETIFICAÇÃO Na Instrução de 18 de março de 2008, publicada no DODF N° 56, de 25 de março de2008, pg. 27, ONDE SE LÊ: “...1403 (um mil, quatrocentos e três) dias, correspondendo a 03 anos, 10 meses e 08 dias, conforme certidão de tempo de contribuição expedida pelo Instituto Nacional de Seguridade Social - INSS, relativa aos períodos de 02/01/1975 a 31/05/1975, de 30/09/1977 a 03/01/1978, de 18/02/1978 a 08/ 0711978, de 25/09/1978 a 10/11/1978, de 13/11/1978 a 11/05/1979, de 19/10/1979 a 26/12/1979, contados somente pra fins de aposentadoria, conforme autos do processo 113.000429/2008…", LEIA-SE: "...682 (seiscentos e oitenta e dois) dias, conforme certidão de tempo de contribuição expedida pelo Instituto Nacional de Seguridade Social - INSS, relativa aos períodos de 02/01/1975 a 31/05/1975, de 18/02/1978 a 08/ 0711978, de 25/09/1978 a 10/11/1978, de 19/10/1979 a 26/12/1979, contados somente pra fins de aposentadoria e 721 (setecentos e vinte e um dias) conforme certidão de tempo de serviço expedida pela Empresa Brasileira de Pesquisa Agropecuária - EMBRAPA, relativa aos períodos de 30/09/1977 a 03/01/1978 e de 13/11/1978 a 11/05/1979, contados para fins de serviço público e aposentadoria, conforme autos do processo 113.000429/2008...".

## SECRETARIA DE ESTADO DA AGRICULTURA, ABASTECIMENTO E DESENVOLVIMENTO RURAL

PORTARIA Nº 209, DE 18 DE JUNHO DE 2026. O SECRETÁRIO DE ESTADO DA AGRICULTURA, ABASTECIMENTO E DESENVOLVIMENTO RURAL DO DISTRITO FEDERAL, no uso de suas atribuições regulamentares e considerando o que dispõe o art. 95, inciso VII e IX da Portaria nº 908, de 18 de novembro de 2024, bem como em face do que consta no Documento SEI ID (205645325), resolve: SUSPENDER, por necessidade do serviço e fundamento no art. 128, Parágrafo único, inciso I, da Lei Complementar nº 840, de 23 de dezembro de 2011, as férias regulamentares da servidora ANA CAROLINA CAMPOS MAGALHÃES, matrícula 17208920, Assessora Especial, da Subsecretaria de Defesa Agropecuária, relativa ao período de 18/06/2026 a 27/06/2026, a servidora usufruirá este período em 03/11/2026 a 12/11/2026.

RAFAEL BORGES BUENO

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 193, DE 18 DE JUNHO DE 2026 O SUBSECRETÁRIO DE ADMINISTRAÇÃO GERAL, DA SECRETARIA DA AGRICULTURA, ABASTECIMENTO E DESENVOLVIMENTO RURAL DO DISTRITO FEDERAL, no uso da competência conferida pelo art. 5º, inciso I, alínea “c” da Portaria n° 48, de 16 de junho de 2016, resolve: CONCEDER o Adicional de Qualificação – AQ, instituído pelo art. 2º, Inciso II, do Decreto Nº 31.452 de 22 de março de 2010, a CRISTIANE OLIVEIRA CURCI CESAR, matrícula 1406582-7, cargo de Analista de Desenvolvimento e Fiscalização Agropecuária, (4%), a considerar de 15/06/2026, Processo SEI nº 00070-00003595/2019-12.

MARCELO JESUS KATO AVILA

## SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA

PORTARIA Nº 435, DE 18 DE JUNHO DE 2026 O SECRETÁRIO DE ESTADO DE ECONOMIA DO DISTRITO FEDERAL, no uso de suas atribuições regimentais e com fundamento no art. 7º da Lei nº 14.133/2021, de 1º de abril de 2021, no art. 43, do Decreto nº 32.598/2010,e, ainda, acatando as indicações das áreas técnicas, resolve:

Art. 1º Designar os servidores relacionados abaixo para atuarem como Executores do Termo de Compromisso celebrado entre o Distrito Federal, por meio da Secretaria de Estado de Economia do Distrito Federal e a ASSOCIAÇÃO EDUCACIONAL DOS TRABALHADORES DE BRASÍLIA-AETB (CENTRO UNIVERSITÁRIO PROCESSUS – UniPROCESSUS), inscrita no CNPJ/MF sob o nº 00.116.962/0001-00, que tem por objeto o oferecimento de desconto em matrícula e mensalidades em cursos de graduação, pós-graduação e tecnólogos, nos termos do Decreto nº 46.377, de 10 de outubro de 2024, conforme Processo SEI nº 04044-00004036/2025-55: I - DANIELLE FERNANDES ALMEIDA DO RÊGO, matrícula nº 283.384-0, para atuar como executora Titular no âmbito da Secretaria de Estado de Economia; e II - YEDO ROCHA VIANA, matrícula nº 287.302-8, para atuar como executor Suplente, no âmbito da Secretaria de Estado de Economia. Art. 2º Os servidores, de que trata o art. 1º, devem observar a Lei nº 14.133, de 1º de abril de 2021; o Decreto nº 32.598, de 15 de dezembro de 2010; a Portaria nº 222-SEPLAG, de 31 de dezembro de 2010 e a Portaria nº 550-SEPLAG, de 12 de dezembro de 2018. Art. 3º Esta Portaria entra em vigor na data de sua publicação. Art. 4º Revogam-se as disposições e designações em contrário.

VALDIVINO JOSÉ DE OLIVEIRA

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO

PORTARIA Nº 95, DE 16 DE JUNHO DE 2026 Altera a Portaria nº 100, de 10 de novembro de 2022, que designa representantes suplentes da Comissão Permanente de Análise de Estudo Prévio de Impacto de Vizinhança – CPA/EIV de que trata o Decreto nº 43.804, de 04 de outubro de 2022 e dá outras providências. O SECRETÁRIO DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso das atribuições que lhe conferem o art. 105, parágrafo único, incisos I, III e V da Lei Orgânica do Distrito Federal, a Portaria nº 227, de 11 de julho de 2022, da Secretaria de Estado de Economia do Distrito Federal, o Decreto nº 43.804, de 04 de outubro de 2022, e o que consta do Processo SEI n° 00390- 00002022/2025-14, resolve: Art. 1º O inciso VII e XII do art. 1º da Portaria nº 100, de 10 de novembro de 2022, passam a vigorar com a seguinte redação: "Art. 1º ................ I – ....................................... II – ....................................... III – ..................................... IV – .................................... V – ....................................... VI – ....................................... VII – SIMONE MARIA MEDEIROS COSTA, matrícula n.º 041430-1, da Secretaria de Estado de Proteção da Ordem Urbanística do Distrito Federal - DF-Legal; VIII – .................................... IX – ....................................... X – ....................................... XI –....................................... XII – MAURO JOSÉ LANDIM DOS SANTOS, matrícula n.º 0004595-0, da Companhia Energética de Brasília - CEB; XIII – ...................................... XIV – ...................................... XV – ....................................... " (NR) Art. 2º Ficam dispensados os servidores designados por meio da Portaria nº 100, de 2022, e suas alterações, que foram substituídos na forma desta portaria. Art. 3º Esta portaria entra em vigor na data de sua publicação.

MARCELO VAZ MEIRA DA SILVA

## SECRETARIA DE ESTADO DO MEIO AMBIENTE

PORTARIA Nº 56, DE 18 DE JUNHO DE 2026 Nomeia os membros da Comissão Organizadora da Conferência Distrital de Aquicultura e Pesca do Distrito Federal e dá outras providências. O SECRETÁRIO DE ESTADO DO MEIO AMBIENTE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, inciso III, da Lei Orgânica do Distrito Federal, e considerando: CONSIDERANDO a PORTARIA MPA nº 624, DE 23 DE JANEIRO DE 2026, que convocou a 4ª Conferência Nacional de Aquicultura e Pesca - 4ª CNAP e publicou o seu Regimento Interno; CONSIDERANDO a PORTARIA SEMA nº 46, DE 22 DE MAIO DE 2026, que instituiu a Comissão Organizadora da 1ª Conferência Distrital de Pesca e Aquicultura do Distrito Federal e aprova seu Regimento Interno; CONSIDERANDO a convocação da 4ª Conferência Nacional de Aquicultura e Pesca pelo Ministério da Pesca e Aquicultura; CONSIDERANDO a necessidade de realização da etapa distrital como parte do processo participativo nacional; CONSIDERANDO a importância da pesca e aquicultura para o desenvolvimento sustentável, segurança alimentar e inclusão produtiva; CONSIDERANDO a necessidade de promover a participação social na construção de políticas públicas voltadas à pesca e aquicultura no âmbito do Distrito Federal. resolve:

<!-- pagina 47 -->

Art. 1° Constituir a Comissão Organizadora da 1ª Conferência Distrital de Aquicultura e Pesca do Distrito Federal, nos termos da PORTARIA SEMA nº 46, de 22 de maio de 2026, com atribuição de prestar apoio operacional e assistência técnica na execução das atividades da Comferência. Art. 2° A Comissão Executiva será composta por oito comissões descritas nesta Portaria, as quais deverão executar suas funções orientadas pelos conteúdos dos documentos elaborados pelo Ministério da Pesca e Aquicultura - MPA, acerca da 4ª Conferência Nacional de Aquicultura e Pesca - 4ª CNAP, observando suas orientações técnicas, diretrizes, critérios e regramentos. Art. 3° A Coordenação Geral será exercida por servidores públicos da Secretaria de Estado do Meio Ambiente - SEMA e será responsável por coordenar os trabalhos da Comissão Executiva da 1ª Conferência Distrital de Pesca e Aquicultura do Distrito Federal. Art. 4º A Comissão dos Grupos Temáticos de Trabalho - GTs deverá conduzir os Grupos Temáticos de Trabalho, referentes aos oito Eixos Temáticos da 1ª CDPA, colaborar na construção objetiva das propostas, garantir ampla participação social, equacionar o tempo, garantir o ambiente respeitoso entre os participantes. Os Eixos Temáticos consistem em: Eixo I - Valorização da pesca artesanal, povos e comunidades tradicionais; Eixo II – Desenvolvimento sustentável da aquicultura; Eixo III – Conhecimento tradicional, formação técnica, extensão, pesquisa e inovação; Eixo IV – Fortalecimento institucional e continuidade das políticas públicas; Eixo V – Gestão, ordenamento, governança participativa e mediação de conflitos; Eixo VI - Infraestrutura, Agregação de valor e abertura de mercado; Eixo VII - Equidade de gênero e valorização das mulheres; Eixo VIII - Sustentabilidade, justiça climática e adaptação às emergências climáticas. Art. 5º A Comissão de Homologação de Delegados e Delegadas deverá elaborar os documentos necessários para a homologação das pessoas delegadas na 1ª CDPA, observando os critérios normativos que fundamentam a representatividade e a composição visando a devida eleição na Plenária Final. Art. 6º A Comissão de Sistematização das Propostas deverá sistematizar todo conteúdo das propostas consolidadas nos Grupos Temáticos de Trabalhos GTs, referentes aos Eixos Temáticos da 1ª CDPA, garantindo a qualidade ortográfica e os critérios estabelecidos no regramento para construção de propostas. A Comissão deverá respeitar o teor dos conteúdos elaborados pelos participantes e deverá produzir o Caderno de Propostas. Art. 7º A Comissão de Conteúdo Técnico deverá elaborar conteúdos técnicos e didáticos transversais sobre os cinco eixos temáticos alinhados ao Documento Base elaborado pela Comissão Organizadora da 1ª CNPA. A Comissão deverá garantir a qualidade técnica dos conteúdos. Art. 8º A Comissão de Mobilização deverá promover a articulação e a mobilização em todas as regiões do Distrito Federal visando garantir o máximo de participação social na 1ª CDPA. A Comissão deverá apresentar um Plano de Mobilização, realizar campanhas, movimentar as redes sociais, construir listas de contatos por segmentos sociais, mobilizar setores da sociedade civil, poder público e setor privado. Art. 9º A Comissão de Comunicação deverá realizar todas as atividades de divulgação em redes sociais e imprensa por meio de estratégias de comunicação social. A Comissão deverá construir a identidade visual da 1ªCDPA a partir das regras e conteúdos disponibilizados pela Comissão de Organização da 4ªCNAP. Art. 10. A Comissão de Logística, Infraestrutura e Gestão de TI deverá garantir as contratações necessárias para realização da 1ª CDPA, os recursos financeiros e o controle de custos, bem como toda logística do evento. Art.11. A Comissão de Assessoria Jurídica e Ouvidoria deverá promover orientação jurídica geral para os(as) participantes, bem como garantir o registro de dúvidas, reclamações, elogios ou sugestões. Art. 12. A Comissão de Relatoria Final deverá promover a consolidação das propostas da 1ª CDPA e elaborar o Caderno de Propostas a ser encaminhado para a 4ª Conferência Nacional de Aquicultura e Pesca. Art. 13. A composição da Comissão Executiva da 1ª CDPA consta no Anexo Único desta Portaria. Art. 14. Revoga-se a Portaria nº 55, publicada no Diário Oficial do Distrito Federal nº 110, de 18 de Junho de 2026. Art. 15. Esta Portaria entra em vigor na data de sua publicação.

RAFAEL SANTANA

Anexo Único

- Função Nome / matrícula

1 Coordenação-Geral da Conferência Distrital

Secretário de Estado do Meio Ambiente - Rafael

do Meio Ambiente

Santana

2 Coordenação Técnica Edson Buscácio - SEMA/DF

3 Coordenação Executiva Glauco Amorim da Cruz - SEMA/DF

Israel Dourado Guerra - SEMA/DF

4 Moderador geral Relatores da Plenária Geral

Edson Buscácio - SEMA/DF Carlos Eduardo Porto Montel - SEMA/DF

Valdo Abreu - Ministério da Pesca e Aquicultura -

MPA Paulo Franco - Associação de Pesca Subaquática -

Facilitadores e Relatores dos Eixos 1 e 3

Eixo 1 - valorização da pesca artesanal,

APSHARK Marcelo Portela - Associação Brasileira de Esportes

povos e comunidades tradicionais

e Pesca Subaquático Marllon Douglas - Associação Brasileira de

Eixo 3 - conhecimento tradicional, formação técnica, extensão, pesquisa e

Esportes e Pesca Subaquático Rodrigo Navarro - Universidade de Brasília - UNB

inovação

Sebastiana - Pescadora artesanal Celismar Júnior - União Nacional das Associações de Pesca e Federação Candanga de Pesca Esportiva

Adalmyr Morais Borges - EMATER/DF Claudia Coelho de Assis - EMATER/DF Madalena Maria Saldanha Coelho - Secretaria de

Facilitadores e Relatores dos Eixos 2 e 6

Eixo 2 - desenvolvimento sustentável da

Estado da Agricultura do Distrito Federal -

SEAGRI/DF Jaqueline Reisman - Associação Brasileira de

aquicultura

Eixo 6 - infraestrutura, agregação de valor

Esportes e Pesca Subaquáticos Kenji Amano - Confederação Brasileira de Pesca

e abertura de mercado

Esportiva José Joaquim Carneiro Filho - Ministério da Agricultura, Pecuária e Abastecimento - MAPA

Maria Fontalvo Mazzonetto - Ministério da Agricultura, Pecuária e Abastecimento - MAPA

Jansley de Amorim - Confederação Brasileira de

Pesca Esporitva Marcelo Reisman - Associação Brasileira de

Facilitadores e Relatores dos Eixos 4 e 5

Eixo 4 - fortalecimento institucional e

Esportes e Pesca Subaquáticos Rodrigo Rodrigues - Associação Brasileira de

continuidade das políticas públicas

Esportes e Pesca Subaquáticos Daniel Cabral - Ministério da Pesca e Aquicultura -

Eixo 5 - gestão, ordenamento, governança

MPA Guth Berger Falcon Rodrigues - Instituto Brasília

participativa e mediação de conflitos

Ambiental - IBRAM/DF

Eleutéria Pacheco Guerra - SEMA/DF Ingrid Lopes Fernandes da Rocha - Ministério da

Facilitadores e redatores dos Eixos 7 e 8

Eixo 7 - equidade de gênero e valorização

Pesca e Aquicultura - MPA Aline Almeida - Confederação Brasileira de Pesca

das mulheres

Esportiva André Souza - SEMA/DF Carla Matias - SEMA/DF Marco Honório - Associação de Pesca Subaquática

Eixo 8 - sustentabilidade, justiça climática

e adaptação às emergências climáticas

- APSHARK

Jaira Maria Puppim - MPA

Comissão Homologação de Delegados e

Valdo Sena Abreu- MPA Alvaro Luiz Marinho Castro - EMATER/DF

Emanuelle Cristina Benvenutti Rodrigues -

Delegadas

Ministério da Pesca e Aquicultura - MPA

Ciro Joko - Universidade do Distrito Federal - UDF

10 Comissão Sistematização de Propostas

Gabriela Mingote - Universidade do Distrito

Federal - UDF

Glauco Amorim da Cruz - SEMA/DF

Israel Dourado Guerra - SEMA/DF Flávia Ilíada Furtado Coelho de Oliveira -

11 Comissão de Conteúdo Técnico

SEMA/DF Júlia Dâmaso - SEMA/DF

Luciana de Carvalho dos Santos - SEMA/DF

Hélio Carlos - SEMA Eliana Damacena - SEMA/DF

Comissão de Mobilização

Ione Ferreira - SEMA/DF Alisson Falcão - SEMA/DF

Mirelle Prais - SEMA/DF Giovanna Gonçalves de Aquino - SEMA/DF

Kátia Lima Bruno - SEMA/DF

13 Comissão de Logística, Infraestrutura e TI Edneuza Queiroz Pereira - SEMA/DF

Mahatma Lima - SEMA/DF

Rayssa Rios da Silva - SEMA/DF

Comissão de Comunicação

Deassis Alves - SEMA/DF

Flávio Costa - SEMA/DF Hudson Portela - SEMA/DF Ana Cecília Roscoe Bessa Fonte - SEMA/DF

15 Comissão de Ouvidoria Cristiane Longo Correia - SEMA/DF

16 Comissão de Assessoria Jurídica Alessandro Domingos - SEMA/DF

17 Comissão de Relatoria Final Carlos Eduardo Porto Montel - SEMA/DF

Aline de Queiroz Caldas - SEMA/DF Carlos Alberto Ferreira Netto - SEMA/DF Amanda Cesia Villacorta Silva - SEMA/DF

Lorena da Silveira Bougleux - SEMA/DF

Comissão de Apoio

Francisco José Feijó Paiva - SEMA/DF Pietro Matheus Pereira Santos - SEMA/DF

Kamilly Cristina Rodrigues - SEMA/DF

Wanderson Fernandes - SEMA/DF

Raquel de Sousa - SEMA/DF Cleusa de Sousa - SEMA/DF Cleidson Pereira - SEMA/DF

<!-- pagina 48 -->

PORTARIA Nº 57, DE 19 DE JUNHO DE 2026 Dispõe sobre a designação e a dispensa de membros na Comissão de Monitoramento e Avaliação, no âmbito da Secretaria de Estado do Meio Ambiente e Proteção Animal do Distrito Federal (SEMA-DF), instituída pela Portaria nº 38, de 30 de abril de 2025, nos termos do Decreto Distrital nº 37.843, de 13 de dezembro de 2016, da Lei nº 13.019, de 31 de julho de 2014, para acompanhamento da parceria celebrada com Organização da Sociedade Civil - Fundação Pedro Jorge (FPJ), mediante Termo de Fomento, cujo o objeto é a realização do "Projeto Circuito Reciclo", voltado para a promoção da educação ambiental e conscientização da comunidade quanto ao consumo consciente de água e o descarte de resíduo sólidos. O SECRETÁRIO DE ESTADO DO MEIO AMBIENTE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o art. 105, parágrafo único, inciso III, da Lei Orgânica do Distrito Federal, resolve: Art.1º Dispensar a servidora ANA BEATRIZ BENÍCIO, matrícula 285.445-7. Art. 2º Designar o servidor DÁLIO RIBEIRO DE MENDONÇA FILHO, matrícula nº 37.709-0. Art. 3º Manter a designação da servidora ELIZABETE ELIAS CAMPOS - Matrícula: 285.061-3. Art. 4º Esta Portaria entra em vigor na data de sua publicação.

RAFAEL SANTANA

## SECRETARIA EXTRAORDINÁRIA

## DE PROTEÇÃO ANIMAL

### SECRETARIA EXECUTIVA

ORDEM DE SERVIÇO Nº 08, DE 19 DE JUNHO DE 2026 O SECRETÁRIO-EXECUTIVO, DE PROTEÇÃO ANIMAL DO DISTRITO FEDERAL, no uso da delegação de competências conferida pelo art. 44 da Portaria nº 05, de 22 de setembro de 2025, publicada no DODF nº 180, de 23 de setembro de 2025, resolve: Art. 1º Designar para compor a Comissão de Monitoramento e Avaliação de Parcerias celebradas com organizações da sociedade civil, nos termos da Portaria nº 05, de 22 de setembro de 2025, os seguintes servidores: LAIZA MARA NEVES SPAGNA, matrícula 1726879-6; ALINE VICENTE DE CARVALHO, matrícula 1730990-X; THAÍS PUCCINELLI COSTA DE ARAÚJO, matrícula 1727000-6; LEONARDO FRANCO AMARAL, matrícula 1726964-4; SUELLEN CHRISTINE ROCHA DE HOLANDA, matrícula 1729999-3; GEVERSON DOURADO BRITO, matrícula 1732098-4; KARINE ALVES BATISTA, matrícula 1726799-4. Art. 2º A Comissão é coordenada pelo servidor designado no inciso I, do artigo 1º e, na sua ausência, pelo servidor designado no inciso II do artigo 1º ou incisos subsequentes. Art. 3º Fica revogada a Ordem de Serviço nº 07, de 14 de maio de 2026, publicada no Diário Oficial do Distrito Federal nº 88, de 15 de maio de 2026. Art. 4º Esta Ordem de Serviço entra em vigor na data de sua publicação.

LEONARDO ARAÚJO EMERICK

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO

## ECONÔMICO, TRABALHO E RENDA

PORTARIA Nº 73, DE 19 DE JUNHO DE 2026 O SECRETÁRIO DE ESTADO DE DESENVOLVIMENTO ECONÔMICO, TRABALHO E RENDA DO DISTRITO FEDERAL, no uso das atribuições legais que lhe confere o art. 105, parágrafo único, da Lei Orgânica do Distrito Federal; considerando a Lei nº 13.019, de 31 de julho de 2014; considerando o Decreto Distrital nº 37.843, de 13 de dezembro de 2016; considerando a Portaria nº 20, de 24 de fevereiro de 2026; considerando a celebração do TERMO DE FOMENTO Nº 04/2026, firmado entre o Distrito Federal, por intermédio desta Secretaria de Estado de Desenvolvimento Econômico, Trabalho e Renda do Distrito Federal – SEDET/DF, e o Instituto de Capacitação, Desenvolvimento e Inovação – ICDI; e considerando o constante nos autos do Processo SEI nº 04035-00003743/2026-14, resolve: Art. 1º Instituir Comissão Gestora com a finalidade de acompanhar, monitorar e fiscalizar a execução do TERMO DE FOMENTO Nº 04/2026, referente ao projeto “FEIRÃO DO TRABALHADOR 2026 – BRASÍLIA”. Art. 2º A Comissão Gestora será composta da seguinte forma: I – MICHELLY FERREIRA RIBEIRO, matrícula nº 172.934-9, na função de Membro Gestor Coordenadora;

II – THAIS GOMES MELO DE OLIVEIRA, matrícula nº 283.694-7, na função de Primeiro Membro Gestor; III – RENATA LAUANE FRANÇA RIBEIRO, matrícula nº 276.838-0, na função de Segundo Membro Gestor; e IV – AMANDA JESSICA CARLOS GUSMÃO, matrícula nº 284.676-4, na função de Terceiro Membro Gestor. Art. 3º Compete à Comissão Gestora: I – acompanhar a execução física e financeira da parceria; II – verificar o cumprimento das metas e resultados previstos no Plano de Trabalho aprovado; III – emitir relatórios de monitoramento e avaliação da execução do objeto; IV – adotar as providências necessárias ao fiel cumprimento da parceria, nos termos da legislação vigente; V – subsidiar a autoridade competente quanto à regularidade da execução do ajuste. Art. 4º A presente Comissão Gestora terá vigência enquanto durar o Termo de Fomento nº 04/2026. Art. 5º Esta Portaria entra em vigor na data de sua publicação.

THALES MENDES FERREIRA

### JUNTA COMERCIAL, INDUSTRIAL E SERVIÇOS DO DISTRITO FEDERAL

PORTARIA Nº 98, DE 19 DE JUNHO DE 2026 A PRESIDENTE DA JUNTA COMERCIAL, INDUSTRIAL E SERVIÇOS DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o artigo 25 do Decreto Federal nº 1.800, de 30 de janeiro de 1996, da Lei Distrital nº 6.315, de 27 de junho de 2019, considerando o disposto no art. 3º, do Decreto nº 39.002, de 24 de abril de 2018, bem como nos arts. 44 e 45 da Lei Complementar nº 840, de 23 de dezembro de 2011, e conforme Processo nº 04019-00000557/2026-95, resolve: DESIGNAR o servidor GUILHERME GOMES TORRES, matrícula nº 2792761, Assessor da Coordenação de Tecnologia da Informação e Comunicação, para substituir, sem acumular vencimentos e sem prejuízo das suas atribuições, o servidor ANDRÉ RODRIGUES DE SOUZA JÚNIOR, matrícula nº 277765-7, Coordenador de Tecnologia da Informação e Comunicação, CNE-04, desta JUNTA COMERCIAL, INDUSTRIAL E SERVIÇOS DO DISTRITO FEDERAL, no período de 19/06/2026, por motivo de usufruto de Abono de Ponto anual, do titular da unidade, conforme constam no Processos SEI nº 04019-00000314/2026-57.

RAQUEL OTÍLIA DE CARVALHO

## DEFENSORIA PÚBLICA

PORTARIA Nº 92, DE 09 DE MARÇO DE 2023 (*) O DEFENSOR PÚBLICO-GERAL DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL, no uso das atribuições legais e tendo em vista o disposto no artigo 97-A, inciso III e VI c/c artigo 100, ambos da Lei Complementar nº 80, de 12 de janeiro de 1994, c/c artigo 21, incisos I e XIII da Lei Complementar Distrital nº 828/2010, em sua nova redação dada pela Lei Complementar Distrital nº 908/2016 e a Emenda à Lei Orgânica nº 61, de 2012, e, ainda, a Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: CONCEDER abono de permanência, equivalente ao valor de sua contribuição previdenciária, a DEUSELY FERREIRA MELGACO DE OLIVEIRA, matrícula nº 91.216-6, Cargo Técnico em Políticas Públicas e Gestão Governamental do Quadro de Pessoal do Governo do Distrito Federal, lotada no Núcleo de Assistência Jurídica de Samambaia, de acordo com o § 5º do artigo 2º, da Emenda Constitucional nº 41, de 19/12/2003 e o que dispõe o artigo 45 da Lei Complementar Distrital nº 769, de 30/06/2008, c/c o artigo 114 da Lei Complementar Distrital nº 840/2011, a contar de 28/08/2018, por haver preenchido os requisitos para a aposentadoria nos termos do Artigo 40, §§ 3º, 4º, inciso I, 8º e 17 da CRFB, combinado com os artigos 3º, inciso III, da Lei Complementar Federal nº 142/2013, 1º da Lei federal nº 10.887/2004 e 51 da Lei Complementar distrital nº 769/2008 e tendo optado por permanecer em atividade. Processo nº 00401-00003345/2023-14.

REINALDO ROSSANO ALVES __________________ (*) Republicado por ter sido encaminhado com incorreção no original, publicado no DODF nº 50, de 14 de março de 2023, página 76.

PORTARIA Nº 238, DE 19 DE JUNHO DE 2026 O DEFENSOR PÚBLICO-GERAL DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL, nos termos do art. 134, §§ 1º, 2º e 3º, da Constituição Federal; art. 114, §1º, da Lei Orgânica do Distrito Federal; art. 2º, § 7ª, da Emenda à Lei Orgânica nº 61/2012; e no uso das atribuições que lhe conferem os artigos 97-A, incisos I e III, e 100, da Lei Complementar Federal nº 80/94, e nos artigos 9º, incisos III, VII e XV, e 21, incisos I e XIII, da Lei Complementar Distrital nº 828/2010, com as alterações promovidas pela Lei Complementar Distrital nº 908/2016, resolve:

<!-- pagina 49 -->

EXONERAR, a pedido, EDUARDO ATROCH MACHADO, matrícula nº 12071, do Cargo em Comissão, Símbolo CCDPDF-12, de Assessor(a) Técnico(a), da Gerência de Transformação e Inovação em Serviços Públicos e Laboratório Júnior de Inovação e Tecnologia, da Coordenação de Tecnologia da Informação e Comunicação, Unidade de Inovação, Tecnologia da Informação e Comunicação, da Subsecretaria de Administração - Geral, da Defensoria Pública-Geral, da Defensoria Pública do Distrito Federal, a contar de 17/06/2026.

REINALDO ROSSANO ALVES

PORTARIA Nº 239, DE 19 DE JUNHO DE 2026. O DEFENSOR PÚBLICO-GERAL DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL nos termos do art. 134, §§ 1º, 2º e 3º, da Constituição Federal; art. 114, §1º, da Lei Orgânica do Distrito Federal; art. 2º, § 7ª, da Emenda à Lei Orgânica nº 61/2012; e no uso das atribuições que lhe conferem os artigos 97-A, incisos I e III, e 100, da Lei Complementar Federal nº 80/94, e nos artigos 9º, incisos III, VII e XV, e 21, incisos I e XIII, da Lei Complementar Distrital nº 828/2010, com as alterações promovidas pela Lei Complementar Distrital nº 908/2016, resolve: EXONERAR, a pedido, YURI LUIGI LOPES MENDONÇA, matrícula nº 2541033, do Cargo efetivo de Analista de Apoio à Assistência Judiciária, da Defensoria Pública do Distrito Federal, conforme processo SEI nº 00401-00015317/2026-84, a contar de 22 de junho de 2026.

REINALDO ROSSANO ALVES

PORTARIA Nº 240, DE 19 DE JUNHO DE 2026 O DEFENSOR PÚBLICO-GERAL DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL, no uso das atribuições legais e tendo em vista o que dispõe a Lei Federal Complementar nº 80, de 12 de janeiro de 1994, a Emenda à Lei Orgânica nº 61, de 2012, o artigo 44 da Lei Complementar nº 840, de 23 de dezembro de 2011 c/c com o Decreto 39.002, de 24 de abril de 2018, e ainda, a Portaria nº 175, de 29 de maio de 2019, resolve: REVOGAR na Portaria nº 299, de 08 de julho de 2024, publicada no DODF nº 131, de 11/07/2024, página 55, o ato que designou NILSON RIOS DA SILVA, matrícula nº 11210, como substituto eventual do(a) Gerente, Símbolo CCDPDF-14, da Gerência de Gestão Patrimonial, da Diretoria de Patrimônio, da Unidade de Logística, da Subsecretaria de Administração Geral, da Defensoria Pública do Distrito Federal, nas licenças, afastamentos, férias e demais ausências ou impedimentos legais ou regulamentares do(a) titular. DESIGNAR MARCELO ALEXANDRE DE OLIVEIRA, matrícula nº 12934, como substituto eventual do(a) Gerente, Símbolo CCDPDF-14, da Gerência de Gestão Patrimonial, da Diretoria de Patrimônio, da Unidade de Logística, da Subsecretaria de Administração Geral, da Defensoria Pública-Geral, da Defensoria Pública do Distrito Federal, nas licenças, afastamentos, férias e demais ausências ou impedimentos legais ou regulamentares do(a) titular.

REINALDO ROSSANO ALVES

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

ORDEM DE SERVIÇO Nº 81, DE 18 DE JUNHO DE 2026 O SUBSECRETÁRIO DE ADMINISTRAÇÃO GERAL, DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL, no uso de suas atribuições legais, considerando o disposto no inciso VII do art. 55 e art. 59, ambos do Decreto nº 44.330/2023, resolve: Art. 1º Instituir a Equipe de Planejamento da Contratação que atuará em conformidade com as competências necessárias ao acompanhamento e apoio de todas as etapas da contratação objeto do Processo nº 00401-00014831/2026-01, referente à pretensa contratação de serviços de certificação digital institucional, contemplando certificados digitais para pessoas físicas (e-CPF), pessoas jurídicas (e-CNPJ) e certificados SSL para aplicações institucionais, em observância ao art. 10 da Instrução Normativa - SGD/ME nº 94, de 23 de dezembro de 2022, aplicável à Administração Pública Direta e Indireta do Distrito Federal conforme preconiza o art. 269-A do Decreto Distrital nº 44.330, de 15 de março de 2018, composta pelos seguintes servidores: I - Integrante Requisitante: PELÓPIDAS AUGUSTO MOREIRA DE SOUZA – Matrícula nº 12.935; II - Integrante Técnico: LAYON BRITO – Matrícula nº 10.666; III - Integrante Administrativo: GUILHERME DE JESUS SANTOS – Matrícula nº 10.658. Art. 2º A Equipe instituída deverá realizar todas as atividades das etapas de Planejamento da Contratação, além de acompanhar e apoiar as fases do processo de licitação, quando solicitado pelas áreas responsáveis. Art. 3º A Equipe de Planejamento da Contratação será automaticamente destituída quando da formalização do contrato. Art. 4º Esta Ordem de Serviço entra em vigor na data de sua publicação.

ANDRÉ LUIZ ALVARENGA CALANDRINE

ORDEM DE SERVIÇO Nº 82, DE 19 DE JUNHO DE 2026. O SUBSECRETÁRIO DE ADMINISTRAÇÃO GERAL, DA DEFENSORIA PÚBLICA DO DISTRITO FEDERAL - DPDF, no uso de suas atribuições legais, tendo em vista a delegação de competência prevista na Portaria nº 313, de 4 de novembro de 2019, publicada no DODF nº 213 de 7 de novembro de 2019, resolve:

Art. 1º Designar PELÓPIDAS AUGUSTO MOREIRA DE SOUZA, Matrícula nº 12935, e RAFAEL SADO ANDRADE, Matrícula nº 1127-8, para atuarem como Gestor e Suplente respectivamente do Termo de Cooperação celebrado entre a Defensoria Pública do Distrito Federal e as Defensorias Públicas do Estado do Acre, Amazonas, Piauí, Rondônia, Roraima e Sergipe, cujo objeto é o compartilhamento de conhecimentos e de transferência de tecnologias, mediante a disponibilização de sistemas informatizados desenvolvidos pelas partes, bem como dos conhecimentos utilizados na sua construção e desenvolvimento, capacitação de técnicos, intercâmbio de informações, estudos e pesquisas de assuntos de interesse comum, conforme consta do processo nº 00401-00015328/2025-83. Art. 2º Os servidores designados no artigo anterior deverão observar o disposto nos artigos 117 e 184 da Lei Federal nº 14.133/2021, c/c o Capítulo VII, do Decreto nº 32.598/2010, e no Capítulo IX do Decreto nº 44.330/2023. Art. 3º A Diretoria de Contratos e Convênios desta DPDF disponibilizará o processo aos servidores, bem como toda a legislação pertinente que se fizer necessária ao bom desempenho da função de gestor. Art. 4º Esta Ordem de Serviço entra em vigor na data de sua publicação. Art. 5º Revogam-se as disposições em contrário, em especial a ordem de serviço nº 07, de 23/01/2026, publicada no DODF nº 16, de 26/01/2026

ANDRÉ LUIZ ALVARENGA CALANDRINE

## PROCURADORIA-GERAL

PORTARIA Nº 391, DE 17 DE JUNHO DE 2026 A PROCURADORA-GERAL DO DISTRITO FEDERAL, no exercício das atribuições que lhe conferem o art. 6º, XXXV, da Lei Complementar nº 395, de 31 de julho de 2001; o art. 1º, II, 'f', do Decreto nº 39.133, de 15 de junho de 2018; o artigo 2º, I, do Decreto 29.290, de 22 de julho de 2008, bem como o artigo 6º do Decreto nº 45.001, de 26 de setembro de 2023, e considerando o que dispõem os arts. 104 e 105 da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: AUTORIZAR O DESLOCAMENTO EM TERRITÓRIO NACIONAL de ITALLO GABRIEL ALBUQUERQUE DE ANDRADE, matrícula nº 244.357-0, Gerente de Manutenção e Administração Predial, no período de 22 a 25 de junho de 2026, para participação no evento 26º Congresso de Stress da ISMA-BR em Porto Alegre/RS, com ônus total para o Distrito Federal, incluindo a concessão de diárias e de passagens aéreas. Processo SEI nº 00020-00031597/2026-15.

DIANA DE ALMEIDA RAMOS

PORTARIA Nº 392, DE 17 DE JUNHO DE 2026 A PROCURADORA-GERAL DO DISTRITO FEDERAL, no exercício das atribuições que lhe conferem o art. 6º, XXXV, da Lei Complementar nº 395, de 31 de julho de 2001; o art. 1º, II, 'f', do Decreto nº 39.133, de 15 de junho de 2018; o artigo 2º, I, do Decreto 29.290, de 22 de julho de 2008, bem como o artigo 6º do Decreto nº 45.001, de 26 de setembro de 2023, e considerando o que dispõem os arts. 104 e 105 da Lei Complementar nº 840, de 23 de dezembro de 2011, resolve: AUTORIZAR O DESLOCAMENTO EM TERRITÓRIO NACIONAL de JOSÉ CARLOS CASTELO BRANCO FILHO, matrícula nº 254.622-1, Gerente de Registros Funcionais e Atendimento da Diretoria de Gestão de Pessoas, no período de 22 a 25 de junho de 2026, para participação no evento 26º Congresso de Stress da ISMA-BR em Porto Alegre/RS, com ônus total para o Distrito Federal, incluindo a concessão de diárias e de passagens aéreas. Processo SEI nº 00020- 00031591/2026-30.

DIANA DE ALMEIDA RAMOS

### SECRETARIA GERAL SUBSECRETARIA GERAL DE ADMINISTRAÇÃO

ORDEM DE SERVIÇO Nº 137, DE 18 DE JUNHO DE 2026 O SUBSECRETÁRIO-GERAL DE ADMINISTRAÇÃO, DA PROCURADORIA- GERAL DO DISTRITO FEDERAL, no uso das atribuições que lhe foram delegadas pelo artigo 2º, VIII, da Portaria nº 371, de 15 de junho de 2026; os artigos 1º, 2º, inciso II, 18, caput e §§ 1º ao 3º, art. 19, inciso III, e art. 20, todos do Decreto nº 29.290, de 22 de julho de 2008, resolve: AUTORIZAR O AFASTAMENTO, mediante dispensa de ponto, de MARCIA MILENA BARROS ROCHA, matrícula nº 1728746-4, servidora requisitada, ocupante do cargo de Farmacêutico-Bioquímico – Farmácia, pertencente ao quadro de pessoal da Secretaria de Estado de Saúde do Distrito Federal (SES/DF), atualmente em exercício na Gerência de Apoio Técnico na Área da Saúde, da Diretoria de Apoio Técnico e Científico, da Subsecretaria-Geral de Apoio Técnico, Operacional e Científico, da Secretaria-Geral da Procuradoria-Geral do Distrito Federal, no período de 17 a 19 de junho de 2026, com ônus limitado para o Distrito Federal, com o escopo de viabilizar a participação no evento "I Congresso da Assistência Farmacêutica do Distrito Federal", promovido pela Sociedade Brasileira de Políticas Farmacêuticas (SBPFAR) e pela Secretaria de Estado de Saúde do Distrito Federal, em Brasília/DF, conforme instrução dos autos do Processo Administrativo nº 00020-00032877/2026-32.

GEORGE ANDERSON HOLANDA COUTINHO

<!-- pagina 50 -->

# SEÇÃO III

## PODER LEGISLATIVO

### CÂMARA LEGISLATIVA COMISSÃO PERMANENTE DE CONTRATAÇÃO

AVISO DE ABERTURA DE LICITAÇÃO

PREGÃO ELETRÔNICO Nº 90021/2026 Processo nº 00001-00015597/2026-14. Objeto: Contratação de pessoa jurídica para prestação de serviços de agenciamento de viagens, compreendendo cotação de preços, reserva, marcação/remarcação, emissão e fornecimento de bilhetes de passagens aéreas nacionais e internacionais, incluindo o pagamento da taxa de embarque, e a aquisição seguro-viagem internacional de acordo com as quantidades e especificações técnicas descritas no Termo de Referência – Anexo I do Edital. Valor estimado: R$ 894.663,00. Data/hora da Sessão Pública: 06/07/2026, às 14:00h. Local: Internet, no endereço www.gov.br/compras. Critério de Julgamento: maior desconto, incidente sobre o valor do volume de vendas de passagens aéreas, nacionais e internacionais, inclusive sobre as tarifas promocionais e reduzidas disponíveis no momento da compra, bem como taxas de bagagens eventualmente cobradas pela companhia, com a exclusão apenas das taxas de embarque, remarcação, cancelamento, seguro-viagem internacional e taxa de agenciamento de viagens, com desconto mínimo de 16% (dezesseis por cento). O edital encontra-se nos endereços: www.gov.br/compras (UASG 974004), pncp.gov.br e www.cl.df.gov.br/pregoes. Mais informações: (61) 3348-8650 ou cpc@cl.df.gov.br.

DIRCEU FALCÃO DA MOTA NETO

Pregoeiro

## CASA CIVIL

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

EXTRATO TERMO DE CREDENCIAMENTO Nº 36/2026 - SEPAN-DF / CASA CIVIL Espécie: TERMO DE CREDENCIAMENTO Nº 36/2026 – SEPAN/DF. Partes: O DISTRITO FEDERAL, por intermédio da CASA CIVIL DO DISTRITO FEDERAL – CACI, inscrita no CNPJ nº 09.639.459/0001-04, com sede no Centro Cívico – Praça do Buriti – Edifício Anexo do Palácio do Buriti – 3º andar – Brasília/DF – CEP 70.075-900, representada por ELISANGELA CANDIDA DOS SANTOS MARTINS, Subsecretária de Administração Geral substituta, com delegação de competência prevista no art. 3º, II, da Portaria nº 31, de 17 de dezembro de 2020; e da SECRETARIA EXTRAORDINÁRIA DE PROTEÇÃO ANIMAL DO DISTRITO FEDERAL – SEPAN/DF, com sede na SEPN 511 - Bloco B - Edifício Bittar III - 2° andar - Brasília/DF - CEP: 70.750-542, inscrita no CNPJ nº 58.440.929/0001-11, representada por LEONARDO ARAÚJO EMERICK, na qualidade de Secretário Extraordinário de Proteção Animal do Distrito Federal - Substituto, conforme Decreto de 29 de setembro de 2025, doravante denominadas, em conjunto, CREDENCIANTES; e, de outro lado, a empresa AGROPECUARIA AMORIM PRODUTOS AGROPECUARIOS E VETERINARIOS LTDA, inscrita no CNPJ nº 61.808.508/0001-05, doravante denominada CREDENCIADA. Objeto: formalizar a habilitação de pessoas jurídicas para a prestação de serviços e fornecimento de insumos, de forma não exclusiva, para a operacionalização do Programa de Apoio à Proteção dos Animais, instituído pela Lei nº 7.765, de 24 de novembro de 2025, conforme Edital de credenciamento - 001/2025 - SEPAN/DF (192674477), na seguinte modalidade: Cartão Ração - Credenciamento de estabelecimentos comerciais para o fornecimento de ração e insumos de manutenção de cães e gatos, a serem adquiridos pelos beneficiários da modalidade Cartão Ração do Programa. Vigência: O Termo de Credenciamento terá vigência de 24 (vinte e quatro) meses, contados da data de sua assinatura. Processo nº 04045-000000054/2026-11. Data de Assinatura: 10/06/2026. Pela CACI/DF: JOSÉ EDUARDO COUTO RIBEIRO. Pela SEPAN/DF: LEONARDO ARAÚJO EMERICK. Pela Empresa: TAYLON ARIEL NUNES AMORIM.

## SECRETARIA DE ESTADO DE GOVERNO

### SECRETARIA EXECUTIVA DAS CIDADES

EDITAL DE CHAMAMENTO PÚBLICO Nº 27, DE 19 DE JUNHO DE 2026 A Secretaria de Estado de Governo do Distrito Federal, através da Secretaria Executiva das Cidades, torna público o Edital de Chamamento Público para vendedores Ambulantes na modalidade de barraca e caixeiro, para emissão de Licenças Eventuais em área pública, no SRPN Qd.901 trecho 01 - Asa Norte/DF e no gramado ao lado do estacionamento do Planetário de Brasília/DF para o evento: "Djavanear 50 anos - Só sucessos", dia 27/06/2026 de 16:00h às 01:00h da madrugada, na ARENA ESTÁDIO MANÉ GARRINCHA, SRPN - Asa Norte - Brasília/DF. As Licenças Eventuais serão na modalidade de barraca, sendo 20 vagas na SRPN Qd.901 - Asa Norte/DF e 10 vagas no gramado ao lado do estacionamento do Planetário de Brasília - Brasília/DF.

Na modalidade de caixeiro/circulante serão 30 vagas (no SRPN QD 901 ou gramado do Planetário) - Asa Norte/DF. Caso vendedor ambulante licenciado não possa estar trabalhando no dia do evento, deverá passar uma autorização pessoal reconhecida firma para o ambulante que for ocupar a área pública. Os vendedores ambulantes licenciados para o 1º período (13/06/2026 a 05/07/2026) do NA PRAIA FESTIVAL 2026, não poderão concorrer as vagas deste edital. As barracas licenciadas só poderão utilizar no máximo 06 mesas plásticas com 04 cadeiras na área em frente a barraca. 1.DAS INSCRIÇÕES 1.1. DIA: 23/06/2026 (terça-feira). 1.2. HORÁRIO: 09:00h às 17:00h. 1.3. LOCAL: Auditório do Edifício Sede do DETRAN-DF, SAM lote A Bloco B - Asa Norte/DF. 1.4. O edital poderá ser obtido no sítio eletrônico da Secretaria de Estado de Governo do Distrito Federal, https://segov.df.gov.br/ ou pessoalmente no endereço: Anexo do Palácio do Buriti, Praça do Buriti, 9º andar, sala 917, Brasília - DF, CEP: 70.075-900, a partir da data da publicação deste Edital, ou pelo telefone (061) 3313-5933 e WhatsApp (061) 99149-1325, de segunda à sexta-feira, das 9:00h às 17:00h. 2. DA MONTAGEM 2.1. A montagem será a partir de 13:00h do dia 27/06/2026; 2.2. A área de montagem para barraca de alimentação é de 36m2 (6m x 6m); 2.3. A área de montagem para barraca de artigos é de 20m2 ( 4m x 5m); 2.3. A área para caixeiro/circulante é de 4m2 para carrinho ou mesa retrátil e 6m2 para carrinho com churrasco. 3. DO OBJETO. 3.1. O presente chamamento tem por objeto a concessão de licenças eventuais para o trabalho de vendedor Ambulante para os eventos "Djavanear 50 anos - Só sucessos". 3.2. A concessão de vagas para Ambulantes na modalidade barraca e caixeiro será conforme tabela abaixo:

MODALIDADE LOCAL QUANTIDADE

BARRACA área descampada, após a ciclovia, na SRPN Qd. 901 trecho 01 - Asa Norte 20

BARRACA gramado ao lado do estacionamento público do Planetário de Brasília 10

CAIXEIRO na SRPN Qd. 901 ou gramado do Planetário. 30

4. DOCUMENTAÇÃO PARA PARTICIPAÇÃO DO CHAMAMENTO. No momento da inscrição que ocorrerá conforme item 1 deste edital, os participantes deverão apresentar; 4.1. Original e cópia de documento pessoal com foto; 4.2. Comprovante de endereço em seu nome ou uma declaração de residência; 4.3. Em caso de dúvida do funcionário da Secretaria, a pessoa deverá apresentar o Certificado de vendedor ambulante. 5. DO VALOR DO PREÇO PÚBLICO. 5.1. É obrigatório o pagamento do preço público de acordo com a publicação da Ordem de Serviço nº 15, de 09/02/2026 e Ordem de Serviço nº 18, de 20/02/2026, artigo 8º, da Administração Regional do Plano Piloto; 5.2. O Preço Público no valor de R$ 1,45 por dia, por m²; 5.3. Como o evento será em 01 dia (R$1,45 * 20m2 * 1 ou R$1,45 * 36m2 * 1) o valor a ser cobrado pela barraca (artigos) de 20m2 será de R$ 29,00 (vinte nove reais), pela barraca de alimentação de 36m2 será de R$ 52,20 (cinquenta dois reais e vinte centavos). O valor cobrado para caixeiros/circulantes de até 6m2 será de R$ 10,00 (dez reais). 5.4. O DAR eletrônico, será emitido pelo SISLANCA da Secretaria de Estado de Economia do Distrito Federal. 6. DAS VAGAS RESERVADAS PARA PESSOAS COM DEFICIÊNCIA. 6.1. Será reservado 01 vagas para barraca (SRPN QD.901) e 01 vagas para caixeiro, correspondendo a 5% (cinco por cento), como cota mínima para atender pessoas com deficiências (PCD), mediante apresentação da carteirinha (comprovação), conforme Decreto 9.508/2018. 7. DA NECESSIDADE DE REALIZAÇÃO DE SORTEIO. 7.1. Havendo inscrições validadas em número maior que a quantidade de vagas ofertadas, a Gerência de Ambulantes Food Truck e Engenhos Publicitários subordinada a Subsecretaria de Mobiliário Urbano e Apoio as Cidades, realizará sorteio, imediatamente após o término do horário previsto para as inscrições do evento. 7.2. O sorteio será realizado no aplicativo sorteio fácil; 7.3. O sorteio será numerado de acordo com o número de inscritos; 7.4. O sorteio poderá contar com os Ambulantes que estiverem presentes ao final do horário limite de inscrição; 7.5. Não havendo Ambulantes presentes no local será realizada confecção de ata assinada por todos os servidores presente no ato da inscrição, bem como anexo de fotos dos números sorteados em tela, para comprovar transparência. 8. DO RESULTADO DO CHAMAMENTO E ENTREGA DAS LICENÇAS. 8.1. A divulgação do resultado do chamamento com o nome dos vendedores ambulantes contemplados será no dia 24/06/2026 a tarde, no site da Secretaria de Estado de Governo - GOV (https://segov.df.gov.br/).

<!-- pagina 51 -->

8.2. Os contemplados pegarão as licenças no dia 26/06/2026 (sexta-feira), no Anexo do Buriti, de 09:00h às 16:00h, onde serão repassadas informações e orientações sobre o trabalho Ambulante no dia do evento; 8.3. Não será entregue autorização fora do dia e horário estipulados no item 8.2 deste edital; 8.4. Não será entregue autorização a terceiros, a não ser por procuração, uma vez que é pessoal, intransferível e concedida a título provisório, conforme artigo 15 da Lei 6.190/2018; 9. DAS PROIBIÇÕES. 9.1. Venda de bebidas alcoólicas à criança e adolescente, de acordo com a Lei Federal nº 8.069, de 13/07/1990, artigo 81, inciso II, do Estatuto da Criança e Adolescente(ECA); 9.2. Venda de bebida alcoólica a indígena, de acordo com a Lei nº 6.001/1973, artigo 58, inciso III ( Estatuto do Índio); 9.3. Venda de cigarros, cigarrilhas, charutos, cachimbos ou qualquer outro produto fúmigeno, derivado ou não do tabaco, de acordo com a Lei nº 9.294/1996, artigo 3º, inciso IX; 9.4. Venda de bebidas destiladas para qualquer consumidor, de acordo com a Lei nº 9.294/1973, artigo 3º, inciso IX; 9.5. Venda de facas ou material cortante que propicie risco a vida das pessoas; 9.6. Vender, alugar ou ceder a qualquer título o espaço público objeto desta autorização; 9.7. Montagem de estrutura com mesas e cadeiras para utilização dos clientes; 9.8. Deixar o veiculo motorizado junto a barraca, utilizando Área Pública fora do especificado no licenciamento; 10. DOS DEVERES. 10.1. As bebidas (cerveja, sucos, refrigerantes e energéticos) deverão ser comercializadas em copo plástico, latas de alumínio e/ou garrafas de plástico; 10.2. Os alimentos comercializados deverão ser servidos em pratos plásticos e com talheres descartáveis. Em relação ao churrasquinho, estes somente poderão ser entregues aos consumidores em pratos de plástico e fora dos espetos; 10.3. Caberá aos Ambulantes a responsabilidade pelo recolhimento e ensacamento de todo o lixo gerado durante a duração da atividade; 10.4. No botijão de gás deverá ser utilizado mangueiras, com regulador de pressão e revestimento de aço; 10.5. Está PROIBIDA a comercialização de mercadorias que utilize "varais", especialmente em utilizando postes ou árvores. 10.6. Manter, no entorno da área ocupada por Ambulantes, faixa livre de circulação em calçadas e pontos de acessibilidade, permitindo acesso de pessoas com deficiência; 10.7. O descumprimento dos itens acima acarretará notificação pelos órgãos de controle, multas, sanções conforme a Lei nº 6.190, de 20 de julho de 2018. 11. DAS PENALIDADES. 11.1. Os Ambulantes que operam sem licença ou em desacordo com as regulamentações podem ser multados pela Secretaria Secretaria de Estado de Proteção da Ordem Urbanística do Distrito Federal - DF LEGAL. O valor da multa pode variar; 11.2. Apreensão de mercadorias; 11.3. Remoção do local de venda, em caso de ocupação ilegal de um espaço público; 11.4. O Ambulante que descumprir as regras deste Edital de Chamamento Público ficará impedido de participar dos próximos 03 (três) chamamentos. Sendo reincidente perderá o direito de participar de eventos. 12. DA LOCALIZAÇÃO. 12.1. Os Ambulantes modalidade barraca deverão ocupar os espaços determinados na autorização conforme croqui abaixo. 12.2. A montagem das barracas será acompanhada pelos servidores designados da Secretaria Executiva das Cidades e do DF LEGAL, no local determinado no croqui. 13. DISPOSIÇÕES FINAIS 13.1. Não haverá reserva de vagas no chamamento público para as associações representativas da categoria dos Ambulantes.

SUELY MARIA DE SOUZA

Secretária Executiva

ADMINISTRAÇÃO REGIONAL DE ÁGUA QUENTE

EXTRATO DE TERMO ADITIVO REFERENTE AO CONTRATO

DE LOCAÇÃO DE IMÓVEL Nº 03/2024 PROCESSO DO ALUGUEL: 04041-00000151/2024-54. PROCESSO DO TERMO ADITIVO: 04041-00000151/2024-54. Das Partes: DISTRITO FEDERAL, por intermédio da ADMINISTRAÇÃO REGIONAL DE ÁGUA QUENTE – RA XXXV, e GBR INVESTIMENTOS HOLDING LTDA., inscrita no CNPJ nº 30.673.729/0001-90. Objeto: redução temporária, excepcional e consensual do valor mensal da locação do imóvel objeto do Contrato de Locação nº 03/2024, em atendimento às medidas de racionalização, controle e eficiência das despesas públicas instituídas pelo Decreto Distrital nº 48.509/2026. Valor: o valor mensal da locação passa de R$ 17.000,00 (dezessete mil reais) para R$ 15.000,00 (quinze mil reais), representando redução aproximada de 11,76% (onze vírgula setenta e seis por cento). Vigência da Redução: de 1º de junho de 2026 a 31 de dezembro de 2026, ou até a eventual revogação, suspensão ou cessação dos efeitos do Decreto Distrital nº 48.509, de 24 de abril de 2026, prevalecendo o evento que ocorrer primeiro. Fundamentação Legal: Lei Federal nº 14.133/2021, especialmente seus arts. 5º e 11; Decreto Distrital nº 48.509/2026; e Processo SEI nº 04041-00000151/2024-54. Economia Estimada: R$ 14.000,00 (quatorze mil reais) durante o período de vigência da redução. LÚCIA GOMES DA SILVA.

## SECRETARIA DE ESTADO DE ECONOMIA

### SECRETARIA EXECUTIVA DE CONTRATOS SUBSECRETARIA DE COMPRAS GOVERNAMENTAIS

COORDENAÇÃO DE GESTÃO DE SUPRIMENTOS DIRETORIA DE SISTEMA DE REGISTRO DE PREÇOS

EXTRATO DO 1º TERMO ADITIVO A ATA DE REGISTRO DE PREÇOS N.° 0133/2025 (*) Processo SEI-GDF n.° 00060-00104864/2024-61, Pregão Eletrônico n.° 90035/2025. Assinatura do 1º Termo Aditivo: 18/06/2026. Objeto: prorrogação da vigência da Ata de Registro de Preços n.° 0133/2025, por mais 12 (doze) meses, contados a partir de 24/06/2026, passando a vigorar até 24/06/2027, bem como a renovação dos quantitativos registrados. Empresa vencedora: SIMPRESS COMÉRCIO, LOCAÇÃO E SERVIÇOS LTDA, CNPJ: 07.432.517/0001-07. O Termo Aditivo, na íntegra, será disponibilizada no Sistema de Gestão de Atas de Registro de Preços (SGARP).

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços ____________________ (*) Republicado por ter sido encaminhado com incorreção no original, publicado no DODF nº 111, de 19 de junho de 2026, pág. 51.

AVISO DE ABERTURA DE INTENÇÃO DE REGISTRO DE PREÇOS

DO DISTRITO FEDERAL (IRPDF) N.° 0042/2026 A Diretoria de Sistema de Registro de Preços, da Coordenação de Gestão de Suprimentos, da Subsecretaria de Compras Governamentais (SCG), em face do disposto no art. 192, inciso I, do Decreto n.° 44.330, de 16 de março de 2023, COMUNICA aos órgãos da estrutura administrativa do Distrito Federal acerca da abertura de Intenção de Registro de

<!-- pagina 52 -->

Preços do Distrito Federal (IRPDF) n.° 0042/2026, visando ao Registro de Preços relativo à eventual aquisição de açúcar e materiais de copa e cozinha (copo descartável, filtro de café, pano multiuso, dentre outros similares), grupo 30.07 e 30.21. Os órgãos interessados deverão manifestar-se, IMPRETERIVELMENTE, em até 10 (DEZ) DIAS ÚTEIS a contar da data de publicação deste comunicado, mediante preenchimento do Protocolo de Resposta da Intenção de Registro de Preços/DF disponível no sítio do Sistema de Gestão de Atas de Registro de Preços (SGARP), conforme instruções dispostas no Ofício Circular Nº 27/2026 - SEEC/SCG/COSUP/DIREP/GEPSM.

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços

AVISO DE ABERTURA DE INTENÇÃO DE REGISTRO DE PREÇOS DO DISTRITO FEDERAL (IRPDF) N.° 0043/2026 A Diretoria de Sistema de Registro de Preços, da Coordenação de Gestão de Suprimentos, da Subsecretaria de Compras Governamentais (SCG), em face do disposto no art. 192, inciso I, do Decreto n.° 44.330, de 16 de março de 2023, COMUNICA aos órgãos da estrutura administrativa do Distrito Federal acerca da abertura de Intenção de Registro de Preços do Distrito Federal (IRPDF) n.° 0043/2026, visando ao Registro de Preços relativo à eventual contratação de empresa especializada para a prestação de serviços de controle sanitário integrado de vetores e pragas urbanas, compreendendo desinsetização, desratização, descupinização e manejo de pombos, grupo 39.78. Os órgãos interessados deverão manifestar-se, IMPRETERIVELMENTE, em até 15 (QUINZE) DIAS ÚTEIS a contar da data de publicação deste comunicado, mediante preenchimento do Protocolo de Resposta da Intenção de Registro de Preços/DF disponível no sítio do Sistema de Gestão de Atas de Registro de Preços (SGARP), conforme instruções dispostas no Ofício Circular Nº 28/2026 - SEEC/SCG/COSUP/DIREP/GEPSM.

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços

EXTRATO DA ATA DE REGISTRO DE PREÇOS N.° 0080/2026 Processo SEI-GDF n.° 00060-00507919/2025-72 - Pregão Eletrônico n.° 90042/2026 com homologação em 11 de junho de 2026. Objeto: Registro de preços para a aquisição de Van Adaptada para Consultório na Rua, zero km, a fim de atender às demandas da Secretaria de Estado de Saúde do Distrito Federal (SES/DF). Assinatura da Ata: 18/06/2026. Vigência: 12 meses a contar da publicação no Portal Nacional de Compras Públicas (PNCP). Empresa vencedora: CKS VEÍCULOS ESPECIAIS LTDA, CNPJ: 30.330.883/0001-69, item: 1. A Ata, na íntegra, será disponibilizada no Sistema de Gestão de Atas de Registro de Preços (SGARP).

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços

CONVOCAÇÃO PARA ASSINATURA DE ARP PROVENIENTE

DO PREGÃO ELETRÔNICO N.° 90001/2026 A Diretoria de Sistema de Registro de Preços, da Coordenação de Gestão de Suprimentos, da Subsecretaria de Compras Governamentais, tendo em vista a homologação do Pregão Eletrônico n.° 90001/2026, que fita o Registro de preços para a aquisição de equipamentos, racks e componentes de tecnologia da informação, visando atender às necessidades da Secretaria de Estado de Saúde do Distrito Federal (SES-DF), CONVOCA as empresas classificadas: AZ METAL LTDA, inscrita no n.° 13.578.459/0001-19; BRASLYNC COMÉRCIO ELETRÔNICO LTDA, inscrita no n.° CNPJ 35.858.504/0001-21; ELETROQUIP COMÉRCIO E LICITAÇÕES LTDA, inscrita no n.° CNPJ 05.854.663/0001-97; FORMATO DIGITAL COMÉRCIO E COMUNICAÇÃO MULTIMÍDIA LTDA, inscrita no n.° CNPJ 31.070.939/0001-56; KSC TECNOLOGIA LTDA, inscrita no n.° CNPJ 45.304.454/0001-94; L&R SOLUÇÕES LTDA, inscrita no n.° CNPJ 52.623.583/0001-00 e; MICROTÉCNICA INFORMÁTICA LTDA, inscrita no n.° CNPJ 01.590.728/0009-30 a assinarem eletronicamente a Ata de Registro de Preços, em até 05 (cinco) dias, a partir da publicação desta convocação, por meio do Sistema Eletrônico de Informações – SEI/DF. Em caso de dúvidas, entrar em contato pelo e-mail: "gefoa.scg@economia.df.gov.br".

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços

CONVOCAÇÃO PARA ASSINATURA DE ARP PROVENIENTE

DO PREGÃO ELETRÔNICO N.° 90036/2025 A Diretoria de Sistema de Registro de Preços, da Coordenação de Gestão de Suprimentos, da Subsecretaria de Compras Governamentais, tendo em vista a homologação do Pregão Eletrônico n.° 90036/2025, que fita o Registro de preços para aquisição de material de limpeza e produção de higienização (álcool líquido, balde, cesto para lixo, rodo de limpeza, entre outros), visando atender às necessidades dos diversos órgãos e entidades que compõem o Complexo Administrativo do Distrito Federal, CONVOCA as empresas classificadas: PALLET RIO INDUSTRIA E COMERCIO LTDA, inscrita no n.° CNPJ 37.104.931/0001-40 e; ING - DISTRIBUIÇÃO LTDA, inscrita no n.° CNPJ 60.284.814/0001-27 a assinarem eletronicamente a Ata de Registro de Preços, em até 05

(cinco) dias úteis, a partir da publicação desta convocação, por meio do Sistema Eletrônico de Informações – SEI/DF. Em caso de dúvidas, entrar em contato pelo e-mail: "gefoa.scg@economia.df.gov.br".

Brasília/DF, 19 de junho de 2026 CRISTIANA DE CASTRO MESQUITA Diretora de Sistema de Registro de Preços ___________________ (*) Republicado por ter sido encaminhado com incorreção no original, publicado no DODF nº 111, de 19 de junho de 2026, pág. 51.

COORDENAÇÃO DE LICITAÇÕES

AVISO DE RESULTADO DE JULGAMENTO PREGÃO ELETRÔNICO N° 90052/2026 - UASG 974002 A Pregoeira torna público o resultado de julgamento do Pregão acima citado, onde sagrouse vencedora a empresa RICARDO ALVES RAMOS DE BRITO EXTINTORES, no valor total de R$ 5.464.326,83. Processo nº 04044-00013439/2026-76. Demais informações no site: www.gov.br/compras.

Brasília/DF, 19 de junho de 2026

CLAUDETE PEREIRA LIMA

AVISO DE RESULTADO DE RECURSO E JULGAMENTO

PREGÃO ELETRÔNICO N° 90044/2026 - UASG 974002 A Pregoeira informa que, pelas razões inseridas no sistema e acolhidas pela Senhora Subsecretária de Compras Governamentais desta Pasta, foi julgado improcedente os recursos interpostos pelas empresas: 3I Comercio e Serviços de Manutenção em Equipamentos Eletro-mecanicos Ltda; J.F. Alves de Morais Ltda; Medic Vitall Comercio e Serviços hospitalares Ltda, contra o resultado de julgamento do grupo 1, e J. F. Alves de Morais Ltda, contra o resultado de julgamento do grupo 2, do Pregão acima citado. Comunica também o resultado de julgamento onde sagraram-se vencedoras as empresas MCR Comercio Representações e Serviços Ltda, no valor total de R$ 755.220,03 para o grupo 1, e Medic Vitall Comércio e Serviços Hospitalares Ltda, no valor total de R$ 241.168,08 para o grupo 2. Demais informações no site: www.gov.br/compras.

Brasília/DF, 19 de junho de 2026 ESTER WANDERLEY DE SOUSA

### SECRETARIA EXECUTIVA DE ADMINISTRAÇÃO E LOGÍSTICA SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

UNIDADE DE GESTÃO PATRIMONIAL DIRETORIA DE PATRIMÔNIO MOBILIÁRIO GERÊNCIA DE CONTROLE E ACOMPANHAMENTO DE LEILÕES

AVISO DE DESCREDENCIAMENTO DE LEILOEIROS OFICIAIS EDITAL DE LICITAÇÃO CREDENCIAMENTO Nº 004/2025 - UASG 974002 A Gerência de Controle e Acompanhamento de Leilões (GECAL), vinculada à Subsecretaria de Administração Geral da Secretaria de Estado de Economia do Distrito Federal, torna público o descredenciamento do leiloeiro oficial Sr. Tiago Tessler Blecher, matriculado na Junta Comercial do Distrito Federal sob o nº 104, anteriormente credenciado no âmbito do Edital de Credenciamento nº 004/2025 – UASG 974002. O descredenciamento decorre da constatação de suspensão de sua situação funcional perante a Junta Comercial do Distrito Federal, circunstância que compromete o atendimento dos requisitos de habilitação exigidos para o credenciamento, nos termos do artigo 7º – Da Documentação Mínima Exigida para Credenciamento e respectivos subitens do referido edital. Considerando a necessidade de manutenção das condições de habilitação durante todo o período de vigência do credenciamento, fica o referido profissional excluído da relação de leiloeiros oficiais credenciados, Nº 54, produzindo efeitos a partir da data desta publicação. Dessa forma, a lista de credenciados passa a vigorar sem a inclusão do profissional acima mencionado, permanecendo inalterada a classificação dos demais credenciados.

LISTA DE CREDENCIADOS

Colocação Leiloeiro E-mail Documentação UF do

UF da Inscrição

Domicílio

da Junta

1 Mauricio José de

qui 22/05/2025

Em

conformidade São Paulo - SP São Paulo - SP

Souza Costa

00:00

2 Daniel Elias

qui 22/05/2025

Em

Distrito

Distrito Federal

Garcia

09:00

conformidade

Federal - DF

- DF

3 Sandro de

qui 22/05/2025

Em

Distrito

Distrito Federal

Oliveira

16:32

conformidade

Federal - DF

- DF

<!-- pagina 53 -->

sex 23/05/2025

Em conformidade

Rio de Janeiro -

Rio de Janeiro - RJ

4 Juliana Vettorazzo Rodrigues Barros

17:28

RJ

5 Joao Emilio de Oliveira

sex 23/05/2025

Em conformidade

Rio de Janeiro -

Rio de Janeiro - RJ

Filho

17:36

RJ

6 Fernando Gonçalves

sex 23/05/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Costa

18:03

DF

7 Gustavo Moretto Guimarães de Oliveira

seg 26/05/2025

Em conformidade São Paulo - SP Distrito Federal - DF

10:14

8 Arthur Ferreira Nunes seg 26/05/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

19:34

DF

9 Cesar Luis Moresco ter 27/05/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

16:25

DF

10 Denise Araujo dos

qua 28/05/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Santos

09:57

DF

11 Georgia de Souza

qua 28/05/2025

Em conformidade Fortaleza - CE Distrito Federal - DF

Castelo

11:31

qua 28/05/2025

Em conformidade São Paulo - SP Distrito Federal - DF

12 Marcus Vinicius

16:46

Yoshimi Uebara

13 Catiele Borges Leffa qui 29/05/2025

Em conformidade

Rio Grande do

Distrito Federal - DF

11:42

Sul - RS

14 Jorge Vinícius de Moura

sex 30/05/2025

Em conformidade

Rio Grande do

Distrito Federal - DF

Correa

16:31

Sul - RS

15 Rafael Ceretta

sex 30/05/2025

Em conformidade

Rio Grande do

Distrito Federal - DF

Alegranzzi

17:06

Sul - RS

16 Giovano Àvila Alves ter 03/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

14:50

DF

17 Paulo Alexandre Heisler qua 04/06/2025

Em conformidade

Rio Grande do

Distrito Federal - DF

12:49

Sul - RS

18 Anderson Lopes de Paula qui 05/06/2025

Em conformidade São Paulo - SP Distrito Federal - DF

08:30

19 José Luiz Pereira Vizeu qui 05/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

10:54

DF

20 Juliana Sevidanes de

qui 05/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Araújo

17:31

DF

21 Marta Simone Shiokawa sex 06/06/2025

Em conformidade São Paulo - SP São Paulo -

08:00

SP

22 Victor Renno Polatto

sex 06/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Vizeu

13:56

DF

23 Moacira Tegoni Goedert sáb 07/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

17:03

DF

24 Elenice Lira Sales de

seg 09/06/2025

Em conformidade Goiânia - GO Distrito Federal - DF

Sousa

15:48

25 Rossana Paiva Borges de

seg 09/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Oliveira

15:49

DF

26 Ana Lucia Borba

seg 09/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Assunção

22:08

DF

27 Luciano Gonsalves

ter 10/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Borba Assunção

00:31

DF

28 Helcio Kronberg ter 10/06/2025

Em conformidade Curitiba - PR Distrito Federal - DF

15:23

29 Vicente Domiseth de

ter 10/06/2025

Em conformidade São Paulo - SP São Paulo -

Oliveira

17:27

SP

30 Joacir Monzon Pouey qua 11/06/2025

Em conformidade Coritiba/PR Distrito Federal - DF

18:33

31 Mateus Gonçalves Borba

qui 12/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Assunção

07:44

DF

32 Lucas Rafael Antunes

qui 12/06/2025

Em conformidade

Belo Horizonte/MG

Distrito Federal - DF

Moreira

10:08

33 Jonas Gabriel Antunes

qui 12/06/2025

Em conformidade

Pará de Minas/MG

Distrito Federal - DF

Moreira

10:25

34 Fernando Caetano

qui 12/06/2025

Em conformidade Contagem/MG Distrito Federal - DF

Moreira Filho

10:46

35 Moacir de Santi qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

15:56

SP

36 Otavio Lauro Sodré

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Santoro

16:01

SP

37 Luiz Fernando de Abreu

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Sodré Santoro

16:05

SP

38 Jose Eduardo de Abreu

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Sodré Santoro

16:12

SP

39 Flavio Cunha Sodré

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Santoro

16:14

SP

40 Carolina Lauro Sodré

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Santoro

16:16

SP

41 Mariana Lauro Sodré

qui 12/06/2025

Em conformidade São Paulo - SP São Paulo -

Santoro Batochio

16:24

SP

42 Bruno Duarte Araújo

qui 12/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

dos Santos

16:28

DF

43 Orlando Araujo dos

qui 12/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Santos

16:37

DF

44 Tatiana Paula Zani de

qui 12/06/2025

Em conformidade Santo André/SP Distrito Federal - DF

Souza

17:42

45 Caroline de Sousa Ribas qui 12/06/2025

Em conformidade Santo André/SP Distrito Federal - DF

17:53

46 Ozias Pereira Tavares qui 12/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

18:28

DF

47 Sebastião Felix da Costa

sex 13/06/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Neto

10:00

DF

48 Martha Helena Tobias

ter 15/07/2025

Em conformidade

Distrito Federal -

Distrito Federal -DF

da Silva

14:15

DF

49 Adriano de Souza

qui 14/08/2025

Em conformidade

Distrito Federal -

Distrito Federal - DF

Cardoso

10:01

DF

50 Gian Roberto Cagni

sex 19/09/2025

Em Conformidade

Distrito Federal-

Distrito Federal - DF

Braggio

18:06

DF

51 Marilaine Borges de

seg 29/09/2025

Em Conformidade

Ribeirão Preto -

SP São Paulo-SP

Paula

18:04

52 Jussiara Santos Ermano

sex 03/10/2025

Em Conformidade

Distrito Federal -

Distrito Federal - DF

Sukiennik

10:20

DF

53 Fernando Cézar Tobias

sex 24/10/2025

Em Conformidade

Distrito Federal -

Distrito Federal - DF

da Silva

08:00

DF

54 - x - - X - - X - - X - - X -

55 Natalia Narita Nunes de

sex 13/03/2026

Em Conformidade

Distrito Federal -

Distrito Federal - DF

Freitas

11:23

DF

56 Rodrigo Schmitz ter 05/05/2026

Em Conformidade

Distrito Federal -

Distrito Federal - DF

12:23

DF

57 Eduardo Schmitz quart 06/05/2026

Em Conformidade

Santa Catarina -

Distrito Federal - DF

10:53

SC

Os leiloeiros credenciados estão aptos a atuar nos leilões públicos para alienação de bens móveis e/ou imóveis do Distrito Federal, conforme estabelecido no Edital de Licitação de Credenciamento nº 004/2025, Mais informações podem ser obtidas pelo e-mail: gecal.dipat@economia.df.gov.br.

RENÉ MENDES LOPES

Gerente

<!-- pagina 54 -->

AVISO DE SESSÃO PÚBLICA PARA SORTEIO DE LEILOEIROS CREDENCIADOS

NO EDITAL DE LICITAÇÃO CREDENCIAMENTO Nº 004/2025 - UASG 974002 A Gerência de Controle e Acompanhamento de Leilões (GECAL), vinculada à Subsecretaria de Administração Geral da Secretaria de Estado de Economia do Distrito Federal, nos termos do item 6.8 do Edital de Credenciamento nº 004/2025, CONVOCA todos os leiloeiros credenciados e habilitados para participarem da sessão pública de sorteio, destinada à definição do leiloeiro oficial responsável pela condução da hasta pública referente ao Seguinte Órgãos: 1) Companhia Urbanizadora da Nova Capital do Brasil - Processo SEI nº 00112- 00001689/2026-05 Data da sessão: 23/06/2026 Horário: 08:00hs Local: Escola de Governo do Distrito Federal situada no SGO ÁREA ESPECIAL N 1, QUADRA 01, Brasília DF, Sala 5. Orientações: - É importante que os participantes tragam suas próprias garrafas (água) ou copos para uso pessoal durante o evento; não é permitido o consumo de lanches ou de refeições nas salas de aula, reuniões, auditório e corredores; não é permitida a retirada e/ou movimentação de mobiliário dos espaços, sem prévia autorização; não é permitida a permanência de cursistas nos corredores durante o horário de cursos; não é permitido barulho ou música nos corredores da EGOV em horário de cursos; e não é permitida a entrada e permanência de jornalistas, bem como captação de imagens nas dependências desta escola, sem autorização prévia. A sessão será realizada de forma não eletrônica, e ocorrerá independentemente da presença dos leiloeiros. Os leiloeiros credenciados e habilitados até a presente data são os seguintes:

Leiloeiro Situação

Mauricio José de Souza Costa Credenciado

Daniel Elias Garcia Credenciado

Sandro de Oliveira Credenciado

Juliana Vettorazzo Rodrigues Barros Credenciado

Joao Emilio de Oliveira Filho Credenciado

Fernando Gonçalves Costa Credenciado

Gustavo Moretto Guimarães de Oliveira Credenciado

Arthur Ferreira Nunes Credenciado

Cesar Luis Moresco Credenciado

Denise Araujo dos Santos Credenciado

Georgia de Souza Castelo Credenciado

Marcus Vinicius Yoshimi Uebara Credenciado

Catiele Borges Leffa Credenciado

Jorge Vinícius de Moura Correa Credenciado

Rafael Ceretta Alegranzzi Credenciado

Giovano Àvila Alves Credenciado

Paulo Alexandre Heisler Credenciado

Anderson Lopes de Paula Credenciado

José Luiz Pereira Vizeu Credenciado

Juliana Sevidanes de Araújo Credenciado

Marta Simone Shiokawa Credenciado

Victor Renno Polatto Vizeu Credenciado

Moacira Tegoni Goedert Credenciado

Elenice Lira Sales de Sousa Credenciado

Rossana Paiva Borges de Oliveira Credenciado

Ana Lucia Borba Assunção Credenciado

Luciano Gonsalves Borba Assunção Credenciado

Helcio Kronberg Credenciado

Vicente Domiseth de Oliveira Credenciado

Joacir Monzon Pouey Credenciado

Mateus Gonçalves Borba Assunção Credenciado

Lucas Rafael Antunes Moreira Credenciado

Jonas Gabriel Antunes Moreira Credenciado

Fernando Caetano Moreira Filho Credenciado

Moacir de Santi Credenciado

Otavio Lauro Sodré Santoro Credenciado

Luiz Fernando de Abreu Sodré Santoro Credenciado

Jose Eduardo de Abreu Sodré Santoro Credenciado

Flavio Cunha Sodré Santoro Credenciado

Carolina Lauro Sodré Santoro Credenciado

Mariana Lauro Sodré Santoro Batochio Credenciado

Bruno Duarte Araújo dos Santos Credenciado

Orlando Araujo dos Santos Credenciado

Tatiana Paula Zani de Souza Credenciado

Caroline de Sousa Ribas Credenciado

Ozias Pereira Tavares Credenciado

Sebastião Felix da Costa Neto Credenciado

Martha Helena Tobias da Silva Credenciado

Adriano de Souza Cardoso Credenciado

Gian Roberto Cagni Braggio Credenciado

Marilaine Borges de Paula Credenciado

Jussiara Santos Ermano Sukiennik Credenciado

Fernando Cézar Tobias da Silva Credenciado

Natalia Narita Nunes de Freitas Credenciado

Rodrigo Schmitz Credenciado

Eduardo Schmitz Credenciado

A cada nova solicitação proveniente dos órgãos integrantes do complexo administrativo do Distrito Federal, será excluído do sorteio o leiloeiro que já tenha sido previamente designado, até que todos os profissionais constantes na lista de credenciados tenham sido sorteados. Leiloeiros credenciados após esta data participarão dos sorteios seguintes, em datas oportunamente divulgadas. Nos leilões presenciais, somente poderão conduzir os procedimentos os leiloeiros com inscrição na Junta Comercial do Distrito Federal. Aqueles inscritos em outras unidades federativas deverão declarar-se impedidos de participar da sessão pública de sorteio. Os leiloeiros credenciados se submeterão às regras e deliberações tratadas na sessão pública de sorteio. O resultado será publicado no site oficial da Secretaria de Estado de Economia do Distrito Federal: https://www.economia.df.gov.br.

RENÉ MENDES LOPES

Gerente

AVISO DE RESULTADO DE SORTEIO REALIZADO NA SESSÃO PÚBLICA PARA SORTEIO DE LEILOEIROS CREDENCIADOS NO EDITAL DE LICITAÇÃO

CREDENCIAMENTO Nº 004/2025 - UASG 974002 A Gerência de Controle e Acompanhamento de Leilões (GECAL), vinculada à Subsecretaria de Administração Geral da Secretaria de Estado de Economia do Distrito Federal, nos termos do item 6.8 do Edital de Credenciamento nº 004/2025, TORNA PÚBLICO o resultado do Sorteio realizado na Sessão Pública de 19/06/2026 às 08:00h na Escola de Governo do Distrito Federal situada no SGO ÁREA ESPECIAL N 1, QUADRA 01, Brasília DF, SALA 06. O sorteio teve o seguinte resultado: 1) Polícia Militar do Distrito Federal - Processo SEI nº. 00054-00088899/2026-32 – FOI SORTEADO O NÚMERO 25 - ROSSANA PAIVA BORGES DE OLIVEIRA A sessão foi realizada de forma não eletrônica, e ocorreu independentemente da presença dos leiloeiros conforme Edital de Licitação de Credenciamento nº 004/2025 - UASG 974002. Lembramos que a cada nova solicitação proveniente dos órgãos integrantes do complexo administrativo do Distrito Federal, será excluído do sorteio os leiloeiros que já tenha sido previamente designados, até que todos os profissionais constantes na lista de credenciados tenham sido sorteados. Leiloeiros credenciados após esta data participarão dos sorteios seguintes, em datas oportunamente divulgadas.

<!-- pagina 55 -->

Nos leilões presenciais, somente poderão conduzir os procedimentos os leiloeiros com inscrição na Junta Comercial do Distrito Federal. Aqueles inscritos em outras unidades federativas deverão declarar-se impedidos de participar da sessão pública de sorteio. Os leiloeiros credenciados se submeterão às regras e deliberações tratadas na sessão pública de sorteio. O presente aviso de resultado será publicado no site oficial da Secretaria de Estado de Economia do Distrito Federal: https://www.economia.df.gov.br.

RENÉ MENDES LOPES

Gerente

### INSTITUTO DE PREVIDÊNCIA DOS SERVIDORES

DIRETORIA DE ADMINISTRAÇÃO E FINANÇAS

AVISO DE CONTRATAÇÃO DIRETA DISPENSA ELETRÔNICA Nº 0024/2026 - REPUBLICAÇÃO AVISO DE DISPENSA DE LICITAÇÃO ELETRÔNICA Nº 0024/2026 - (UASG: 926936) Com fulcro no Art. 75, inciso II, da Lei nº 14.133/2021 e Decreto nº 44.300/2023. Processo: 00413-00000063/2026-14 (Aquisição: Material de Consumo). Objeto: O objeto da presente dispensa é a escolha da proposta mais vantajosa para contratação de empresa para fornecimento de sabão em barra, conforme especificações e quantitativos previstos no Aviso de Contratação Direta e seus anexos, de forma a atender as necessidades do Instituto de Previdência dos Servidores do Distrito Federal. Data e horário da dispensa: 25 de junho de 2026 - às 08h, por meio do Sistema Dispensa Eletrônica no site www.compras.gov.br. O Termo de Referência poderá ser acessado no endereços eletrônico: https://pncp.gov.br/app/editais?q=&status=recebendo_proposta&pagina=1.

ELAINE DE FÁTIMA DE ALMEIDA LIMA

Diretora de Administração e Finanças

### INSTITUTO DE PESQUISA E ESTATÍSTICA

EXTRATO DO SÉTIMO TERMO ADITIVO DE RENEGOCIAÇÃO

AO CONTRATO Nº 02/2022 Extrato do Sétimo Termo Aditivo de Renegociação ao Contrato nº 02/2022, celebrado entre o Instituto de Pesquisa e Estatística do Distrito Federal - IPEDF CODEPLAN e a Quallity Pró Saúde Plano de Assistência Médica LTDA. CNPJ: n.º 09.433.795/0001-04. Processo SEI nº. 00121-00001182/2021-20. Objeto: Constitui objeto do presente Termo Aditivo a Renegociação do Contrato nº 02/2022, firmado entre as partes em 29/04/2022, com empresa especializada, operadora de planos de saúde, para a prestação de serviços de assistência suplementar a saúde, em Rede Regional no âmbito de Brasília-DF e atendimento nacional por meio de rede credenciada própria, conveniada, ou terceirizada ou, reembolso na forma prescrita pela Agencia Nacional de Saúde Suplementar – ANS, na modalidade de Plano Coletivo Empresarial, para os empregados do Instituto de Pesquisa e Estatística do Distrito Federal - IPEDF CODEPLAN, seus dependentes, grupo familiar e pedevistas, conforme previsto no DECRETO Nº 48.509, DE 24 DE ABRIL DE 2026, que determina a revisão dos contratos administrativos vigentes. O valor total do contrato é de R$ 6.811.546,45 (Seis milhões, oitocentos e onze mil, quinhentos e quarenta e seis reais e quarenta e cinco centavos), passando para o valor de R$ 6.130.391,86 (Seis milhões, cento e trinta mil, trezentos e noventa e um reais e oitenta e seis centavos), representando uma redução de 10% (dez por cento) em relação ao valor anteriormente pactuado. O presente Termo Aditivo entrará em vigor na data de sua assinatura: 19/06/2026. Assinam pela Contratante: MANOEL CLEMENTINO BARROS NETO - Diretor-Presidente e MARCOS DA SILVA AMARO - Diretor Administração Geral. Pela Contratada: MISAEL ALVES DA SILVA - Diretor Operacional.

EXTRATO DO PRIMEIRO TERMO ADITIVO DE RENEGOCIAÇÃO

AO CONTRATO Nº 11/2025 Extrato do Primeiro Termo Aditivo de Renegociação ao Contrato nº 11/2025, celebrado entre o Instituto de Pesquisa e Estatística do Distrito Federal - IPEDF CODEPLAN e a empresa CERRADO VIAGENS LTDA, inscrita no CNPJ nº 26.722.189/0001-10. Processo nº 04031-00001136/2025-41. Objeto: Tem por objeto o presente Termo Aditivo a renegociação do Contrato nº 11/2025 com a empresa especializada na prestação de serviços de agenciamento de viagens, que compreende a reserva, emissão, marcação, remarcação e cancelamento de bilhetes de passagens aéreas internacionais, a fim de atender as demandas do Instituto de Pesquisa e Estatística – IPEDF Codeplan, conforme condições, quantidades e exigências estabelecidas no Decreto nº 48.509, de 24 de abril de 2026. O Valor Total do Contrato é de R$ 5.000,00 (Cinco mil reais) passando para o valor de R$ 4.600,00 (Quatro mil e seiscentos reais), representando uma redução de 8% (oito por cento) em relação ao valor anterior pactuado. O presente Termo Aditivo entrará em vigor a partir da data de sua assinatura: 19/06/2026. Assinam pela Contratante: MANOEL CLEMENTINO BARROS NETO - Diretor-Presidente, e MARCOS DA SILVA AMARO - Diretor de Administração Geral. Pela Contratada: JOSÉ RICARDO MOREIRA OLIVEIRA CAIXETA – Diretor Financeiro.

### BANCO DE BRASÍLIA S/A DIRETORIA EXECUTIVA DE PESSOAS,

ADMINISTRAÇÃO E RETAGUARDA SUPERINTENDÊNCIA DE LOGÍSTICA E OPERAÇÕES

GERÊNCIA DE CONTRATAÇÕES COMISSÃO PERMANENTE DE LICITAÇÃO

EXTRATO DO CONTRATO BRB Nº 111/2026 Empresa: Cristal Terceirização de Serviços Ltda. Modalidade: PE 031/2026. Objeto: Prestação de serviços contínuos especializados de brigada de incêndio civil.Vigência: 6 meses a partir de 17/06/2026. Valor: R$ 1.455.000,00. Gestor: Viviane N. Torres Pelo BRB: Tunas de S. S. Ferreira; e pela contratada: Leonardo L. da Silva. Proc. nº 147/2026. Rayssa G. da Silva - Gerente de Área.

AVISO DE LICITAÇÃO PREGÃO ELETRÔNICO Nº 038/2026 Objeto: Contratação de empresa para prestação de serviços de agenciamento de viagens. Valor estimado em R$ 4.980.000,00. Abertura: 13/07/2026, às 14h (horário de Brasília). Obtenção do edital e fase de lances: www.portaldecompraspublicas.com.br. Proc. nº 187/26.

DENISE CORRÊA

Pregoeira

I TERMO ADITIVO DO CONTRATO 366/2023 Empresa: RG SEGURANÇA E VIGILANCIA LTDA. Objeto: serviço de vigilância e segurança armada. Fica prorrogado por 30 meses a partir de 07/06/2026. Signatários: Pelo BRB: Tunas de S. S. Ferreira; pela Contratada: Glauco S. T. de Oliveira. Proc. nº 1.022/2023. Rayssa G. da Silva - Gerente de Área.

I TERMO ADITIVO DO CONTRATO Nº 446/2025 Empresa: Global Produções e Empreendimentos LTDA. Objeto: Serviço especializado de conservação e limpeza. Alteração qualitativa. Pelo BRB: Tunas de S. Soares; pela Contratada: Cristiane R. Araújo. Proc. nº 840/2025. Rayssa G. da Silva. Gerente de Área.

### INSTITUTO DE ASSISTÊNCIA

### A SAÚDE DOS SERVIDORES

RECONHECIMENTO DE DÍVIDA Processo: 04001-00000846/2025-66. Interessado: QUALITY HEALTH CARE LTDA, CNPJ nº 13.604.595/0001-36. Valor: R$50.076,89 (cinquenta mil setenta e seis reais e oitenta e nove centavos), relativo ao Termo de Credenciamento nº 577/2024. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00001208/2026-43. Interessado: DF CARE HOSPITAL DE ESPECIALIDADES CRÔNICAS LTDA, CNPJ nº 43.147.837/0001-70. Valor: R$230.631,49 (duzentos e trinta mil seiscentos e trinta e um reais e quarenta e nove centavos), relativo ao Termo de Credenciamento nº 55994/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00001497/2026-81. Interessado: I.A.B INSTITUTO DE ANGIOLOGIA DE BRASÍLIA LTDA, CNPJ nº 02.873.843/0001-28. Valor: R$1.074,00 (um mil setenta e quatro reais), relativo ao Termo de Credenciamento nº 55416/2025. Em 19/06/2026, o Diretor- Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00001621/2025-27. Interessado: ACREDITAR ONCOLOGIA S.A, CNPJ Nº 03.989.821/0002-71. Valor: R$5.076,77 (cinco mil setenta e seis reais e setenta e sete centavos), relativo ao Termo de Credenciamento nº 200/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

<!-- pagina 56 -->

RECONHECIMENTO DE DÍVIDA Processo: 04001-00001701/2026-63. Interessado: ASSOCIAÇÃO DO CORPO CLÍNICO DE BRASÍLIA - ACB, CNPJ nº 26.473.934/0001-34. Valor: R$7.186,93 (sete mil cento e oitenta e seis reais e noventa e três centavos), relativo ao Termo de Credenciamento nº 376/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00001938/2024-82. Interessado: AA M. ISRAEL SAÚDE LTDA, CNPJ nº 72.593.742/0001-89. Valor: R$250,00 (duzentos e cinquenta reais), relativo ao Termo de Credenciamento nº 181/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002114/2025-19. Interessado: ONCOBRASÍLIA INSTITUTO BRASILIENSE DE ONCOLOGIA CLÍNICA LTDA, CNPJ Nº 01.302.851/0001-51. Valor: R$1.428.883,37 (um milhão, quatrocentos e vinte e oito mil oitocentos e oitenta e três reais e trinta e sete centavos), relativo ao Termo de Credenciamento nº 51/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002193/2023-98. Interessado: ÍMPAR SERVIÇOS HOSPITALARES S/A, CNPJ Nº 60.884.855/0024-40. Valor: R$3.072.126,19 (três milhões, setenta e dois mil cento e vinte e seis reais e dezenove centavos), relativo ao Termo de Credenciamento nº 22/2020. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002278/2025-38. Interessado: ASSOCIAÇÃO DOS PROFISSIONAIS DE SERVIÇOS DA SAÚDE EM BRASÍLIA - APROSS, CNPJ Nº 23.471.994/0001-20. Valor: R$2.934,59 (dois mil novecentos e trinta e quatro reais e cinquenta e nove centavos), relativo ao Termo de Credenciamento nº 321/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002451/2023-36. Interessado: HOSPITAL SANTA MARTA LTDA, CNPJ nº 00.610.980/0001-44. Valor: R$764.483,92 (setecentos e sessenta e quatro mil quatrocentos e oitenta e três reais e noventa e dois centavos), relativo ao Termo de Credenciamento nº 01/2020. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002545/2026-58. Interessado: CLÍNICA RADIOLÓGICA VILA RICA LTDA, CNPJ nº 00.508.572/0001-86. Valor: R$1.212,48 (um mil duzentos e doze reais e quarenta e oito centavos), relativo ao Termo de Credenciamento nº 139/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002586/2025-63. Interessado: ÍMPAR SERVIÇOS HOSPITALARES S.A, CNPJ nº 60.884.855/0019-83,. Valor: R$21.415,61 (vinte e um mil quatrocentos e quinze reais e sessenta e um centavos), relativo ao Termo de Credenciamento nº 23/2020. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002651/2026-31. Interessado: CLÍNICA FERRAZ DE FISIOTERAPIA E PILATES LTDA, CNPJ nº 24.065.951/0001-07. Valor: R$61.542,75 (sessenta e um mil quinhentos e quarenta e dois reais e setenta e cinco centavos), relativo ao Termo de Credenciamento nº 55753/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002668/2025-16. Interessado: FISIOEMOV CLÍNICA DE FISIOTERAPIA DO MOVIMENTO LTDA, CNPJ Nº 14.990.692/0001-77. Valor: R$2.942,30 (dois mil novecentos e quarenta e dois reais e trinta centavos), relativo ao Termo de Credenciamento nº 409/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002720/2025-26. Interessado: HO SOBRADINHO SALUTE LTDA, CNPJ nº 29.725.323/0001-24. Valor: R$22.127,57 (vinte e dois mil cento e vinte e sete reais e cinquenta e sete centavos), relativo ao Termo de Credenciamento nº 391/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002982/2025-91. Interessado: DIGIMED DIAGNÓSTICOS POR IMAGENS LTDA, CNPJ Nº 04.403.934/0002-06. Valor: R$15.679,04 (quinze mil seiscentos e setenta e nove reais e quatro centavos), relativo ao Termo de Credenciamento nº 84/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00002983/2025-35. Interessado: VISOMED INTEGRATIVE LTDA, CNPJ Nº 35.343.038/0001-41. Valor: R$4.885,78 (quatro mil oitocentos e oitenta e cinco reais e setenta e oito centavos), relativo ao Termo de Credenciamento nº 329/2021. Em 18/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003034/2025-72. Interessado: ATITUDE CLÍNICA PSICOLÓGICA E MULTIDISCIPLINAR LTDA, CNPJ Nº 08.073.742/0001-59. Valor: R$3.600,00 (três mil e seiscentos reais), relativo ao Termo de Credenciamento nº 535/2022. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003245/2025-13. Interessado: CLÍNICA DE OTORRINOLARINGOLOGIA OTO NORTE LTDA, CNPJ Nº 01.859.881/0001-63. Valor: R$21.970,34 (vinte e um mil novecentos e setenta reais e trinta e quatro centavos), relativo ao Termo de Credenciamento nº 133/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003328/2025-02. Interessado: VITA CARE BRASÍLIA LTDA, CNPJ Nº 48.618.108/0001-79. Valor: R$17.087,25 (dezessete mil oitenta e sete reais e vinte e cinco centavos), relativo ao Termo de Credenciamento nº 557/2023. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

<!-- pagina 57 -->

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003425/2025-97. Interessado: RADIOGRAPH CLÍNICA DE IMAGEM LTDA, CNPJ Nº 00.243.530/0001-60. Valor: R$49.000,70 (quarenta e nove mil reais e setenta centavos), relativo ao Termo de Credenciamento nº 83/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003438/2026-47. Interessado: OFTALMOCLINIC SS LTDA, CNPJ Nº 01.241.695/0001-66. Valor: R$13.555,00 (treze mil quinhentos e cinquenta e cinco reais), relativo ao Termo de Credenciamento nº 55710/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003491/2025-67. Interessado: INSTITUTO BRASILIENSE DE NEFROLOGIA LTDA, CNPJ Nº 27.544.160/0001-58. Valor: R$239.945,73 (duzentos e trinta e nove mil novecentos e quarenta e cinco reais e setenta e três centavos), relativo ao Termo de Credenciamento nº 72/2021. Em 18/06/2026, o Diretor- Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003509/2025-21. Interessado: H2 FISIO CENTRO DE EXCELÊNCIA EM REABILITAÇÃO LTDA, CNPJ nº 10.636.592/0001-96. Valor: R$31,42 (trinta e um reais e quarenta e dois centavos), relativo ao Termo de Credenciamento nº 103/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003766/2024-81. Interessado: ATEMDO - ATENDIMENTO MÉDICO DOMICILIAR LTDA, CNPJ nº 16.064.313/0006-58. Valor: R$1.617,72 (um mil seiscentos e dezessete reais e setenta e dois centavos), relativo ao Termo de Credenciamento nº 587/2024. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003805/2026-11. Interessado: CLINICA DOMICILIAR SANTA CAMILA LTDA, CNPJ Nº 13.649.407/0001-96. Valor: R$5.068,86 (cinco mil sessenta e oito reais e oitenta e seis centavos), relativo ao Termo de Credenciamento nº 204/2021. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003815/2026-48. Interessado: CLINICA DOMICILIAR SANTA CAMILA LTDA, CNPJ nº 13.649.407/0001-96. Valor: R$1.270,38 (um mil duzentos e setenta reais e trinta e oito centavos), relativo ao Termo de Credenciamento nº 56325/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003910/2026-41. Interessado: CENTRO CLÍNICO ALPHA PSICOLOGIA E SAÚDE LTDA, CNPJ nº 34.069.551/0001-23. Valor: R$350,00 (trezentos e cinquenta reais), relativo ao Termo de Credenciamento nº 56315/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00003948/2026-14. Interessado: VIDERE CENTRO DE REABILITAÇÃO E ATIVIDADE FÍSICA LTDA, CNPJ Nº 03.794.340/0001-20. Valor: R$125,68 (cento e vinte e cinco reais e sessenta e oito centavos), relativo ao Termo de Credenciamento nº 56381/2025. Em 18/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00004061/2026-43. Interessado: INSTITUTO ORTOPÉDICO TAGUATINGA LTDA, CNPJ Nº 04.739.465/0001-10. Valor: R$9.439,65 (nove mil quatrocentos e trinta e nove reais e sessenta e cinco centavos), relativo ao Termo de Credenciamento nº 55845/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026- SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00004173/2026-02. Interessado: MEDICARE SERVIÇOS DE EMERGÊNCIA MÓVEL E HOME CARE LTDA, CNPJ nº 37.566.567/0001-30. Valor: R$759,76 (setecentos e cinquenta e nove reais e setenta e seis centavos), relativo ao Termo de Credenciamento nº 575/2024. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00005845/2025-16. Interessado: SERFA LTDA ME, CNPJ Nº 03.276.801/0001-72. Valor: R$905,00 (novecentos e cinco reais), relativo ao Termo de Credenciamento nº 583/2024. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00006023/2025-44. Interessado: ASSOCIAÇÃO DE MÉDICOS, CLÍNICAS E HOSPITAIS PRIVADOS DO DISTRITO FEDERAL, CNPJ nº 00.735.860/0001-73. Valor: R$472.696,17 (quatrocentos e setenta e dois mil seiscentos e noventa e seis reais e dezessete centavos), relativo ao Termo de Credenciamento nº 54114/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00006114/2025-80. Interessado: HOSPITAL HUEB LTDA, CNPJ Nº 31.612.634/0001-29. Valor: R$5.745,62 (cinco mil setecentos e quarenta e cinco reais e sessenta e dois centavos), relativo ao Termo de Credenciamento nº 54850/2025. Em 19/06/2026, o Diretor-Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

RECONHECIMENTO DE DÍVIDA Processo: 04001-00006360/2025-31. Interessado: OCULARE OFTALMOLOGIA LTDA, CNPJ Nº 05.090.412/0001-83. Valor: R$11.200,16 (onze mil e duzentos reais e dezesseis centavos), relativo ao Termo de Credenciamento nº 54316/2025. Em 19/06/2026, o Diretor- Presidente do INAS, com base nos arts. 30 e 86 do Decreto nº 32.598/2010, e em respeito ao Ofício nº 292/2026-SEEC/SEFIN, no uso das atribuições previstas no art. 21 da Portaria nº 262/2006, AUTORIZA o reconhecimento da dívida, a emissão de nota de empenho, a liquidação e o pagamento da despesa em favor do Interessado. PABLO VIEIRA DE CASTRO.

## SECRETARIA DE ESTADO DE SAÚDE

### SECRETARIA EXECUTIVA DE GESTÃO ADMINISTRATIVA SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06907 PROCESSO: 00060-00277194/2026-63. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa

<!-- pagina 58 -->

ABA MED S.A . CNPJ Nº 04.369.147/0001-04. OBJETO: AQUISIÇÃO DE TESTOSTERONA (CIPIONATO) SOLUÇÃO INJETÁVEL 100 MG/ ML AMPOLA 2ML, conforme Ata de Registro de Preço nº 90040/2026-A , Pedido de Aquisição de Material nº 5-26/PAM002691 e Autorização de Fornecimento de Material nº 5- 26/AFM002521. VALOR: R$ 718,00 (setecentos e dezoito reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06908 PROCESSO: 00060-00280246/2026-89. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - SAÚDE - COMÉRCIO DE PRODUTOS HOSPITALARES LTDA. CNPJ Nº 33.498.171/0001-41. OBJETO: AQUISIÇÃO DE FIO DE SUTURA DE POLIESTER REVESTIDO,TRANÇADO, Nº05 4X75 CM, 75CM, conforme Ata de Registro de Preço nº 90258/2025-B , Pedido de Aquisição de Material nº 5-26/PAM002701 e Autorização de Fornecimento de Material nº 5-26/AFM002530. VALOR: R$ 9.996,00 (nove mil novecentos e noventa e seis reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06909 PROCESSO: 00060-00250953/2026-41. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - BELBI COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO . CNPJ Nº 27.901.764/0001- 04. OBJETO: AQUISIÇÃO DE TUBO DE HEMOLISE 12X75MM, VIDRO BOROSSILICATO E OUTROS, conforme Ata de Registro de Preço nº 90208/2025-C , Pedido de Aquisição de Material nº 5-26/PAM002395 e Autorização de Fornecimento de Material nº 5-26/AFM002247. VALOR: R$ 19.275,64 (dezenove mil duzentos e setenta e cinco reais e sessenta e quatro centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06910 PROCESSO: 00060-00250953/2026-41. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - BELBI COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO . CNPJ Nº 27.901.764/0001- 04. OBJETO: AQUISIÇÃO DE PONTEIRA DESCARTÁVEL, conforme Ata de Registro de Preço nº 90208/2025-C , Pedido de Aquisição de Material nº 5- 26/PAM002395 e Autorização de Fornecimento de Material nº 5-26/AFM002247. VALOR: R$ 183,70 (cento e oitenta e três reais e setenta centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06939 PROCESSO: 00060-00270302/2026-77. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa AGMASHI COMÉRCIO DE MATERIAL MÉDICO E SERVIÇOS DE COBRANÇAS. CNPJ Nº 08.234.423/0001-88. OBJETO: AQUISIÇÃO DE KIT PARA NEFROSTOMIA PERCUTANEA COM CATETER PIGTAIL 12FR DE 25CM., conforme Ata de Registro de Preço nº 90001/2025-A, Pedido de Aquisição de Material nº 5-26/PAM002629 e Autorização de Fornecimento de Material nº 5-26/AFM002454. VALOR: R$ 3.692,00 (três mil seiscentos e noventa e dois reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06941 PROCESSO: 00060-00275192/2026-30. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - BELBI COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO. CNPJ Nº 27.901.764/0001-04. OBJETO: AQUISIÇÃO DE AGULHA PARA ANESTESIA PERIDURAL, EPIDURAL OU CAUDAL, 18G 3 1/2, conforme Ata de Registro de Preço nº 90017/2026-A , Pedido de Aquisição de Material nº 5-26/PAM002673 e Autorização de Fornecimento de Material nº 5-26/AFM002498. VALOR: R$ 961,40 (novecentos e sessenta e um reais e quarenta centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06942 PROCESSO: 00060-00275209/2026-59. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa BELBI COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO. CNPJ Nº 27.901.764/0001-04. OBJETO: AQUISIÇÃO DE CATÉTER PARA ANESTESIA PERIDURAL, EPIDURAL OU CAUDAL CONTÍNUA 16G, conforme Ata de Registro de Preço nº 90017/2026-A , Pedido de Aquisição de Material nº 5-26/PAM002674 e Autorização de Fornecimento de Material nº 5-26/AFM002499. VALOR: R$ 10.319,40 (dez mil trezentos e dezenove reais e quarenta centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06943 PROCESSO: 00060-00276538/2026-17. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa OLTRAMED COMÉRCIO DE PRODUTOS MÉDICOS LTDA. CNPJ Nº

14.829.987/0004-09. OBJETO: AQUISIÇÃO DE GRAMPEADOR CIRCULAR DESCARTÁVEL, CURVO e OUTROS, conforme Ata de Registro de Preço nº 90080/2025-A , Pedido de Aquisição de Material nº 5-26/PAM002687 e Autorização de Fornecimento de Material nº 5-26/AFM002515. VALOR: R$ 39.505,00 (trinta e nove mil quinhentos e cinco reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06944 PROCESSO: 00060-00276827/2026-16. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa BIOMED DISTRIBUIDORA DE MEDICAMENTOS EIRELI. CNPJ Nº 38.329.458/0001- 61. OBJETO: AQUISIÇÃO DE CAPTOPRIL COMPRIMIDO SULCADO 25 MG, conforme Ata de Registro de Preço nº 90313/2025-B, Pedido de Aquisição de Material nº 5-26/PAM002688 e Autorização de Fornecimento de Material nº 5-26/AFM002516. VALOR: R$ 437,00 (quatrocentos e trinta e sete reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06945 PROCESSO: 00060-00275380/2026-68. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa CM HOSPITALAR S.A . CNPJ Nº 12.420.164/0005-80. OBJETO: AQUISIÇÃO DE RIBOCICLIBE (SUCCINATO) COMPRIMIDO REVESTIDO 200MG, conforme Ata de Registro de Preço nº 90024/2026-C , Pedido de Aquisição de Material nº 5-26/PAM002677 e Autorização de Fornecimento de Material nº 5-26/AFM002502. VALOR: R$ R$ 3.477.011,58 (três milhões, quatrocentos e setenta e sete mil onze reais e cinquenta e oito centavos) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06946 PROCESSO: 00060-00275915/2026-09. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - HTS - TECNOLOGIA DE SAUDE LTDA. CNPJ Nº 66.437.831/0001-33. OBJETO: AQUISIÇÃO DE AGULHA PARA PUNÇÃO DE CATETER TOTALMENTE IMPLANTÁVEL, 20GX 19m, conforme Ata de Registro de Preço nº 90214/2025-C, Pedido de Aquisição de Material nº 5-26/PAM002678 e Autorização de Fornecimento de Material nº 5-26/AFM002504. VALOR: R$ 7.089,00 (sete mil oitenta e nove reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06946 PROCESSO: 00060-00275915/2026-09. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa HTS - TECNOLOGIA DE SAUDE LTDA. CNPJ Nº 66.437.831/0001-33. OBJETO: AQUISIÇÃO DE AGULHA PARA PUNÇÃO DE CATETER TOTALMENTE IMPLANTÁVEL, 20GX 19mm , conforme Ata de Registro de Preço nº 90214/2025-C, Pedido de Aquisição de Material nº 5-26/PAM002678 e Autorização de Fornecimento de Material nº 5-26/AFM002504. VALOR: R$ 7.089,00 (sete mil oitenta e nove reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE06947 PROCESSO: 00060-00280451/2026-44. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - BN EXPRESS II COMÉRCIO E SERVIÇOS LTDA. CNPJ Nº 44.891.225/0001-50. OBJETO: AQUISIÇÃO DE FÓRMULA DIETOTERÁPICA PARA PORTADORES DE TIROSINEMIA COM RESTRIÇÃO DE FENILALANINA E TIROSINA., conforme Ata de Registro de Preço nº 90285/2025-A, Pedido de Aquisição de Material nº 5- 26/PAM002706 e Autorização de Fornecimento de Material nº 5-26/AFM002534. VALOR: R$ 1.750,00 (um mil setecentos e cinquenta reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 15/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07018 PROCESSO: 00060-00261981/2026-93. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa PRATI DONADUZZI CIA LTDA. CNPJ Nº 73.856.593/0001-66. OBJETO: AQUISIÇÃO DE METFORMINA (CLORIDRATO) COMPRIMIDO 850 MG, conforme Ata de Registro de Preço nº 90172/2025-E, Pedido de Aquisição de Material nº 5- 26/PAM002498 e Autorização de Fornecimento de Material nº 5-26/AFM002335. VALOR: R$ 897,60 (oitocentos e noventa e sete reais e sessenta centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07020 PROCESSO: 00060-00212309/2026-74. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa PRATI DONADUZZI CIA LTDA. CNPJ Nº 73.856.593/0001-66. OBJETO: AQUISIÇÃO DE MICONAZOL CREME VAGINAL 20MG/G BISNAGA 80 G + APLICADORES, conforme Ata de Registro de Preço nº 90192/2025-H, Pedido de

<!-- pagina 59 -->

Aquisição de Material nº 5-26/PAM002003 e Autorização de Fornecimento de Material nº 5-26/AFM001869. VALOR: R$ 60.720,00, PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07024 PROCESSO: 00060-00216004/2026-31. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - YELLUX INDÚSTRIA DE COSMÉTICOS LTDA. CNPJ Nº 32.274.485/0001-06. OBJETO: AQUISIÇÃO DE COPO, Material, plástico, Capacidade mínima: 180 ml, conforme Ata de Registro de Preço nº 0014/2026 - SEECDF, Pedido de Aquisição de Material nº 1-26/PAM002054 e Autorização de Fornecimento de Material nº 1- 26/AFM001914. VALOR:R$ 90.060,00 (noventa mil sessenta reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07027 PROCESSO: 00060-00225560/2026-07. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LTDA. CNPJ Nº 44.734.671/0022-86. OBJETO: AQUISIÇÃO DE TOBRAMICINA POMADA OFTALMICA 0,3 % BISNAGA 3,5 G, conforme Ata de Registro de Preço nº 90067/2025-B, Pedido de Aquisição de Material nº 5-26/PAM002123 e Autorização de Fornecimento de Material nº 5-26/AFM001982. VALOR: R$ 1.376,36 (um mil trezentos e setenta e seis reais e trinta e seis centavos) PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07028 PROCESSO: 00060-00240124/2026-50. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - LABORATORIO TEUTO BRASILEIRO S/A. CNPJ Nº 17.159.229/0001-76. OBJETO: AQUISIÇÃO DE FENITOINA COMPRIMIDO 100 MG, conforme Ata de Registro de Preço nº 90023/2026-C, Pedido de Aquisição de Material nº 5- 26/PAM002265 e Autorização de Fornecimento de Material nº 5-26/AFM002112. VALOR: R$ 56.756,00 (cinquenta e seis mil setecentos e cinquenta e seis reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07033 PROCESSO: 00060-00259393/2026-90. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - ELLO DISTRIBUIÇÃO LTDA. CNPJ Nº 14.115.388/0002- 61. OBJETO: AQUISIÇÃO DE ALENDRONATO SODICO COMPRIMIDO 70 MG, conforme Ata de Registro de Preço nº 90236/2025-B , Pedido de Aquisição de Material nº 5-26/PAM002477 e Autorização de Fornecimento de Material nº 5- 26/AFM002316. VALOR: R$ 13.448,64 (treze mil quatrocentos e quarenta e oito reais e sessenta e quatro centavos) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07036 PROCESSO: 00060-00257662/2026-83. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - MEDCOM COMÉRCIO DE MEDICAMENTOS HOSPITALARES LTDA. CNPJ Nº 25.211.499/0003-79. OBJETO: AQUISIÇÃO DE PRÓTESE DE MAMA, MATERIAL SILICONE, conforme Ata de Registro de Preço nº 90212/2024-B, Pedido de Aquisição de Material nº 5-26/PAM002739 e Autorização de Fornecimento de Material nº 5-26/AFM002572 . VALOR: R$ R$ 22.750,00 (vinte e dois mil setecentos e cinquenta reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07038 PROCESSO: 00060-00257568/2026-24. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa BIOMED DISTRIBUIDORA DE MEDICAMENTOS EIRELI. CNPJ Nº 38.329.458/0001- 61. OBJETO: AQUISIÇÃO DE METRONIDAZOL COMPRIMIDO 400 MG, conforme Ata de Registro de Preço nº 90313/2025-B , Pedido de Aquisição de Material nº 5- 26/PAM002453 e Autorização de Fornecimento de Material nº 5-26/AFM002292. VALOR: R$ 1.900,80 (um mil e novecentos reais e oitenta centavos) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07040 PROCESSO: 00060-00257520/2026-16. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PRODUTOS. CNPJ Nº 12.418.191/0001-95. OBJETO: AQUISIÇÃO DE SULFADIAZINA DE PRATA CREME DERMATOLOGICO 1% BISNAGA 50 G, conforme Ata de Registro de Preço nº 90314/2025-A, Pedido de Aquisição de Material nº 5-26/PAM002451 e Autorização de

Fornecimento de Material nº 5-26/AFM002291. VALOR:R$ 18.176,70 (dezoito mil cento e setenta e seis reais e setenta centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07042 PROCESSO: 00060-00255368/2026-37. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa SURGICALL PRODUTOS MÉDICOS LTDA. – ME. CNPJ Nº 27.437.015/0001-78. OBJETO: AQUISIÇÃO DE AZUL DE TRIPAN 0,1 FRASCO 1 ML CORANTE INTRAOCULAR SOLUÇÃO INJETÁVEL, conforme Ata de Registro de Preço nº 90043/2026-B, Pedido de Aquisição de Material nº 5-26/PAM002394 e Autorização de Fornecimento de Material nº 5-26/AFM002241. VALOR: R$ 504,00 (quinhentos e quatro reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07043 PROCESSO: 00060-00254840/2026-14. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LTDA. CNPJ Nº 44.734.671/0022-86. OBJETO: AQUISIÇÃO DE LIDOCAINA (CLORIDRATO) GELEIA 2 % BISNAGA 30 G, conforme Ata de Registro de Preço nº 90155/2025-A, Pedido de Aquisição de Material nº 5-26/PAM002429 e Autorização de Fornecimento de Material nº 5-26/AFM002269. VALOR: R$ 98.771,00 (noventa e oito mil setecentos e setenta e um reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07044 PROCESSO: 00060-00250494/2026-03. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - F&R HOSPITALAR IMPORTAÇÃO, EXPORTAÇÃO E DISTRIBUIÇÃO LTDA. CNPJ Nº 51.837.171/0001-00. OBJETO: AQUISIÇÃO DE Equipo para nutrição enteral do tipo gravitacional, conforme Ata de Registro de Preço nº 90126/2025-B , Pedido de Aquisição de Material nº 5-26/PAM002388 e Autorização de Fornecimento de Material nº 5- 26/AFM002235. VALOR: R$ R$ 38.110,50 (trinta e oito mil cento e dez reais e cinquenta centavos) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07046 PROCESSO: 00060-00247810/2026-51. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa UNI HOSPITALAR CEARÁ LTDA. CNPJ Nº 21.595.464/0001-68. OBJETO: AQUISIÇÃO DE OXICODONA COMPRIMIDO REVESTIDO DE LIBERAÇÃO CONTROLADA 10MG, conforme Ata de Registro de Preço nº 90067/2026-G, Pedido de Aquisição de Material nº 5-26/PAM002349 e Autorização de Fornecimento de Material nº 5-26/AFM002274. VALOR: R$ 80.944,50 (oitenta mil novecentos e quarenta e quatro reais e cinquenta centavos) PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07047 PROCESSO: 00060-00242409/2026-25. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa ABC FARMACÊUTICO LTDA. CNPJ Nº 52.967.925/0001-00. OBJETO: AQUISIÇÃO DE BENZILPENICILINA POTASSICA PO PARA SOLUCAO INJETAVEL 5, conforme Ata de Registro de Preço nº 90048/2026-A, Pedido de Aquisição de Material nº 5- 26/PAM002288 e Autorização de Fornecimento de Material nº 5-26/AFM002130. VALOR: R$ 17.127,00 (dezessete mil cento e vinte e sete reais) PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07073 PROCESSO: 00060-00262302/2026-01. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - PROVIDE HOSPITALAR LTDA. CNPJ Nº 43.573.889/0001-09. OBJETO: AQUISIÇÃO DE CLORETO DE POTASSIO SOLUÇAO ORAL 60 MG/ML FRASCO 100 ML COM DOSEADOR, conforme Ata de Registro de Preço nº 90236/2025-G, Pedido de Aquisição de Material nº 5-26/PAM002507 e Autorização de Fornecimento de Material nº 5- 26/AFM002345. VALOR: R$ 4.838,00 (quatro mil oitocentos e trinta e oito reais) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07074 PROCESSO: 00060-00262206/2026-55. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - FARMACE INDUSTRIA QUIMICO FARMACEUTICA CEARENSE LTDA. CNPJ Nº 06.628.333/0001-46. OBJETO: AQUISIÇÃO DE OLEO MINERAL 100 % PURO FRASCO 100 ML, conforme Ata de Registro de Preço nº 90165/2025-G , Pedido de Aquisição de Material nº 5-26/PAM002505 e Autorização de Fornecimento de Material nº 5-26/AFM002342. VALOR: R$ R$ 39.480,00 (trinta e nove mil quatrocentos e oitenta reais), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

<!-- pagina 60 -->

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07075 PROCESSO: 00060-00287802/2026-48. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - R.DE .F.TORRES EPP. CNPJ Nº 19.231.616/0001-00. OBJETO: AQUISIÇÃO DE BROCA BAIXA ROTAÇÃO, TIPO CONTRA ÂNGULO, conforme Ata de Registro de Preço nº 90241/2025-A, Pedido de Aquisição de Material nº 5-26/PAM002775 e Autorização de Fornecimento de Material nº 5-26/AFM002611. VALOR: R$ 161,28 (cento e sessenta e um reais e vinte e oito centavos), PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 17/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07087 PROCESSO: 00060-00245304/2026-28. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa - CINORD INDÚSTRIA FARMACÊUTICA LTDA. CNPJ Nº 06.879.626/0001-04. OBJETO: AQUISIÇÃO DE ALCOOL GEL 70% FRASCO COM TAMPA ACOPLADA 85 a 100G. , conforme Ata de Registro de Preço nº 90192/2025-A, Pedido de Aquisição de Material nº 5-26/PAM002320 e Autorização de Fornecimento de Material nº 5- 26/AFM002162. VALOR: R$ 1.305,60 (um mil trezentos e cinco reais e sessenta centavos) , PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 18/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

EXTRATO DE NOTA DE EMPENHO Nº 2026NE07093 PROCESSO: 00060-00248893/2026-04. Partes: DISTRITO FEDERAL, por intermédio de sua SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL e a empresa ORTOPEDIA BRASIL LTDA,. CNPJ Nº 05.477.107/0001-49 . OBJETO: AQUISIÇÃO DE ÓRTESE DE DENNIS BROWN., conforme Ata de Registro de Preço nº 90049/2025-C , Pedido de Aquisição de Material nº 1-26/PAM002595 e Autorização de Fornecimento de Material nº 1-26/AFM002428. VALOR: R$ R$ 16.590,00, PRAZO DE ENTREGA: 100% em 30 dias. Data do Empenho: 18/06/2026. Pela SES/DF: GLAUCIA MARIA MENEZES DA SILVEIRA.

### SECRETARIA EXECUTIVA DE COMPRAS, CONTRATOS E INSTRUMENTOS CONGÊNEROS

SUBSECRETARIA DE COMPRAS E CONTRATAÇÕES

DIRETORIA DE AQUISIÇÕES

CENTRAL DE COMPRAS

AVISO DE ABERTURA PREGÃO ELETRÔNICO POR SRP Nº 90177/2026 - UASG 926119 Objeto: Aquisição regular de medicamento CALCITRIOL CAPSULA e outros, em sistema de registro de preços, para atender às necessidades da Secretaria de Saúde – DF, conforme especificações e quantitativos constantes no Anexo I do Edital. Processo SEI nº: 00060- 00116060/2026-77. Total de 07 itens (Ampla Concorrência e Cotas reservadas às ME/EPP’s). Valor Estimado: R$ 17.498.006,6486. Cadastro das Propostas: a partir de 22/06/2026. Abertura das Propostas: 02/07/2026, às 8h30, horário de Brasília, no site www.comprasnet.gov.br. O Edital encontra-se disponibilizado, sem ônus, no site, ou, com ônus, no endereço: SRTVN 701, Lote D, Edifício PO 700, 2º andar, Central de Compras/DAQ/SUCOMP, CEP: 70.719-040 - Brasília/DF.

WELIKA FARIA SANTOS

Pregoeira

AVISO DE ABERTURA PREGÃO ELETRÔNICO POR SRP Nº 90194/2026 - UASG 926119 Objeto: Aquisição regular de Órteses, Próteses e Materiais Especiais (OPME) pertencente(s) ao(s) Grupo 36.30.33 - OPME - Medicina Física, em sistema de registro de preços, para atender às necessidades da Secretaria de Saúde – DF, conforme especificações e quantitativos constantes no Anexo I do Edital. Processo SEI nº: 00060-00365386/2025-45. Total de 05 itens (Exclusividade às ME/EPP’s). Valor Estimado: R$ 123.624,5041. Cadastro das Propostas: a partir de 22/06/2026. Abertura das Propostas: 02/07/2026, às 8h30, horário de Brasília, no site www.comprasnet.gov.br. O Edital encontra-se disponibilizado, sem ônus, no site, ou, com ônus, no endereço: SRTVN 701, Lote D, Edifício PO 700, 2º andar, Central de Compras/DAQ/SUCOMP, CEP: 70.719-040 - Brasília/DF.

FABIANA MENDES DE OLIVEIRA CORTEZ

Pregoeira

AVISO DE ABERTURA PREGÃO ELETRÔNICO POR SRP Nº 90195/2026 - UASG 926119 Objeto: Aquisição potencial de Órteses, Próteses e Materiais Especiais (OPME) pertencente(s) ao(s) Grupo 36.30.33 - OPME Endoscopia - Compra Regular, nos termos da tabela abaixo, para atender às necessidades da Secretaria de Saúde – DF, conforme especificações e quantitativos constantes no Anexo I do Edital. Processo SEI nº: 00060- 00309921/2025-88. Total de 03 itens (AMPLA CONCORRÊNCIA e COTA 25% RESERVADO À ME/EPP.). Valor Estimado: R$ 548.317,8000. Cadastro das Propostas: a partir de 22/06/2026. Abertura das Propostas: 02/07/2026, às 8h30, horário de Brasília, no site www.comprasnet.gov.br. O Edital encontra-se disponibilizado, sem ônus, no site, ou, com ônus, no endereço: SRTVN 701, Lote D, Edifício PO 700, 2º andar, Central de Compras/DAQ/SUCOMP, CEP: 70.719-040 - Brasília/DF.

QUEILA BARRETO ROCHA

Pregoeira

AVISO DE ABERTURA PREGÃO ELETRÔNICO POR SRP Nº 90196/2026 - UASG 926119 Objeto: Aquisição regular de Órteses, Próteses e Materiais Especiais (ALMOFADA TERAPÊUTICA PARA PREVENÇÃO DE ÚLCERA DE PRESSÃO e outra), em sistema de registro de preços, para atender às necessidades da Secretaria de Saúde – DF, conforme especificações e quantitativos constantes no Anexo I do Edital. Processo SEI nº: 00060- 00006886/2026-29. Total de 03 itens (Ampla Concorrência e Cotas reservadas às ME/EPP’s). Valor Estimado: R$ 496.562,71. Cadastro das Propostas: a partir de 22/06/2026. Abertura das Propostas: 03/07/2026, às 8h30, horário de Brasília, no site www.comprasnet.gov.br. O Edital encontra-se disponibilizado, sem ônus, no site, ou, com ônus, no endereço: SRTVN 701, Lote D, Edifício PO 700, 2º andar, Central de Compras/DAQ/SUCOMP, CEP: 70.719-040 - Brasília/DF.

WELIKA FARIA SANTOS

Pregoeira

### HOSPITAL SÃO VICENTE DE PAULO

DIRETORIA ADMINISTRATIVA

EXTRATO DE DISPENSA DE LICITAÇÃO PDPAS - SES/HSVP O DIRETOR ADMINISTRATIVO, DO HOSPITAL SÃO VICENTE DE PAULO, DA SECRETARIA DE ESTADO DE SAÚDE DO DISTRITO FEDERAL, no uso das atribuições que lhe confere o Art. 1º da Portaria Nº 473, de 04 de dezembro de 2023, concernente à Ordenação de Despesas do Programa Descentralização Progressiva de Ações da Saúde – PDPAS, e para fins de atendimento ao inciso X, art. 16 da mesma portaria, resolve: RATIFICAR a dispensa de licitação em razão do valor Nº 2130-001452, Processo SEI nº 00060-00207115/2026-57, com fundamento no artigo 75 inciso II da Lei nº 14.133 de 1º de abril de 2021, à empresa MOISÉS E CAIXETA LTDA /CNPJ: 37.163.698/0001-76 cujo objeto é a aquisição dos produtos identificados pelos códigos SES: 12335 - TINTA ESMALTE SINTÉTICO; e 6434 - DILUENTE, Tipo: THINNER 2800; no valor global de R$ 1.708,20 (mil setecentos e oito reais e vinte centavos) para atender às necessidades da URD - HSVP. TORNAR SEM EFEITO a dispensa de licitação em razão do valor Nº 2130-001450, Processo SEI nº 00060-00193056/2026-22, com fundamento no artigo 75 inciso II da Lei nº 14.133 de 1º de abril de 2021, à empresa IMEDIATA DISTRIBUIDORA DE PRODUTOS PARA A SAUDE LTDA/CNPJ: 36.590.911/0001-63 cujo objeto é a aquisição do produto identificado pelo código SES: 1038 - QUETIAPINA COMPRIMIDO 100 MG, no valor global de R$ 750,00 (setecentos e cinquenta reais) para atender às necessidades da URD - HSVP, publicada no DODF Nº 88, SEXTA-FEIRA, 15 DE MAIO DE 2026.

HÉRCULES MARINHO LOPES

### FUNDAÇÃO HEMOCENTRO DE BRASÍLIA

EXTRATO DO QUARTO TERMO ADITIVO AO CONTRATO Nº 012/2023 – DCC/UNIAF/FHB Contratante: FUNDAÇÃO HEMOCENTRO DE BRASÍLIA - CNPJ nº 86.743.457/0001- 01. Contratada: BIOPLASMA PRODUTOS PARA LABORATÓRIOS E CORRELATOS LTDA. - CNPJ nº 04.086.552/0001-15. Objeto: prorrogar o prazo de vigência do contrato originário por mais 12 (doze) meses, com amparo no inciso II, art. 57 da Lei n° 8.666/93; e apresentar cronograma de entregas. Unidade Orçamentária: 23.202. Empenho 2026NE00372 emitido 16/06/2026 no valor de R$72.200,00. Programa de Trabalho: 10.303.6202.2811.0002. Natureza da Despesa: 33.90.30. Fonte de Recurso: 138. Valor total do Contrato: R$144.400,00. Processos n.º 00063-00002630/2023-15 e n.º: 00063- 00002545/2021-95. Vigência: 21 de junho de 2026 e termo final em 21 de junho de 2027. Assinam em 19 de junho de 2026, pelo Contratante: GILSON MARTINS RIBEIRO, Presidente Substituto, e pela Contratada: CAIO ALMEIDA ANDRADE.

### INSTITUTO DE GESTÃO ESTRATÉGICA

### DE SAÚDE DO DISTRITO FEDERAL

EXTRATO DO PRIMEIRO TERMO ADITIVO À ATA DE REGISTRO DE PREÇOS Nº 42/2025 Processo: 04016-00002084/2025-64. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, CNPJ nº 28.481.233/0001-72 e a SISNAC PRODUTOS PARA SAUDE LTDA, CNPJ nº 10.444.624/0001-51. Objeto: Prorrogação da vigência da Ata de Registro de Preços nº 042/2025, Do Valor Total Estimado: R$ 5.235.065,50 (cinco milhões, duzentos e trinta e cinco mil, sessenta e cinco reais e cinquenta centavos), assinado em 12/06/2026. Da Ratificação: Ficam mantidas as demais cláusulas e condições constantes na Ata Originária. Signatários: pelo IGESDF, representado por sua Diretora-Presidente, a Sra. ELIANE SOUZA DE ABREU, seu Diretor Vice-Presidente, Sr. RUBENS DE OLIVEIRA PIMENTEL JÚNIOR e por sua Diretora de Infraestrutura, Logística e Obras - Interina, Sra. BÁRBARA LIRA FREITAS SANTOS; e, pela contratada: IVANI DO NASCIMENTO CAMPAGNARI, na qualidade de representante legal.

EXTRATO DO TERMO DE ACEITE Nº 1.450/2026 Processo: 04016-00059021/2026-61. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA LITORAL COMÉRCIO

<!-- pagina 61 -->

DE PRODUTOS MÉDICOS E HOSPITALARES LTDA, CNPJ nº 25.164.770/0001-09. Dispensa nº 43/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE OPME. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 11/06/2026. Signatário: Pela Contratada: CAMILA LAU SOARES, na qualidade de procuradora.

EXTRATO DO TERMO DE ACEITE Nº 1.451/2026 Processo: 04016-00059021/2026-61. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA SUPLEN MEDICAL LTDA, CNPJ nº 21.581.995/0001-00. Dispensa nº 43/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE OPME. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 15/06/2026. Signatário: Pela Contratada: FERNANDO GOULART DE CARVALHO CAMPOS, na qualidade de Representante Legal.

EXTRATO DO TERMO DE ACEITE Nº 1.452/2026 Processo: 04016-00059021/2026-61. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA BOSTON SCIENTIFIC DO BRASIL LTDA, CNPJ nº 01.513.946/0001-14. Dispensa nº 43/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE OPME. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 11/06/2026. Signatário: Pela Contratada: LETICIA QUINTAL MENDES, na qualidade de procuradora.

EXTRATO DO TERMO DE ACEITE Nº 1.453/2026 Processo: 04016-00059021/2026-61. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA TOP MED IMPORTAÇÃO E DISTRIBUIÇÃO LTDA, CNPJ nº 11.172.836/0003-51. Dispensa nº 43/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE OPME. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 11/06/2026. Signatário: Pela Contratada: FERNANDO GOULART DE CARVALHO CAMPOS, na qualidade de Representante Legal.

EXTRATO DO TERMO DE ACEITE Nº 1.458/2026 Processo: 04016-00069147/2026-43. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA LABORATÓRIOS BBRAUN AS, CNPJ nº 31.673.254/0010-95. Dispensa nº 55/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE SOLUÇÕES. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 16/06/2026. Signatário: Pela Contratada: REGINA SANTOS AMMIRATTI, na qualidade de procuradora.

EXTRATO DO TERMO DE ACEITE Nº 1.459/2026 Processo: 04016-00069147/2026-43. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA MAEVE PRODUTOS HOSPITALARES LTDA, CNPJ nº 09.034.672/0003-54. Dispensa nº 55/2026. Objeto: AQUISIÇÃO EMERGENCIAL DE SOLUÇÕES. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 16/06/2026. Signatário: Pela Contratada: TOMAZ LOBO DE MELLO FERNANDES, na qualidade de Representante Legal.

EXTRATO DO TERMO DE ACEITE Nº 1.462/2026 Processo: 04016-00028824/2026-73. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF e EMPRESA MEDPLUS HOSPITALAR COMERCIO E SERVIÇOS LTDA, CNPJ nº 34.075.280/0001-19. Dispensa nº 10396/2026. Objeto: AQUISIÇÃO DE CABO DE ECG COMP. C/ MONITOR LIFEMED M15. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Assinatura: 17/06/2026. Signatário: Pelo Contratado: LUCAS OLIVEIRA PEIXOTO, na qualidade de Representante Legal.

EXTRATO DO PRIMEIRO TERMO ADITIVO AO CONTRATO Nº 441/2025 Processo: 04016-00028991/2025-33. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, CNPJ nº 28.481.233/0001-72 e a PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALARES LTDA, CNPJ nº 81.706.251/0001-98. Objeto: Prorrogação do prazo de vigência para a entrega de saldo remanescente do CONTRATO nº 441/2025, por mais 12 (doze) meses, a contar de 09 de junho de 2026 a 09 de junho de 2027 e acréscimo no percentual de aproximadamente 24,55% do valor inicial atualizado do CONTRATO Nº 441/2025. Do Valor total do acréscimo: R$ 958,50 (novecentos e cinquenta e oito reais e cinquenta centavos) e Do Valor total remanescente, incluído o acréscimo contratual: R$ 2.094,50 (dois mil noventa e quatro reais e cinquenta centavos), assinado em 09/06/2026. Da Ratificação: Ficam mantidas as demais cláusulas e condições constantes do instrumento originário. Signatários: pelo INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina e pela contratada: JEFERSON CAMPOS MASTALER, na qualidade de procurador.

DIRETORIA VICE-PRESIDÊNCIA

EXTRATO DO CONTRATO Nº 106/2026 Processo: 04016-00031234/2026-28. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e CAPACITACAO LEGAL - TREINAMENTOS

LTDA, CNPJ nº 42.818.048/0001-51. Objeto: CONTRATAÇÃO DE LICENÇA DE USO DE PLATAFORMA ELETRÔNICA ESPECIALIZADA EM PESQUISA, ANÁLISE E COMPARAÇÃO DE PREÇOS PRATICADOS NA ADMINISTRAÇÃO PÚBLICA. Do Valor Total da Contratação: R$ 24.000,00 (vinte e quatro mil reais), assinado em 16/06/2026. Da Vigência: será de 12 (doze) meses, a partir da data de sua assinatura, podendo ser prorrogado por até 60 meses. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: RUBENS DE OLIVEIRA PIMENTEL JÚNIOR, na qualidade de Diretor Vice-Presidente; Pelo Contratado: RUBEMAR BARBOSA DOS REIS, na qualidade de Representante Legal.

EXTRATO DO TERMO DE RESCISÃO AMIGÁVEL AO CONTRATO Nº 664/2025 Processo: 04016-00077447/2025-15. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, CNPJ nº 28.481.233/0001-72 e a SANTISA LABORATORIO FARMACEUTICO S.A, CNPJ nº 04.099.395/0001-82. Objeto: RESCISÃO AMIGÁVEL DO CONTRATO nº 664/2025, assinado em 09/06/2026. Signatários: representado por seu Diretor Vice-Presidente, o Senhor RUBENS DE OLIVEIRA PIMENTEL JUNIOR, e por seu Diretor de Infraestrutura, Logística e Obras, o Senhor MARCOS DUTRA VARGAS, Pela Contratada: representada por seu Representante Legal, Senhor JOÃO PEDRO FILGUEIRA GUIMARAES PENNA.

EXTRATO DO SEGUNDO TERMO ADITIVO AO CONTRATO Nº 965/2024 Processo: 04016-00114869/2023-17. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, CNPJ nº 28.481.233/0001-72 e a TOP MED IMPORTAÇÃO E DISTRIBUIÇÃO LTDA, CNPJ nº 11.172.836/0003-51. Objeto: a) prorrogação do prazo de vigência para a entrega do saldo remanescente do CONTRATO Nº 965/2024, por mais 6 (seis) meses, a contar de 18 de junho de 2026 a 18 de dezembro de 2026; b) Inclusão de Cláusula de Rescisão a Termo. Do Valor Total da Contratação: R$ 601.466,30 (seiscentos e um mil quatrocentos e sessenta e seis reais e trinta centavos), assinado em 18/06/2026. Da Ratificação: Ficam mantidas as demais cláusulas e condições constantes do instrumento originário. Signatários: pelo INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, RUBENS DE OLIVEIRA PIMENTEL JÚNIOR, na qualidade de Diretor Vice-Presidente e BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras – Interina; Pelo Contratado: FERNANDO GOULART DE CARVALHO CAMPOS, na qualidade de Representante Legal.

DIRETORIA DE INFRAESTRUTURA, LOGÍSTICA E OBRAS

EXTRATO DO CONTRATO Nº 86/2026 Processo: 04016-00170699/2025-12. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e DMI MATERIAL MEDICO HOSPITALAR LTDA, CNPJ nº 37.109.097/0001-85. Objeto: AQUISIÇÃO DE FIOS CIRÚRGICOS. Do Valor Total da Contratação: R$ 6.087,36 (seis mil oitenta e sete reais e trinta e seis centavos), assinado em 12/06/2026. Da Vigência: será de 12 (doze) meses ou até a entrega total do objeto, o que ocorrer primeiro, a partir da data de sua assinatura. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina; Pelo Contratado: LUIZ AMÂNCIO ROSA, na qualidade de Procurador.

EXTRATO DO CONTRATO Nº 87/2026 Processo: 04016-00170699/2025-12. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e BIOLINE FIOS CIRURGICOS LTDA, CNPJ nº 37.844.479/0002-33. Objeto: AQUISIÇÃO DE FIOS CIRÚRGICOS. Do Valor Total da Contratação: R$ 46.851,84 (quarenta e seis mil oitocentos e cinquenta e um reais e oitenta e quatro centavos), assinado em 12/06/2026. Da Vigência: será de 12 (doze) meses ou até a entrega total do objeto, o que ocorrer primeiro, a partir da data de sua assinatura Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina; Pelo Contratado: JOSÉ ALBERTO DA LUZ MOTA, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 88/2026 Processo: 04016-00170699/2025-12. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e SUTCARE LTDA, CNPJ nº 61.771.120/0001- 87. Objeto: AQUISIÇÃO DE FIOS CIRÚRGICOS. Do Valor Total da Contratação: R$ 110.937,60 (cento e dez mil novecentos e trinta e sete reais e sessenta centavos), assinado em 12/06/2026. Da Vigência: será de 12 (doze) meses ou até a entrega total do objeto, o que ocorrer primeiro, a partir da data de sua assinatura. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina; Pelo Contratado: GUSTAVO DE MIRANDA RIBEIRO, na qualidade de Representante Legal.

EXTRATO DO SEGUNDO TERMO ADITIVO AO CONTRATO Nº 544/2024 Processo: 04016-00098893/2022-11. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, CNPJ nº 28.481.233/0001-72 e a ROCHE DIAGNOSTICA BRASIL LTDA, CNPJ nº 30.280.358/0006-90. Objeto: a) prorrogação do prazo de vigência para a entrega do saldo remanescente do CONTRATO

<!-- pagina 62 -->

Nº 544/2024, por mais 12 (doze) meses ou até a entrega total do objeto, a contar de 13 de junho de 2026 a 13 de junho de 2027; b) Reajuste do CONTRATO Nº 544/2024, com base no Índice Nacional de Preços ao Consumidor Amplo (IPCA/IBGE), de aproximadamente 5,52973%, correspondente ao período de maio de 2024 a abril de 2025; c) Inclusão da cláusula de rescisão a termo. Do Valor Remanescente Estimado: R$ 267.696,73 (duzentos e sessenta e sete mil seiscentos e noventa e seis reais e setenta e três centavos), assinado em 15/06/2026. Da Ratificação: Ficam mantidas as demais cláusulas e condições constantes do instrumento originário. Signatários: pelo INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL - IGESDF, BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras – Interina; Pelos Contratados: ADRIANO JOSE RODRIGUES e RODRIGO SANTOS DE SOUZA, na qualidade de Procuradores.

EXTRATO DO TERMO DE RESCISÃO AMIGÁVEL AO CONTRATO Nº 658/2025 Processo: 04016-00032427/2025-15. Partes: Instituto de Gestão Estratégica de Saúde do Distrito Federal - IGESDF, CNPJ nº 28.481.233/0001-72 e a AGLMED PRODUTOS E EQUIPAMENTOS HOSPITALARES LTDA, CNPJ nº 47.853.686/0001-27. Objeto: RESCISÃO AMIGÁVEL AO CONTRATO Nº 658/2025, assinado em 17/06/2026. Signatários: Pelo Distratante: BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina; Pelo Distratado: GLELBERSON LUIS LEOPOLDINO BERTANTE, na qualidade de Representante Legal.

EXTRATO DA ATA DE REGISTRO DE PREÇOS Nº 183/2026 Processo: 04016-00102952/2025-13. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e BIO INFINITY COMERCIO HOSPITALAR E LOCACAO LTDA. CNPJ nº 03.679.808/0001-35. Objeto: AQUISIÇÃO DE SENSOR DE OXIMETRIA ADULTO. Valor Total da Contratação: R$ 2.376,00 (dois mil trezentos e setenta e seis reais), assinado em 30/01/2026. Vigência: será de 12 (doze) meses, a partir da data de sua assinatura, podendo ser prorrogada por igual período, pelo mesmo quantitativo inicialmente contratado, desde que tenha saldo remanescente, e mediante concordância expressa do fornecedor e comprovada a vantajosidade para o IGESDF. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: MARCOS DUTRA VARGAS, na qualidade de Diretor de Infraestrutura, Logística e Obras; pela Contratada: CLAUDIA CRISTINA CORREA CESAR, na qualidade de Representante Legal.

EXTRATO DA ATA DE REGISTRO DE PREÇOS N° 518/2026 Processo: 04016-00127309/2025-94. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e AGW COMEX HOSPITALAR LTDA, CNPJ n° 21.333.449/0001-41. Objeto: AQUISIÇÃO DE SENSORES DE TEMPERATURA. Valor Total Estimado: R$ 53.988,00 (cinquenta e três mil novecentos e oitenta e oito reais), assinado em 12/06/2026. Vigência: 12 (doze) meses, a partir da data de sua assinatura, podendo ser prorrogada por igual período, pelo mesmo quantitativo inicialmente contratado, desde que tenha saldo remanescente, e mediante concordância expressa do fornecedor e comprovada a vantajosidade para o IGESDF. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: BÁRBARA LIRA FREITAS SANTOS, na qualidade de Diretora de Infraestrutura, Logística e Obras - Interina; pela Contratada: ALEXCILENIO FROTA ARAUJO, na qualidade de representante legal.

EXTRATO DA ATA DE REGISTRO DE PREÇOS N° 521/2026 Processo: 04016-00132063/2025-72. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e MEDTREM MATERIAIS E EQUIPAMENTOS HOSPITALARES LTDA, CNPJ n° 57.370.564/0001-33. Objeto: AQUISIÇÃO DE ITENS DE ALMOXARIFADO. Valor Total Estimado: R$ 3.750,00 (três mil setecentos e cinquenta reais), assinado em 12/06/2026. Vigência: 12 (doze) meses, a partir da data de sua assinatura, podendo ser prorrogada por igual período, pelo mesmo quantitativo inicialmente contratado, desde que tenha saldo remanescente, e mediante concordância expressa do fornecedor e comprovada a vantajosidade para o IGESDF. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: representado por sua Diretora de Infraestrutura, Logística e Obras - Interina, Sra. BÁRBARA LIRA FREITAS SANTOS; pela Contratada: PEDRO DORNAS CIPRIANI, na qualidade de representante legal.

DIRETORIA DE ATENÇÃO À SAÚDE

EXTRATO DO CONTRATO Nº 96/2026 Processo: 04016-00024451/2025-81. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e CIRURGICA SAO FELIPE PRODUTOS PARA SAUDE LTDA, CNPJ nº 07.626.776/0001-60. Objeto: AQUISIÇÃO DE ELETROCARDIÓGRAFO. Valor Total da Contratação: R$ 19.000,00 (dezenove mil reais), assinado em 10/06/2026. Vigência: será de 24 (vinte e quatro) meses a partir da assinatura do contrato, podendo ser prorrogado por igual período. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: EDSON GONÇALVES FERREIRA JUNIOR, na qualidade de Diretor de Atenção à Saúde; Pela Contratada: MARISTELA BELOTTO PELOZZO, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 97/2026 Processo: 04016-00103391/2021-38. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e BRAKKO COMERCIO E IMPORTACAO LTDA, CNPJ nº 01.085.207/0001-79. Objeto: AQUISIÇÃO DE NASOFIBROSCÓPIO FLEXÍVEL. Valor do Contrato: R$ 73.074,00 (setenta e três mil setenta e quatro reais), assinado em 10/06/2026. Vigência: 24 (vinte e quatro) meses a partir da data de sua assinatura, podendo ser prorrogado por igual período Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: EDSON GONCALVES FERREIRA JUNIOR, na qualidade de Diretor de Atenção à Saúde; pela Contratada: MARCELLO DE ALMEIDA CHAGAS, na qualidade de representante legal.

EXTRATO DO CONTRATO Nº 99/2026 Processo: 04016-00004714/2024-54. Partes: INSTITUTO DE GESTÃO ESTRATÉGICA DE SAÚDE DO DISTRITO FEDERAL e MEDIFARR PRODUTOS PARA A SAUDE LTDA, CNPJ nº 07.540.203/0001-10. Objeto: AQUISIÇÃO DE MESA CIRÚRGICA ELÉTRICA. Valor Total da Contratação: R$ 162.000,00 (cento e sessenta e dois mil reais), assinado em 10/06/2026. Vigência: será de 24 (vinte e quatro) meses a partir da assinatura do contrato, podendo ser prorrogado por igual período. Fundamento Legal: Na forma do Regulamento Próprio de Compras e Contratações do IGESDF. Signatários: Pelo Contratante: EDSON GONÇALVES FERREIRA JUNIOR, na qualidade de Diretor de Atenção à Saúde; Pelo Contratado: RENATO MAROLDI SAVISKI, na qualidade de Representante Legal.

## SECRETARIA DE ESTADO DE EDUCAÇÃO

EDITAL Nº 27, DE 19 DE JUNHO DE 2026 RETIFICAÇÃO DO EDITAL Nº 49, DE 11 DE DEZEMBRO DE 2025, REFERENTE

AO PROCESSO SELETIVO SIMPLIFICADO PARA CONTRATAÇÃO TEMPORÁRIA DE PROFESSOR SUBSTITUTO PARA A REDE PÚBLICA

DE ENSINO DO DISTRITO FEDERAL A SECRETÁRIA DE ESTADO DE EDUCAÇÃO DO DISTRITO FEDERAL, interina, no uso das atribuições legais, torna pública a retificação do Edital nº 49, de 11 de dezembro de 2025, publicado no Suplemento do Diário Oficial do Distrito Federal nº 235, em 12 de dezembro de 2025, referente ao resultado final e homologação do Processo Seletivo Simplificado destinado a selecionar candidatos a professor substituto temporário para integrar o Banco de Reservas da Secretaria de Estado de Educação do Distrito Federal, regido pelo Edital nº 36, publicado no Diário Oficial do Distrito Federal nº 160, em 26 de agosto de 2025, conforme as alterações a seguir, permanecendo inalterados os demais itens e subitens. a) eliminação, na forma do §2º do art. 2º da Lei nº 6.741/2020, bem como do subitem 14.11.6.1 do Edital nº 36, da candidata ELIZIANE ALVES GOMES, inscrição nº 733000012981, cargo de Professor de Educação Básica – Pedagogia, Coordenação Regional de Ensino de Samambaia, turno diurno, classificada na lista de ampla concorrência na posição 1.583ª e na lista de vagas reservadas às pessoas hipossuficientes na posição 43ª. Em razão dessa eliminação, os candidatos originalmente classificados, na mesma área de formação, Coordenação Regional de Ensino e turno, classificados após a 1.583ª colocação na lista de ampla concorrência e após a 43ª colocação na lista de pessoas hipossuficientes passam a ocupar a posição imediatamente superior na ordem classificatória, para fins de composição do Banco de Reservas da Educação Básica; b) eliminação, na forma do §2º do art. 2º da Lei nº 6.741/2020, bem como do subitem 14.11.6.1 do Edital nº 36, da candidata LUCIANA RODRIGUES DOS SANTOS, inscrição nº 733000004344, cargo de Professor de Educação Básica – Pedagogia, Coordenação Regional de Ensino de Taguatinga, turno diurno, classificada na lista de ampla concorrência na posição 678ª e na lista de vagas reservadas às pessoas hipossuficientes na posição 7ª. Em razão dessa eliminação, os candidatos originalmente classificados, na mesma área de formação, Coordenação Regional de Ensino e turno, classificados após a 678ª colocação na lista de ampla concorrência e após a 7ª colocação na lista de pessoas hipossuficientes passam a ocupar a posição imediatamente superior na ordem classificatória, para fins de composição do Banco de Reservas da Educação Básica.

IÊDES SOARES BRAGA

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

UNIDADE DE GESTÃO E ACOMPANHAMENTO

DAS LICITAÇÕES E AJUSTES COMISSÃO PERMANENTE DE LICITAÇÃO

AVISO DE RESULTADO DE LICITAÇÃO PREGÃO ELETRÔNICO Nº 90006/2026 - (UASG 450432) O Pregoeiro da Secretaria de Estado de Educação do Distrito Federal (SEEDF) vem comunicar aos interessados que, após a conclusão do Pregão Eletrônico n.º 90006/2026, processo SEI n.º 00080-00094200/2026-74, que tem por objeto a contratação de empresa especializada na prestação dos serviços de eventos destinados arealização do III ENCONTRO DOS CONSELHOS DE ALIMENTAÇÃO ESCOLAR DA REGIÃO CENTRO - OESTE, sagrou-se vencedora do certame a licitante NAUL EVENTOS LTDA, inscrita no CNPJ sob nº 30.481.176/0001-73, pelo valor total de R$ 97.555,50

<!-- pagina 63 -->

(noventa e sete mil quinhentos e cinquenta e cinco reais e cinquenta centavos). O presente resultado, juntamente com a documentação, decisões e análises pertinentes, estão disponíveis nos sites: https://www.gov.br/compras/pt-br e https://www.educacao.df.gov.br/pregao-eletronico/.

CAIO CAMILO SANTOS

## SECRETARIA DE ESTADO DE SEGURANÇA PÚBLICA

### POLÍCIA MILITAR DO DISTRITO FEDERAL

DEPARTAMENTO DE GESTÃO DE PESSOAL

EDITAL Nº 92/2026-DGP/PMDF, DE 17 DE JUNHO DE 2026 (*)

EDITAL DE REINTEGRAÇÃO DEFINITIVA CONCURSO PÚBLICO DE ADMISSÃO AO CURSO DE FORMAÇÃO DE PRAÇAS

EDITAL DE ABERTURA Nº 04/2023 - DGP/PMDF O CHEFE DO DEPARTAMENTO DE GESTÃO DE PESSOAL, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso de suas atribuições legais, conferidas por meio do inciso VI do artigo 1º da Portaria PMDF nº 670, de 3 de junho de 2009, mediante as condições estipuladas neste edital e nas demais disposições legais aplicáveis, TORNA PÚBLICO O EDITAL DE REINTEGRAÇÃO DEFINITIVA, referente ao concurso público aberto pelo Edital nº 04/2023 – DGP/PMDF, conforme as disposições a seguir: 1. Em cumprimento à decisão judicial transitada em julgado proferida nos autos do processo nº 0716382-64.2024.8.07.0018, fica retirada a condição de sub judice da candidata THABATA CRISTINA BARBOSA DE CARVALHO, inscrição nº 4630034611.

ROSIVAN CORREIA DE SOUZA – CEL QOPM ___________________ (*) Republicado por ter saído com incorreção, publicado no DODF nº 111, de 19 de junho de 2026, página 78.

EDITAL Nº 93/2026 - DGP/PMDF, DE 18 DE JUNHO DE 2026 EDITAL DE RESULTADO DA SINDICÂNCIA DA VIDA PREGRESSA

E INVESTIGAÇÃO SOCIAL DE CANDIDATAS SUB JUDICES CONCURSO PÚBLICO DE ADMISSÃO AO CURSO DE FORMAÇÃO DE PRAÇAS

EDITAL DE ABERTURA Nº 04/2023 - DGP/PMDF O CHEFE DO DEPARTAMENTO DE GESTÃO DE PESSOAL, DA POLÍCIA MILITAR DO DISTRITO FEDERAL, no uso de suas atribuições legais, que lhe são conferidas no inciso VI do artigo 1º da Portaria PMDF nº 670, de 03 de junho de 2009, mediante as condições estipuladas neste Edital e demais disposições legais aplicáveis, TORNA PÚBLICO o Edital de Resultado da Sindicância da Vida Pregressa e Investigação Social de candidatas sub juices, para o Concurso Público regido pelo Edital Nº 04/2023 - DGP/PMDF, conforme as seguintes disposições: 1- Fica divulgado o resultado da Avaliação da Vida Pregressa e da Investigação Social das candidatas sub judice que não foram eliminadas em outras fases do certame e que foram consideradas INDICADAS: Amanda De Jesus Barboza (Sub Judice), inscrição nº 4630001534; Amanda De Oliveira Gonçalves (Sub Judice), inscrição nº 4630020875; Amanda Montalvão Souza (Sub Judice), inscrição nº 4630008857; Ana Carolina Valeriano Guerreiro (Sub Judice), inscrição nº 4630028000; Ana Gabriela De Araujo Cordeiro (Sub Judice), inscrição nº 4630003106; Ana Júlia Lopes Pires (Sub Judice), inscrição nº 4630003687; Ana Karlla Francisco de Oliveira (Sub Judice), inscrição nº 4630038948; Ana Paula Fernandes De Sousa (Sub Judice), inscrição nº 4630001862; Ana Paula Gouveia Carneiro (Sub Judice), inscrição nº 4630049117; Andressa De Paula Gomes Dos Santos (Sub Judice), inscrição nº 4630005683; Andressa Lima Duarte Santos (Sub Judice), inscrição nº 4630009975; Beatriz Aragão Pavão De Mendonça (Sub Judice), inscrição nº 4630045280; Bruna Borges De Resende Freitas (Sub Judice), inscrição nº 4630041628; Camila da Silva Gomes (Sub Judice), inscrição nº 4630001601; Camila Rosa De Souza Lima (Sub Judice), inscrição nº 4630009355; Gabriella Divina dos Santos Carvalho (Sub Judice), inscrição nº 4630029911; Laís Priscila De Sousa Pinto (Sub Judice), inscrição nº 4630010896; Laísla Neri Alves (Sub Judice), inscrição nº 4630009164; Laryssa Santos Souza (Sub Judice), inscrição nº 4630032039; Laura Caetano Mota (Sub Judice), inscrição nº 4630037174; Lorena Gameiro Azevedo* (Sub Judice), inscrição nº 4630025961; Maralice Santos De Melo (Sub Judice), inscrição nº 4630022860; Maria Luana Silva De Araújo França (Sub Judice), inscrição nº 4630038624; Mariana Botazini Pereira Nery (Sub Judice), inscrição nº 4630005062; Marina Marilia Mendes Cruz (Sub Judice), inscrição nº 4630013171; Pyetra Santiago de Melo (Sub Judice), inscrição nº 4630000886; Renata Glauciene Antunes Soares Borges (Sub Judice), inscrição nº 4630005748. *Candidata com etapa pendente em razão de situação gestacional. 2- Em razão de todas as candidatas terem sido consideradas indicadas, fica dispensado o prazo recursal, tornando-se definitivo o resultado desta etapa.

ROSIVAN CORREIA DE SOUZA – CEL QOPM

### CORPO DE BOMBEIROS MILITAR

SUBCOMANDO GERAL DEPARTAMENTO DE ADMINISTRAÇÃO,

LOGÍSTICA E FINANCEIRA DIRETORIA DE CONTRATAÇÕES E AQUISIÇÕES

EXTRATO DO CONTRATO Nº 54/2026

AQUISIÇÃO DE BENS Processo: 00053-00009898/2026-68. Partes: CBMDF X BEMFRIO SERVICOS LTDA, CNPJ nº 26.077.955/0001-30. Objeto: contratação de empresa especializada para prestação de serviços de manutenção preventiva e corretiva (incluindo peças e recarga de gás), desinstalação e instalação de aparelhos de ar condicionado, que se encontram fora do prazo de garantia. UO:170394. PT:250002. ND:339039. FR:100- (FCDF). Valor do Contrato R$ 464.400,00; conforme NE nº280, emitida em 28/04/2026. Vigência de 12meses. Fundamento Legal: Pregão Eletrônico n. 90087/2025 - COLIC/SCG/SECONT/SEEC. Assinatura: 16/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Bruno Araujo dos Passos, na qualidade de Representante Legal.

EXTRATO DO CONTRATO DE CREDENCIAMENTO Nº 56/2026

PRESTAÇÃO DE SERVIÇOS Processo: 00053-00111990/2025-14. Partes: CBMDF X CLÍNICA DE OFTALMOLOGIA PEDIÁTRICA JOÃO CARLOS LTDA, CNPJ nº 01.611.888/0001-61. Objeto: Prestação de serviços de oftalmologia. UO: 73901. PT: 28845090300FM0053. ND: 339039. FR: 100 (FCDF). O empenho inicial é de R$ 1,00 (Um real), conforme Notas de Empenho nº 01/2026 e nº 02/2026, emitidas em 07/01/2026, na modalidade ESTIMATIVA. Vigência de 60 (sessenta) meses, a contar da data de assinatura. Fundamento Legal: Inexigibilidade de Licitação nº 42/2026. Assinatura: 12/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: João Carlos Cendron, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 56/2026

AQUISIÇÃO DE BENS Processo:00053-00089024/2024-14. Partes: CBMDF X 36.068.602 ELTON FERREIRA DO PRADO - ME, CNPJ nº 36.068.602/0001-28. Objeto: Contratação de empresa especializada para fornecimento contínuo de peças (sob demanda) e realização de serviço contínuo de manutenção preventiva e corretiva para 03 equipamentos autoclaves da marca Phoenix Luferco e seus componentes, pertencentes às Policlínicas Médica (POMED) e Odontológica (PODON). UO:170495. PT:89304. ND:339039. FR:100- (FCDF). Valor do Contrato R$ 230.515,11; conforme NE nº 187, emitida em21/05/2026. Vigência de 30 meses. Fundamento Legal: Pregão Eletrônico n.90012/2026. Assinatura: 16/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Elton Ferreira do Prado, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 63/2025

AQUISIÇÃO DE BENS Processo: 00053-00049399/2026-11. Partes: CBMDF X INDÚSTRIA DE ÁGUA MINERAL IBIÁ LTDA, CNPJ nº 05.655.158/0001-13. Objeto: aquisição de 7.000 (sete mil) garrafões retornáveis com 20 (vinte) litros de água mineral natural ou água natural, sem gás, obtida diretamente de fontes naturais ou por extração de águas subterrâneas. UO: 170394. PT: 28.845.0903.00NR.0053. ND: 33.90.30. FR:100- (FCDF). Valor do Contrato R$ 23.100,00; conforme NE nº 348, emitida em 28/05/2026. Vigência de 12 meses. Fundamento Legal: Pregão Eletrônico nº 90060/2025 . Assinatura: 18/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Lucca Camalle Couto, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 64/2026

AQUISIÇÃO DE BENS Processo:00053-00125732/2025-15. Partes: CBMDF X ALMA CAMINHÕES LTDA, CNPJ nº 29.749.527/0001-03. Objeto: contratação de empresa para execução do serviço de fabricação de carroceria abertas de metal para 2 (dois) caminhões. UO:170394. PT:250002. ND:339030. FR:100- (FCDF). Valor do Contrato R$ 61.000,00; conforme NE nº 350, emitida em28/05/2026. Vigência de 12 meses. Fundamento Legal: Dispensa de Licitação n. 52/2026. Assinatura: 18/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Antônio Ribeiro de Souza Junior, na qualidade de Representante Legal.

EXTRATO DO CONTRATO Nº 68/2026

AQUISIÇÃO DE BENS Processo: C00053-00049255/2026-57. Partes: CBMDF X MI COMÉRCIO DE PRODUTOS HOSPITALARES E EQUIPAMENTOS LTDA, CNPJ nº 33.484.007/0001- 85. Objeto: aquisição de 480 (quatrocentos e oitenta) unidades de eletrodos adultos descartáveis multifuncionais para DEA. UO: 17394. PT: 28.845.0903.00NR.0053 . ND: 33.90.30. FR:100- (FCDF). Valor do Contrato R$ 719.520,00; conforme NE nº 358, emitida em 03/06/2026. Vigência de 12 meses. Fundamento Legal: Pregão Eletrônico nº

<!-- pagina 64 -->

90019/2026. Assinatura: 18/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Henrique Santos de Freitas, na qualidade de Representante Legal.

EXTRATO DO CONTRATO DE CREDENCIAMENTO Nº 76/2026

PRESTAÇÃO DE SERVIÇOS Processo: 00053-00091800/2025-27. Partes: CBMDF X INSTITUTO DE CATARATA DE BRASILIA LTDA, CNPJ nº 12.992.115/0001-99. Objeto: Prestação de serviços de oftalmologia. UO: 73901. PT: 28845090300FM0053. ND: 339039. FR: 100 (FCDF). O empenho inicial é de R$ 1,00 (Um real), conforme Notas de Empenho nº 01/2026 e nº 02/2026, emitidas em 07/01/2026, na modalidade ESTIMATIVA. Vigência de 60 (sessenta) meses, a contar da data de assinatura. Fundamento Legal: Inexigibilidade de Licitação nº 71/2026. Assinatura: 10/06/2026. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições e pela Contratada: Marcia Suely Akaishi, na qualidade de Representante Legal.

AVISO DE ADJUDICAÇÃO E HOMOLOGAÇÃO

PREGÃO ELETRÔNICO Nº 90039/2026 PROCESSO SEI Nº 00053-00121092/2025-66 - CBMDF. TIPO: Menor preço. OBJETO: Contratação de empresa especializada para o fornecimento de 26 (vinte e seis) licenças de software para edição de imagens, vídeos e editoração eletrônica por subscrição para o CBMDF, conforme Edital e anexos. O DICOA informa: a ADJUDICAÇÃO do objeto do item 1 à empresa MCR SISTEMAS E CONSULTORIA LTDA, CNPJ: 04.198.254/0001- 17, com o valor total de R$ 361.790,00; e, a HOMOLOGAÇÃO do resultado da licitação, com fulcro no inciso IV, art. 71, da Lei 14.133/21 c/c art.140 do Dec. Distrital. nº 44.330/23. Inf.: (61) 31930190.

ELCIO DE AZEVEDO CARDOSO - Cel. QOBM/Comb.

Diretor

EXTRATO DE NOTA DE EMPENHO Processo: 00053-00059696/2026-67. Nota de Empenho Ordinário, n.º 205, emitida em 03/06/2026. Contratada: SOCIAL INSTRUMENTOS CIRURGICOS LTDA., CNPJ: 41.306.823/0001-27, no valor de R$ 4.700,00. Objeto: Aquisição de instrumentais cirúrgicos diversos, incluindo caixas completas, conjuntos específicos e acessórios utilizados em procedimentos cirúrgicos e ambulatoriais (itens 1, 2 e 15 do PE nº 90023/2026- DICOA/DEALF/CBMDF). Fundamento Legal: Pregão Eletrônico nº 90023/2026 - DICOA/DEALF/CBMDF. Elemento de Despesa: 339030. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições.

EXTRATO DE NOTA DE EMPENHO Processo: 00053-00059791/2026-61. Nota de Empenho Ordinário, n.º 202, emitida em 02/06/2026. Contratada: MEDICAL CIRURGICA LTDA., CNPJ:60.683.786/0001-10, no valor de R$ 14.950,00. Objeto: Aquisição de instrumentais cirúrgicos diversos, incluindo caixas completas, conjuntos específicos e acessórios utilizados em procedimentos cirúrgicos e ambulatoriais (eletrodo para eletrocirurgia medcir – eletrodo leep meia alça tungstênio ref.lma3020-120). Item 51. Fundamento Legal: Pregão Eletrônico nº90023/2026- DICOA/DEALF/CBMDF. Elemento de Despesa: 339030. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições.

EXTRATO DE NOTA DE EMPENHO Processo: 053-00063626/2026-11. Nota de Empenho Ordinário, n.º 368, emitida em 15/06/2026. Contratada: ELITE FESTIVA EVENTOS E FESTAS LTDA., CNPJ: 51.073.622/0001-80, no valor de R$ 4.560,00. Objeto: Contratação de serviço de buffet para 150 pessoas "Capacitação para Contratações Anual e Sistema de Planejamento e Gerenciamento de Contratações".. Fundamento Legal: Pregão Eletrônico nº90014/2025 - PMDF. Elemento de Despesa: 339039. Signatários: Pelo Contratante: Cel. QOBM/Comb. Elcio de Azevedo Cardoso, Diretor de Contratações e Aquisições.

DEPARTAMENTO DE RECURSOS HUMANOS

EDITAL Nº 39/2026, DE 18 DE JUNHO DE 2026 – COMPLEMENTAR – SUB JUDICE

CONCURSO PÚBLICO PARA MATRÍCULA NO CURSO DE FORMAÇÃO

DE PRAÇAS BOMBEIROS MILITARES (CFPBM) NO QUADRO GERAL DE PRAÇAS NA QUALIFICAÇÃO BOMBEIRO MILITAR GERAL DE CONDUTOR

E OPERADOR DE VIATURAS DO CORPO DE BOMBEIROS MILITAR

DO DISTRITO FEDERAL O CHEFE DO DEPARTAMENTO DE RECURSOS HUMANOS, DO CORPO DE BOMBEIROS MILITAR DO DISTRITO FEDERAL, em exercício, no uso de suas atribuições legais, torna público, em cumprimento a determinação judicial nos autos do processo 0709192-73.2026.8.07.0020, o EDITAL de convocação para o TESTE DE APTIDÃO FÍSICA (TAF) – SUB JUDICE do concurso público para matrícula no Curso de Formação de Praças Bombeiros Militares (CFPBM), do Corpo de Bombeiros Militar do Distrito Federal, para provimento de vagas na graduação de Soldado Bombeiro Militar do Quadro Geral de Praças Bombeiros Militares na Qualificação Bombeiro Militar Geral de Condutor e Operador de Viaturas - QBMG-2, nos termos das Leis Federais nos 7.479/1986, 8.255/1991, 12.086/2009 e suas respectivas alterações posteriores e regulamentos; da Lei Distrital nº 4.949/2012.]

1. DAS DISPOSIÇÕES PRELIMINARES 1.1. Ficam convocados para a realização do Teste de Aptidão Física (TAF) os candidatos relacionados no Anexo II deste Edital. 1.2. O Teste de Aptidão Física (TAF) será realizado presencialmente nos dias 31 de outubro e 1º de novembro de 2026. O horário e o local de realização serão divulgados posteriormente, por meio de comunicado a ser publicado no site oficial do concurso. 1.3. Os candidatos convocados deverão comparecer ao local indicado no item 1.2 deste Edital com antecedência mínima de 1 (uma) hora do horário previsto para o início de sua avaliação, munidos de documento de identidade original (nos termos do subitem 17.14 do Edital de Abertura). 1.3.1. No caso de perda ou roubo do documento de identidade, o candidato deverá apresentar certidão que ateste o registro da ocorrência em órgão policial expedida há, no máximo, 30 (trinta) dias da data de entrega dos exames médicos e, ainda, ser submetido à identificação especial, consistindo na coleta de impressão digital, assinatura e fotografia. 1.4. Os candidatos convocados para o turno da tarde, com apresentação às 14h30, deverão comparecer para a realização dos procedimentos preliminares, incluindo identificação datiloscópica e demais trâmites de segurança. O TAF terá início somente após as 15h. 2. DO TESTE DE APTIDÃO FÍSICA (TAF) 2.1. O Teste de Aptidão Física - TAF será de caráter eliminatório e classificatório. 2.2. Serão convocados para o TAF, todos os candidatos aprovados e classificados nas provas objetivas e discursivas e não eliminados no procedimento de heteroidentificação e na avaliação biopsicossocial. 2.2.1. O TAF será realizado no Distrito Federal em data, horário e local, nos termos do edital de convocação a ser publicado de acordo com o item 28 do Edital de abertura. 2.3. O Teste de Aptidão Física tem por objetivo medir a capacidade mínima do candidato para suportar, física e organicamente, as exigências da prática de atividades físicas e demais exigências próprias do cargo. 2.4. O(A) candidato(a) será considerado(a), ao final do TAF, “apto(a)” ou “inapto(a)”. 2.4.1. Será considerado(a) “apto(a)” no Teste de Aptidão Física o(a) candidato(a) que atingir o desempenho mínimo no TAF, isto é, a nota mínima de 1,33 (uma vírgula trinta e três), considerando o atingimento das notas mínimas previstas para cada um dos exercícios que o compõem, conforme disposto no item 3 deste Edital. 2.4.2. Será considerado(a) “inapto” o(a) candidato(a) que não atingir a nota mínima de 1,33 (uma vírgula trinta e três) no TAF. 2.5. A nota final no Teste de Aptidão Física será calculada da forma descrita a seguir: a) a nota final do Teste de Aptidão Física (TAF) será calculada por meio de média aritmética: a soma da nota individual de cada exercício que compõe o TAF, dividido por 3 (três), conforme equação da alínea “b” do presente subitem; b) a equação para calcular a nota final do TAF será:

c) considerando que o candidato deve alcançar a nota mínima em cada um dos testes, e considerando a fórmula descrita no item anterior, a nota mínima a ser alcançada para classificação na etapa do Teste de Aptidão Física é de 1,33 (um vírgula trinta e três): [(2+1+1) / 3 = 1,33]. 2.6. Para a realização do TAF, o candidato deverá comparecer em data, local e horário divulgados neste edital de convocação, onde será submetido à identificação, com: a) bolsa contendo traje esportivo – camiseta; calção ou bermuda; tênis; traje para banho para o exercício de natação (sunga, para os candidatos do sexo masculino, maiô de peça única, para as candidatas do sexo feminino, toca para ambos os sexos e óculos opcional). b) documento de identidade original, de acordo com o determinado no subitem 17.14 do Edital de abertura; e c) atestado médico (original ou cópia autenticada em cartório), específico para tal fim, emitido há, no máximo, 30 (trinta) dias anteriores ao TAF, conforme modelo constante do Anexo I deste Edital. 2.6.1. É de inteira responsabilidade do candidato acompanhar a convocação, assim como seu comparecimento, em dia, hora e local corretos, conforme edital de convocação. 2.6.2. O candidato somente poderá realizar o TAF na data, horário, local e sala constantes do edital de convocação, não podendo ser alegado qualquer espécie de desconhecimento para justificar o seu atraso ou a sua ausência ou a sua apresentação em dia, horário ou local diferentes dos estabelecidos no edital de convocação. 2.6.3. Não será permitida a realização do TAF em local, data, horário ou turma diferentes do previsto no edital de convocação, com exceção de candidato com pedido de tratamento diferenciado por sua convicção religiosa, previamente deferido nos termos do item 11 do Edital de abertura. 2.6.4. Não haverá segunda chamada ou repetição de prova, seja qual for o motivo alegado para justificar o atraso ou a ausência do candidato. 2.6.5. Os candidatos ausentes no TAF serão eliminados do concurso público. 2.7. Os exercícios previstos para o TAF serão realizados em uma única oportunidade e tentativa. 2.7.1. Entre a realização de um exercício e outro, será respeitado um intervalo mínimo de 5 (cinco) minutos. 2.8. O aquecimento e/ou alongamento para realização dos exercícios físicos que compõem o TAF, serão de responsabilidade do candidato, não sendo permitido o acompanhamento de qualquer pessoa estranha ao certame.

<!-- pagina 65 -->

2.9. Não será fornecido lanche aos candidatos nem haverá lanchonete disponível no local de realização do teste de aptidão física, sendo permitido ao candidato levar seu próprio lanche. 2.10. Nenhum candidato poderá se retirar do local de realização do TAF sem a devida autorização dos membros do IDECAN. 2.11. O candidato deverá assinar a lista de presença e o "Termo de Responsabilidade do Candidato", fornecido no local do TAF. Esse termo não substitui a entrega do atestado médico, conforme o descrito no subitem 2.6 deste Edital. 2.12. O candidato deverá entregar antes da realização dos exercícios físicos, o atestado médico específico, emitido em período não superior a 30 (trinta) dias da realização dos testes físicos, no qual deverá constar expressamente que o candidato está “apto” para realizar os exercícios previstos neste certame, contendo local, data, nome e número do CRM do profissional médico que elaborou o atestado, os quais poderão ser certificados mediante carimbo do médico ou impresso eletrônico, tudo devidamente legível relativo ao médico que emitiu o atestado, acompanhado da assinatura do mesmo. 2.12.1. O atestado médico, de caráter eliminatório, comprova as condições físicas de saúde do candidato para que o mesmo possa ser submetido ao teste de capacidade física, não podendo conter no mesmo qualquer causa restritiva da realização do teste, sendo que a não comprovação das condições de saúde para a realização do exame de teste físico, resultará na consequente eliminação do candidato. 2.12.2. O atestado médico emitido digitalmente deverá ser apresentado e entregue de forma impressa, no dia do TAF. Deverá, ainda, conter a assinatura do profissional por certificação digital e o código de autenticação documental. 2.12.3. O candidato que não apresentar o atestado médico, conforme modelo contido no Anexo I deste Edital, ou apresentar atestado médico que não apresente, expressamente, que o candidato está apto a realizar o teste de aptidão física ou a realizar exercícios físicos vigorosos, será impedido de realizar o TAF, sendo, consequentemente, eliminado do concurso. 2.13. O candidato ao ingressar no local de realização do TAF, deverá manter qualquer aparelho eletrônico que esteja em sua posse acondicionado em invólucro indicado pelo IDECAN, mantendo-o desligado, ainda que o sinal de alarme esteja no modo vibração ou silencioso. 2.14. Os objetos pessoais dos candidatos, tais como bolsas, utensílios, sacolas ou similares ficarão em local indicado pela equipe do IDECAN, responsável pela realização do TAF, sendo permitido apenas a utilização de equipamentos que permitam sua hidratação durante a realização dos exercícios físicos. 2.15. Para a segurança dos candidatos e a garantia da lisura do certame, todos os candidatos deverão se submeter à identificação datiloscópica, bem como a outros procedimentos de segurança, se julgados necessários pela Organizadora, no dia de realização do TAF. Poderá ainda ser solicitada, em momento posterior ao TAF, nova identificação datiloscópica, excepcionalmente, a critério da Comissão de Acompanhamento do Concurso. 2.15.1. Caso o candidato esteja impedido fisicamente de colher a impressão digital do polegar direito, deverá ser colhida a digital do polegar esquerdo ou de outro dedo, sendo registrado o fato no Termo de Ocorrência. 2.16. No dia de realização do TAF, o IDECAN poderá submeter os candidatos, quantas vezes forem necessárias, ao sistema de detecção de metais, a fim de verificar se o candidato está portando material não permitido. 2.17. Caso as condições meteorológicas ou outro fato de força maior não permitam ou coloquem em risco a realização do TAF, o IDECAN, em consonância com a Comissão de Acompanhamento do Concurso, poderá interromper e/ou cancelar a realização dos testes físicos, com o objetivo de garantir a integridade física dos candidatos, evitando prejuízos ao seu desempenho. 2.18. Os candidatos que apresentarem casos de alteração psicológica e/ou fisiológica temporários (estado menstrual, cãibras, indisposições, contusões, luxações, fraturas etc.), que venham a impossibilitar a realização do TAF, não serão levados em consideração, para qualquer tipo de tratamento diferenciado. 2.19. À candidata que, no dia da realização do TAF, apresentar atestado médico que comprove seu estado de gravidez ou puerperal, será facultada nova data para a realização desta etapa. 2.19.1. A candidata que, no dia da realização do TAF, apresentar atestado médico que comprove seu estado de gravidez, será facultada nova data para a realização da etapa, após 120 (cento e vinte) dias, a contar da data do parto ou do fim do período gestacional (no caso de aborto), de acordo com a conveniência do CBMDF, sem prejuízo da participação nas demais etapas do concurso. 2.19.2. A candidata deverá comparecer ao local, na data e no horário de realização do TAF, munida de atestado médico original ou cópia autenticada em cartório, no qual deverá constar, expressamente, o estado de gravidez ou puerperal, o período gestacional em que se encontra, a data provável do parto, bem como a data, a assinatura, o carimbo e o CRM do profissional que o emitiu. 2.19.3. O atestado médico deverá ser entregue no momento de identificação da candidata para a realização do TAF, não sendo aceita a entrega em outro momento. 2.19.4. A candidata que não entregar o atestado médico citado no subitem 2.19.2 deste Edital, e se recusar a realizar o TAF, alegando estado de gravidez ou puerperal, será eliminada do concurso. 2.19.5. A candidata que apresentar o atestado médico que comprove estado de gravidez ou puerperal e, ainda assim, desejar realizar o TAF, deverá apresentar atestado médico em que conste, expressamente, que a candidata está apta a realizar o TAF e/ou a realizar todos os exercícios físicos que o compõem.

2.19.6. A candidata deverá apresentar ao IDECAN, por meio do correio eletrônico atendimento@idecan.org.br, no prazo de 30 (trinta) dias após a realização do seu parto ou do fim do seu período gestacional (no caso de aborto), novo atestado médico no qual deverá constar, expressamente, o dia do nascimento ou aborto, assinatura, carimbo e CRM do médico que o emitiu. 2.19.7. A candidata que deixar de apresentar qualquer um dos atestados médicos previstos nos subitens 2.19.2 e 2.19.6 deste Edital, ou que apresentá-los em desconformidade com os subitens 2.19.2 a 2.19.6 deste Edital, será eliminada do concurso. 2.19.8. Os atestados médicos apresentados serão retidos pelo IDECAN e, em hipótese alguma, serão fornecidas cópias à candidata. 2.19.9. Caso a candidata seja eliminada nas etapas posteriores ao TAF, será automaticamente eliminada do concurso, perdendo o direito de realizar o TAF no prazo previsto no subitem 2.19.1 deste Edital. 2.19.10. As candidatas enquadradas no disposto no subitem 2.19 deste Edital serão convocadas para a realização do TAF por meio de edital específico. A data de convocação respeitará o período especificado no subitem 2.19.1 deste Edital. 2.20. O TAF consistirá em 03 (três) exercícios de aptidão física, todos de realização obrigatória, independentemente do desempenho do candidato em cada um deles. 2.20.1. O candidato que se recusar a realizar algum dos 03 (três) exercícios que compõem o TAF, deverá assinar termo de desistência do exercício que não será realizado, sendo, portanto, eliminado do concurso. 2.21. O TAF consistirá em submeter o candidato aos exercícios a seguir elencados, a serem realizados na sequência ora apresentada: a) Teste Dinâmico de Barra Fixa (sexos masculino e feminino); b) Corrida de 2.400 metros (sexos masculino e feminino); e c) Natação de 100 metros (sexos masculino e feminino). 2.21.1. Os testes serão aplicados de forma sequencial e em um mesmo dia, todos de realização obrigatória, independentemente do desempenho do candidato em cada um deles, observando-se a ordem estabelecida no subitem 2.21 deste Edital, com intervalo mínimo de 5 (cinco) minutos entre cada teste. 2.22. O candidato que realizar o TAF só conhecerá o resultado do referido exame por meio da divulgação do resultado preliminar desta etapa. 2.23. Todos os exercícios que compõem o TAF serão gravados em vídeo pela banca organizadora. 2.23.1. O candidato que se recusar a ter os seus exercícios gravados em vídeo será eliminado do concurso. 2.24. O candidato que infringir qualquer proibição prevista neste Edital, independentemente do resultado no TAF, será eliminado do concurso. 2.25. Caberá ao IDECAN formar e contratar a banca examinadora, composta de profissionais devidamente registrados no Conselho Regional de Educação Física (CREF), com habilitação plena em Educação Física. 2.26. Não haverá adaptação do TAF às condições do candidato, de modo que não ocorrerá tratamento diferenciado a nenhum candidato, independentemente das circunstâncias alegadas ou de situações que impossibilitem, diminuam ou limitem a capacidade física e(ou) orgânica do candidato, ocasionadas antes ou durante a realização do exame de aptidão física, ou seja, o candidato deverá realizar os testes de acordo com o previsto no edital de abertura e de convocação. 2.27. Será considerado “inapto” no TAF e, consequentemente, eliminado do concurso público, o candidato que: a) não apresentar o atestado médico específico, conforme subitem 2.6 e o modelo constante do Anexo I deste Edital; b) deixar de realizar algum dos exercícios que compõem o TAF, nos termos do subitem 2.21 deste Edital; c) não comparecer para a realização do TAF; d) infringir qualquer proibição prevista neste Edital e/ou no edital de convocação para a etapa, independentemente do resultado alcançado no TAF; ou e) não obter o desempenho mínimo em qualquer um dos três exercícios, nos termos do subitem 2.4.1 deste Edital. 2.28. As dúvidas, as controvérsias e os casos não previstos neste Edital, acerca do TAF, serão esclarecidos juntamente à Comissão do Concurso e ao IDECAN, no que couber. 2.28.1. Os imprevistos ocorridos durante a realização do TAF serão dirimidos pelo coordenador da banca examinadora, em conjunto com a Comissão de Acompanhamento do Concurso. 2.29. A critério da Administração Pública, a realização do TAF poderá ser remarcada, desde que devidamente justificada. 2.30. Os resultados preliminar e definitivo desta etapa serão publicados na forma prevista no item 28 do edital de abertura e na data prevista no último cronograma publicado. 2.30.1. O candidato poderá interpor recurso contra referido resultado preliminar no prazo previsto no cronograma vigente, por meio de sua Área de Candidato acessível pelo endereço eletrônico www.idecan.org.br, atentando-se ao disposto no item 25 do Edital de abertura. 3. DA DESCRIÇÃO E DOS PROCEDIMENTOS DOS EXERCÍCIOS QUE COMPÕEM O TAF 3.1. DO TESTE DINÂMICO DE BARRA FIXA PARA CANDIDATOS DO SEXO MASCULINO E CANDIDATAS DO SEXO FEMININO (FLEXÃO E EXTENSÃO DE COTOVELOS EM BARRA FIXA) 3.1.1. O(a) candidato(a) deverá posicionar-se sob a barra, de frente para o examinador. Ao comando de “em posição”, o(a) candidato(a) deverá empunhar a barra e retirar os pés do solo, entrando na posição inicial.

<!-- pagina 66 -->

3.1.2. Para posição inicial: empunhadura das mãos em pronação (dorso das mãos voltados para o corpo do executante), cotovelos completamente estendidos, corpo na posição vertical, pernas estendidas e pés sem contato com o solo. No caso em que o(a) candidato(a) tenha estatura que não permita retirar os pés completamente do solo, será permitido flexionar os joelhos em um ângulo máximo de 45º, não sendo permitido pendular. 3.1.3. Para execução: ao comando de “iniciar”, o(a) candidato(a) deverá flexionar simultaneamente os cotovelos e ombros até ultrapassar com o queixo a parte superior da barra. Em seguida, deverá retornar à posição inicial com a completa extensão dos cotovelos, momento em que será contabilizada a repetição. O corpo deverá permanecer na posição vertical durante o exercício. 3.1.4. A contagem das execuções corretas levará em consideração as seguintes observações: a) o teste somente será iniciado com o candidato na posição completamente vertical de todo o corpo e após o comando dado pelo auxiliar de banca; b) a largura da empunhadura deve ser aproximadamente a dos ombros; c) só será contabilizada completa e corretamente, a repetição que começar e terminar na posição inicial; d) a não extensão total dos cotovelos, antes do início de uma nova repetição, será considerada como um movimento incorreto, e portanto, o candidato não terá a repetição computada; e) o(a) candidato(a) deverá manter a posição anatômica da cabeça, ou seja, posição neutra e olhar para o horizonte (não será contabilizada a repetição em que o candidato realizar extensão cervical para compensar a perda de amplitude do movimento de membros superiores); f) a barra deverá ser instalada a uma altura horizontal suficiente para que o(a) candidato (a), mantendo-se em suspensão com os cotovelos em extensão, não tenha contato entre seus pés e o solo; g) no caso de o(a) candidato(a) não alcançar a barra, será oferecido um suporte para que este assuma a posição inicial; h) no caso do(a) candidato(a) ter estatura que exceda essa condição, será permitido flexionar os joelhos em um ângulo máximo de 45°, não sendo permitido pendular; i) o movimento deverá ser dinâmico e o(a) candidato(a) não pode soltar a barra com nenhuma das mãos durante a execução; j) não deverão ocorrer impulsões ou oscilações excessivas durante a execução do teste, invalidando a repetição. 3.1.5. Não será permitido ao(à) candidato(a), quando da realização do teste dinâmico de barra fixa: a) tocar com o(s) pé(s) o solo ou qualquer parte de sustentação da barra após o início das execuções; b) após o início do teste, receber qualquer tipo de ajuda física; c) utilizar luva(s) ou qualquer outro material para a proteção das mãos; d) apoiar o queixo na barra; e) após ultrapassar o queixo em relação à barra, soltar as mãos sem antes completar o movimento com os cotovelos totalmente estendidos; f) movimentos de pernas e quadris (os joelhos poderão ser flexionados, desde que não ultrapassem o ângulo de 90°); g) utilizar impulso de braços e tronco para frente e para cima, levando o peito para cima; h) realizar a “pedalada”; i) realizar o “chute”; j) realizar o “butterfly”; k) não manter o cabeça, o tronco e o quadril completamente na posição vertical; l) estender o pescoço, em vez de ultrapassar o queixo em relação à barra com movimento exclusivo de membros superiores. 3.1.6. O descumprimento de qualquer uma das alíneas de “a” a “l” previstas no subitem 3.1.5 deste Edital, implicará a interrupção e o encerramento do exercício de barra fixa, contabilizando as repetições válidas até o momento da interrupção. 3.1.7. O auxiliar de banca irá contar em voz alta o número de repetições realizadas ao final de sua execução. Quando o exercício não atender ao previsto neste edital, o auxiliar de banca repetirá o número da última execução correta, desconsiderando a execução incorreta. 3.1.8. A contagem oficial a ser considerada será somente a realizada por membro da banca examinadora. 3.1.9. Cada candidato terá direito a somente 1 (uma) tentativa. 3.1.10. O(A) candidato(a) será avaliado(a) de acordo o quadro abaixo:

TESTE NA BARRA FIXA - TABELA DE ÍNDICES

MASCULINO (nº de repetições) Nota FEMININO (nº de repetições)

5 ou menos Eliminado 0

6 2 1

7 4 2

8 6 3

9 8 4

10 ou mais 10 5 ou mais

3.2. DO TESTE DE CORRIDA DE 2.400 (dois mil e quatrocentos) METROS DE DISTÂNCIA PARA CANDIDATOS DO SEXO MASCULINO E CANDIDATAS DO SEXO FEMININO 3.2.1. Para o exercício de corrida de 2.400 (dois mil e quatrocentos) metros, o(a) candidato(a), em uma única tentativa, terá de percorrer a distância referida no menor tempo possível. 3.2.2. O exercício deverá ser realizado em uma pista de atletismo de 400 (quatrocentos) metros, no sentido antihorário. 3.2.3. A metodologia para a preparação e a execução do exercício de corrida de 2.400 (dois mil e quatrocentos) metros para os candidatos do sexo masculino e do sexo feminino obedecerá aos seguintes critérios: a) o(a) candidato(a) poderá, durante o trajeto de dois mil e quatrocentos metros, deslocar-se em qualquer ritmo, correndo ou caminhando, podendo, inclusive, parar e depois prosseguir; b) o comando para iniciar o teste será dado por um silvo de apito; c) para classificação e não eliminação, ao sinal sonoro, o(a) candidato(a) deverá percorrer 2400 (dois mil e quatrocentos) metros, em ritmo livre, no tempo máximo de 12 (doze) minutos e 00 (zero) segundos para o candidato do sexo masculino e 13 (treze) minutos e 05 (cinco) segundos para a candidata do sexo feminino; d) cada bateria de teste será encerrada com 13 (treze) minutos e 06 (seis) segundos; e) o término do exercício será dado quando o(a) candidato(a) cruzar a linha de chegada, após percorrido todo o percurso; f) ao término do exercício, o avaliador confirmará o tempo final de cada candidato(a); g) o exercício será encerrado no mesmo ponto de partida, não importando se o(a) candidato(a) preferiu se manter em outra raia; h) o(a) candidato(a) poderá utilizar relógio para controlar o seu tempo, mas o tempo a ser considerado será o do cronômetro oficial da prova; i) cada bateria será numerada sequencialmente, de modo que cada candidato(a) deverá dizer seu número, em voz alta, todas as vezes em que cruzar o ponto de partida, a fim de ter sua volta contabilizada pelo auxiliar de banca responsável, enquanto o auxiliar de banca deverá verbalizar a quantidade de voltas completadas pelo(a) candidato(a); e j) após finalizado o percurso de 2.400 (dois mil e quatrocentos) metros, o(a) candidato(a) deverá se deslocar para a área de concentração de candidatos, previamente marcada até que toda a bateria finalize, de maneira a não atrapalhar os candidatos que ainda estiverem realizando o exercício. 3.2.4. Será proibido ao(à) candidato(a), quando da realização do exercício de corrida de 2.400 (dois mil de quatrocentos) metros: a) dar ou receber qualquer tipo de ajuda física (como puxar, empurrar, carregar, segurar na mão etc.); b) abandonar a pista antes da liberação do fiscal; c) correr em sentido que não seja o estabelecido pela prova; e 3.2.5. O descumprimento de qualquer das alíneas de “a” a “c” do presente subitem, enseja o encerramento da corrida de 2.400 (dois mil e quatrocentos) metros e a eliminação do(a) candidato(a) no TAF, atentando-se ao disposto nos subitens 2.20 e 2.20.1 deste Edital. 3.2.6. O(A) candidato(a) será avaliado(a) de acordo o quadro abaixo:

CORRIDA DE 2.400 METROS – TABELA DE ÍNDICES

MASCULINO (minutos e segundos) Nota FEMININO (minutos e segundos)

12:01 ou mais Eliminado 13:06 ou mais

11:43 a 12:00 1 12:50 a 13:05

11:25 a 11:42 2 12:34 a 12:49

11:07 a 11:24 3 12:18 a 12:33

10:49 a 11:06 4 12:02 a 12:17

10:31 a 10:48 5 11:46 a 12:01

10:13 a 10:30 6 11:30 a 11:45

09:55 a 10:12 7 11:14 a 11:29

09:37 a 09:54 8 10:58 a 11:13

09:18 a 09:36 9 10:42 a 10:57

09:17 ou menos 10 10:41 ou menos

3.3. DO TESTE DE NATAÇÃO DE 100 (CEM) METROS PARA CANDIDATOS DO SEXO MASCULINO E CANDIDATAS DO SEXO FEMININO 3.3.1. Para a prova de natação de 100 (cem) metros, o(a) candidato(a), em uma única tentativa, deverá percorrer a referida distância no menor tempo possível. O teste deverá ser realizado em piscina de natação de 50 (cinquenta) metros de comprimento. 3.3.2. A metodologia para a preparação e a execução do teste de natação de 100 (cem) metros para os candidatos do sexo masculino e do sexo feminino obedecerá aos seguintes critérios: a) ao comando verbal do avaliador de “em posição”, o(a) candidato(a) deverá entrar na piscina e posicionar-se dentro da piscina segurando na borda; b) ao comando do avaliador de “às suas marcas”, o(a) candidato(a) deve se preparar para a largada; c) para classificação e não eliminação, ao sinal sonoro ou comando verbal, o(a) candidato(a) deverá nadar 100 (cem) metros, em nado livre, no tempo máximo de 02 (dois) minutos e 07 (sete) segundos para o candidato do sexo masculino; e 02 (dois) minutos e 27 (vinte e sete) segundos para a candidata do sexo feminino; d) cada bateria de teste será encerrada com 02 (dois) minutos e 28 (vinte e oito) segundos; e) na virada, o(a) candidato(a) deverá, obrigatoriamente, tocar a borda com qualquer parte do corpo e retornar no sentido oposto;

<!-- pagina 67 -->

f) a chegada dar-se-á quando o(a) candidato(a) tocar, com qualquer parte do corpo, a borda onde o teste se iniciou; g) a piscina utilizada no teste deverá ter dimensões olímpicas, ou seja, 50 (cinquenta) metros de comprimento por 25 (vinte e cinco) metros de largura, e o candidato deverá realizar o teste no comprimento da piscina (50 metros); h) o tempo válido para a prova será somente o do cronômetro do avaliador, não havendo possibilidade, em hipótese alguma, de utilizar marcação própria do avaliado ou de terceiros. 3.3.3. Será proibido ao(à) candidato(a), quando da realização do teste de natação: a) apoiar-se ou impulsionar-se na parede lateral ou nas raias da piscina (será permitida a impulsão inicial e após a virada, nas bordas de saída ou de virada); b) dar ou receber qualquer ajuda física; c) utilizar qualquer acessório que facilite o ato de nadar (inclusive roupas de Neoprene), exceto touca e óculos de natação; e 3.3.4. O descumprimento de qualquer das alíneas de “a” a “c” do presente subitem, enseja o encerramento da natação de 100 (cem) metros e a eliminação do(a) candidato(a) no TAF, atentando-se ao disposto nos subitens 2.20 e 2.20.1 deste Edital. 3.3.5. O(A) candidato(a) será avaliado(a) de acordo o quadro abaixo:

NATAÇÃO DE 100 METROS – TABELA DE ÍNDICES

MASCULINO (minutos e segundos) Nota FEMININO (minutos e segundos)

A partir de 02:08 Eliminado A partir de 02:28

02:03 a 02:07 1 02:22 a 02:27

01:58 a 02:02 2 02:16 a 02:21

01:53 a 01:57 3 02:10 a 02:15

01:48 a 01:52 4 02:04 a 02:09

01:43 a 01:47 5 01:58 a 02:03

01:38 a 01:42 6 01:52 a 01:57

01:33 a 01:37 7 01:46 a 01:51

01:28 a 01:32 8 01:40 a 01:45

01:23 a 01:27 9 01:34 a 01:39

01:22 ou menos 10 01:33 ou menos

4. DAS DISPOSIÇÕES FINAIS 4.1. O resultado preliminar desta etapa será divulgado na data prevista no cronograma oficial do certame. 4.2. O candidato poderá interpor recurso contra referido resultado preliminar no prazo previsto no cronograma oficial do certame, por meio de sua Área de Candidato acessível pelo endereço eletrônico www.idecan.org.br.

Brasília/DF, 18 de junho de 2026 ALBERTO WESLEY DOURADO DE SOUZA – CEL BM QOBM/Comb

ANEXO I DO ATESTADO MÉDICO PARA REALIZAÇÃO DO TESTE DE APTIDÃO

FÍSICA ATESTADO MÉDICO Atesto, para os devidos fins, que o(a) Senhor(a) ______________________________________________________ goza de boas condições de saúde, estando apto(a) para realizar o Teste de Aptidão Física do Concurso Público do CBMDF, para matrícula no Curso de Formação de Praças Bombeiros Militares (CFPBM), do Corpo de Bombeiros Militar do Distrito Federal, para provimento de vagas na graduação de Soldado Bombeiro Militar do Quadro Geral de Praças Bombeiros Militares na Qualificação Bombeiro Militar Geral de Condutor e Operador de Viaturas - QBMG-2, regido pelo Edital nº 01/2025, de 15 de agosto de 2025.

________________________________,_______/_______/_______ .

Local Data

_______________________________________________

Assinatura e carimbo do(a) médico(a) emitente

ANEXO II DO CANDIDATO CONVOCADO PARA O TESTE DE APTIDÃO FÍSICA (TAF)

INSCRIÇÃO NOME

2093538 LEONARDO FERNANDES XAVIER

## SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA

EXTRATO DO CONTRATO ADMINISTRATIVO Nº 16/2026 - SIGGO: 057455 PROCESSO SEI-GDF Nº 04026-00041662/2025-41. DAS PARTES: SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL - SEAPE, na qualidade de CONTRATANTE, e a empresa JD CONSTRUCOES E SERVICOS LTDA, inscrita no CNPJ/MF sob o nº 13.609.718/0001-21, na qualidade de CONTRATADA. DO OBJETO: contratação de empresa especializada na prestação de serviços sob demanda, de manutenção predial corretiva, por sistema de registro de preços, com fornecimento de equipamentos, peças, materiais e mão de obra, na forma estabelecida em planilhas de serviços e insumos diversos descritos no sistema nacional de pesquisa de custos e índices da construção civil – SINAPI – nas edificações, equipamentos e instalações prediais utilizados pela SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA (SEAPE). DA DOTAÇÃO ORÇAMENTÁRIA: Fonte de Recurso: 100; Unidade Orçamentária: 64.101; Programa de Trabalho: 06.421.6217.2727.0006 e 06.122.8217.2396.0095; Natureza da Despesa: 3.3.90.39, Nota de Empenho 2026NE00575 e 2026NE00585. DA VIGÊNCIA: 12 (doze) meses, contados da assinatura do contrato. DATA DA ASSINATURA: 19/06/2026. SIGNATÁRIOS: pelo Distrito Federal: WENDERSON SOUZA E TELES, Secretário de Estado de Administração Penitenciária do Distrito Federal; e pela empresa JD CONSTRUCOES E SERVICOS LTDA: DARLAN RILER COSTA, Representante Legal.

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

EXTRATO DO PRIMEIRO TERMO ADITIVO À ATA DE REGISTRO DE PREÇOS Nº 14/2025 Ata de Registro de Preços nº 14/2025 - SEAPE/DF. Modalidade: Pregão Eletrônico Nº 90007/2025 - SEAPE/DF. Processo: 04026-00025380/2025-04- SEI/GDF. Objeto: PRORROGAR a validade da Ata de Registro de Preços nº 14/2025 - SEAPE, por mais 12 (doze) meses, a contar de 26/07/2026 a 25/06/2027. A presente prorrogação renova o quantitativo inicialmente registrado, a contar de 31/07/2026 e REAJUSTAR, no percentual de 4,391720%, conforme período de acúmulo do Índice Nacional de Preços ao Consumidor Amplo (IPCA), a contar da data do orçamento estimado da licitação (169926198) (Maio/2025 -Abril/2026). Os efeitos financeiros terão vigência retroativa a contar de 09/06/2026. Signatários: pela SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA, RAISSA WINTER DE CARVALHO; pela empresa RL COMERCIO DE UTILIDADES DO LAR LTDA, SONIA ROSA DE PAULA CAMPOS.

EXTRATO DO PRIMEIRO TERMO ADITIVO À ATA DE REGISTRO DE PREÇOS Nº 17/2025 Ata de Registro de Preços nº 17/2025 - SEAPE/DF. Modalidade: Pregão Eletrônico Nº 90011/2025 - SEAPE/DF. Processo: 04026-00031634/2025-15- SEI/GDF. Objeto: PRORROGAR a validade da Ata de Registro de Preços nº 17/2025 - SEAPE, por mais 12 (doze) meses, a contar de 31/07/2026 a 30/07/2027. A presente prorrogação renova o quantitativo inicialmente registrado, a contar de 31/07/2026 e REAJUSTAR no percentual de 4,391720%, conforme período de acúmulo a contar da data do orçamento estimado da licitação (Maio/2025 a Abril/2026). Os efeitos financeiros terão vigência retroativa a contar de 15/05/2026. Signatários: pela SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA, RAISSA WINTER DE CARVALHO; pela empresa MTK HOSPITALAR LTDA, JACKELINE AMARAL DA SILVA.

## SECRETARIA DE ESTADO DE TRANSPORTE E MOBILIDADE

### SUBSECRETARIA DE SERVIÇOS

EXTRATO DE DIVULGAÇÃO DO RESULTADO PRELIMINAR DE CLASSIFICAÇÃO DAS PROPOSTAS DO EDITAL DE CHAMAMENTO

PÚBLICO Nº 01/2026 - SEMOB Processo: 00090-00000556/2024-56. Objeto: seleção de entidades de classe, representativa dos taxistas, para a prestação de serviços para a organização e gestão da fila física e/ou virtual de táxis no Aeroporto Internacional de Brasília, conforme condições, quantidades e exigências estabelecidas neste Edital e seus anexos. Resultado: Em cumprimento ao item 7 do Edital Chamamento Público nº 01/2026 - SEMOB, que trata da divulgação do resultado de classificação das propostas e análise da documentação de habilitação, a Comissão Avaliadora, instituída pela Portaria n.º 292, de 24 de outubro de 2025, tornou público, na data de hoje, o resultado preliminar das etapas de recebimento de propostas e habilitação da entidade provisoriamente em 1º lugar, no âmbito do Chamamento Público n.º 01/2026 - SEMOB. Informamos que, dentro do prazo legal, foram apresentadas 4 propostas ao Edital e atribuídas as seguintes notas:

<!-- pagina 68 -->

Classificação das Propostas

Classificação Entidade Tarifa Administrativa

1º ASTDF R$ 2,25

2º ANTAXI R$ 3,00

3º ANTF R$ 4,00

4º SINDETAXI R$ 5,87

A Comissão Avaliadora procedeu à conferência da documentação apresentada pelas entidades participantes, contemplando os documentos de habilitação jurídica, regularidade fiscal e trabalhista, qualificação técnica, plano de operação, proposta financeira, declarações obrigatórias e demais exigências previstas no Edital. Da análise realizada, verificou-se o atendimento aos requisitos de participação e habilitação estabelecidos no Chamamento Público nº 01/2026, conforme Relatório de Julgamento n.º 07/2026, que encontra-se publicado no sítio eletrônico https://semob.df.gov.br/licitacoes. Considerações finais: As entidades participantes poderão se manifestar, conforme subitens 7.1 a 7.3 do Edital, no prazo de 5 (cinco) dias úteis, contados da data da publicação deste Resultado, através dos e-mails chamamentopublicotaxi@semob.df.gov.br e cecon@semob.df.gov.br. Caso seja impetrado Recurso, este deverá ser fundamentado, assinado pelo representante legal da OSC e encaminhado em formato PDF, em único arquivo, contendo a identificação da entidade, número do Edital e argumentação clara e objetiva.

WALISSON DO NASCIMENTO PERÔNICO

Subsecretário de Serviços

RAFAEL SILVEIRA GUIMARÃES FURTADO

Coordenador de Contratos e Convênios

### COMPANHIA DO METROPOLITANO COMISSÃO ESPECIAL DE CHAMAMENTO PÚBLICO

RESULTADO DE HABILITAÇÃO - METRÔ-DF

CHAMAMENTO PÚBLICO Nº 01/2026 A COMPANHIA DO METROPOLITANO DO DISTRITO FEDERAL – METRÔ-DF, por intermédio do Presidente da Comissão Especial de Chamamento Público, torna público o resultado da habilitação da Chamada Pública destinada à seleção de interessados na concessão onerosa de uso de espaços públicos localizados nas estações Terminal Samambaia e Ceilândia Centro, para instalação e exploração comercial de quiosques. Os espaços disponibilizados possuem as seguintes características: Estação Terminal Samambaia: 4 (quatro) espaços, cada um medindo 2,25 m x 2,75 m, com área individual de 6,1875 m²; Estação Ceilândia Centro: 4 (quatro) espaços, cada um medindo 2,40 m x 2,40 m, com área individual de 5,7600 m². Após a análise da documentação de habilitação, a Comissão declarou HABILITADA a empresa FAP LTDA., inscrita no CNPJ nº 44.603.081/0001-90, para a exploração dos espaços localizados na Estação Terminal Samambaia. Fica aberto o prazo de 5 (cinco) dias úteis, contado da publicação deste aviso, para a interposição de recursos, nos termos do instrumento convocatório. Os autos do Processo nº 00097-00013528/2023-21 encontram-se com vista franqueada aos interessados, mediante solicitação formal encaminhada ao e-mail: licitacao@metro.df.gov.br.

MARÍLIA OLIVEIRA DE JESUS

Presidente da Comissão

## SECRETARIA EXTRAORDINÁRIA

## DO CONSUMIDOR

### INSTITUTO DE DEFESA DO CONSUMIDOR

EDITAL DE NOTIFICAÇÃO Ficam os fornecedores mencionados abaixo notificados para apresentar defesa escrita, no prazo de 20 (vinte) dias, nos termos do disposto no art. 42, do Decreto-Lei nº 2.181/97: CRISTAIS PRESTACAO DE SERVICOS LTDA, CNPJ 35.105.770/0001-83, referente ao processo 00015-00008726/2025-89; FNX PREMIUM COMERCIO DE VEICULOS LTDA, CNPJ 55.506.987/0001-02, referente ao processo 00015-00007169/2025-89; UNIVIDA USA OPERADORA EM SAUDE S/A, CNPJ 34.608.096/0001-97, referente ao processo 00015-00006268/2025-43; A. L. DE TARSO BRANDAO, CNPJ 21.717.348/0001-74, referente ao processo 00015-00004502/2025-06; AVDV ESTETICA LTDA, CNPJ 31.237.773/0109-30, referente aos processos 00015-00021165/2025-11 e 00015-00004187/2025-17; LOJAS MOVEISLAR LTDA, CNPJ 00.125.435/0001-62, referente ao processo 00015-00004143/2025-89; TOPO DISTRIBUICAO E COMERCIO LTDA, CNPJ 50.288.243/0001-45, referente ao processo 00015-00001838/2025-17; HM PRIMER SOLAR LTDA, CNPJ 54.015.848/0001-13, referente ao processo 00015- 00000837/2025-47; ASSOCIACAO BRASILEIRA DE CREDITO DE CARBONO E METANO – ABCARBON, CNPJ 47.943.532/0001-26, referente ao processo 00015- 00000416/2025-16; INOVE CLINICA ODONTOLOGICA LTDA, CNPJ 07.664.116/0001-74, referente ao processo 00015-00000189/2025-29; FACIL ADMINISTRADORA DE CARTOES DE CREDITO LTDA, CNPJ 28.911.037/0001-90, referente ao processo 00015-00000141/2025-11; 21.188.027 APARECIDA FERNANDES

SOUSA PANTA, CNPJ 21.188.027/0001-20, referente ao processo 00015-00040286/2024- 73; NACIONAL DISTRIBUIDORA DE CARNES BEEF LTDA, CNPJ 16.995.395/0001- 40, referente ao processo 00015-00037450/2024-65; PENATTI IMPORTACOES LTDA, CNPJ 53.903.341/0001-33, referente ao processo 00015-00033757/2024-97; 48.424.332 JOSE VALDEMIR BRITO DE ARAUJO, CNPJ 48.424.332/0001-20, referente ao processo 00015-00002732/2023-61; PAULISTA COMERCIO E LOCADORA DE VEICULOS LTDA, CNPJ 34.338.933/0001-05, referente ao processo 00015- 00037625/202500015-00015865/2026-40-15; NARCISO FRANCISCO DA SILVA JUNIOR LTDA, CNPJ 59.571.233/0001-97, referente ao processo 00015-00033659/2025- 31; LILLY ESTETICA S.A. - EM RECUPERACAO JUDICIAL, CNPJ 24.817.299/0028- 50, referente ao processo 00015-00019788/2024-35; AVDV ESTETICA LTDA, CNPJ 31.237.773/0068-27, referente ao processo 00015-00008480/2025-45; BRASILIA ESTOFADOS LTDA, CNPJ 40.663.138/0001-95, referente ao processo 00015- 00004290/2025-59; AVDV ESTETICA LTDA, CNPJ 31.237.773/0029-10, referente aos processos 00015-00016877/2025-19, 00015-00011533/2025-13 e 00015-00010109/2025- 43; LASER FAST DEPILACAO LTDA SCP ITAJAI, CNPJ 40.609.108/0001-09, referente ao processo 00015-00007464/2025-35; FEDERAL COLCHOES LTDA, CNPJ 47.384.802/0001-06, referente ao processo 00015-00005590/2025-55; EVK COSTA COMERCIO DE PRODUTOS DE SAUDE E BELEZA LTDA, CNPJ 41.482.527/0001-87, referente ao processo 00015-00029403/2024-48; S&S SERVICOS DE DIVULGACAO PROPAGANDA E MARKETING LTDA, CNPJ 49.352.886/0001-21, referente ao processo 00015-00029686/2024-28; AVDV ESTETICA LTDA, CNPJ 31.237.773/0186- 71, referente aos processos 00015-00019348/2025-69, 00015-00013440/2025-15, 00015- 00011683/2025-19, 00015-00001905/2025-95, 00015-00011210/2025-11 e 00015- 00015935/2025-89; INSTITUTO BENEFICENTE FAMILY CLUB, CNPJ 37.888.036/0001-63, referente ao processo 00015-00014791/2025-43; AVDV ESTETICA LTDA, CNPJ 31.237.773/0084-47, referente aos processos 00015-00009469/2024-11, 00015-00011215/2025-44 e 00015-00017995/2025-36; AVDV ESTETICA LTDA, CNPJ 31.237.773/0068-27, referente ao processo 00015-00011189/2025-54; DAG COMERCIO LTDA, CNPJ 51.120.999/0004-96, referente ao processo 00015-00015865/2026-40; A4 REPRESENTACAO COMERCIAL LTDA, CNPJ 18.422.874/0001-00, referente ao processo 00015-00015475/2024-16; UNI INVESTIMENTOS LTDA, CNPJ 29.533.784/0001-03, referente ao processo 00015-00030082/2024-24; ON STAGE PRODUCOES LTDA, CNPJ 32.032.524/0001-50, referente ao processo 00015- 00028596/2024-10; 2MN COMERCIO EM GERAL LTDA, CNPJ 54.656.474/0001-15, referente ao processo 00015-00038994/2024-44; ST CLINICA DE ESTETICA LTDA, CNPJ 40.566.243/0001-06, referente ao processo 00015-00030778/2024-51; GCSM PLANEJADOS LTDA, CNPJ 46.733.548/0001-41, referente ao processo 00015- 00012213/2025-72; J. C. PERES ENGENHARIA LTDA, CNPJ 01.651.769/0001-32, referente ao processo 00015-00013388/2025-05; MASTER PREV CLUBE DE BENEFICIOS, CNPJ 43.012.440/0001-71, referente ao processo 00015-00014344/2025- 94; PAULISTA SAUDE S/A, CNPJ 04.677.722/0001-36, referente ao processo 00015- 00016091/2025-93; MASTER PREV CLUBE DE BENEFICIOS, CNPJ 43.012.440/0001- 71, referente ao processo 00015-00015379/2025-41; UNIVIDA USA OPERADORA EM SAUDE S/A, 34.608.096/0001-97, referente ao processo 00015-00015720/2025-68; AVDV ESTETICA LTDA, CNPJ 31.237.773/0001-10, referente aos processos 00015- 00024881/2025-42, 00015-00023240/2025-71 e 00015-00016938/2025-30; M.J.A EMPREENDIMENTOS LTDA, CNPJ 13.531.492/0001-93, referente ao processo 00015- 00022279/2025-71; R4 BRASILIA COMERCIO DE VEICULOS LTDA, CNPJ 37.483.976/0001-72, referente ao processo 00015-00027864/2025-67; AVDV ESTETICA LTDA, CNPJ 31.237.773/0085-28, referente ao processo 00015-00023252/2025-03.

JOHNATAN RACHID PIRES FARAJ

Diretor Geral– IDC-PROCON/DF

## SECRETARIA DE ESTADO DE

## OBRAS E INFRAESTRUTURA

AVISO DE RECEBIMENTO DA LICENÇA AMBIENTAL SIMPLIFICADA-LAS Processo Ibram nº 00391-00003146/2026-61 - A Secretaria de Estado de Obras e Infraestrutura do Distrito Federal - SODF torna público que recebeu do Instituto Brasília Ambiental - IBRAM/DF a Licença Ambiental Simplificada nº 15/2026 - IBRAM/PRESI, para a atividade de duplicação de vias para Execução das Obras na Via de Ligação entre Anel Viário do Guará II ao Núcleo Bandeirante – DF075.

Brasília-DF, 18 de junho de 2026 VALTER CASIMIRO SILVEIRA

Secretário de Estado

### COMPANHIA DE SANEAMENTO AMBIENTAL

EXTRATO DE CONTRATO CONTRATO Nº 10193. ASSINATURA: 17/06/2026. PROCESSO Nº 00092- 00049831/2025-93. LC nº 19/2026 - CAESB. OBJETO: Obras para implantação do SAA do Residencial Jacarandás e Residencial das Sucupiras, Complexo Urbanístico Aldeias do Cerrado – Etapa 1, Jardim Botânico/DF. DOTAÇÃO ORÇAMENTÁRIA: UO: 22.202; PROGRAMA DE TRABALHO: 17.512.6209.1827.0001/44.90.51, CÓDIGO 22.202.013.041-4, FONTE DE RECURSO: RECURSOS PRÓPRIOS DE

<!-- pagina 69 -->

INVESTIMENTOS - REPI, CÓDIGO 21.101.100.000-6; UG: 190.206; GESTÃO: 19.206; EMPENHO 1538/2026, DATADO DE: 11/06/2026, VALOR DO EMPENHO: R$ 548.172,43 (quinhentos e quarenta e oito mil e cento e setenta e dois reais e quarenta e três centavos). VALOR DO CONTRATO: R$ 3.242.429,74 (três milhões e duzentos e quarenta e dois mil e quatrocentos e vinte e nove reais e setenta e quatro centavos) EXECUÇÃO/VIGÊNCIA: 300(trezentos) e 405 (quatrocentos e cinco) dia(s), respectivamente. FISCALIZAÇÃO: Guilherme Oliveira Gobbi, matrícula nº 52.964-8 gestor. Felipe Corte Paiva, matrícula nº 53.482-0 fiscal. ASSINANTES: Pela CAESB: Luís Antônio Almeida Reis - Presidente e Sergio Antunes Lemos - DE - Diretor de Engenharia. Pela HF ENGENHARIA E CONSTRUÇÃO LTDA: Fabrício Manuel Martins Oliveira.

EXTRATO DE CONTRATO CONTRATO Nº 10194. ASSINATURA: 18/06/2026. PROCESSO Nº 00092- 00020491/2026-53. LC nº 90012/2026 - CAESB. OBJETO: Aquisição de ferramentas e instrumentos a serem utilizadas pelas equipes de manutenção preventiva e corretiva das áreas de manutenção elétrica e automação nas unidades operacionais da Companhia de Saneamento Ambiental do Distrito aquisição de ferramentas e instrumentos a serem utilizadas pelas equipes de manutenção preventiva e corretiva das áreas de manutenção elétrica e automação nas unidades operacionais da Companhia de Saneamento Ambiental do Distrito Federal no Distrito Federal e áreas de abrangência, Lote 06 (itens 14, 15, 16,17,18,19,20,21e22).DOTAÇÃO ORÇAMENTÁRIA: UO: 22.202; PROGRAMA DE TRABALHO: 17.122.8209.8517.6977/33.90.30, CÓDIGO 12.203.205.200-7, FONTE DE RECURSO: RECURSOS PRÓPRIOS, CÓDIGO 11.101.000.000-3; UG: 190.206; GESTÃO: 19.206; EMPENHO 1418/2026, DATADO DE: 25/05/2026, VALOR DO EMPENHO: R$ 29.188,50 (vinte e nove mil e cento e oitenta e oito reais e cinquenta centavos). VALOR DO CONTRATO: R$ 29.188,50 (vinte e nove mil e cento e oitenta e oito reais e cinquenta centavos) VIGÊNCIA/ENTREGA: 210 (duzentos e dez) dia(s) e 60 (sessenta) dia(s), respectivamente FISCALIZAÇÃO: Rodolfo Alexandre Meurer, matrícula nº 52.141-8 gestor. Alfredo Franco Neto, matrícula nº 52.161-2, Rodrigo Da Silva De Cardozo, matrícula nº 51.769-0 para fiscais. ASSINANTES: Pela CAESB: Luís Antônio Almeida Reis - Presidente e Walter Lucio Dos Santos Barros - DP - Diretor de Operação e Manutenção. Pela EMPRESA CALDESUL PRODUTOS E SERVIÇOS LTDA: Tarcisio Chiarelli.

EXTRATO DE TERMO ADITIVO 1º Termo Aditivo ao Contrato 10010/2025, publicado no DODF em 25/07/2025. ASSINATURA: 17/06/2026.PROCESSO GDOC nº 00092-00027106/2023-89. ALTERAÇÃO DE OUTRAS CLÁUSULAS: A COMPANHIA DE SANEAMENTO AMBIENTAL DO DISTRITO FEDERAL-CAESB, sociedade de economia mista do Distrito Federal, inscrita no CNPJ sob o n.º00.082.024/0001-37 e na CF/DF sob o n.º 07324667/001- 67, com sena Avenida Sibipiruna, Lotes 13, 15, 17, 19 e 21, CEP 71.928-720 - Águas Claras/DF, doravante denominada CONTRATANTE, neste ato representada por seu Presidente, LUIS ANTÔNIO ALMEIDA REIS, brasileiro, casado, arquiteto, portador do CAU/DF A121452 e inscrito no CPF sob o n.º 154.***.***-87, e pelo Diretor de Operação e Manutenção, WALTER LÚCIO DOS SANTOS BARROS, brasileiro, casado, engenheiro mecânico, portador do RG n.º 433.***, expedido pela SSP/DF, e inscrito no CPF sob o n.º 597.***.***-53, ambos residentes e domiciliados nesta Capital, e do outro lado, o CONSÓRCIO MANUTENÇÃO BRASÍLIA, inscrito no CNPJ sob o n.º 61.684.277/0001-75, constituído pelas empresas L. PHILIPPE CONSTRUÇÕES LTDA, inscrita no CNPJ 11.816.706/0001-42, com sede na Rua Miguel de Frias, 77 salas 1.605 1.606 e 1.607, Icaraí, Niterói/RJ representada por Luiz Philippe Alves de Carvalho, brasileiro, casado, engenheiro civil, portador da Carteira de Identidade nº 11.***.***-4, expedida pela IFP/RJ e CREA/RJ n.º 200400279-4, e inscrito no CPF sob o n.º 077.***.***-51 e APD CONSTRUÇÕES E SERVIÇOS LTDA, empresa líder, inscrita no CNPJ: 29.763.109/0001-62, com sede na Rua Visconde de Sepetiba, 935, sala 1614,Centro, Niterói/RJ, representada por ANDRÉ DE PAULA DE FREITAS, brasileiro, casado, portador do RG nº 108***493 IFP/RJ e do CPF nº 082.***.***-76, residente e domiciliado em Niterói/RJ; doravante denominadas CONTRATADAS, tendo em vista a Adjudicação e Homologação do Pregão Eletrônico n.º 90168/2024, conforme IDs 2338446 e 2342055.1 nos autos do Processo n.º 00092- 00027106/2023-89, têm entre si justa e avençada a celebração do presente contrato, vinculando-se as partes ao Edital e seus Anexos, ao Termo de Referência ID. 2182661, à Proposta da CONTRATADA ID. 2332003, à Constituição Federal, à Lei n.º 13.303/2016, ao Regulamento de Licitações e Contratações da CAESB - RILC, às normas internas da CAESB, e as demais normas legais aplicáveis referenciadas no Termo de Referência, mediante as seguintes cláusulas e condições: ASSINANTES: Pela CAESB: Luís Antônio Almeida Reis - Presidente e Walter Lucio dos Santos Barros - Diretor de Operação e Manutenção. Pelo CONSÓRCIO MANUTENÇÃO BRASÍLIA: André de Paula de Freitas e Luiz Philippe Alves de Carvalho.

EDITAL Nº 31 – CAESB, DE 22 DE JUNHO DE 2026 CONCURSO PÚBLICO PARA O PROVIMENTO DE VAGAS E A FORMAÇÃO DE CADASTRO DE RESERVA EM CARGOS DE NÍVEL

SUPERIOR E DE NÍVEL MÉDIO O Presidente da Companhia de Saneamento Ambiental do Distrito Federal (Caesb) torna pública a retificação do caput e do subitem 4.2 do Edital nº 22 – CAESB, de 26 de janeiro de 2026, e alterações, conforme a seguir especificado. [...] O Presidente da Companhia de Saneamento Ambiental do Distrito Federal (Caesb) torna públicos [...]

[...] 4.2 O resultado final no concurso público, somente para os cargos de nível médio e de nível médio técnico – exceto para o Cargo 27, fica devidamente homologado nesta data pelo Presidente da Caesb. [...] Torna público, ainda, conforme subitem 18.29 do edital de abertura, que o prazo de validade do concurso para os cargos de que trata este edital esgotar-se-á após um ano, contados a partir desta data de homologação, podendo ser prorrogado, uma única vez, por igual período.

LUÍS ANTÔNIO ALMEIDA REIS

Presidente da CAESB

EDITAL Nº 32 – CAESB, DE 22 DE JUNHO DE 2026 CONCURSO PÚBLICO PARA O PROVIMENTO DE VAGAS E A FORMAÇÃO DE CADASTRO DE RESERVA EM CARGOS DE NÍVEL

SUPERIOR E DE NÍVEL MÉDIO O Presidente da Companhia de Saneamento Ambiental do Distrito Federal (Caesb) torna público que o resultado final no concurso público para o provimento de vagas e a formação de cadastro de reserva em cargos de nível superior e de nível médio, somente para os cargos de nível superior e para o Cargo 27, fica devidamente homologado nesta data pelo Presidente da CAESB. Torna pública, ainda, conforme subitem 18.29 do edital de abertura, que o prazo de validade do concurso para os cargos de que trata este edital esgotar-se-á após um ano, contados a partir desta data de homologação, podendo ser prorrogado, uma única vez, por igual período.

LUÍS ANTÔNIO ALMEIDA REIS

Presidente da CAESB

### COMPANHIA ENERGÉTICA DE BRASÍLIA

EXTRATO DE TERMO ADITIVO Espécie: Primeiro Termo Aditivo ao Contrato nº 010/2025-CJU/CEB-H. Processo SEI/GDF nº 00093-00000239/2025-36. Contratada:SEGTRACK SEGURANÇA ELETRONICA E SERVIÇOS INTELIGENTES LTDA Inscrita sob o CNPJ nº 17.949.399/0001-54. Objeto: Acréscimo de 1 (um) posto de garçom. Valor: O valor total da suplementação será de R$ 192.761,23 (cento e noventa e dois mil, setecentos e sessenta e um reais e vinte e três centavos), até a vigência final do instrumento pricipal, que se dará em 10/02/2028. Assinaturas: Pela Companhia Energética de Brasília: Elie Issa El Chidiac, Diretor- Presidente, Ivan Carlos Ferreira Lima, Diretor Administrativo-Financeiro e de Relações com Investidores, Kleber Borges de Moura, Consultor Jurídico. Pela Contratada: Haynner Leonardo da Mota, Sócio-Propritário.

### COMPANHIA URBANIZADORA DA NOVA CAPITAL DO BRASIL

EXTRATO CONTRATUAL PROCESSO Nº 00112-00002669/2025-62. PRIMEIRO TERMO ADITIVO AO CONTRATO DE PRESTAÇÃO DE SERVIÇOS D.S. Nº 135/2025. CONTRATANTES: NOVACAP e ITA INDÚSTRIA E COMÉRCIO DE CARIMBOS LTDA EPP. OBJETO: Prorrogação do prazo de vigência do Contrato por mais 1 ano, passando seu término de 27/06/2026 para 27/06/2027. LOTE: 01. O valor do Contrato permanece em R$ 10.438,10. Empenho: 2026NE00647, Programa de Trabalho 15.122.8209.8517.0001, Natureza da Despesa 33-90-39, Fonte de Recurso 100. DATA DA ASSINATURA: 17/06/2026. Por: Fernando Rodrigues Ferreira Leite, José Itamar Feitosa e Luiz Henrique Innecco.

EXTRATO CONTRATUAL PROCESSO Nº 0112-001492/2003. TERMO DE CESSÃO DE USO - Nº 002/2026 - D.S. CONTRATANTES: NOVACAP e SECRETARIA DE ESTADO DE ADMINISTRAÇÃO PENITENCIÁRIA DO DISTRITO FEDERAL — SEAPE/DF. OBJETO: Cessão de Uso, em caráter provisório e gratuito, de 01 imóvel de propriedade da NOVACAP, situado no SIA trecho 04, lotes 1.650/1.680 - Brasília/DF, para abrigar o Centro de Progressão Penitenciária (CPP), sendo um galpão em alvenaria com área total construída de 1.974 m2. VIGÊNCIA: 24 meses. DATA DA ASSINATURA: 17/06/2026. Por: Fernando Rodrigues Ferreira Leite, José Itamar Feitosa e Wenderson Souza e Teles.

### DEPARTAMENTO DE ESTRADAS DE RODAGEM

EXTRATO DO CONTRATO Nº 27/2026. PROCESSO nº: 00113-00029733/2025-24; CONTRATANTES: DER/DF e a empresa: SO CO2 GASES ESPECIAIS LTDA, Objeto: fornecimento de recarga de cilindros, de Gás Oxigênio, Gás Acetileno e Gás Argônio de uso industrial para realização de serviços de solda e corte de aço para manutenção de equipamentos; Prazo de Vigência: 12 (doze) meses; Dotação Orçamentária: I - Unidade: 26.205; II - Fonte de Recurso 183; III - Programa de Trabalho: 26.782.6216.2885-0001; Elemento de Despesa: 339030. Nota de Empenho nº: 2026NE00724; data: 14/04/2026; Valor: R$ 9.689,50; Data da Assinatura: 16/06/2026; Signatários: Pelo DER/DF Eng. FAUZI NACFUR JUNIOR e Pela Empresa: ADELAIDE DESTEFANI CAMPOREZ CRISPIM. Valor Total: R$ 49.841,00 (quarenta e nove mil oitocentos e quarenta e um reais).

<!-- pagina 70 -->

EDITAL DE NOTIFICAÇÃO Nº 09/2026 - DER/DF

PROCESSO Nº 00113-00012608/2026-66 O Presidente do Departamento de Estradas de Rodagem do Distrito Federal, em consonância com a Lei nº 5.795/2016, art. 35, § 3º, combinado com o Decreto nº 48.239/2026, artigo 135, inciso VII, notifica o proprietário e/ou responsável pela ocupação relacionada abaixo para que promova a remoção/demolição de toda e qualquer edificação erigida na faixa de domínio da rodovia DF-290, cuja largura é de 130 metros divididos simetricamente em relação ao seu eixo do seu futuro canteiro central, conforme estabelecido pelo Decreto nº 27.365/2006, no prazo máximo de 30 (trinta) dias após esta publicação. Em caso de descumprimento ficará sujeitos às sanções legais dispostas na Lei nº 5.795/2016.

Endereço Referência* Coordenadas Geográficas (WGS 84)*

Início Final

Latitude Longitude Latitude Longitude

Quadra 07,

DF-290, nas proximidades

Conjunto A,

do quilômetro 22+562,

-

-

-

-

Casa 18, Setor

margem esquerda no sentido

16.033065°

48.074361°

16.033086°

48.074323°

Sul - Gama/DF.

crescente da quilometragem.

* as informações apresentadas possuem o cunho apenas referencial, com o intuito de localizarmos e

identificarmos as propriedades em softwares de georeferenciamento com maior facilidade.

Art. 1º Informações esclarecedoras quanto à localização e situação podem ser visualizadas no Relatório de Ação Fiscal nº 2256/2026, Doc SEI nº 203675013, Processo: 00113- 00012608/2026-66 (DER-DF - Ocupação Faixa de Domínio: Ocupação de Área Pública) Art. 2º Nos colocamos à disposição para demais esclarecimentos.

FAUZI NACFUR JUNIOR

SUPERINTENDÊNCIA ADMINISTRATIVA E FINANCEIRA

DIRETORIA DE MATERIAIS E SERVIÇOS

GERÊNCIA DE LICITAÇÃO

AVISO DE RESULTADO DE JULGAMENTO CONCORRÊNCIA ELETRÔNICA Nº 90006/2025 - UASG 926120

PROCESSO: 00113-00003392/2025-67

RETIFICAÇÃO O Agente de Contratação torna público o resultado da licitação modalidade Concorrência Eletrônica nº 90006/2025, para a contratação semi-integrada de empresa especializada para implantação do complexo viário de acesso ao Setor Noroeste, na Rodovia DF-010 (EPAA) e via W9 - Noroeste (SHCNW - trecho 2) e ao SRPN - Setor de Recreação Pública Norte (Setor Esportivo trecho 2) de acesso ao autódromo Nelson Piquet, conforme condições, quantidades e exigências estabelecidas no Edital e seus anexos., onde sagrou-se vencedora a empresa: HYTEC CONSTRUCOES, TERRAPLENAGEM E INCORPORACAO LTDA, CNPJ 02.141.279/0001-59, no valor de R$ R$ 39.375.515,77 (trinta e nove milhões, trezentos e setenta e cinco mil, quinhentos e quinze reais e sessenta e sete centavos). Maiores informações podem ser encontradas no sistema eletrônico, no site https://www.compras.gov.br/.

Brasília/DF, 19 de junho de 2026 CAIO GUIMARÃES OLIVEIRA

Agente de Contratação

PREGÃO ELETRÔNICO Nº 90010/2026

PROCESSO:00113-00030527/2025-67 O pregoeiro torna público o resultado da licitação modalidade Pregão Eletrônico, do Tipo Menor Preço, contratação de serviço comum de engenharia por meio de Registro de Preços: fornecimento com instalação de defensas metálicas, poste removível, terminal tipo D, absorvedores de impacto, tachas, tachões e balizadores, conforme condições, quantidades e exigências estabelecidas no Edital e seus anexos. Lotes 1 e 2: Empresa: SINALVIP Sinalização e Segurança Viária Ltda., CNPJ n° 23.440.487/0001-29, valor R$ 2.066.791,60 (dois milhões, sessenta e seis mil, setecentos e noventa e um reais e sessenta centavos); lote 3: FRACASSADO. Maiores informações podem ser encontradas no sistema eletrônico, no site https://www.compras.gov.br, UASG: 926120.

Brasília/DF, 19 de junho de 2026 ANTÔNIO MARCOS RAMOS DE MORAIS

## SECRETARIA DE ESTADO DA AGRICULTURA, ABASTECIMENTO E DESENVOLVIMENTO RURAL

EXTRATO DA LICENÇA POR ADESÃO E COMPROMISSO -LAC Nº 08/2026-IBRAM Processo nº: 00391-00011755/2024-22 Documento Técnico: Parecer Técnico n.º 78/2025 - IBRAM/PRESI/SULAM/DILAM-IV e Manifestação 31726. Interessado: Secretaria de Estado da Agricultura, Abastecimento e Desenvolvimento Rural do DF. Objeto: Concessão de Licença de Adesão e Compromisso nº 8/2026.

Concessão de Licença Ambiental por Adesão e Compromisso para Manutenção de estradas rurais locais e atividade de extração de cascalho, em área localizada na DF 170 - KM 07, Rua 25, Núcleo Rural Lago Oeste - assentamento Chapadinha, na Região Administrativa Sobradinho II-DF. A validade da Licença Ambiental por Adesão e Compromisso-LAC será de 1(um) ano a contar de sua assinatura. Publique-se e encaminhe-se o presente processo à Subsecretaria de Desenvolvimento Rural para os demais procedimentos administrativos. Em 25 de maio de 2026, Rafael Borges Bueno, Secretário de Estado da Agricultura, Abastecimento e Desenvolvimento Rural do Distrito Federal.

RAFAEL BORGES BUENO

Secretário de Estado

## SECRETARIA DE ESTADO DE CIÊNCIA,

## TECNOLOGIA E INOVAÇÃO

### FUNDAÇÃO DE APOIO À PESQUISA

SUPERINTENDÊNCIA CIENTÍFICA,

TECNOLÓGICA E DE INOVAÇÃO

EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO

A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS EXTRATO DE TERMO DE OUTORGA E ACEITAÇÃO Processo: 00193-00000781/2026-23. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 142/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, ANDRE LUIZ MARQUES SERRANO como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "FedIHRAS: A Privacy-Preserving Federated Learning Framework for Multi-Institutional Collaborative Radiological Analysis with Integrated Explainability and Automated Clinical Reporting", a ser publicado na Revista Biomedicines 2026. NOTA DE EMPENHO 2026NE00417, Data: 10/06/2026, Valor: R$20.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: ANDRE LUIZ MARQUES SERRANO. Processo: 00193-00000788/2026-45. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 147/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, MATHEUS DE SOUSA PEREIRA como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Optimizing the operational efficiency of Brazilian ports: an application of bibliometric analysis and data envelopment analysis to port performance”, a ser publicado no periódico "International Journal of Facilities Management". NOTA DE EMPENHO 2026NE00427, Data: 10/06/2026, Valor: R$20.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: MATHEUS DE SOUSA PEREIRA Processo: 00193-00000790/2026-14. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 149/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, VINÍCIUS MACHADO DOS SANTOS como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Multivariate assessment of microbiological and incubation data from an experimental trial evaluating essential oil–based sanitizers and formaldehyde on hatching eggs”, a ser publicado no periódico "Pathogens". NOTA DE EMPENHO 2026NE00431, Data: 10/06/2026, Valor: R$18.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: VINÍCIUS MACHADO DOS SANTOS

<!-- pagina 71 -->

Processo: 00193-00000791/2026-69. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 150/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, MATHEUS GOMES DE CASTRO como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "BDNF Val66met Gene Polymorphism in Primary Acute and Subacute Stroke Functional Recovery: A Systematic Review”, a ser publicado no periódico "Biomedicines". NOTA DE EMPENHO 2026NE00432, Data: 10/06/2026, Valor: R$16.530,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: MATHEUS GOMES DE CASTRO Processo: 00193-00000787/2026-09. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 146/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, ANDRÉA SAMARA DA SILVA MORAES como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Production and characterization of cassava and sweet potato spirits using different methodologies for the hydrolysis of starchy raw materials”, a ser publicado no periódico "Foods". NOTA DE EMPENHO 2026NE00419, Data: 10/06/2026, Valor: R$20.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: ANDRÉA SAMARA DA SILVA MORAES Processo: 00193-00000792/2026-11. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 141/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, BRUNA RODRIGUES GONTIJO como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Interleukin-1β(C-511T) Genetic Variant and Major Depressive Disorder: A Systematic

Review”, a ser publicado no periódico "International Journal of Molecular Sciences". NOTA DE EMPENHO 2026NE00421, Data: 10/06/2026, Valor: R$15.784,77; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 16/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: BRUNA RODRIGUES GONTIJO Processo: 00193-00000789/2026-90. Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 148/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, ANA LUIZA ARAUJO DOS SANTOS como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Empreendedorismo no contexto da saúde brasileira: análise conceitual”, a ser publicado no periódico "Acta Paulista de Enfermagem". NOTA DE EMPENHO 2026NE00429, Data: 10/06/2026, Valor: R$5.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 17/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: ANA LUIZA ARAUJO DOS SANTOS Processo: 00193-00000784/2026-67 Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 144/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, JOSIVANIA SILVA FARIAS como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "The use of the UTAUT model for telemedicine: A systematic review for developing a research agenda for future studies”, a ser publicado no periódico "DIGITAL HEALTH (SAGE)". NOTA DE EMPENHO 2026NE00448, Data: 10/06/2026, Valor: R$16.480,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de

Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 17/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: JOSIVANIA SILVA FARIAS Processo:00193-00000785/2026-10 Espécie: TERMO DE OUTORGA E ACEITAÇÃO DE APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS - Nº 145/2026 - EDITAL Nº 01/2026 - FAPDF PUBLICA SELEÇÃO PÚBLICA DE PROPOSTAS PARA APOIO FINANCEIRO A PUBLICAÇÃO EM REVISTAS CIENTÍFICAS; PARTES: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como CONCEDENTE; do outro lado, VINÍCIUS COUTINHO DA SILVA como OUTORGADO/COORDENADOR. OBJETO: Conceder apoio financeiro à publicação do artigo científico à publicação do artigo científico ao (a) OUTORGADO(A), intitulado "Start-up of Couette Flow and the Rayleigh–Stokes Problem in a Right-Angled Isosceles Triangular Channe”, a ser publicado no periódico "Symmetry". NOTA DE EMPENHO 2026NE00423, Data: 10/06/2026, Valor: R$ 20.000,00; Programa de trabalho: 19573620727860009; Fonte: 1500.100000000; Natureza de Despesa: 33.90.20; VIGÊNCIA: terá vigência contados a partir da data da sua assinatura do TOA até 12 (doze) meses após a liberação do recurso. DATA DA ASSINATURA: 17/06/2026; SIGNATÁRIOS: pela CONCEDENTE: ANA PAULA ALMEIDA ARAGÃO, Superintendente Científica, Tecnológica e de Inovação; como OUTORGADO/COORDENADOR: VINÍCIUS COUTINHO DA SILVA

ANA PAULA ALMEIDA ARAGÃO Superintendente Científica, Tecnológica e de Inovação

EDITAL Nº 03/2026 - FAPDF MOVIMENTA SELEÇÃO PÚBLICA DE PROPOSTAS APOIO À PROMOÇÃO, REALIZAÇÃO E ORGANIZAÇÃO DE EVENTOS CIENTÍFICOS, TECNOLÓGICOS E DE INOVAÇÃO

EXTRATO DE TERMO DE OUTORGA E ACEITAÇÃO Processo: 00193-00000806/2026-99 Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 130/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; DULCE MARIA FILGUEIRA DE ALMEIDA DONNICI, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “SEMINARIO INTERNACIONAL CORPOREIDADE E TRANSDISCIPLINARIDADE". Nota de Empenho: 2026NE00438, Data: 10/06/2026. Valor: R$ 141.969,11. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: DULCE MARIA FILGUEIRA DE ALMEIDA DONNICI; como Instituição Executora: Universidade de Brasília - (UnB). Processo:00193-00000679/2026-28. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 100/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; ALEXANDRE DODONOV, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “XV Escola de Física Roberto A. Salmeron (EFRAS-15): Mecânica Estatística, Física Quântica e seu Ensino”. Nota de Empenho: 2026NE00420, Data: 10/06/2026. Valor: R$ 42.245,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: ALEXANDRE DODONOV; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000683/2026-96. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 124/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; ULISDETE RODRIGUES DE SOUZA RODRIGUES, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “I LinC – I ENCONTRO INTERNACIONAL DA LINGUÍSTICA DE CONTATO CONTEMPORÂNEA & LANÇAMENTO DO LIVRO “NA ROTA DO CONTATO LINGUÍSTICO: INTERFACES E RESULTADOS” Subtítulo: Interconectando saberes locais e globais a partir do Distrito Federal”. Nota de Empenho: 2026NE00435, Data: 10/06/2026. Valor: R$ 100.052,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 17/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: ULISDETE RODRIGUES DE SOUZA RODRIGUES; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000812/2026-46. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº131/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; SAYONARA DE AMORIM GONÇALVES LEAL, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização

<!-- pagina 72 -->

e à organização do evento intitulado “IV Colóquio Brasil/França Crítica e Pragmatismo nas Ciências Sociais: Repensar a Democracia”. Nota de Empenho: 2026NE00436, Data: 10/06/2026. Valor: R$ 147.191,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: ROZANA REIGOTA NAVES; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000684/2026-31 Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 105/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; EMÍLIA CARVALHO LEITÃO BIATO, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “Encontro Centro-Oeste de Pesquisa Qualitativa Crítica em Saúde: inovação metodológica, formação e articulação em rede”. Nota de Empenho: 2026NE00418, Data: 10/06/2026. Valor: R$ 70.493,81. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: EMÍLIA CARVALHO LEITÃO BIATO; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000681/2026-05. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 103/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; FELIPE RODRIGUES DA COSTA, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “V Seminário Internacional sobre Dupla Carreira Esportiva”. Nota de Empenho: 2026NE00430, Data: 10/06/2026. Valor: R$ 140.609,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: FELIPE RODRIGUES DA COSTA; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000690/2026-98. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação - nº 110/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; MIGUEL GALLY DE ANDRADE, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “VII Colóquio Internacional Estéticas no Centro: Artes e estéticas nos limites da democracia”. Nota de Empenho: 2026NE00428, Data: 10/06/2026. Valor: R$ 67.019,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: MIGUEL GALLY DE ANDRADE; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000813/2026-91. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação - nº 132/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; SÉBASTIEN OLIVIER CHARNEAU, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “3rd Host-Pathogen Interactions Meeting in the One Health Context”. Nota de Empenho: 2026NE00441, Data: 10/06/2026. Valor: R$ 131.302,80. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: SÉBASTIEN OLIVIER CHARNEAU; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000803/2026-55. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação nº 134/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; CYRO LUCAS SILVA CHAGAS, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “IX ENCONTRO REGIONAL DA SOCIEDADE BRASILEIRA DE QUÍMICA – REGIÃO CENTRO-OESTE (SBQ-CO)”. Nota de Empenho: 2026NE00440, Data: 10/06/2026. Valor: R$ 105.900,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 16/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: CYRO LUCAS SILVA CHAGAS; como Instituição Executora: Universidade de Brasília - (UnB). Processo: 00193-00000811/2026-00. Extrato de Termo de Outorga e Aceitação de Apoio à Promoção, Realização e Organização de Eventos Científicos, Tecnológicos e de Inovação

- nº 140/2026 - Edital Nº 03/2026 - FAPDF Movimenta; Partes: Fundação de Apoio à Pesquisa do Distrito Federal (FAPDF) como Concedente; JUSCELINO EUDÂMIDAS BEZERRA, como Outorgado/Coordenador; ROZANA REIGOTA NAVES como Instituição Executora. Objeto: Conceder apoio financeiro à promoção, à realização e à organização do evento intitulado “32º CONGRESSO DE INICIAÇÃO CIENTÍFICA DA UNB E 23º CONGRESSO DE INICIAÇÃO CIENTÍFICA DO DF”. Nota de Empenho: 2026NE00444, Data: 10/06/2026. Valor: R$ 147.315,00. Programa de trabalho: 19573620727860009; Fonte: 100; Natureza de Despesa: 339020; Vigência: até 60 (sessenta) dias após o término do evento. Data da Assinatura: 17/06/2026. Signatários: pela Concedente: Ana Paula Almeida Aragão, Superintendente Científica, Tecnológica e de Inovação; como Outorgado/Coordenador: JUSCELINO EUDÂMIDAS BEZERRA; como Instituição Executora: Universidade de Brasília - (UnB).

ANA PAULA ALMEIDA ARAGÃO Superintendente Científica, Tecnológica e de Inovação

EDITAL Nº 06/2026 – DEMANDA ESPONTÂNEA SELEÇÃO PÚBLICA DE PROPOSTAS DE PESQUISA CIENTÍFICA,

TECNOLÓGICA E INOVAÇÃO RESULTADO PRELIMINAR DA ETAPA I - HABILITAÇÃO A Superintendência Científica, Tecnológica e de Inovação da FUNDAÇÃO DE APOIO À PESQUISA DO DISTRITO FEDERAL – FAPDF, no uso de suas atribuições legais conferidas pelo artigo 17 do Decreto nº 43.189, de 05 de abril de 2022, que aprovou o Estatuto Social da FAPDF, e com fundamento nos artigos 27, incisos II e XVIII, do Regimento Interno, e nos termos do processo 00193-00000011/2026-81, TORNA PÚBLICO O RESULTADO PRELIMINAR DA ETAPA I - HABILTIAÇÃO referente às propostas submetidas para o EDITAL 06/2026 – DEMANDA ESPONTÂNEA - SELEÇÃO PÚBLICA DE PROPOSTAS DE PESQUISA CIENTÍFICA, TECNOLÓGICA E INOVAÇÃO, as propostas serão apresentadas em ordem alfabética, indicando a instituição executora e o valor aprovado por proposta. Inicialmente, será divulgada a relação correspondente à FAIXA A, seguida, posteriormente, da lista referente à FAIXA B. FAIXA A: Ana Claudia Guerra de Araujo, EMBRAPA, R$ 148.130,00; Andreanne Gomes Vasconcelos, PSPDIL, R$ 168.140,00; André Gustavo de Melo Araújo, UnB, R$ 135.000,00; Andréia de Almeida, UnB, R$ 158.110,00; Carla Simone Vizzotto, UnB, R$ 175.000,00; Carlos Andres Charris Vizcaino, UCB, R$ 167.019,00; Daniel Holanda Barroso, UnB, R$ 173.215,91; Diana Quirino Monteiro, UCB, R$ 146.479,22; Diogo de Oliveira Costa, UnB, R$ 87.980,00; Diogo Martins de Sá, UnB, R$ 174.700,00; Diogo Vieira Tibery, UnB, R$ 166.450,00; Elen Presotto, UnB, R$ 126.680,00; Emmanuel de Nazareth Brasil, IDP, R$ 174.660,00; Francine Golghetto Casemiro, UCB, R$ 174.920,00; Frederico Machado Almeida, UnB, R$ 146.000,00; Gabriel Pasquarelli do Nascimento, UnB, R$ 175.000,00; Guilherme Botelho Meireles de Souza, EMBRAPA, R$ 171.550,00; Heitor Siqueira Ribeiro, UnB, R$ 117.000,00;Hugo de Luca Corrêa, UCB, R$ 170.905,22; Ian Carlos Bispo de Carvalho, EMBRAPA, R$ 174.920,00; Isângelo Senna da Costa, ISCP, R$ 170.000,00; Isabella Márcia Soares Nogueira Teotônio, UnB, R$ 172.050,00; Ivair José de Morais Júnior, UCB, R$ 175.000,00; Jayanaraian Ferreira Martins Andrade, UnB, R$ 175.000,00; Jeann Luccas de Castro Sabino de Carvalho, UnB, R$ 174.999,77; José Roberto de Souza Júnior, UDF, R$ 100.000,00; Laura Davison Mangilli Toni, UnB, R$ 138.172,60; Linconl Agudo Oliveira Benito, UNICEUB, R$ 175.000,00; Luciana Lilian Louzada Martini, R$ 175.000,00; Lucas Silva de Oliveira, UnB, R$ 175.000,00; Luis Augusto Conte Mendes Veloso, UnB, R$ 170.000,00; Luis Claudio Martins de Moura, IFB - Gama, R$ 443.107,84; Lysleine Alves de Deus, UCB, R$ 174.970,00; Maria do Carmo de Lima Bezerra, UnB, R$ 164.680,00; Maria Eduarda Azambuja Amaral, IDP, R$ 85.540,00; Márcia Aparecida de Souza, Fênix, R$ 164.928,63; Matheus Anthony de Melo, UCB, R$ 173.324,80; Natalia Pazin Almeida, EMBRAPA, R$ 175.000,00; Patrícia Medeiros de Lima, UCB, R$ 200.200,00; Rafael Barreiros Porto, UnB, R$ 98.706,00; Rafael Besse, UnB, R$ 175.000,00; Raphael Severino Bonadio, UnB, R$ 171.600,00; Rayane Vieira Rodrigues, FGV, R$ 142.404,98; Roberta Fátima Neumeister, UnB, R$ 171.650,00; Samuel Leite Cardoso, UCB, R$ 160.112,83; Tchella Fernandes Maso, UnB, R$ 173.237,44; Thiago Marcel Moyano, UnB, R$ 169.000,00; Vinícius Vigolo, UnB, R$ 171.630,00; Yago de Souza Paiva, FGV, R$ 170.000,00; FAIXA B: Ailton Reis, EMBRAPA, R$ 239.000,00; Aisel Valle Garay, UnB, R$ 350.000,00; Aldo Henrique Fonseca Pacheco Tavares, UnB, R$ 217.000,00; Alessandra Monteiro de Paula, UnB, R$ 302.960,00; Alexandre Anderson de Sousa Munhoz Soares, ARAMARI, R$ 350.000,00; Alexandre Floriani Ramos, CENARGEN, R$ 346.519,50; Alexandre Franco Miranda, UCB, R$ 175.210,00; Alice Kazuko Inoue Nagata, CNPH, R$ 350.000,00; Aline de Queiroz Rodrigues, UnB, R$ 350.000,00; Aline Mizusaki Imoto, ESCS, R$ 286.600,00; Aline Pic-Taylor, UnB, R$ 350.000,00; Aline Silva Moraes, Unb, R$ 350.000,00; Ana Clara Giannecchini, UnB, R$ 338.840,00; Ana Cristi Basile Dias, UnB, R$ 350.000,00; Ana Flávia Alves Parente, UnB, R$ 334.139,00; Anderson de Jesus Gomes, UnB, R$ 300.000,00; André Luís Brasil Cavalcante, UnB, R$ 350.000,00; André Luís Rodrigues Araújo, UnB, R$ 324.040,00; André Von Borries Lopes, UnB, R$ 300.000,00; Andréa de Souza Lobo, UnB, R$ 223.860,00; Andréia Alves Costa Lindinger, UnB, R$ 290.000,00; Andréia Borges Avelar da Silva, UnB, R$ 165.026,90; Andreza Fabro de Bem, UnB, R$ 350.000,00; Angélica Amorim Amato, UnB, R$ 350.000,00; Antonia Débora Camila de Lima Ferreira, Arbor, R$ 348.500,00; Antonio Carlos de Oliveira Miranda, UnB, R$ 328.150,00; Artem Andrianov, UnB, R$ 332.476,00; Aryane Ribeiro Oliveira, FTPDI, R$ 350.000,00; Bárbara Eckstein, CENARGEN, R$ 350.000,00; Beatriz Amália Albarello, UCB, R$ 316.820,00; Benedito Leandro Neto, UnB, R$ 200.482,60; Benjamin Miranda Tabak, FGV, R$ 350.000,00; Brenda Rabello de Camargo, UnB, R$ 182.000,00; Bruna Pena

<!-- pagina 73 -->

Sollero, CENARGEN, R$ 326.547,00; Bruno Stéfano Lima Dallago, UnB, R$ 324.534,72; Carine Royer, UnB, R$ 350.000,00; Carla Nunes de Araujo, UnB, R$ 316.750,00; Carla Tatiana Mota Anflor, UnB, R$ 350.000,00; Carlos Emanoel Vieira Flores Soares, CES My Tech, R$ 349.860,00; Carlos Hiroo Saito, UnB, R$ 283.920,00; Carolina Pescatori Candido da Silva, UnB, R$ 350.000,00; Caroline Oliveira Andrino, UnB, R$ 317.535,00; Cíntia Marques Coelho, UnB, R$ 350.000,00; Clarissa Raquel Motter Dala Senta, UCB, R$ 171.678,00; Claudio Chauke Nehme, UCB, R$ 313.106,11; Cristiano Jacques Miosso Rodrigues Mendes, UnB, R$ 189.112,33; Cristiano Torres do Amaral, Censipam, R$ 349.995,00; Dâmaris Silveira, UnB, R$ 349.500,00; Daniel Abreu de Azevedo, UnB, R$ 340.070,00; Daniel Mendes Pereira Ardisson de Araújo, UnB, R$ 346.560,00; Daniel Teixeira da Costa Araujo, UnB, R$ 97.689,00; Daniela Prometi Ribeiro, UnB, R$ 124.800,00; Daniele Nantes Sobrinho, UnB, R$ 275.450,00;Debora Pires Paula, CENARGEN, R$ 350.000,00; Delvio Sandri, UnB, R$ 127.462,00; Diego Marques Ferreira, Unb, R$ 64.133,33; Eduarda Rezende Freitas, UCB, R$ 94.200,00; Eduardo Cyrino de Oliveira Filho, EMBRAPA, R$ 285.400,00; Eduardo Yoshio Nakano, UnB, R$ 200.000,00; Elaine Cristina Leite Pereira, UnB, R$ 350.000,00; Eleuza Rodrigues Machado, HUB, R$ 350.000,00; Eliana Fortes Gris, UnB, R$ 348.780,00; Eliane Ferreira Noronha, UnB, R$ 343.200,00;Eliete Neves da Silva Guerra, UnB, R$ 350.000,00; Erika Valeria Saliba Albuquerque Freire, CENARGEN, R$ 337.080,00; Fabio Akiyoshi Suinaga, EMBRAPA, R$ 122.035,00; Fábio Comes de Castro, UnB, R$ 259.000,00; Fábio Ferreira Monteiro, UnB, R$ 350.000,00; Fábio Henrique Monteiro Oliveira, IFB, R$ 333.170,00; Fabio Lucio Lopes de Mendonca, UnB, R$ 350.000,00; Fabio Viegas Caixeta, UnB, R$ 349.959,00; Fabricio Machado Silva, UnB, R$ 346.000,00; Felipe Augusto Arakaki, UnB, R$ 257.670,10; Felipe Malheiros Gawryszewski, UnB, R$ 200.500,00; Felipe Saldanha de Araujo, UnB, R$ 302.773,33; Fernanda Cipriano Rocha, UnB, R$ 133.760,00; Fernanda Marsaro dos Santos, SEDF, R$ 238.725,88; Fernanda Vasconcelos de Almeida, UnB, R$ 349.996,00; Fernando Araripe Gonçalves Torres, UnB, R$ 350.000,00; Francis Arody Moreno Vásquez, UnB, R$ 292.200,00; Frank Eduardo da Silva Steinhoff, UnB, R$ 116.180,00; Gabriela Cunha Possa, UnB, R$ 350.000,00; Gabriela Garcia Batista Lima Moraes, UnB, R$ 334.926,61; Genaina Nunes Rodrigues, UnB, R$ 349.936,12; Geovany Araujo Borges, Unb, R$ 213.360,00; Geraldo Magela e Silva, UnB, R$ 350.000,00; Grace Ferreira Ghesti, UnB, R$ 420.520,00; Grácia Maria Soares Rosinha, CENARGEN, R$ 350.000,00; Graziella França Bernardelli Cipriano, UnB, R$ 341.700,00; Guarino Rinaldi Colli, UnB, R$ 337.602,72; Guilherme Caribé de Carvalho, UnB, R$ 349.868,00;Guilherme Siqueira Gomide, UnB, R$ 240.000,00; Gustavo Barcelos Barra, SABIN, R$ 291.812,59; Gustavo de Castro da Silva, UnB, R$ 349.992,00; Gustavo Targino Valente, IFB, R$ 185.700,00; Hadassah Laís de Sousa Santana, FGV, R$ 350.000,00; Helena de Souza Braganca Rocha, UnB, R$ 122.700,00; Helson Mario Martins do Vale, UnB, R$ 205.900,00; Henrique Llacer Roig, UnB, R$ 309.000,00; Herbert Kimura, UnB, R$ 350.000,00; Hugo Tadashi Muniz Kussaba, UnB, R$ 350.000,00; Inez Lopes Matos Carneiro de Farias, UnB, R$ 350.000,00; Ingrid Tavora Weber, UnB, R$ 95.100,00; Isabela Almeida Viana Ramos, UCB, R$ 88.904,60; Izabela Marques Dourado Bastos Charneau, UnB, R$ 350.000,00; Izabela Nunes do Nascimento, Arbor, R$ 341.850,00; Jader Galba Busato, Unb, R$ 286.720,00; Jair Trapé Goulart, UnB, R$ 350.000,00; Jamila Reis de Oliveira, UnB, R$ 350.000,00; Janice Magalhães Lamas, CMBL, R$ 349.946,89; Jiazheng Zhou, UnB, R$ 336.948,00; João Batista Lopes Martins, UnB, R$ 336.632,00; João da Costa Pantoja, Unb, R$ 350.000,00; João Henrique Moreira Viana, CENARGEN, R$ 348.897,80; Joao Luiz Quaglitoti Durigan, UnB, R$ 316.000,00; João Paulo Figueiró Longo, UnB, R$ 313.440,00; Jorge Carlos Lucero, Unb, R$ 182.260,00; Jorge Cesar dos Anjos Antonini, EMBRAPA, R$ 165.841,84; José Antonio Huamaní Coaquira, UnB, R$ 332.980,00; José Francisco Gonçalves Júnior, UnB, R$ 349.971,19; Josevan Cerqueira Leal, UnB, R$ 317.680,00; Juliana Dantas de Almeida, EMBRAPA, R$ 337.620,00; Juliana Lott de Carvalho, UnB, R$ 350.000,00; Laise Rodrigues de Andrade, UnB, R$ 350.000,00; Leandro de Bessa Oliveira, UCB, R$ 297.830,00; Leandro de Sousa Cruz, UnB, R$ 330.460,00; Leonardo Silva Boiteux, CNPH, R$ 350.000,00; Leticia Correa Celeste, UnB, R$ 349.942,60; Lilian Gimenes Giugliano, UnB, R$ 308.400,00; Lívia de Lacerda de Oliveira, UnB, R$ 350.000,00; Liza Maria Souza de Andrade, UnB, R$ 350.000,00; Lorena Carneiro Albernaz, UnB, R$ 274.533,33;Luciana Hagstrom Bex, UnB, R$ 205.899,95; Luciana Hartmann, UnB, R$ 343.758,69; Luciana Lana Rigueira, UCB, R$ 350.000,00; Luciana Melo de Moura, SES/DF, R$ 163.370,00; Ludgero Cardoso Galli Vieira, UnB, R$ 286.150,00; Luis Alexandre Muehlmann, UnB, R$ 350.000,00; Luis Felipe Miguel, UnB, R$ 345.630,00; Luis Henrique Ferreira do Vale, UnB, R$ 350.000,00; Luiz Antonio Ribeiro Junior, UnB, R$ 350.000,00; Luiz Guilherme Grossi Porto, UnB, R$ 237.393,00; Marcella Lemos Brettas Carneiro, UnB, R$ 169.510,00; Marcelo de Macedo Brigido, UnB, R$ 298.000,00; Marcelo Henrique Soller Ramada, UCB, R$ 350.000,00; Marcia Cristina da Silva Magro, UnB, R$ 259.252,16; Marcílio Sérgio Soares da Cunha Filho, UnB, R$ 349.940,00; Marcio José Poças Fonseca, UnB, R$ 350.000,00; Marco Aurélio Caldas de Pinho Pessoa Filho, EMBRAPA, R$ 350.000,00; Marco Aurelio Chaves Cepik, UnB, R$ 350.000,00; Marcos Aparecido Gimenes, CENARGEN, R$ 186.941,60; Maria Cristina Mattar da Silva, CENARGEN, R$ 350.000,00; Maria Esther de Noronha Fonseca Boiteux, EMBRAPA, R$ 350.000,00; Maria Natacha Toral Bertolin, UnB, R$ 345.256,00; Mariana de Souza Castro, UnB, R$

255.000,00; Mariana Machado Hecht, UnB, R$ 333.314,00; Marileusa Dosolina Chiarello, Unb, R$ 349.800,00; Marília de Castro Rodrigues Pappas, CENARGEN, R$ 349.350,00; Marilia Santos Silva Patriota, CENARGEN, R$ 325.500,00; Marisa Von Bülow, UnB, R$ 348.000,00; Martino Giorgioni, UnB, R$ 213.720,00; Maurício Rossato, UnB, R$ 333.200,00; Maxelle Martins Teixeira, FGV, R$ 329.820,00; Mayra Soares Costa Rodrigues, UnB, R$ 303.660,00; Melissa Nara de Carvalho Picinato Pirola, UnB, R$ 127.330,00; Michelle Machado de Oliveira Vilarinho, UnB, R$ 349.980,00; Mônica Alves de Macedo, CNPH, R$ 350.000,00; Muriel Bauermann Gubert, UnB, R$ 330.000,00; Murilo Sversut Dias, UnB, R$ 349.980,00; Naile Dame Teixeira, Unb, R$ 332.180,00; Natalia Maria Aggio, UnB, R$ 63.045,20; Nathann Teixeira Rodrigues, UnB, R$ 283.345,00; Nizamara Simenremis Pereira, IFB - Gama, R$ 349.845,66; Octávio Luiz Franco, UCB, R$ 321.060,00; Oscar Jose Smiderle, EMBRAPA, R$ 324.380,00; Osmindo Rodrigues Pires Júnior, UnB, R$ 266.459,00; Patricia Albuquerque de Andrade Nicola, UnB, R$ 340.200,00; Patrícia Azevedo Garcia, UnB, R$ 334.992,00; Patrícia Ianella, EMBRAPA, R$ 340.750,00; Paulo Cesar de Morais, UCB, R$ 324.750,00; Pedro Henrique de Oliveira Neto, UnB, R$ 350.000,00; Pérola de Oliveira Magalhães Dias Batista, UnB, R$ 350.000,00; Philippe Claude Thierry Lacour, UnB, R$ 273.630,00; Potira Meirelles Hermuche, UnB, R$ 322.855,00; Rafael Castilho Faria Mendes, Unb, R$ 350.000,00; Rafael Plakoudi Souto Maior, UnB, R$ 348.829,80; Raphael Matozo Tromer, UnB, R$ 350.000,00; Raquel Braz Assunção Botelho, UnB, R$ 169.792,00; Regina Célia de Oliveira, UnB, R$ 349.943,00; Regina da Silva Pina Neves, UnB, R$ 228.594,00; Regina Dalcastagnè, UnB, R$ 350.000,00; Regina Maria Dechechi Gomes Carneiro, CENARGEN, R$ 298.185,00; Rejane Ennes Cicerelli, UnB, R$ 274.500,00; Renata Ferreira Silva, FEPECS, R$ 250.600,00; Renata Garcia Dusi, LAZUTECH, R$ 297.000,00; Renata Puppin Zandonadi, UnB, R$ 307.527,76; Reuber Albuquerque Brandao, UnB, R$ 349.910,00; Ricardo Borges Pereira, CNPH, R$ 250.000,00; Ricardo Gargano, UnB, R$ 350.000,00; Ricardo Titze de Almeida, UnB, R$ 698.256,00; Rinaldo Eduardo Machado de Oliveira, UnB, R$ 347.920,00; Rita de Cassia Marqueti Durigan, UnB, R$ 349.000,00; Robert Edward Pogue, UCB, R$ 320.000,00; Roberta Azeredo Murta da Fonseca, UnB, R$ 82.588,00; Roberta Mary Vidotti, UnB, R$ 318.114,00; Roberto Arnaldo Trancoso Gomes, UnB, R$ 350.000,00; Robson de Oliveira Albuquerque, UCB,R$ 348.720,00; Rodrigo Vidal Oliveira, UnB, R$ 259.295,00; Rogerio Biaggioni Lopes, CENARGEN, R$ 315.800,00; Rômulo José da Costa Ribeiro, UnB, R$ 350.000,00; Rosalvo Ermes Streit, UCB, R$ 181.468,00; Rosangela Vieira de Andrade, UCB, R$ 349.727,67; Roseany de Vasconcelos Vieira Lopes, UnB, R$ 330.960,00; Samuel Cordeiro Vitor Martins, EMBRAPA, R$ 331.378,00; Samuel da Silva Aguiar, UCB, R$ 349.345,00; Sandra Fernandes Arruda, UnB, R$ 287.560,00; Sérgio Nogueira Seabra, IESB, R$ 134.490,00; Silvia Ribeiro de Souza, Unb, R$ 290.230,00; Silviene Fabiana de Oliveira, UnB, R$ 135.000,00; Simone da Graca Ribeiro, CENARGEN, R$ 350.000,00; Solange Carvalho Barrios Roveri José, CENARGEN, R$ 254.490,00; Sonia Maria de Freitas, UnB, R$ 350.000,00; Sônia Nair Báo, UnB, R$ 349.460,00; Soraya Adiva Roman Eyzaguirre, UCB, R$ 307.990,60; Suzana Moreira Avila, UnB, R$ 349.805,32; Taís Gratieri, UnB, R$ 350.000,00; Tania Mara Passarelli Tonhati, Unb, R$ 349.225,00; Tanise Vendruscolo Dalmolin, UnB, R$ 271.460,00; Tatiana Karla dos Santos Borges, UnB, R$ 349.898,41; Tatsuya Nagata, UnB, R$ 350.000,00; Taygoara Felamingo de Oliveira, UnB, R$ 332.000,00; Thiago Aparecido Trindade, UnB, R$ 348.340,00; Thiago Felippe Kurudez Cordeiro, UnB, R$ 309.850,00; Thiago Jose de Carvalho Andre, UnB, R$ 350.000,00; Thomas Christopher Rhys Williams, UnB, R$ 181.000,00; Uidemar Morais Barral, UnB, R$ 251.080,00; Valdirene Maria Silva Capuzzo, UnB, R$ 324.000,00; Veronica de Barros Slobodian Motta, UnB, R$ 345.782,00; Vinícius Machado dos Santos, IFB, R$ 141.000,00; Vinicius Zacarias Maldaner da Silva, UnB, R$ 341.600,00; Wagner Fontes, UnB, R$ 350.000,00; Wagner Rodrigues Martins, UnB, R$ 271.300,00; Walter de Britto Vidal Filho, UnB, R$ 112.250,00; Walterlânia Silva Santos, UnB, R$ 349.443,87; Warley Marcos Nascimento, CNPH, R$ 181.460,80; Weeberb João Réquia Júnior, FGV, R$ 347.600,00; Welitom Rodrigues Borges, UnB, R$ 347.890,00; Wiliam Ferreira da Cunha, UnB, R$ 350.000,00; William Ferreira Giozza, UnB, R$ 350.000,00; Yris Maria Fonseca Bazzo, UnB, R$ 350.000,00. INFORME: Ressalta-se que esta lista contempla apenas as propostas habilitadas de forma PRELIMINAR e não ranqueadas na ETAPA I – HABILITAÇÃO, conforme item 13.1.1.1 do Edital. A classificação nesta etapa não implica direito subjetivo ao apoio financeiro, constituindo mera expectativa de direito, condicionada à disponibilidade orçamentária e financeira do presente Edital, nos termos do item 17.3. Ressalta-se, ainda, que a habilitação preliminar nesta fase refere-se exclusivamente à verificação de requisitos formais e documentais, não representando julgamento de mérito da proposta. Em atenção aos itens 16.1 e 16.2, a partir desta data está aberto o prazo para interposição de recurso administrativo. Em caso de não habilitação da proposta ou de interesse em obter detalhes sobre a análise da proposta habilitada, o proponente deverá encaminhar sua solicitação para coobe@fap.df.gov.br.

ANA PAULA ALMEIDA ARAGÃO Superintendente Científica, Tecnológica e de Inovação

<!-- pagina 74 -->

## SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA

EDITAL Nº 10 CONVOCAÇÃO DOS SUPLENTES HABILITADOS DAS PROPOSTAS INSCRITAS NA SELEÇÃO PÚBLICA DE QUE TRATA O EDITAL Nº 23/2025 - FAC II - DEMAIS ÁREAS, PARA FIRMAR TERMO DE AJUSTE DE APOIO FINANCEIRO COM O FUNDO DE APOIO À CULTURA A SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA DO DISTRITO FEDERAL, observado o Edital nº 23/2025 - FAC II - DEMAIS ÁREAS, convoca os seguintes suplentes Habilitados no "Anexo III - Ampla Concorrência" para assinar Termo de Ajuste de apoio financeiro com o Fundo de Apoio à Cultura. 1. ANEXO III - AMPLA CONCORRÊNCIA:

NÚMERO DO PROJETO

SUBMODALIDADE DE CONCORRÊNCIA

ÁREA CULTURAL

LINHA DE APOIO

AGENTE CULTURAL

Criação de Espetáculos e Números - Módulo I

II.AC.0939 Ampla Concorrência Manifestações Circenses

Júlio Cesar Macedo Esquinas

Criação de Espetáculos e Números - Módulo I

II.AC.0132 Ampla Concorrência Manifestações Circenses

Cleuberth Santana Bandeira Sob a Lira

Criação de Espetáculos e Números - Módulo I

MARCELLA SEIXAS FERNANDES ROMAR

II.AC.0386 Ampla Concorrência Manifestações Circenses

RESULTADO FINAL DE HABILITAÇÃO

CONVOCAÇÃO PARA ASSINATURA DE TERMO DE AJUSTE

NOME DO PROJETO CONVOCAÇÃO COLOCAÇÃO

CONVOCADO PARA HABILITAÇÃO COMO SUPLENTE

CONVOCADO PARA ASSINAR TERMO DE AJUSTE

1º SUPLENTE HABILITADO

CONVOCADO PARA HABILITAÇÃO COMO SUPLENTE

CONVOCADO PARA ASSINAR TERMO DE AJUSTE

2º SUPLENTE HABILITADO

MIMESE, MANEIRISTO E MELANCIA

CONVOCADO PARA HABILITAÇÃO COMO SUPLENTE

CONVOCADO PARA ASSINAR TERMO DE AJUSTE

3º SUPLENTE HABILITADO

2. NOTAS EXPLICATIVAS: 2.1. Em virtude da Portaria nº 121, de 10 de junho de 2026, publicada no Diário Oficial do Distrito Federal - Edição Extra nº 57-A, de 12 de junho de 2026, que trata da descentralização da execução de crédito orçamentário da Secretaria de Estado de Cultura e Economia Criativa do DF para o Fundo de Apoio à Cultura - FAC, no valor de R$ 300.000,00 (trezentos mil reais), houve a suplementação do valor originalmente destinado à linha de apoio Criação de Espetáculos e Números, Área Cultural Manifestações Circenses do Edital FAC nº 23/2025 e a consequente necessidade de convocação dos suplentes da referida linha de apoio para preenchimento das vagas criadas, até o limite do valor decentralizado. 2.2 De acordo com o Edital nº 23/2025 - FAC II - DEMAIS ÁREAS, os Agentes Culturais só podem assinar o Termo de Ajuste com 01 (um) projeto do referido Edital. 3. DAS DISPOSIÇÕES FINAIS 3.1 As fichas de avaliações da Fase de Habilitação poderão ser consultadas no site da Subsecretaria de Fomento e Incentivo Cultural - SUFIC/SECEC, por meio do endereço eletrônico: https://sufic.cultura.df.gov.br/. 3.2 A Secretaria de Estado de Cultura e Economia Criativa do DF fará a verificação de ocorrências impeditivas, nos Sistemas SIGGO e CEPIM, em relação à pessoa física ou jurídica; e poderá reemitir certidões disponíveis eletronicamente, nos casos de vencimento de sua validade. 3.3 O proponente de projeto contemplado nesta seleção deverá efetuar cadastro, como usuário externo no Sistema Eletrônico de Informações - SEI (http://portalsei.df.gov.br/), no prazo de 72h, após a publicação deste resultado. 3.4 Após efetuar o cadastro, o proponente contemplado na seleção será notificado via e-mail para que acesse seu processo e efetue a impressão de ofício que deverá ser apresentado em uma agência do Banco de Brasília - BRB para abertura de conta corrente específica do projeto, sendo de sua inteira responsabilidade o acompanhamento de seu processo eletrônico, bem como o cumprimento de todos os prazos. 3.5 O comprovante de abertura de conta deve ser apresentado, via E-Protocolo, no prazo máximo de 72h, a contar do primeiro dia útil subsequente ao envio do e-mail indicado no item anterior. 3.6 O Termo de Ajuste será disponibilizado ao "CONVOCADO PARA ASSINAR TERMO DE AJUSTE", por meio do processo SEI/GDF, e deverá ser assinado no prazo de até 5 (cinco) dias corridos, a contar da data de disponibilização do documento para assinatura. 3.7 O acompanhamento de todas as etapas do processo seletivo e a observância aos prazos serão de inteira responsabilidade do proponente, que deverá ficar atento às publicações no Diário Oficial do Distrito Federal - DODF e no site da Subsecretaria de Fomento e Incentivo Cultural - SUFIC (https://sufic.cultura.df.gov.br/).

Brasília/DF, 19 de junho de 2026 FERNANDO MODESTO MAGALHÃES VIEIRA

Secretário de Estado

SEGUNDO TERMO ADITIVO AO CONTRATO DE PRESTAÇÃO DE SERVIÇOS Nº 09/2021-SECEC, NOS TERMOS DO PADRÃO 14/2002.

PROCESSO Nº 00150-00003051/2020-12 CLÁUSULA PRIMEIRA – DAS PARTES: O DISTRITO FEDERAL, por meio da SECRETARIA DE ESTADO DE CULTURA E ECONOMIA CRIATIVA, representada por FERNANDO MODESTO MAGALHÃES VIEIRA, na qualidade de Secretário de Estado, cuja delegação de competência prevista nas Normas de Execução Orçamentária, Financeira e Contábil do Distrito Federal e a empresa INFORMA SOFTWARE SOLUTIONS LTDA, doravante denominada Contratada, CNPJ nº 04.248.864/0001-88, com sede em Rua Agostinho Honório Braga, 85, - Jardim Maracanã - São José do Rio Preto/SP - CEP 15092-010, representada por MARCELO RENATO PATRÃO ESTEVES, na qualidade de representante legal. CLÁUSULA SEGUNDA – DO OBJETO: O presente Termo Aditivo objetiva a prorrogação do prazo de vigência do CONTRATO DE PRESTAÇÃO DE SERVIÇOS Nº 09/2021- SECEC por mais 12 (doze) meses, ou seja, de 24/06/2026 a 23/06/2027, com base no art. 57, II, combinado com o §1º e §4º da Lei Federal nº 8.666, de 21 de junho de 1993. CLÁUSULA TERCEIRA – DO PRAZO DE VIGÊNCIA E DA RESOLUÇÃO CONTRATUAL ANTECIPADA: Subcláusula Primeira - O prazo de vigência deste Termo Aditivo é de até 12 (doze) meses, com início em 24 de junho de 2026 e encerramento em 23 de junho de 2027. Subcláusula Segunda – Da Resolução Antecipada: O período fixado na Subcláusula Primeira fica sujeito à condição resolutiva expressa, podendo o contrato ser resolvido de pleno direito a qualquer tempo, em período inferior a 12 (doze) meses, bastando para isso a conclusão do procedimento licitatório objeto do Processo nº 00150-00005103/2026-81 e a consequente assinatura do novo instrumento contratual. Subcláusula Terceira – Dos Efeitos da Resolução e Inexistência de Indenização: Ocorrendo a resolução antecipada pelo motivo previsto na Subcláusula Segunda, a CONTRATADA aceita e concorda, de forma expressa, irrevogável e irretratável, que: I – Não subsistirá em favor da CONTRATADA qualquer direito a indenização, retenção, reembolso, lucros cessantes ou reparação financeira de qualquer natureza em decorrência do encerramento antecipado do vínculo; II – A única e exclusiva obrigação financeira do órgão público CONTRATANTE será o pagamento estrito dos serviços que tenham sido efetivamente prestados e atestados pela fiscalização até a data em que operada a resolução, calculados pro rata temporis se necessário. Subcláusula Quarta – Do Termo Final e Notificação: O contrato considerar-se-á formalmente resolvido na data imediatamente anterior à do início da vigência do novo contrato decorrente da licitação. O CONTRATANTE notificará a CONTRATADA por escrito com antecedência mínima de 30 (trinta) dias sobre a data exata do encerramento das atividades. CLÁUSULA QUARTA – DA RATIFICAÇÃO: Permanecem inalteradas as demais cláusulas do Contrato a que se refere o presente Termo Aditivo. CLÁUSULA QUINTA – DO CUMPRIMENTO AO DECRETO DISTRITAL Nº 34.031/2012: Havendo irregularidades neste instrumento, entre em contato com a Ouvidoria de Combate à Corrupção, no telefone 0800.6449060 – Decreto nº 34.031/2012. CLÁUSULA SEXTA – DA PUBLICAÇÃO E DO REGISTRO: A eficácia deste Termo fica condicionada à publicação resumida do instrumento pela Administração, na imprensa oficial, até o quinto dia útil do mês seguinte ao da assinatura, para ocorrer no prazo de vinte dias daquela data, após o que deverá ser providenciado o registro do instrumento pela Secretaria de Estado de cultura e Economia Criativa do Distrito Federal. Brasília, 16 de junho de 2026. Pelo Distrito Federal: FERNANDO MODESTO MAGALHÃES VIEIRA Pela Contratada: MARCELO RENATO PATRÃO ESTEVES.

<!-- pagina 75 -->

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO SOCIAL

### SECRETARIA EXECUTIVA DE DESENVOLVIMENTO SOCIAL SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

EXTRATO DE NOTIFICAÇÃO O SUBSECRETÁRIO DE ADMINISTRAÇÃO GERAL, DA SECRETARIA EXECUTIVA DE DESENVOLVIMENTO SOCIAL, DA SECRETARIA DE ESTADO DE DESENVOLVIMENTO SOCIAL DO DISTRITO FEDERAL, Substituto, no uso da atribuição que lhe confere o art. 17, inciso VI, do Anexo Único à Portaria Seplad nº 610, de 20 de setembro de 2023, resolve NOTIFICAR os cidadãos abaixo identificados, para ressarcimento ao erário de parcelas recebidas irregularmente, provenientes de Programas Sociais geridos por esta Secretaria de Estado:

Nome Processo Nº CPF

Erci Oliveira de Lacerda Costa 00431-00026184/2025-89

***219.766**

Laura Maria Coelho de Oliveira 00431-00024115/2025-31

***893.851**

Celma Andreza da Costa Pedro 00431-00018835/2025-67

***646.344**

Fernanda de Souza Tiago 00431-00018803/2025-61

***101.816**

Maria Aparecida 00431-00018854/2025-93

***709.671**

Rosangela da Silva Correa 00431-00018889/2025-22

***523.561**

Celina Teixeira Costa 00431-00018866/2025-18 ***842.042**

Lorena Mendes Guerra 00431-00027043/2025-83 ***026.071**

Maria de jesus Goncalves dos santos 00431-00026408/2025-52 ***885.151**

Damiana Lopes da Silva 00431-00022589/2025-48 ***958.911**

O (A) cidadão (ã) deverá procurar pessoalmente a Sedes/DF, localizada na SEPN 515, Bloco B, 3º andar, por intermédio da Subsecretaria de Administração Geral (Suag), ou pelo telefone 61 3373-7168, para melhores informações e para regularização das pendências havidas.

YAN DE OLIVEIRA CARVALHO

COORDENAÇÃO DE LICITAÇÕES, CONTRATOS E CONVÊNIOS

RESULTADO DE LICITAÇÃO PREGÃO ELETRÔNICO SRP Nº 90006/2025 A Secretaria de Estado de Desenvolvimento Social - SEDES/DF torna público aos interessados o resultado do pregão supracitado, cujo objeto é a contratação, por meio de sistema de Registro de Preços, de empresa especializada na prestação do serviço continuado de alimentação e nutrição, sem dedicação de mão de obra exclusiva, para gestão do Restaurante Comunitário do DF, localizado na Região Administrativa da Estrutural, a partir do preparo, fornecimento e distribuição de refeições nutricionalmente adequadas e saudáveis do tipo café da manhã, almoço e jantar, visando o atendimento das demandas da Secretaria de Estado de Desenvolvimento Social, conforme condições e especificações constantes no Termo Referência constante do Anexo I do Edital. A vencedora com o lance de R$ 10.245.398,40 (dez milhões, duzentos e quarenta e cinco mil, trezentos e noventa e oito e quarenta centavos) para o Grupo/Lote 2, adjudicado e homologado à empresa: CIGA COZINHA INDUSTRIAL E GESTAO ALIMENTAR LTDA, inscrita no CNPJ sob nº 11.133.237/0001-67. Os Termos de Adjudicação e Homologação atendem ao Art. 46 do Decreto Federal nº 10.024/2019, recepcionado no Distrito Federal pelo Decreto Distrital nº 40.205/2019, e estão disponíveis no sítio www.compras.gov.br. UASG 450858.

LEIDIANE DA SILVA SILVERIO

Pregoeira

RESULTADO DE LICITAÇÃO PREGÃO ELETRÔNICO SRP Nº 90006/2025 A Secretaria de Estado de Desenvolvimento Social - SEDES/DF torna público aos interessados o resultado do pregão supracitado, cujo objeto é a contratação, por meio de sistema de Registro de Preços, de empresa especializada na prestação do serviço continuado de alimentação e nutrição, sem dedicação de mão de obra exclusiva, para gestão do Restaurante Comunitário do DF, localizado na Região Administrativa do Sol Nascente, a partir do preparo, fornecimento e distribuição de refeições nutricionalmente adequadas e saudáveis do tipo café da manhã, almoço e jantar, visando o atendimento das

demandas da Secretaria de Estado de Desenvolvimento Social, conforme condições e especificações constantes no Termo Referência constante do Anexo I do Edital. A vencedora com o lance de R$ 9.349.167,60 (nove milhões, trezentos e quarenta e nove mil cento e sessenta e sete reais e sessenta centavos) para o Grupo/Lote 3, adjudicado e homologado à empresa: CIGA COZINHA INDUSTRIAL E GESTAO ALIMENTAR LTDA, inscrita no CNPJ sob nº 11.133.237/0001-67. Os Termos de Adjudicação e Homologação atendem ao Art. 46 do Decreto Federal nº 10.024/2019, recepcionado no Distrito Federal pelo Decreto Distrital nº 40.205/2019, e estão disponíveis no sítio www.compras.gov.br. UASG 450858.

LEIDIANE DA SILVA SILVERIO

Pregoeira

DIRETORIA DE LICITAÇÕES

RESULTADO DE LICITAÇÃO PREGÃO ELETRÔNICO SRP Nº 90006/2025 Processo SEI-GDF nº 00431-00004839/2026-49. A Secretaria de Estado de Desenvolvimento Social – SEDES/DF torna público aos interessados o resultado do pregão supracitado, cujo objeto é a contratação, por meio de sistema de Registro de Preços, de empresa especializada na prestação do serviço continuado de alimentação e nutrição, sem dedicação de mão de obra exclusiva, para gestão do Restaurante Comunitário do DF, localizado na Região Administrativa da Estrutural, a partir do preparo, fornecimento e distribuição de refeições nutricionalmente adequadas e saudáveis do tipo café da manhã, almoço e jantar, visando o atendimento das demandas da Secretaria de Estado de Desenvolvimento Social, conforme condições e especificações constantes no Termo Referência constante do Anexo I do Edital. A vencedora com o lance de R$ 10.245.398,40 (dez milhões, duzentos e quarenta e cinco mil, trezentos e noventa e oito e quarenta centavos) para o Grupo/Lote 2, adjudicado e homologado à empresa: CIGA COZINHA INDUSTRIAL E GESTAO ALIMENTAR LTDA, inscrita no CNPJ sob nº 11.133.237/0001-67. Os Termos de Adjudicação e Homologação atendem ao Art. 46 do Decreto Federal nº 10.024/2019, recepcionado no Distrito Federal pelo Decreto Distrital nº 40.205/2019, e estão disponíveis no sítio www.compras.gov.br. UASG 450858.

LEIDIANE DA SILVA SILVERIO

Pregoeira

RESULTADO DE LICITAÇÃO PREGÃO ELETRÔNICO SRP Nº 90006/2025 Processo SEI-GDF nº 00431-00004842/2026-62. A Secretaria de Estado de Desenvolvimento Social – SEDES/DF torna público aos interessados o resultado do pregão supracitado, cujo objeto é a contratação, por meio de sistema de Registro de Preços, de empresa especializada na prestação do serviço continuado de alimentação e nutrição, sem dedicação de mão de obra exclusiva, para gestão do Restaurante Comunitário do DF, localizado na Região Administrativa do Sol Nascente, a partir do preparo, fornecimento e distribuição de refeições nutricionalmente adequadas e saudáveis do tipo café da manhã, almoço e jantar, visando o atendimento das demandas da Secretaria de Estado de Desenvolvimento Social, conforme condições e especificações constantes no Termo Referência constante do Anexo I do Edital. A vencedora com o lance de R$ 9.349.167,60 (nove milhões, trezentos e quarenta e nove mil cento e sessenta e sete reais e sessenta centavos) para o Grupo/Lote 3, adjudicado e homologado à empresa: CIGA COZINHA INDUSTRIAL E GESTAO ALIMENTAR LTDA, inscrita no CNPJ sob nº 11.133.237/0001-67. Os Termos de Adjudicação e Homologação atendem ao Art. 46 do Decreto Federal nº 10.024/2019, recepcionado no Distrito Federal pelo Decreto Distrital nº 40.205/2019, e estão disponíveis no sítio www.compras.gov.br. UASG 450858.

LEIDIANE DA SILVA SILVERIO

Pregoeira

### COMISSÃO DE SELEÇÃO

COMUNICADO Nº 01/2026 - COMISSÃO DE SELEÇÃO DO EDITAL

DE CHAMAMENTO PÚBLICO Nº 02/2026-SEDES/DF No exercício da competência exarada pela cláusula 7.1 do Edital de Chamamento Público nº 02/2026-Sedes/DF, publicado no Diário Oficial do Distrito Federal - DODF nº 83, de 22 de abril de 2026, a Comissão de Seleção resolve divulgar o Resultado Provisório de classificação de propostas do Edital de Chamamento Público nº 02/2026-Sedes/DF. 1. DA RELAÇÃO DAS PROPOSTAS CLASSIFICADAS 1.1 Relação das propostas classificadas na fase de seleção, em ordem de classificação, observado o disposto no Anexo I - Critérios de Seleção:

Edital de Chamamento Público nº 02/2026-Sedes/DF RESULTADO PROVISÓRIO DE CLASSIFICAÇÃO DAS PROPOSTAS

Classificação Instituição Pontuação

Parecer da

Total

Comissão

Desclassificada Coletivo da Cidade 19 Desclassificada

Desclassificada Eden Instituto de apoio ao desenvolvimento

humano 13 Desclassificada

Desclassificada Fundação Cajuina 14 Desclassificada

<!-- pagina 76 -->

Desclassificada Instituto Cuida Brasil 16 Desclassificada

Desclassificada Instituto Mundo Novo de Economia Sustentável 4 Desclassificada

1ª Instituto Mãos Solidárias 43 Classificada

2ª Instituto EVA – Empoderamento, Valorização e Autoestima 28 Classificada

3ª Instituto Adenilson Cruz 21 Classificada

1.2 Não foram observados empates nas propostas apresentadas, não sendo necessário realizar análise de critérios de desempate, conforme especificado no Inciso III do item PROCEDIMENTOS DE AVALIAÇÃO, do Anexo I do Edital. 1.3 O Relatório de Avaliação das propostas expresso pela Comissão de Seleção consta na Plataforma de Parcerias do GDF e será publicizado no sítio eletrônico oficial da Secretaria de Estado de Desenvolvimento Social do Distrito Federal - Sedes/DF, tal seja “www.sedes.df.gov.br”, até a data de 22 de junho de 2026. 2. DAS PROPOSTAS NÃO ANALISADAS 2.1 Informa-se que as propostas apresentadas pelas instituições abaixo relacionadas não foram analisadas pela Comissão de Seleção, em razão da ausência de envio da proposta necessária para avaliação no âmbito do Edital de Chamamento Público nº 02/2026-Sedes/DF: I – Associação Novo Abraço de Assistência Social a Crianças Carentes, Adolescentes e Meninos de Rua; II – Instituto Tocar; III – Cruz Santos Sociedade Individual de Advocacia; IV – J Carvalho Sociedade Individual de Advocacia; V – Sociedade Vida e Natureza. 2.2 Dessa forma, as referidas instituições não participaram da etapa de avaliação e classificação das propostas. 3. DOS RECURSOS 3.1 A organização da sociedade civil participante poderá interpor recurso até as 23h59 do dia 26 de junho de 2026, pela Plataforma de Parcerias do GDF. 3.1.1 É de inteira responsabilidade da organização da sociedade civil proponente a correta inserção do recurso na Plataforma de Parcerias do GDF. 3.2 O recurso deverá ser redigido de maneira fundamentada, em linguagem clara, consistente e objetiva de seu pleito, subscrito pelo representante legal da instituição. 3.3 Recurso inconsistente ou intempestivo ou cujo teor desrespeite os membros da Comissão de Seleção será preliminarmente indeferido. 3.4 Não será aceito recurso fora do prazo ou em desacordo com o Edital nº 02/2026-Sedes- DF, de 17 de abril de 2026 e seus anexos, ou com este Comunicado.

THAIS MANDARINO DE ALBUQUERQUE

Presidente da Comissão

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO

AVISO DE CONVOCAÇÃO PARA AUDIÊNCIA

PÚBLICA EM SESSÃO PRESENCIAL O GOVERNO DO DISTRITO FEDERAL, por intermédio da SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso de suas atribuições legais estabelecidas na Lei Orgânica do Distrito Federal, e em cumprimento ao estabelecido na Lei nº 5.081, de 11 de março de 2013, que dispõe sobre os procedimentos para a realização de audiências públicas relativas à apreciação de matérias urbanísticas e ambientais no Distrito Federal, CONVOCA toda a população do Distrito Federal - DF, especialmente os moradores do Lago Norte, para participar da audiência pública destinada à apresentação do Estudo Territorial Urbanístico da Saída Norte - ETU 01/2026, a fim de orientar a elaboração de projetos de urbanismo e de regularização fundiária na Região Administrativa do Lago Norte (RA XVIII). A audiência será realizada no dia 10 de agosto de 2026 (segunda-feira), com início às 19h (horário de Brasília), em sessão pública presencial, no auditório da Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal (Seduh), localizado no 18° andar do Edifício Number One, SCN Quadra 1, Bloco A - Asa Norte, Brasília - DF. As informações necessárias sobre a audiência pública estão disponíveis no site da Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal, no link: https://www.seduh.df.gov.br/category/audiencias-publicas, e também no Processo SEI-GDF nº 00390-00008717/2023-30.

REGULAMENTO

Capítulo I Disposições Preliminares Art. 1º A audiência pública realizar-se-á com a finalidade de apresentar e discutir o Estudo Territorial Urbanístico da Saída Norte - ETU 01/2026. Art. 2º Este regulamento define o procedimento que será adotado para o andamento da audiência pública presencial. §1º A audiência pública será de livre acesso para qualquer pessoa, em sessão pública presencial, no auditório da Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal (Seduh), localizado no 18° andar Edifício Number One, SCN Quadra 1, Bloco A - Asa Norte, Brasília - DF.

§2º A audiência pública será registrada por gravação de áudio, sendo que o material produzido comporá a memória do processo, objeto da audiência pública. §3º A audiência pública será transmitida pelo YouTube, através do Canal Conexão Seduh (https://www.youtube.com/conexaoseduh). Art. 3º O público presente no local da audiência deverá preencher lista de presença, que conterá: nome completo, RG ou CPF, número de telefone ou endereço eletrônico (e-mail) e assinatura.

Capítulo II Dos Objetivos da Audiência Pública Art. 4º A audiência pública de que trata o presente aviso tem por objetivo: I – dar publicidade às ações conduzidas pelo Governo do Distrito Federal e pela Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal - Seduh; II – fomentar, provocar e democratizar a efetiva participação da sociedade em geral; III – oferecer à sociedade em geral um ambiente propício ao encaminhamento de seus pleitos e sugestões relacionados à matéria em discussão; e IV – aprimorar, com base nas contribuições recebidas, a proposta do projeto. Parágrafo único. A audiência pública de que trata o presente instrumento tem caráter consultivo e não deliberativo.

Capítulo III Da Condução Art. 5º A audiência pública será conduzida pelo presidente da mesa, responsável pelo planejamento da audiência, composta por representante da equipe técnica da Subsecretaria de Planejamento e Gestão Territorial (Suplan/Seduh). Art. 6º Compete ao presidente: I – abrir a sessão; II – organizar os trabalhos, coordenar a atuação dos demais integrantes da mesa, direcionar as perguntas e complementar as respostas; III – dispor sobre a interrupção, suspensão, prorrogação ou postergação da sessão, bem como sua reabertura e continuação; IV – adotar quaisquer medidas que visem a segurança e o bem-estar do público presente e dos representantes do governo; V – decidir sobre casos omissos e questões de ordem; e VI – encerrar a sessão. Parágrafo único. O presidente poderá, após consulta aos participantes, aumentar o tempo disponível para exposição oral, a depender do número de inscrições e do tempo restante para o final da audiência, sendo-lhe facultado reduzi-lo posteriormente, pelas mesmas razões. Art. 7º A coordenação da mesa terá por atribuições: I – fornecer apoio ao presidente e integrantes da mesa; e II – a guarda da documentação produzida na audiência pública.

Capítulo IV Dos Participantes Art. 8º São direitos e deveres do público presente: I – manifestar-se livremente sobre a matéria em discussão; II – respeitar o tempo estabelecido para intervenção, a ordem de inscrição e as demais regras estabelecidas; e III – tratar com respeito e civilidade os participantes da audiência e seus organizadores. §1º É condição para manifestação oral a prévia inscrição junto à organização do evento durante a audiência pública. §2º A ordem de inscrição determinará a sequência das manifestações. §3º A inscrição para manifestação oral é pessoal e intransferível, vedada a cessão, transferência, compartilhamento ou fracionamento do tempo de fala, total ou parcial, em favor de outro participante, inscrito ou não. Art. 9º Para os debates orais, a manifestação dos participantes deverá seguir a ordem de inscrição e respeitar os seguintes tempos de duração: 5 (cinco) minutos, quando se tratar de representantes de entidades, limitado a 1 (um) representante de cada entidade, e 3 (três) minutos no caso de manifestações individuais.

Capítulo V Da Realização Art. 10. A audiência pública terá a seguinte ordem: I – leitura das regras de funcionamento; II – apresentação técnica; III – exposição resumida do conteúdo da proposta, pela equipe técnica da Subsecretaria de Planejamento e Gestão Territorial (Suplan/Seduh); IV – manifestações dos participantes; e V – encerramento. Art. 11. As perguntas recebidas presencialmente poderão ser respondidas, a critério da mesa, pelos seus integrantes e pela equipe técnica, isoladamente ou em blocos, conforme sua similaridade. Art. 12. Os integrantes da mesa, se o caso, se manifestarão de forma concisa e direta em relação às intervenções orais e escritas dos participantes. Art. 13. Durante a audiência pública serão permitidas gravações ou outras formas de registro pelos participantes do evento.

Capítulo VI Das Disposições Finais Art. 14. A Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal - Seduh divulgará quaisquer alterações ocorridas nas informações constantes deste aviso de convocação para audiência pública por meio de comunicado relevante, a ser publicado no Diário Oficial do Distrito Federal e no site eletrônico www.seduh.df.gov.br.

<!-- pagina 77 -->

Art. 15. A audiência pública será registrada em ata sucinta, anexada à proposição a ser apreciada, publicada no Diário Oficial do Distrito Federal, e no site da Seduh (https://www.seduh.df.gov.br/category/audiencias-publicas), no prazo máximo de 30 (trinta) dias, contados da sua realização, conforme estabelecido no art. 9º da Lei nº 5.081, de 11 de março de 2013. Art. 16. Os casos omissos serão dirimidos pela Secretaria de Estado de Desenvolvimento Urbano e Habitação - Seduh no endereço eletrônico www.seduh.df.gov.br, ou pelo presidente da mesa, durante a realização da audiência pública, observadas as disposições da Lei nº 5.081, de 11 de março de 2013, que disciplina os procedimentos para a realização de audiências públicas relativas à apreciação de matérias urbanísticas e ambientais no Distrito Federal e dá outras providências.

MARCELO VAZ MEIRA DA SILVA

Secretário de Estado

AVISO DE CONVOCAÇÃO PARA AUDIÊNCIA PÚBLICA EM SESSÃO VIRTUAL O GOVERNO DO DISTRITO FEDERAL, por intermédio da SECRETARIA DE ESTADO DE DESENVOLVIMENTO URBANO E HABITAÇÃO DO DISTRITO FEDERAL, no uso de suas atribuições legais estabelecidas na Lei Orgânica do Distrito Federal, e em cumprimento ao estabelecido na Lei nº 5.081, de 11 de março de 2013, que dispõe sobre os procedimentos para a realização de audiências públicas relativas à apreciação de matérias urbanísticas e ambientais no Distrito Federal, CONVOCA toda a população do Distrito Federal - DF, especialmente os moradores do Lago Sul, para participar da audiência pública destinada à apresentação e debate das propostas de regularização de lotes localizados na Região Administrativa do Lago Sul (RA XVI), conforme descrição abaixo: Regularização do Hospital Lago Sul (Hospital Daher), na QI 7 do SHIS; e Regularização do Centro Comercial Gilberto Salomão, na QI 5 do SHIS. A audiência será realizada no dia 27 de julho de 2026 (segunda-feira), com início às 19h30 (horário de Brasília), por meio da plataforma Zoom: https://us02web.zoom.us/j/89491628447?pwd=kcvFd0jaFlrWOcRqkKP6A2BTW8BAea.1 (ID da reunião: 894 9162 8447 - Senha: 321512). As informações necessárias sobre a audiência pública estão disponíveis no site da Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal, no link: https://www.seduh.df.gov.br/category/audiencias-publicas, e também no Processo SEI-GDF nº 00390-00000853/2026-24.

REGULAMENTO

Capítulo I Disposições Preliminares Art. 1º A audiência pública realizar-se-á com a finalidade de apresentar e debater as propostas de regularização de lotes localizados na Região Administrativa do Lago Sul: do Hospital Lago Sul (Hospital Daher), situado na QI 7 do SHIS, e do Centro Comercial Gilberto Salomão, situado na QI 5 do SHIS. Art. 2º Este regulamento define o procedimento que será adotado para o andamento da audiência pública virtual. §1º A audiência pública será de livre acesso para qualquer pessoa, bem como aos meios de comunicação, de forma virtual. §2º A audiência pública será registrada por gravação de áudio e vídeo, sendo que o material produzido comporá a memória do processo, objeto da audiência pública. Art. 3º O público participante deverá realizar o registro de presença no ambiente virtual, informando o nome completo, telefone e endereço de e-mail. O mesmo registro deverá ser efetuado por meio do chat da plataforma utilizada para a audiência pública.

Capítulo II Dos Objetivos da Audiência Pública Art. 4º A audiência pública de que trata o presente aviso tem por objetivo: I – dar publicidade às ações conduzidas pelo Governo do Distrito Federal e pela Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal - Seduh; II – fomentar, provocar e democratizar a efetiva participação da sociedade em geral; III – oferecer à sociedade em geral um ambiente propício ao encaminhamento de seus pleitos e sugestões relacionados à matéria em discussão; e IV – aprimorar, com base nas contribuições recebidas, a proposta do projeto. Parágrafo único. A audiência pública de que trata o presente instrumento tem caráter consultivo e não deliberativo.

Capítulo III Da Condução Art. 5º A audiência pública será conduzida pelo presidente, responsável pelo planejamento da audiência pública virtual, composta por representante da equipe técnica da Subsecretário de Projetos e Licenciamento de Infraestrutura(Suproj/Seduh). Art. 6º Compete ao presidente: I – abrir a sessão; II – organizar os trabalhos, coordenar a atuação dos demais integrantes da mesa, direcionar as perguntas e complementar as respostas; III – dispor sobre a interrupção, suspensão, prorrogação ou postergação da sessão, bem como sua reabertura e continuação; IV – adotar quaisquer medidas que visem a segurança e o bem-estar do público presente e dos representantes do governo; V – decidir sobre casos omissos e questões de ordem; e VI – encerrar a sessão.

Parágrafo único. O presidente poderá, após consulta aos participantes, aumentar o tempo disponível para exposição oral, a depender do número de inscrições e do tempo restante para o final da audiência, sendo-lhe facultado reduzi-lo posteriormente, pelas mesmas razões. Art. 7º A coordenação da mesa terá por atribuições: I – fornecer apoio ao presidente; e II – a guarda da documentação produzida na audiência pública.

Capítulo IV Dos Participantes Art. 8º São direitos e deveres do público presente: I – manifestar-se livremente sobre a matéria em discussão; II – respeitar o tempo estabelecido para intervenção, a ordem de inscrição e as demais regras estabelecidas; e III – tratar com respeito e civilidade os participantes da audiência e seus organizadores. §1º É condição para manifestação oral a prévia inscrição no chat durante a audiência pública. §2º A ordem de inscrição determinará a sequência das manifestações. §3º A inscrição para manifestação oral é pessoal e intransferível, vedada a cessão, transferência, compartilhamento ou fracionamento do tempo de fala, total ou parcial, em favor de outro participante, inscrito ou não. Art. 9º Para os debates orais, a manifestação dos participantes deverá seguir a ordem de inscrição e respeitar os seguintes tempos de duração: 5 (cinco) minutos, quando se tratar de representantes de entidades, limitado a 1 (um) representante de cada entidade, e 3 (três) minutos no caso de manifestações individuais.

Capítulo V Da Realização Art. 10. A audiência pública terá a seguinte ordem: I – leitura das regras de funcionamento; II – apresentação técnica; III – exposição resumida do conteúdo da proposta, pela equipe técnica da Subsecretário de Projetos e Licenciamento de Infraestrutura(Suproj/Seduh); IV – manifestações dos participantes; e V – encerramento. Art. 11. Os integrantes da mesa, no ambiente virtual, se o caso, se manifestarão de forma concisa e direta em relação às intervenções orais dos participantes. Art. 12. Durante a audiência pública serão permitidas gravações ou outras formas de registro pelos participantes do evento.

Capítulo VI Das Disposições Finais Art. 13. A Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal - Seduh divulgará quaisquer alterações ocorridas nas informações constantes deste aviso de convocação para audiência pública por meio de comunicado relevante, a ser publicado no Diário Oficial do Distrito Federal e no site eletrônico www.seduh.df.gov.br. Art. 14. A audiência pública será registrada em ata sucinta, anexada à proposição a ser apreciada, publicada no Diário Oficial do Distrito Federal, e no site da Seduh (https://www.seduh.df.gov.br/category/audiencias-publicas), no prazo máximo de 30 (trinta) dias, contados da sua realização, conforme estabelecido no art. 9º da Lei nº 5.081, de 11 de março de 2013. Art. 15. Os casos omissos serão dirimidos pela Secretaria de Estado de Desenvolvimento Urbano e Habitação - Seduh no endereço eletrônico www.seduh.df.gov.br, ou pelo presidente da mesa, no ambiente virtual, durante a realização da audiência pública, observadas as disposições da Lei nº 5.081, de 11 de março de 2013, que disciplina os procedimentos para a realização de audiências públicas relativas à apreciação de matérias urbanísticas e ambientais no Distrito Federal e dá outras providências.

MARCELO VAZ MEIRA DA SILVA

Secretário de Estado

LICENÇA DISTRITAL DE IMPLANTAÇÃO DE INFRAESTRUTURA

DE TELECOMUNICAÇÕES Nº 19/2026 Esta Licença Distrital de Implantação de Infraestrutura de Telecomunicações nº 19/2026 foi emitida pela Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal, para a implantação de equipamentos de infraestrutura de Telecomunicações, Estação Rádio Base - small cell (biosite), localizada em área pública próxima ao Lote 39, Quadra 811 do Setor de Embaixadas Sul - SES, Plano Piloto/DF, pela empresa Tim S.A., CNPJ nº 02.421.421/0001-11, em conformidade com os documentos acostados ao processo administrativo nº 00390-00007339/2024-58. Observação: Esta licença foi emitida visando a renovação da Licença Distrital de Implantação de Redes e Equipamentos de Infraestrutura de Telecomunicações nº 040/2014 (32113488), no âmbito do Processo SEI nº 0390-000610/2014 em atenção ao parágrafo único do art. 19, da Lei Complementar nº 971, de 20 de julho de 2020. Referências de contato: Sr. Yago Vargas Cavalcante - Gestor Financeiro Telefone: (21) 4119-8899 Endereço Eletrônico: tim@timbrasil.com.br

ALTURA DO EQUIPAMENTO VOLUMÉTRICO FIXADO (m) -

ALTURA DA INFRAESTRUTURA DE SUPORTE (m) -

EXTENSÃO DO EQUIPAMENTO – LINEAR EM SUBSOLO (m) 39,50

<!-- pagina 78 -->

TOTAL DA ÁREA OCUPADA – SUPERFÍCIE (m3) -

TOTAL DA ÁREA OCUPADA – SUPERFÍCIE E SUBSOLO (m2) 24,59

TOTAL DA ÁREA OCUPADA – ESPAÇO AÉREO (m3) -

CONCESSÃO DE USO DE ÁREA

PÚBLICA X sim não

MARCELO VAZ MEIRA DA SILVA

Secretário

ESTA LICENÇA DISTRITAL DE IMPLANTAÇÃO DE INFRAESTRUTURA DE TELECOMUNICAÇÕES TEM VALIDADE POR 10 ANOS A PARTIR DA DATA DE SUA

PUBLICAÇÃO NO DIÁRIO OFICIAL DO DISTRITO FEDERAL - DODF.

LICENÇA DISTRITAL DE IMPLANTAÇÃO DE INFRAESTRUTURA

DE TELECOMUNICAÇÕES Nº 20/2026 Esta Licença Distrital de Implantação de Infraestrutura de Telecomunicações nº 20/2026 foi emitida pela Secretaria de Estado de Desenvolvimento Urbano e Habitação do Distrito Federal, para regularização de infraestrutura de telecomunicações implantada de uma Estação Rádio Base - ERB, greenfield, modelo monoposte, localizada no endereço: Setor Habitacional Nova Colina, Condomínio Colina, Lote 20, Sobradinho/DF, pela empresa IHS Brasil Cessão de Infraestrutura S/A., CNPJ nº 15.811.119/0001-11, em conformidade com os documentos acostados ao processo administrativo nº 00390-00011206/2022-14 Observação: Aprovado por inviabilidade técnica (impossibilidade de adequação), a regularização da infraestrutura de telecomunicações, nos moldes do art. 26 da Lei Complementar nº 971, de 10 de julho de 2020. Referências de contato: José Evandro Monteiro - Diretor Legal Endereço e CEP: Av. Dr. Chucri Zaidan, nº 296 – 22º andar, Vila Cordeiro, São Paulo / CEP: 04578-901 Telefone: (11) 4210-6503 - E-mail: evandro.monteiro@ihstowers.com

ALTURA DO EQUIPAMENTO VOLUMÉTRICO FIXADO (m) 37,22

ALTURA DA INFRAESTRUTURA DE SUPORTE (m) 40,00

EXTENSÃO DO EQUIPAMENTO – LINEAR EM SUBSOLO (m) -

TOTAL DA ÁREA OCUPADA – SUPERFÍCIE (m3) -

TOTAL DA ÁREA OCUPADA – SUPERFÍCIE E SUBSOLO (m2) 122,80

TOTAL DA ÁREA OCUPADA – ESPAÇO AÉREO (m3)

CONCESSÃO DE USO DE ÁREA

PÚBLICA sim X não

MARCELO VAZ MEIRA DA SILVA

Secretário

ESTA LICENÇA DISTRITAL DE IMPLANTAÇÃO DE INFRAESTRUTURA DE TELECOMUNICAÇÕES TEM VALIDADE POR 10 ANOS A PARTIR DA DATA DE SUA

PUBLICAÇÃO NO DIÁRIO OFICIAL DO DISTRITO FEDERAL - DODF.

### COMPANHIA DE DESENVOLVIMENTO HABITACIONAL

EXTRATO DO PRIMEIRO TERMO ADITIVO DO CONTRATO Nº 008/2026 Processo: 00392-00001074/2026-90 – Contratante: COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL/CODHAB - CNPJ nº 09.335.575/0001-30; Contratada: ELONETH HABITAÇÃO CONSULTORIA E ASSESSORIA EMPRESARIAL LTDA – CNPJ nº 02.371.211/0001-66. Objeto: Formalização da supressão consensual de 7% (sete por cento) do valor atualizado do Contrato nº 008/2026, nos termos do Decreto Distrital nº 48.509, de 24 de abril de 2026. Valor atualizado do Contrato: R$ 8.159.910,26 (oito milhões, cento e cinquenta e nove mil novecentos e dez reais e vinte e seis centavos). Data da Assinatura: 15/06/2026. Signatários: Pela CODHAB/DF: MARCELO FAGUNDES GOMIDE, na qualidade de Diretor- Presidente; ROXANE DELGADO ALMEIDA, na qualidade de Diretora Financeira; JOSÉ ANTONIO MARTINS JÚNIOR, na qualidade de Procurador Jurídico. Pela Contratada: ÍTALO OLIVEIRA TORRES, na qualidade de Sócio Representante. (Contrato nº 008/2026 publicado no DODF nº 55, de 24 de março de 2026, pág. 157).

DIRETORIA DE ADMINISTRAÇÃO E GESTÃO

EXTRATO DO QUARTO TERMO ADITIVO DO CONTRATO Nº 002/2023 Processo: 00392-00024147/2022-98 – Contratante: COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL/CODHAB - CNPJ nº 09.335.575/0001-30; Contratada: CRUZEIRO SERVIÇOS TÉCNICOS EIRELLI - ME – CNPJ nº 22.575.793/0001-00. Objeto: Formalização da supressão consensual de 1% (um por cento) do valor atualizado do Contrato nº 002/2023, nos termos do Decreto Distrital nº 48.509, de 24 de abril de 2026. Valor atualizado do Contrato: R$ 18.687,70 (dezoito mil, seiscentos e oitenta e sete reais e setenta centavos). Data da Assinatura: 11/06/2026. Signatários: Pela CODHAB/DF: DENNYS DOS SANTOS QUEIROZ, na qualidade de Diretor de Administração e Gestão; JOSÉ ANTONIO MARTINS JÚNIOR, na qualidade de Procurador Jurídico. Pela Contratada: HUGO FLÁVIO RIBEIRO SILVA, na qualidade de Sócio Representante. (Contrato nº 002/2023 publicado no DODF nº 27, de 7 de fevereiro de 2023, pág. 88; Primeiro Termo Aditivo do Contrato nº 002/2023, publicado no DODF nº 28, de 8 de fevereiro de 2024,

pág. 78; Segundo Termo Aditivo do Contrato nº 002/2023, publicado no DODF nº 28, de 10 de fevereiro de 2025, pág. 115; Terceiro Termo Aditivo do Contrato nº 002/2023, publicado no DODF nº 25, de 6 de fevereiro de 2026, pág. 91).

EXTRATO DO SEGUNDO TERMO ADITIVO AO CONTRATO Nº 012/2024 Processo: 00392-00008979/2024-29 – Contratante: COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL/CODHAB – CNPJ nº 09.335.575/0001-30; Contratada: CONFIANÇA EXTINTORES DE INCÊNDIO LTDA – CNPJ nº 00.853.366/0001-03. Objeto: Formalização da supressão consensual de 5% (cinco por cento) do valor atualizado do Contrato nº 012/2024, nos termos do Decreto Distrital nº 48.509, de 24 de abril de 2026. Valor atualizado do Contrato: R$ 1.370,03 (um mil trezentos e setenta reais e três centavos). Data da Assinatura: 17/06/2026. Signatários: Pela CODHAB/DF: DENNYS DOS SANTOS QUEIROZ, na qualidade de Diretor de Administração e Gestão; JOSÉ ANTONIO MARTINS JÚNIOR, na qualidade de Procurador Jurídico. Pela Contratada: GENIVALDO APARECIDO RAMOS DE BRITO, na qualidade de Sócio Representante. (Contrato nº 012/2024 publicado no DODF nº 167, de 30 de agosto de 2024, pág. 75; Primeiro Termo Aditivo ao Contrato nº 012/2024, publicado no DODF nº 156, de 20 de agosto de 2025, pág. 140).

DIRETORIA IMOBILIÁRIA

EDITAL 231/2026 O DISTRITO FEDERAL, representado pela COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL- CODHAB/DF, no uso das atribuições legais, notadamente da Lei nº 4.020/2007, da Lei nº 3.877/2006 e do Decreto nº 33.965/2012. Resolve tornar pública a habilitação de 339 (trezentos e trinta e nove) candidatos que cumpriram aos requisitos da Lei distrital nº 3.877/2006, para compor a demanda do Programa Habitacional do DF. A listagem dos habilitados se encontra disponibilizada no Portal www.codhab.df.gov.br/candidato/pesquisa-cpf.

Brasília/DF, 19 de junho de 2026

RUBENS MENDES

Diretor Imobiliário

EDITAL N° 230/2026 O DISTRITO FEDERAL, representado pela COMPANHIA DE DESENVOLVIMENTO HABITACIONAL DO DISTRITO FEDERAL- CODHAB/DF, no uso das atribuições legais, com fundamentação na Lei Distrital nº 3.877/06, que dispõe sobre a Política Habitacional do Distrito Federal, RESOLVE: a) Abrir prazo para que os candidatos habilitados do Programa Morar Bem, com renda familiar entre R$ 2.000,00 até 12 salários mínimos, manifestarem interesse em adquirir uma unidade habitacional no Residencial Julieta - Samambaia, até as 18 horas do dia 30/06/2026 exclusivamente por meio do aplicativo CODHAB, podendo ser prorrogado por igual período de acordo com determinação da Diretoria Imobiliária da CODHAB.

Brasília/DF, 19 de junho de 2026

RUBENS MENDES

Diretor Imobiliário

## SECRETARIA DE ESTADO DE ESPORTE E LAZER

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

COORDENAÇÃO DE LICITAÇÃO

AVISO DE ABERTURA DE LICITAÇÃO PREGÃO ELETRÔNICO SRP Nº 90002/2026 Processo nº 00220-00004847/2026-43, A Secretaria de Estado de Esporte e Lazer do DF, torna público aos interessados a abertura do certame em epígrafe, cujo objeto é a Contratação de empresa especializada na prestação de serviços de controle e combate de vetores e pragas urbanas, compreendendo as ações de desinsetização, desratização, descupinização e dedetização. Conforme condições, quantidades e exigências estabelecidas no instrumento convocatório e seus anexos. Valor estimado: LOTE 01 Valor TOTAL (R$): 748.047,59 (setecentos e quarenta e oito mil quarenta e sete reais e cinquenta e nove centavos). LOTE 02 Valor TOTAL (R$): 520.889,72(quinhentos e vinte mil oitocentos e oitenta e nove reais e setenta e dois centavos). Tipo: Menor preço por lote. Data de abertura do certame: 09/07/2026 às 10:00h (horário de Brasília/DF). Cópia do Edital no sítio https://www.gov.br/compras/pt-br e em https://www.esporte.df.gov.br/. UASG: 926246. Informações: (61) 4042-2004.

ISAAC SANTOS CARVALHO

Pregoeiro

## SECRETARIA DE ESTADO DO MEIO AMBIENTE

### CONSELHO DO MEIO AMBIENTE DO DISTRITO FEDERAL

CÂMARA JULGADORA DE AUTOS DE INFRAÇÃO

DIRETORIA DE COLEGIADOS

NOTIFICAÇÃO Nº 22/2026 PROCESSO Nº: 00391-00001579/2023-30. INTERESSADO: Departamento Nacional de Infraestrutura de Transportes- DNIT. PROCURADOR: Luiz Guilherme Rodrigues de

<!-- pagina 79 -->

Mello – Diretor. ASSUNTO: Auto de Infração Ambiental nº AI 9559/2023. RELATOR: Lucas Mendonça Takaki – CACI/DF. Fica o Departamento Nacional de Infraestrutura de Transportes- DNIT e seu representante legal, o senhor Luiz Guilherme Rodrigues de Mello - Diretor, NOTIFICADOS do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 9559/2023, que decidiu, por unanimidade, acompanhar o voto do relator (205640858), por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo, por ter atendidos os pressupostos de admissibilidade; e desprovido o recurso, com a manutenção integral da Decisão nº 27/2025-SEMA/GAB/AJL e da Decisão nº 395/2023-IBRAM/PRESI/CIJU/CTIA, confirmando a procedência do Auto de Infração nº 09559/2023 e preservando as penalidades de advertência e multa no valor de R$ 51.151,45 (equivalente a 101 UPDFs/2023). Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

Brasília/DF, 17 de junho de 2026

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 23/2026 PROCESSO Nº: 00391-00003199/2022-59. INTERESSADO: Emerson Francisco da Silva. PROCURADOR: Marcelo Almeida Alves – OAB/DF Nº 34.265 e Júlio Cézar Prates - OAB/DF Nº 58.766. ASSUNTO: Auto de Infração Ambiental nº AI 04862/2022. RELATOR: Glenda Evellyn Bispo – OAB/DF. Fica o senhor Emerson Francisco da Silva e seu representante legal, o senhor Marcelo Almeida Alves – OAB/DF Nº 34.265 e Júlio Cézar Prates - OAB/DF Nº 58.766, NOTIFICADOS do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 04862/2022, que decidiu, por unanimidade, acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido e desprovido o Recurso Administrativo interposto pela Senhor Emerson Francisco da Silva, confirmando integralmente a Decisão n.º 51 (114192617), que confirmou a Decisão n.º 554 (88799318), que julgou procedente o Auto de Infração Ambiental nº 04862/2022 (84112814), mantendo-se as penalidades de advertência a recuperar a área onde foi realizado o aterro nos termos da IN 33/2022 do IBRAM, fixado o prazo de 120 (cento e vinte) dias da ciência da decisão de julgamento para iniciar o procedimento junto ao IBRAM e multa no valor de R$ 48.269,92 (quarenta e oito mil duzentos e sessenta e nove reais e noventa e dois centavos - 101 UPDF's 2022, por transgressão ao art. 54, inciso XX, da Lei Distrital nº 41, de 13 de setembro de 1989. Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 24/2026 PROCESSO Nº: 00391-00004710/2024-00. INTERESSADO: BSB Comercialização de Carnes Nobres e Churrascaria LTDA. PROCURADOR: Thiago de Sousa Barros - OAB/MA 9.839. ASSUNTO: Auto de Infração Ambiental nº AI 11807/2024. RELATOR: Natália Cristina Chagas Mendes Teixeira – SO/DF. Fica a BSB Comercialização de Carnes Nobres e Churrascaria LTDA e seu representante legal, o senhor Thiago de Sousa Barros - OAB/MA 9.839, NOTIFICADOS do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 11807/2024, que decidiu, por unanimidade, acompanhar o voto do relator (204102706), acompanhar o voto do relator, por seus próprios fundamentos jurídicos, para que seja conhecido o recurso final interposto e, no mérito, negar-lhe provimento. Ficando mantida integralmente a Decisão nº 32/2025 - SEMA/GAB/AJL (170248951) e, por conseguinte, a penalidade de advertência por escrito aplicada à empresa BSB Comercialização de Carnes Nobres e Churrascaria Ltda. "Perturbar o sossego e o bem estar da população com emissão de sons acima do permitido em lei, foi constatado em 03/05/2024 às 14:23h Laeq de 65,1dB quando o permitido para a área seria de 50dB, digo 55dB (diurno). O ruído é proveniente de sistema de exaustão. Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 25/2026 PROCESSO Nº: 00391-00012427/2023-62. INTERESSADO: Responsa Bar e Restaurante comercio de alimentos LTDA. PROCURADOR: Eduardo Serra Rossigneux Vieira – OAB/DF 29.370. ASSUNTO: Auto de Infração Ambiental nº AI 5748/2023. RELATOR: Rosangela Isolde Fricke – CREA/DF.

Fica o Responsa Bar e Restaurante comercio de alimentos LTDA e seu representante legal, o senhor Eduardo Serra Rossigneux Vieira – OAB/DF 29.370, NOTIFICADOS do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 5748/20233, que decidiu, por unanimidade, acompanhar o voto do relator (205634873), por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto por Responsa Bar e Restaurante Comércio de Alimentos Ltda. e no mérito, negar-lhe provimento, mantendo integralmente a Decisão nº 49/2025 – SEMA/GAB/AJL e, consequentemente, o Auto de Infração Ambiental nº 05748/2023, bem como as penalidades de advertência e multa aplicadas. Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 26/2026 PROCESSO Nº: 00391-00002291/2025-44. INTERESSADO: Leomar Cenci. PROCURADOR: o mesmo ASSUNTO: Auto de Infração Ambiental nº AI 6352/2025. RELATOR: Arildo Ribeiro Jorge – OAB/DF. Fica o o senhor Leomar Cenci NOTIFICADO do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 6352/2025, que decidiu, por unanimidade, acompanhar o voto do relator (205654332), por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto e, no mérito, não provido, mantendo-se íntegra a Decisão nº 630/2025-IBRAM/PRESI/CIJU/CTIA e as penalidades aplicadas no Auto de Infração nº 06352/2025, com a consequente manutenção da multa no valor de R$ 5.514,00 (cinco mil, quinhentos e catorze reais) - 10 UPDF's 2025. Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 27/2026 PROCESSO Nº: 00391-00003492/2025-69. INTERESSADO: Lucio Parrode Badauy – Madeireira Itapema Ltda. PROCURADOR: o mesmo. ASSUNTO: Auto de Infração Ambiental nº AI 05678/2025. RELATOR: Rosangela Isolde Fricke – CREA/DF. Fica o senhor Lucio Parrode Badauy – Madeireira Itapema Ltda NOTIFICADO do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 05678/2025, que decidiu, por unanimidade, acompanhar o voto do relator (205634636), por seus próprios fundamentos jurídicos, para que seja conhecido o recurso administrativo interposto por Lúcio Parrode Badauy, representante legal da Madeireira Itapema Ltda., e no mérito, negar-lhe provimento, mantendo integralmente a Decisão nº 199/2025 – SEMA/GAB/AJL e, consequentemente, o Auto de Infração Ambiental nº 05678/2025 e a multa aplicada. Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

NOTIFICAÇÃO Nº 28/2026 PROCESSO Nº: 00391-00000981/2024-88. INTERESSADO: Figueiredo e Perrusi Comércio de Veículos Ltda. PROCURADOR: Marisa Tavares Barros Paiva de Moura - OAB/PE 23.647. ASSUNTO: Auto de Infração Ambiental nº AI 10710/2024. RELATOR: Natalia Cristina Chagas Mendes Teixeira – SO/DF. Fica a Figueiredo e Perrusi Comércio de Veículos Ltda e sua representante legal, a senhora Marisa Tavares Barros Paiva de Moura - OAB/PE 23.647, NOTIFICADOS do julgamento da Câmara Julgadora de Autos de Infração do Conselho de Meio Ambiente do Distrito Federal – CJAI/CONAM/DF, 3ª instância recursal administrativa, em sua 83° reunião ordinária, ocorrida em 11 de junho de 2026, referente ao Auto de Infração Ambiental nº 10710/2024, que decidiu, por unanimidade, acompanhar o voto do relator (204886233), por seus próprios fundamentos jurídicos, para que seja conhecido e provido parcialmente o Recurso apresentado, mantendo a penalidade de advertência e reformando a Decisão n.º 81/2025 - SEMA/GAB/AJL (174749292) quanto à multa, fixando-a no valor de R$ 4.881,50 (quatro mil oitocentos e oitenta e um reais e cinquenta centavos), em atenção aos parâmetros de atenuidade e à gravidade da reincidência, pelo enquadramento da autuação na condicionante do § 2º do Art. 49 da Lei nº 41, de 13 de setembro de 1989, por: "Deixar, aquele que tiver o dever legal ou contratual de fazê-lo, de cumprir obrigação de interesse ambiental ao oferecer serviço de lavagem automotiva sem observar o estabelecido nas normas ABNT NBR 14.605 (partes 1, 2, 3, 4, 5 e 6) no que diz respeito à

<!-- pagina 80 -->

instalação de canaletas e ao Sistema Separador Água e Óleo (SSAO)." Nos termos do parágrafo único do artigo 60 da Lei Distrital nº 41/1989 e do artigo 13 do Decreto 38.001/2017, não há mais possibilidade de recurso contra a decisão supracitada. Após apreciação do CONAM/DF, o processo será encaminhado ao Instituto Brasília Ambiental - IBRAM/DF para providências cabíveis.

MARICLEIDE MAIA SAID

Diretora de Colegiados

### INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS - BRASÍLIA AMBIENTAL

SUPERINTENDÊNCIA DE ADMINISTRAÇÃO GERAL

NOTIFICAÇÃO Nº 330/2026 - IBRAM/PRESI/SUAG/DIORF/GEAR O SUPERINTENDENTE DE ADMINISTRAÇÃO GERAL DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL, COM BASE NA INSTRUÇÃO NORMATIVA Nº 03 DE 05 DE OUTUBRO DE 2007, resolve: NOTIFICAR DO LANÇAMENTO DO CRÉDITO TRIBUTÁRIO, EXPRESSO RIACHO GRANDE LTDA, CNPJ: 02.XXX.XXX/0001-23, referente à Taxa de Controle e Fiscalização Ambiental do Distrito Federal - TCFA-DF, instituída pela Lei Distrital nº 6.435 de 20/12/2019, constante nos autos do Processo SEI-GDF Nº 00391-00004893/2026- 17, conforme detalhamento abaixo:

Ano Trimestre Valor Trimestre Valor Principal Total

2025 01, 02 e 03 R$ 3.478,04 R$ 10.434,12

O Prazo para a impugnação do referido lançamento é de até 30 (trinta) dias, conforme art. 36 da Lei Distrital nº 4.567 de 09/05/2011, após a ciência da presente notificação. O valor principal da TCFA-DF será atualizado nos termos da Lei Complementar Distrital nº 435, de 27 de dezembro de 2001, no momento da solicitação de pagamento. Para solicitar o pagamento, deverá acessar o sistema de peticionamento eletrônico do Brasília Ambiental – HARPIA, por meio do link https://harpia.ibram.df.gov.br/externo/login e preencher o requerimento informando o número de processo SEI-GDF da presente notificação. Após o prazo de impugnação, caso não ocorra o pagamento, o lançamento da TCFA-DF será inscrito em dívida ativa.

RICARDO RORIZ Superintendente de Administração Geral

DIRETORIA DE GESTÃO DE PESSOAS ASSESSORIA TÉCNICA DE PAGAMENTO

NOTIFICAÇÃO Nº 45/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor ADEMILSON BUCHER JUNIOR, CPF nº 705.XXX.XXX-87, acerca da existência de débito no valor de R$ 5.465,28 (cinco mil quatrocentos e sessenta e cinco reais e vinte e oito centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008653/2021-87. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 46/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor AILSON RIBEIRO DE ALMEIDA, CPF nº 045.XXX.XXX-52, acerca da existência de débito no valor de R$ 534,16 (quinhentos e trinta e quatro reais e dezesseis centavos), decorrente da rescisão contratual referente ao cargo de Chefe de Brigada Florestal, a partir de 30/11/2022, conforme registrado nos autos do Processo SEI nº 00391-00007484/2022-49.

Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 47/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor ANDERSON LEONARDO DA SILVA, CPF nº 698.XXX.XXX-15, acerca da existência de débito no valor de R$ 2.428,82 (dois mil quatrocentos e vinte e oito reais e oitenta e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008664/2021-67. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 48/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor CAIO AUGUSTO DE SOUZA, CPF nº 038.XXX.XXX-88, acerca da existência de débito no valor de R$ 586,84 (quinhentos e oitenta e seis reais e oitenta e quatro centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391- 00008672/2021-11. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 49/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR a senhora CLAUDIA OLIVEIRA FARIA, CPF nº 040.XXX.XXX-80, acerca da existência de débito no valor de R$ 590,73 (quinhentos e noventa reais e setenta e três centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2023, conforme registrado nos autos do Processo SEI nº 00391- 00007865/2023-17. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 50/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor DENIS DURAES DE OLIVEIRA, CPF nº 029.XXX.XXX-11, acerca da existência de débito no valor de R$ 1.975,78 (um mil novecentos e setenta e cinco reais e setenta e oito centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 22/08/2024, conforme registrado nos autos do Processo SEI nº 00391-00004451/2024-17. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

<!-- pagina 81 -->

NOTIFICAÇÃO Nº 51/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor EDSON DA SILVA DOS SANTOS, CPF nº 040.XXX.XXX-25, acerca da existência de débito no valor de R$ 586,82 (quinhentos e oitenta e seis reais e oitenta e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008677/2021-36. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 52/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor EFRAIM VELOSO DE ALMEIDA, CPF nº 025.XXX.XXX-82, acerca da existência de débito no valor de R$ 4.702,02 (quatro mil setecentos e dois reais e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391-00004443/2024-62. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 54/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor FILIPE GUSTAVO ARISTIDES BELO PINTOS, CPF nº 027.XXX.XXX-35, acerca da existência de débito no valor de R$ 10.058,66 (dez mil cinquenta e oito reais e sessenta e seis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391-00004458/2024-21. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 55/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor FLAVIO PEREIRA DA CRUZ SILVA, CPF nº 717.XXX.XXX- 53, acerca da existência de débito no valor de R$ 2.135,42 (dois mil cento e trinta e cinco reais e quarenta e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008693/2021-29. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 56/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor IAGO SOUZA MEDEIROS, CPF nº 065.XXX.XXX-43, acerca da existência de débito no valor de R$ 1.646,38 (um mil seiscentos e quarenta e seis reais e

trinta e oito centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391- 00008703/2021-26. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 57/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor IGO SAN BELO PINTOS, CPF nº 033.XXX.XXX-76, acerca da existência de débito no valor de R$ 5.380,57 (cinco mil trezentos e oitenta reais e cinquenta e sete centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391- 00004501/2024-58. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 58/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor JACKSON RAMOS BARBOSA, CPF nº 088.XXX.XXX-70, acerca da existência de débito no valor de R$ 1.244,04 (um mil duzentos e quarenta e quatro reais e quatro centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 05/08/2024, conforme registrado nos autos do Processo SEI nº 00391- 00004445/2024-51. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 59/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor JOAO PAULO PATROCINA MARQUES, CPF nº 010.XXX.XXX- 05, acerca da existência de débito no valor de R$ 492,26 (quatrocentos e noventa e dois reais e vinte e seis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 11/10/2023, conforme registrado nos autos do Processo SEI nº 00391-00007910/2023-25. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 60/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor JOSE APARECIDO DE SOUSA, CPF nº 393.XXX.XXX-00, acerca da existência de débito no valor de R$ 586,84 (quinhentos e oitenta e seis reais e oitenta e quatro centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008710/2021-28. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

<!-- pagina 82 -->

NOTIFICAÇÃO Nº 61/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor JULIO OLIVEIRA DOS SANTOS, CPF nº 702.XXX.XXX-21, acerca da existência de débito no valor de R$ 3.284,90 (três mil duzentos e oitenta e quatro reais e noventa centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391- 00004428/2024-14. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 62/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor KELVIN ALVES BARBOSA DA SILVA, CPF nº 035.XXX.XXX- 40, acerca da existência de débito no valor de R$ 391,22 (trezentos e noventa e um reais e vinte e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391- 00008717/2021-40. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 63/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor KERLYSON DA SILVA, CPF nº 064.XXX.XXX-75, acerca da existência de débito no valor de R$ 791,66 (setecentos e noventa e um reais e sessenta e seis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391- 00004549/2024-66. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 64/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor LUCIVAN PEREIRA DA SILVA, CPF nº 552.XXX.XXX-04, acerca da existência de débito no valor de R$ 1.130,96 (um mil cento e trinta reais e noventa e seis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 30/10/2024, conforme registrado nos autos do Processo SEI nº 00391- 00004537/2024-31. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 65/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor LUIZ FILIPE DE SOUZA SOARES, CPF nº 066.XXX.XXX-79, acerca da existência de débito no valor de R$ 492,27 (quatrocentos e noventa e dois reais e vinte e sete centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 06/11/2023, conforme registrado nos autos do Processo SEI nº 00391- 00007959/2023-88.

Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 67/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor RAMILSON LEITAO ALVES, CPF nº 034.XXX.XXX-46, acerca da existência de débito no valor de R$ 1.956,16 (um mil novecentos e cinquenta e seis reais e dezesseis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 26/08/2021, conforme registrado nos autos do Processo SEI nº 00391- 00008740/2021-34. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 68/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor RENATO LIMA MEDEIROS, CPF nº 040.XXX.XXX-83, acerca da existência de débito no valor de R$ 2.135,42 (dois mil cento e trinta e cinco reais e quarenta e dois centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391- 00008743/2021-78. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 69/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor ROBSON FERREIRA PINTO SOUZA, CPF nº 714.XXX.XXX-68, acerca da existência de débito no valor de R$ 6.439,59 (seis mil quatrocentos e trinta e nove reais e cinquenta e nove centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391-00004539/2024-21. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 70/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor SELMY DE SA OLIVEIRA, CPF nº 039.XXX.XXX-26, acerca da existência de débito no valor de R$ 3.684,06 (três mil seiscentos e oitenta e quatro reais e seis centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2021, conforme registrado nos autos do Processo SEI nº 00391-00008785/2021-17. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 71/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve:

<!-- pagina 83 -->

NOTIFICAR o senhor WENCESLAU ALVES MOREIRA NETO, CPF nº 723.XXX.XXX- 87, acerca da existência de débito no valor de R$ 2.650,88 (dois mil seiscentos e cinquenta reais e oitenta e oito centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 01/12/2024, conforme registrado nos autos do Processo SEI nº 00391-00008917/2024-45. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

NOTIFICAÇÃO Nº 72/2026 - IBRAM/PRESI/SUAG/DIGEP/ASPAG A ASSESSORIA TÉCNICA DE PAGAMENTO DO INSTITUTO DO MEIO AMBIENTE E DOS RECURSOS HÍDRICOS DO DISTRITO FEDERAL – BRASÍLIA AMBIENTAL, nos termos do artigo 121, § 3º e 5º, da Lei Complementar 840/2011, resolve: NOTIFICAR o senhor WEBERSON DIONISIO DOS SANTOS, CPF nº 053.XXX.XXX- 51, acerca da existência de débito no valor de R$ 3.616,35 (três mil seiscentos e dezesseis reais e trinta e cinco centavos), decorrente da rescisão contratual referente ao cargo de Brigadista Florestal, a partir de 22/01/2026, conforme registrado nos autos do Processo SEI nº 00391-00007806/2025-01. Fica estabelecido o prazo de 10 (dez) dias, contados a partir da data de publicação desta notificação, para a quitação do referido valor. O não pagamento dentro do prazo estipulado implicará na inscrição do débito em Dívida Ativa, nos termos da legislação vigente.

RICARDO RORIZ Superintendente de Administração Geral

## SECRETARIA DE ESTADO DE TURISMO

EXTRATO DO TERMO DE FOMENTO Nº 26/2026 PROCESSO: 04009-00001080/2026-46. DAS PARTES: DISTRITO FEDERAL, por meio da SECRETARIA DE ESTADO DE TURISMO DO DISTRITO FEDERAL e INSTITUTO VITA PROJETOS SOCIAIS. DO OBJETO: Este instrumento tem por objeto a realização do projeto "UNIÃO DAS MULHERES DO GUARÁ", no dia 20 de junho de 2026, no Pavilhão de Exposições do Parque da Cidade, conforme detalhamento contido no Plano de Trabalho em anexo ao processo na plataforma PARCERIAS/MROSC. VALOR GLOBAL DA PARCERIA E DOTAÇÃO: A despesa correrá à conta da seguinte Dotação Orçamentária: UO: 16101, Programa de Trabalho: 13.392.6219.9075.0386, Fonte: 1500.100000000, o empenho terá o valor total de R$ 399.989,30 (trezentos e noventa e nove mil, novecentos e oitenta e nove reais e trinta centavos), conforme Nota de Empenho nº 2026NE00243, emitida em 18/06/2026, sob o evento nº 400097, na modalidade Global, advindos do orçamento do Distrito Federal. DA VIGÊNCIA: Este instrumento terá vigência do dia 19/06/2026 até 04/07/2026. DATA DE ASSINATURA: 18/06/2026. Pelo Distrito Federal, BERNARDO CARVALHO ANTUNES, na qualidade de SECRETÁRIO DE ESTADO INTERINO DA SECRETARIA DE ESTADO DE TURISMO DO DISTRITO FEDERAL e INSTITUTO VITA PROJETOS SOCIAIS, MARCUS VINICIUS DOS SANTOS SEABRA, na qualidade de PRESIDENTE.

### SUBSECRETARIA DE ADMINISTRAÇÃO GERAL

EXTRATO DO 1º TERMO ADITIVO AO CONTRATO DE PRESTAÇÃO DE SERVIÇOS Nº 57173/2026 PROCESSO: 04009-00002076/2025-71. DAS PARTES: DISTRITO FEDERAL, por meio da SECRETARIA DE ESTADO DE TURISMO DO DISTRITO FEDERAL — SETUR, e a empresa UNEXCOM TECNOLOGIA EM TELECOMUNICAÇÕES LTDA, inscrita no CNPJ nº 33.143.334/0001-73. DO OBJETO: A supressão de 11% (onze por cento) do valor global do Contrato de Prestação de Serviços nº 57173/2026 – SETUR, firmado em 15 de abril de 2026, em decorrência da renegociação contratual realizada nos termos do Decreto nº 48.509/2026. Em razão da supressão pactuada, a Cláusula Quinta – Preço do Contrato nº 57173/2026 – SETUR passa a vigorar com a seguinte redação: O valor total da contratação é de R$ 53.506,80 (cinquenta e três mil, quinhentos e seis reais e oitenta centavos)DA DOTAÇÃO ORÇAMENTÁRIA: A despesa correrá à conta da seguinte Dotação Orçamentária: UO: 27.101; Programa de Trabalho: 23.122.8207.8517.0123 – Manutenção de Serviços Administrativos Gerais – Plano Piloto; Natureza da Despesa: 33.90.39; Fonte de Recursos: 100 — Ordinário não vinculado. DA VIGÊNCIA: 15/04/2026 a 15/04/2027. DATA DE ASSINATURA: 15/04/2026. Pelo Distrito Federal, ANALICE MARIA MARÇAL DE LIMA, na qualidade de Subsecretária de Administração Geral da Secretaria de Estado de Turismo do Distrito Federal, e pela Contratada, PAULA TATIANE DE MATOS, na qualidade de Representante Legal da UNEXCOM TECNOLOGIA EM TELECOMUNICAÇÕES LTDA.

## SECRETARIA DE ESTADO DE DESENVOLVIMENTO

## ECONÔMICO, TRABALHO E RENDA

EXTRATO DO ACORDO DE COOPERAÇÃO TÉCNICA Nº 01/2026 Processo: 04035-00004450/2026-54. DAS PARTES: SECRETARIA DE ESTADO DE DESENVOLVIMENTO ECONÔMICO, TRABALHO E RENDA DO DISTRITO FEDERAL/SEDET e a ADMINISTRAÇÃO REGIONAL DA FERCAL – RA XXX. OBJETO: A disponibilização, pela RA FERCAL à SEDET/DF, de servidor com qualificação e experiência em Engenharia Elétrica para atuação como fiscal técnico do contrato administrativo destinado à manutenção de 02 (dois) transformadores de alta potência integrantes da subestação elétrica do Polo JK, representado pelo Contrato nº 55.781/2025 - DATA/SEDET. DA ASSINATURA: 11/06/2026. DOS PARTÍCIPES: Pela SEDET: THALES MENDES FERREIRA. PELA ADMINISTRAÇÃO DA FERCAL: FERNANDO GUSTAVO LIMA DA SILVA MADEIRA.

EXTRATO DO TERMO DE FOMENTO Nº 04/2026 NUPP Nº 0012-01-000000005225/2026-59. PROCESSO SEI Nº 04035-00003743/2026-14. DAS PARTES: SECRETARIA DE ESTADO DE DESENVOLVIMENTO ECONÔMICO, TRABALHO E RENDA DO DISTRITO FEDERAL – SEDET/DF, CNPJ nº 34.346.776/0001-80, e a OSC.INSTITUTO DE CAPACITACAO DESENVOLVIMENTO E INOVACAO - ICDI, CNPJ nº: 05.047.994/0001-15. DO OBJETO: A realização do projeto "Feirão do Trabalhador 2026 – Brasília", evento destinado à oferta de vagas de emprego, intermediação de mão de obra, realização de palestras, oficinas e orientações profissionais, atendimento ao público e disponibilização de serviços de cidadania e programas governamentais voltados ao trabalho, emprego, renda, qualificação profissional e empreendedorismo., conforme detalhamento contido no Plano de Trabalho, aprovado pelo Parecer Técnico.. DO VALOR: R$ 1.999.923,70 (um milhão, novecentos e noventa e nove mil novecentos e vinte e três reais e setenta centavos). DA DOTAÇÃO ORÇAMENTÁRIA: Unidade Orçamentária: 250101. Programas de Trabalho: 11.333.6207.9107.0517 - (EPI) APOIO À PROJETOS DE GERAÇÃO DE EMPREGO E RENDA. Natureza da Despesa: 335041. Fonte de Recursos: 100. Nota de Empenho nº 2026NE00436, emitida em.11/06/2026. Modalidade: Global. Evento: 400097. DA VIGÊNCIA: Este instrumento terá vigência de 03 (três) meses a contar da data da sua assinatura. DATA DE ASSINATURA: 11/06/2026. SIGNATÁRIOS: Pela SEDET: THALES MENDES FERREIRA e pela OSC, ORGANIZAÇÃO DA SOCIEDADE CIVIL INSTITUTO DE CAPACITACAO DESENVOLVIMENTO E INOVACAO - ICDI: FABIANA RIBEIRO DO NASCIMENTO. Comissão Gestora: Coordenadora: Michelly Ferreira Ribeiro - Matrícula: 172934-9; - Primeira Membra: Thais Gomes Melo de Oliveira - Matrícula: 283694-7; - Segunda Membra: Renata Lauanne França Ribeiro - Matrícula: 276838-0 ; - Terceira Membra: Amanda Jessica Carlos Gusmão - Matrícula: 284676-4.

### COMPANHIA IMOBILIÁRIA DE BRASÍLIA

AGÊNCIA DE DESENVOLVIMENTO

EXTRATO DE INSTRUMENTO CONTRATUAL PROCESSO SEI/GDF: 00111-00004630/2024-27; ESPÉCIE: Contrato nº 28/2026; CONTRATANTES: COMPANHIA IMOBILIÁRIA DE BRASÍLIA – TERRACAP E A EMPRESA TRIER ENGENHARIA S/A; OBJETO: A Contratação por escopo de empresa especializada para execução das obras de implantação de infraestrutura de pavimentação (pavimentação asfáltica, respectiva sinalização e meios fios) e drenagem urbana dos conjuntos de “A” a “R” da Quadra QE 60, localizada na Região Administrativa do Guará – RA X; EMBASAMENTO LEGAL: LICITAÇÃO PRESENCIAL Nº 12/2024- CPLIC/TERRACAP, homologado pela Decisão nº 465/2026, da Diretoria Colegiada da TERRACAP, em sua 3940ª Sessão, realizada em 11/06/2026; VALOR: R$ 49.959.000,00 (quarenta e nove milhões novecentos e cinquenta e nove mil reais); VIGÊNCIA: 720 (setecentos e vinte) dias corridos, contados a partir da data de sua celebração; DATA DA CELEBRAÇÃO: 16/06/2026; P/CONTRATANTE: JÚLIO CESAR DE AZEVEDO REIS, KALINE GONZAGA COSTA, CARLOS ANTONIO LEAL; P/CONTRATADA: ROBSON IRINEU DE FREITAS.

DIRETORIA DE REGULARIZAÇÃO SOCIAL

E DESENVOLVIMENTO ECONÔMICO

AVISO DE CONCESSÃO DE DIREITO DE USO A Diretoria Colegiada da Companhia Imobiliária de Brasília – TERRACAP, em sua 3943ª sessão, realizada em 17/06/2026 decidiu, conforme a Decisão DIRET nº 480/2026, e com fundamento disposto na Lei Distrital nº 6.888/2021 e no Decreto Distrital nº 43.209/2022, APROVAR e autorizar a celebração de Contrato de Concessão de Uso - CDU, com preço público mensal de R$ 21.120,00 (vinte e um mil, cento e vinte reais), com base no valor de avaliação de R$ 17.600.000,00 (dezessete milhões e seiscentos mil reais), da gleba urbana designada como área contígua ao imóvel denominado "SCE/S TRECHO 01 Lote 04 Setor de Clubes Esportivos Sul, Brasília/DF", tendo como Concessionária a entidade ASSOCIAÇÃO DOS EMPREGADOS DA ELETRONORTE - ASEEL - CNPJ

<!-- pagina 84 -->

00.527.317/0001-80, nos termos do processo GDF/SEI nº 00111-00005319/2022-33, podendo, no prazo de 30 (trinta) dias contados da assinatura do contrato, ser requerida pela(o) Concessionária(o) a aplicação do sistema de retribuição em moeda social, desde que atendidos os requisitos legais e decretais, considerando o disposto nos arts. 4º, 5º, 9º e 17º da Lei Distrital nº 6.888/2021 e Decreto Distrital nº 43.209/2022.

Brasília/DF, 18 de junho de 2026

MATEUS BARBOSA Gerente de Habitação e Regularização de Imóveis Urbanos

FERNANDO DE ASSIS BONTEMPO Diretor de Regularização Social e Desenvolvimento Econômico

AVISO DE CONCESSÃO DE DIREITO DE USO A Diretoria Colegiada da Companhia Imobiliária de Brasília – TERRACAP, em sua 3943ª sessão, realizada em 17/06/2026, decidiu, conforme a Decisão DIRET nº 479/2026, e com fundamento disposto na Lei Distrital nº 6.888/2021 e no Decreto Distrital nº 43.209/2022, APROVAR e autorizar a celebração de Contrato de Concessão de Uso - CDU, com preço público mensal de R$ 4.215,00 (quatro mil duzentos e quinze reais), com base no valor de avaliação de R$ 2.810.000,00 (dois milhões oitocentos e dez mil reais), da gleba urbana designada como área contígua ao imóvel "SHCS EQS 108/109 LOTE A – BRASÍLIA/DF", tendo como Concessionária a entidade CLUBE SOCIAL DA UNIDADE DE VIZINHANÇA Nº 1 - CNPJ: 00.040.840/0001-88, nos termos do processo GDF/SEI nº 00111-00003365/2026-21, podendo, no prazo de 30 (trinta) dias contados da assinatura do contrato, ser requerida pela(o) Concessionária(o) a aplicação do sistema de retribuição em moeda social, desde que atendidos os requisitos legais e decretais, considerando o disposto nos arts. 4º, 5º, 9º e 17º da Lei Distrital nº 6.888/2021 e Decreto Distrital nº 43.209/2022.

Brasília/DF, 18 de junho de 2026

MATEUS BARBOSA Gerente de Habitação e Regularização de Imóveis Urbanos

FERNANDO DE ASSIS BONTEMPO Diretor de Regularização Social e Desenvolvimento Econômico

AVISO DE CONCESSÃO DE DIREITO DE USO A Diretoria Colegiada da Companhia Imobiliária de Brasília – TERRACAP, em sua 3943ª sessão, realizada em 17/06/206, decidiu, conforme a Decisão DIRET nº 478/2026, e com fundamento disposto na Lei Distrital nº 6.888/2021 e no Decreto Distrital nº 43.209/2022, APROVAR e autorizar a celebração de Contrato de Concessão de Uso - CDU, com preço público mensal de R$ 11.490,00 (onze mil, quatrocentos e noventa reais), com base no valor de avaliação de R$ 7.660.000,00 (sete milhões seiscentos e sessenta mil reais), da gleba urbana designada como áreas contíguas ao imóvel "SCE/S TRECHO 02 Lote 1-B, Setor de Clubes Esportivos Sul, Brasília/DF", tendo como Concessionária a entidade CLUBE DE ENGENHARIA DE BRASÍLIA - CNPJ: 00.317.131/0001-05, nos termos do processo GDF/SEI nº 00111-00004721/2026-24, podendo, no prazo de 30 (trinta) dias contados da assinatura do contrato, ser requerida pela(o) Concessionária(o) a aplicação do sistema de retribuição em moeda social, desde que atendidos os requisitos legais e decretais, considerando o disposto nos arts. 4º, 5º, 9º e 17º da Lei Distrital nº 6.888/2021 e Decreto Distrital nº 43.209/2022.

Brasília/DF, 18 de junho de 2026

MATEUS BARBOSA Gerente de Habitação e Regularização de Imóveis Urbanos

FERNANDO DE ASSIS BONTEMPO Diretor de Regularização Social e Desenvolvimento Econômico

AVISO DE CONCESSÃO DE DIREITO DE USO A Diretoria Colegiada da Companhia Imobiliária de Brasília – TERRACAP, em sua 3944ª sessão, realizada em 18/06/2026, decidiu, conforme a Decisão DIRET nº 487/2026 e com fundamento disposto na Lei Distrital nº 6.888/2021 e no Decreto Distrital nº 43.209/2022, APROVAR e autorizar a celebração de Contrato de Concessão de Uso - CDU, com preço público mensal de R$ 64.500,00 (sessenta e quatro mil e quinhentos reais), com base no valor de avaliação de R$ 64.500.000,00 (sessenta e quatro milhões quinhentos mil reais), da gleba urbana designada como área contígua ao imóvel denominado "Setor de Clubes Esportivos Sul, SCE/Sul Trecho 3 Lote 05 - Brasília/DF", tendo como Concessionária a entidade ASSOCIAÇÃO MÉDICA DE BRASÍLIA - CNPJ 00.085.803/0001-96, nos termos do processo GDF/SEI nº 00111-00003089/2026-00, podendo, no prazo de 30 (trinta) dias contados da assinatura do contrato, ser requerida pela(o) Concessionária(o) a aplicação do sistema de retribuição em moeda social, desde que atendidos os requisitos legais e decretais, considerando o disposto nos arts. 4º, 5º, 9º e 17º da Lei Distrital nº 6.888/2021 e Decreto Distrital nº 43.209/2022.

Brasília/DF, 18 de junho de 2026

MATEUS BARBOSA Gerente de Habitação e Regularização de Imóveis Urbanos

FERNANDO DE ASSIS BONTEMPO Diretor de Regularização Social e Desenvolvimento Econômico

AVISO DE CONCESSÃO REAL DE DIREITO DE USO A Diretoria Colegiada da Companhia Imobiliária de Brasília – TERRACAP, em sua 3943ª sessão, realizada em 17/06/2026, decidiu, conforme a Decisão DIRET nº 482/2026, e com fundamento disposto na Lei Distrital nº 6.888/2021 e no Decreto Distrital nº 43.209/2022, APROVAR e autorizar a celebração de escritura pública de Concessão de Direito Real de Uso, sem opção de compra - CDRU-S, com preço público mensal de R$ 11.880,00 (onze mil, oitocentos e oitenta reais), com base no valor de avaliação de R$ 7.920.000,00 (sete milhões novecentos e vinte mil reais), do imóvel urbano designado como "SCE/N TRECHO ENSEADA NORTE 01 LT 11-A - Brasília/DF", tendo como Concessionário o CLUBE DOS PIONEIROS DE BRASÍLIA - CNPJ: 00.535.732/0001- 86, nos termos do processo GDF/SEI nº 0111-001438/1986, podendo, no prazo de 30 (trinta) dias contados da assinatura da escritura pública, ser requerida pelo Concessionário a aplicação do sistema de retribuição em moeda social, desde que atendidos os requisitos legais e decretais.

Brasília/DF, 18 de junho de 2026

MATEUS BARBOSA Gerente de Habitação e Regularização de Imóveis Urbanos

FERNANDO DE ASSIS BONTEMPO Diretor de Regularização Social e Desenvolvimento Econômico

COMISSÃO PERMANENTE DE LICITAÇÃO PARA VENDA DE IMÓVEIS

AVISO DE ANULAÇÃO DE HOMOLOGAÇÃO E CONVOCAÇÃO

COMPLEMENTAR DE LICITAÇÃO REFERENTE

AO EDITAL Nº 07/2024–IMÓVEIS Em cumprimento ao acórdão proferido pelo d. Juízo da 8ª Turma Cível do Tribunal de Justiça do Distrito Federal e dos Territórios, nos autos da Apelação Cível nº 0716213- 77.2024.8.07.0018, a COMPANHIA IMOBILIÁRIA DE BRASÍLIA – TERRACAP, por meio de sua Comissão Permanente de Licitação de Venda de Imóveis – COPLI, faz saber aos licitantes e demais interessados a anulação da homologação do imóvel descrito no ITEM 12, localizado no SHA Quadra 09, Conjunto 26, Lote 05, Arniqueira-DF, tornando sem efeito a Decisão nº 672/2024 da Diretoria Colegiada da Terracap – DIRET, veiculada na edição nº 158 do DODF, de 19 de agosto de 2024, que homologou o resultado em favor do licitante EDYWIN DE ARAUJO RIBEIRO.

Brasília/DF, 19 de junho de 2026 BRUNO CÉSAR SANTANA DE MENESES

Presidente da Comissão

AVISO DE DESCLASSIFICAÇÃO E CONVOCAÇÃO DE LICITANTE

REFERENTE AO EDITAL Nº 08/2026–IMÓVEIS O Presidente da Comissão Permanente de Licitação de Venda de Imóveis - COPLI, da Companhia Imobiliária de Brasília - TERRACAP, no uso das atribuições estabelecidas no Edital nº 08/2026-Imóveis, torna público o pedido de desistência e a consequente desclassificação da licitante preliminarmente classificada SEASONS IMOBILIARIA LTDA (Proposta de Compra nº 5033312 - ITEM 95), ficando convocados os subsequentes licitantes, respeitando a ordem classificatória, nos termos do Tópico 77.6.1, CAPÍTULO X - DAS PENALIDADES, para que, no prazo de 10 (dez) dias úteis, contados da publicação no DODF do presente aviso, manifestem, formalmente, interesse na compra do imóvel e concordância com o preço oferecido pela primeira colocada, a saber R$ 1.840.000,00 (um milhão oitocentos e quarenta mil reais), juntamente com toda documentação exigida no Capítulo V – B) DA DOCUMENTAÇÃO NECESSÁRIA PARA QUALQUER MODALIDADE DE PAGAMENTO, condicionando-se a homologação ao atendimento dos demais requisitos contidos no Edital.

Brasília/DF, 18 de junho de 2026 BRUNO CÉSAR SANTANA DE MENESES

Presidente da Comissão

COMISSÃO DE LICITAÇÃO PARA COMPRA

DE BENS, SERVIÇOS E OBRAS

AVISO DE SUSPENSÃO O Presidente da Comissão de Licitação para Compra de Bens, Serviços e Obras – CPLIC/TERRACAP, no uso das atribuições que lhe confere a Portaria nº 185/2025 - DIRAF, comunica a suspensão do seguinte certame.

Processo: 00111-00008817/2025-81

Modalidade/número: LICITAÇÃO ELETRÔNICA Nº 03/2026

<!-- pagina 85 -->

Contratação, por escopo, de empresa de engenharia especializada para execução de obras de drenagem pluvial e implantação de pavimentação, compreendendo a pavimentação das vias em blocos intertravados de concreto, estacionamentos, meios-fios, sarjetas, passeios/calçadas de concreto, acessibilidade, plantio de gramas e sinalização viária, da Quadra 03, Residencial dos Pequis, no Condomínio Aldeias do Cerrado, na Região Administrativa de São Sebastião – RA XIV/DF

Objeto:

Valor estimado (R$): O valor total estimado é sigiloso nos termos do art. 34 da Lei nº 13.303/2016

Data/hora de abertura/local:

A Licitação encontra-se suspensa SINE DIE, onde novo Edital, com nova data de abertura, será oportunamente publicado no DODF e jornal de grande Circulação.

Retirada do Edital e anexos:

Gratuitamente no sitio da Terracap www.terracap.df.gov.br, na seção licitações compras/serviços.

Brasília/DF, 17 de junho de 2026 LADÉRCIO BRITO SANTOS FILHO

Presidente da Comissão

## PROCURADORIA-GERAL

### SECRETARIA GERAL

EXTRATO DO CONTRATO ADMINISTRATIVO Nº 016/2026 PROCESSO Nº 00020-00003323/2026-28. PARTES: PROCURADORIA-GERAL DO DISTRITO FEDERAL E JUSTICE AI LTDA. (CNPJ nº 57.027.539/0001-51). Inexigibilidade de Licitação nº 013/2026. OBJETO: Contratação de empresa especializada para fornecimento de serviços de licenças de solução de plataforma de inteligência artificial generativa desenvolvida especificamente para órgãos jurídicos públicos, incluindo treinamento, suporte técnico e atualização de versões. ASSINATURA: 07/05/2026. VIGÊNCIA: 12 (doze) meses, a contar da data da assinatura do Contrato. NOTA DE EMPENHO: O empenho inicial é de R$ 368.200,00 (trezentos e sessenta e oito mil e duzentos reais), conforme Nota de Empenho nº 2026NE00314, emitida em 06/05/2026, sob o evento nº 400091, na modalidade Estimativo. COBERTURA ORÇAMENTÁRIA: A despesa correrá à conta da seguinte Dotação Orçamentária: I – Unidade Orçamentária: 120901 – 12901; II – Programa de Trabalho: 03.126.8203.1471.0034; III – Natureza da Despesa: 33.90.40. SIGNATÁRIOS: Pelo DISTRITO FEDERAL: CARLOS AUGUSTO VALENZA DINIZ, Secretário-Geral da Procuradoria-Geral do Distrito Federal. Pela CONTRATADA: CAIO COSTA PERONA, na qualidade de Representante Legal.

## INEDITORIAL

### HOSPITAL DA CRIANÇA DE BRASÍLIA JOSÉ ALENCAR

CHAMAMENTO Nº 169/2026 PROCESSO: 04024-00007271/2026-34 O Instituto do Câncer Infantil e Pediatria Especializada – Icipe, torna público para o conhecimento de quem possa interessar que até o dia 29/06/2026 às 18h, estará recebendo por meio eletrônico no site www.apoiocotacoes.com.br, propostas relativas ao chamamento n° 169/2026, cujo objeto é a Aquisição de Produtos para Saúde (Luvas), em Sistema de Registro de Preços, visando atender as necessidades do Hospital da Criança de Brasília José Alencar - HCB. Conforme previsões editalícias, o prazo para recebimento de propostas poderá ser prorrogado. Os interessados poderão solicitar o referido edital através do e-mail: compras@hcb.org.br ou acessá-lo no site www.hcb.org.br. Este Procedimento respeitará o disposto pelo Decreto Distrital N° 33.390/11. Brasília/DF, 19 de junho de 2026. Coordenação de Compras, Icipe/HCB.

CHAMAMENTO Nº 164/2026 PROCESSO: 04024-00004545/2026-33 O Instituto do Câncer Infantil e Pediatria Especializada – Icipe, torna público para o conhecimento de quem possa interessar que até o dia 29/06/2026 às 18h, estará recebendo por meio eletrônico no site www.apoiocotacoes.com.br, propostas relativas ao chamamento n° 164/2026, cujo objeto é a Aquisição de Centrífuga Laboratorial, visando atender as necessidades do Hospital da Criança de Brasília José Alencar - HCB. Conforme previsões editalícias, o prazo para recebimento de propostas poderá ser prorrogado. Os interessados poderão solicitar o referido edital através do e-mail: compras@hcb.org.br ou acessá-lo no site www.hcb.org.br. Este Procedimento respeitará o disposto pelo Decreto Distrital N° 33.390/11. Brasília/DF, 19 de junho de 2026. Coordenação de Compras, Icipe/HCB.

AVISO DE RESULTADO CHAMAMENTO Nº 340/2025 – ARTIGO 4º O Hospital da Criança de Brasília José Alencar – HCB, torna público aos interessados o Resultado do Chamamento Nº 340/2025 – ARTIGO 4º, com o prazo de recebimento de propostas finalizado em 27/05/2026, cujo objeto é a Aquisição de Material de Expediente (Fita de Transferência), visando atender as necessidades do Hospital da Criança de Brasília José Alencar - HCB, apresenta a seguinte empresa vencedora: itens 01 e 02 para a empresa Biolab Brasil Equipamentos para Laboratórios Ltda, pelo valor total de R$ 4.978,79 (Quatro mil, novecentos e setenta e oito reais e setenta e nove centavos). Brasília/DF, 19 de junho de 2026. Coordenação de Compras, Icipe/HCB.

REVOGAÇÃO DE RESULTADO

CHAMAMENTO Nº 061/2026 O Instituto do Câncer Infantil e Pediatria Especializada – Icipe, torna público aos interessados, a revogação do resultado do item 25 para a empresa Lunax Comércio de Produtos em Saúde Ltda; referente ao Chamamento 061/2026 publicado no DODF Nº 76, pág 75 em 28/04/2026. Este ato de revogação encontra respaldo no Art.6° do Decreto Distrital 33.390/11 e nos despachos exarados nos autos do processo. Brasília/DF, 19 de junho de 2026. Coordenação de Compras, Icipe/HCB.

AVISO DE RESULTADO CHAMAMENTO Nº 061/2026 O Hospital da Criança de Brasília José Alencar – HCB, torna público aos interessados o Resultado do Chamamento Nº 061/2026, com o prazo para cadastro das propostas na plataforma www.apoiocotacoes.com.br finalizado em 23/03/2026, cujo objeto é Aquisição de Material Médico Hospitalar (Atadura, Bandagem, Cera de Osso, ...), em Sistema de Registro de Preços, visando atender as necessidades do Hospital da Criança de Brasília José Alencar - HCB, apresenta a seguinte empresa vencedora: item 25 para a empresa Cirúrgica Fernandes Comércio de Materiais Cirúrgicos e Hospitalares Ltda, pelo valor total estimado de R$ 3.931,20 (Três mil, novecentos e trinta e um reais e vinte centavos). Brasília/DF, 19 de junho de 2026. Coordenação de Compras, Icipe/HCB. FILANTROPIA – 90/2026.

### ELI RAMIRO PIMENTA

AVISO DE RECEBIMENTO DE LICENÇA DE OPERAÇÃO Torna público que recebeu do Instituto do Meio Ambiente e dos Recursos Hídricos do Distrito Federal - Brasília Ambiental – IBRAM/DF, a Licença de Operação SEI-GDF n.º 30/2026 - IBRAM/PRESI, para a atividade de avicultura, referente ao empreendimento localizado DF 190 KM 14,5 - Laje Giboia, Ceilândia- DF CEP: 72.020.070, no Distrito Federal. ELI RAMIRO PIMENTA, inscrito no CPF nº 184.***.***-72, produtor rural.

### CONDOMÍNIO ALTO DA BOA VISTA – CABV

AVISO DE REQUERIMENTO DE AUTORIZAÇÃO AMBIENTAL Torna público que está requerendo ao Instituto do Meio Ambiente e dos Recursos Hídricos do Distrito Federal - Brasília Ambiental – IBRAM/DF a Autorização Ambiental para a atividade de drenagem e pavimentação, localizada na BR-020, km 12,5, Quadra 100, Bloco 1, Condomínio Alto da Boa Vista, Distrito Federal. Foi determinada a elaboração de Estudo Ambiental. Interessado: CONDOMÍNIO ALTO DA BOA VISTA.

### M RIBEIRO HOLDING LTDA

AVISO DE REQUERIMENTO DE LICENÇA DE INSTALAÇÃO Torna público que requereu ao Instituto do Meio Ambiente e dos Recursos Hídricos do Distrito Federal - Brasília Ambiental – IBRAM/DF, a licença de Instalação para a atividade de Comércio varejista de combustíveis para veículos automotores, no Rua 4A, Chácara 109, S/N, Lote 02, Setor Habitacional Vicente Pires, Brasília/DF, CEP 72.006-241. Foi determinada a elaboração de Estudo Ambiental. Processo: 00391-00003776/2023-93 M RIBEIRO HOLDING LTDA.
