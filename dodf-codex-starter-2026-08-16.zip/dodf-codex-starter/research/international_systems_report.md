# Sistemas internacionais de memória institucional navegável: estado da arte, arquitetura, riscos e roteiro para um sucessor do DODF

## Sumário executivo

A pesquisa muda bastante a avaliação inicial do projeto. **Existe, internacionalmente, quase todo o conjunto de peças necessárias para construir o que você imaginou, mas não encontrei um sistema público que una essas peças exatamente da forma proposta:** ingestão longitudinal de registros oficiais, preservação do documento original, resolução de entidades entre fontes e jurisdições, reconstrução explícita de eventos, manutenção de estado institucional temporal, proveniência por afirmação e uma camada de consultas investigativas com controles sobre inferências sensíveis.

Os parentes mais próximos estão espalhados por famílias diferentes.

O **Aleph/OpenAleph + FollowTheMoney** é o parente técnico e conceitual mais próximo. Foi criado para investigação: recebe documentos e dados estruturados, representa pessoas, empresas, contratos e documentos como entidades relacionadas, indexa grandes coleções e permite cruzamentos. Há, porém, uma mudança importante desde nossa conversa anterior: o Aleph open source original foi oficialmente encerrado pelo OCCRP ao fim de 2025; o novo **Aleph Pro** é uma plataforma reescrita, hospedada, com mais de 4 bilhões de registros/documentos e não é open source no mesmo sentido. Em paralelo, o Data and Research Center criou o **OpenAleph**, fork comunitário que continua o projeto aberto. Ainda mais interessante, em 2025–2026 surgiu em torno dele um novo **FollowTheMoney Data Lake/Lakehouse**, precisamente para preservar documentos, metadados, entidades intermediárias e versões em object storage de maneira modular. Isso está extraordinariamente perto da fundação que eu recomendaria para o projeto. citeturn21search1turn21search2turn21search3turn21search5turn23search0turn23search1turn23search2

O **ICIJ Datashare** resolve muito bem outra parte: document forensics. É AGPL, self-hosted, recebe PDFs, imagens, e-mails e planilhas, faz extração/OCR e reconhecimento de entidades e permite pesquisa em coleções que chegam a milhões de documentos. É excelente como referência para a camada documental, mas não tem como objeto principal reconstruir a evolução institucional de um Estado. citeturn14search8turn14search15

**OpenCorporates e OpenSanctions** demonstram como fazer duas coisas que serão centrais: identidade e proveniência. O OpenCorporates cobre atualmente mais de 220 milhões de empresas em mais de 140 jurisdições e associa aos dados informações de origem; o OpenSanctions normaliza aproximadamente 2 milhões de entidades provenientes de mais de 440 fontes e mantém um pipeline frequente de atualização, deduplicação e matching baseado em FollowTheMoney. citeturn6search1turn6search21turn18search3turn18search8turn18search13

No mundo proprietário, **Quantexa e Palantir** mostram o que acontece quando essa arquitetura deixa de ser “pesquisa documental” e vira uma infraestrutura operacional: dados heterogêneos → entity resolution → grafo/ontologia → contexto → análise → decisão. A Ontology da Palantir, por exemplo, representa explicitamente tipos de objetos, propriedades, links e ações e oferece SDKs para consulta e write-back; a Quantexa combina ingestão, resolução de entidades, geração de grafos, pipelines batch/streaming e APIs. São referências arquiteturais importantes, mas não devem ser confundidas com plataformas abertas ou fontes de dados. citeturn19search1turn19search7turn19search13turn20search2turn20search16

Entre as infraestruturas públicas oficiais, **a União Europeia é provavelmente o modelo mais interessante**. EUR-Lex/CELLAR usa RDF/OWL, REST e SPARQL para representar documentos legais e seus relacionamentos; TED está construído sobre uma ontologia de compras públicas que cobre o ciclo de procurement e publica notices estruturados. Aqui o Estado não apenas entrega PDFs: ele entrega parte da própria estrutura semântica de seus atos. citeturn11search0turn11search5turn11search8turn10search1turn10search2turn10search13

Os Estados Unidos oferecem uma superfície ainda mais ampla, mas fragmentada: **Federal Register + GovInfo + USAspending** dão, respectivamente, decisões regulatórias e notices, cópias oficiais e metadados documentais, e contratos/grants/awards. A fragmentação, paradoxalmente, cria espaço para um sistema como o seu: a API do Federal Register é ótima para descoberta, mas o próprio serviço avisa que sua representação não é a versão oficial para fins jurídicos; a cópia autoritativa deve ser ligada ao GovInfo. Isso é praticamente um caso de uso didático para uma arquitetura *provenance-first*. citeturn12search0turn12search4turn12search1turn12search9turn12search2turn12search6

**GDELT demonstra a escala extrema**, mas é conceitualmente diferente: constrói eventos e knowledge graphs predominantemente a partir de mídia global, não de registros administrativos primários. Um único ano histórico do GDELT Global Knowledge Graph foi reportado pelo próprio projeto em aproximadamente 2,5 TB, e os fluxos do projeto trabalham em cadência de minutos. É um ótimo teste de escalabilidade e uma fonte contextual posterior; não é uma boa fundação de verdade institucional. citeturn19search5turn19search8

Minha conclusão principal é esta:

> **O espaço vazio não é “um Aleph brasileiro/internacional”. O espaço vazio é uma camada de memória institucional temporal, provenance-first e interoperável, capaz de distinguir rigorosamente documento, afirmação, entidade, evento, estado e inferência.**

Isso é mais específico e, em minha avaliação, mais novo.

Também altera a conclusão sobre hardware. **Eu não compraria ainda uma máquina cara.** Primeiro faria um experimento de capacidade com um corpus fechado. Object storage é relativamente barato; busca indexada e processamento são frequentemente muito mais caros. Como ilustração atual, a AWS mostra armazenamento da ordem de dezenas de dólares por TB/mês em seus exemplos de S3, enquanto um exemplo oficial de cluster de produção OpenSearch com aproximadamente 1,5 TB hot mais 3 TB warm chega a cerca de US$ 1.600/mês. A parte cara não é necessariamente “guardar o PDF”; é manter índices, réplicas, workers, disponibilidade e processamento. citeturn17search0turn17search1

Para um primeiro piloto sério, eu recomendaria **um ano completo de uma única instituição americana**, por exemplo EPA/2025, juntando Federal Register, GovInfo e USAspending. Isso testa três naturezas de evidência — atos, documentos oficiais e dinheiro — sem entrar inicialmente no domínio militar que motivou nossa conversa. Depois adicionaria TED/CELLAR para testar multilinguismo e interoperabilidade internacional.

A arquitetura que eu considero mais promissora é:

```mermaid
flowchart TD
    A[Fontes oficiais primárias] --> B[Coleta versionada]
    A2[Fontes de enriquecimento] --> B

    B --> C[Object storage imutável]
    C --> C1[Documento bruto]
    C --> C2[Metadados HTTP/API]
    C --> C3[Hash + timestamp + licença]

    C --> D[Extração]
    D --> D1[Texto / OCR / tabelas]
    D --> D2[Metadados normalizados]
    D --> D3[Entidades mencionadas]

    D1 --> E[Camada de afirmações]
    D2 --> E
    D3 --> E

    E --> F[Entity resolution]
    F --> G[Entidades canônicas]

    E --> H[Reconstrução de eventos]
    G --> H

    H --> I[Estado institucional temporal]
    G --> I

    C --> J[Índice full-text]
    G --> K[Grafo / relações]
    I --> L[Consultas temporais]

    J --> M[Interface investigativa]
    K --> M
    L --> M

    M --> N[Camada de inferência]
    N --> O{Política de inferência}
    O -->|evidência direta| P[Publicável]
    O -->|inferência analítica| Q[Rotulada + auditável]
    O -->|sensível / alto risco| R[Restrita / revisão humana]
```

A diferença decisiva em relação a quase todos os sistemas estudados é a caixa no meio: **camada de afirmações e proveniência antes de transformar informação em “fato”**, seguida de uma distinção explícita entre evidência e inferência.

## Ecossistema internacional comparável

A tabela abaixo não trata todos os nomes como concorrentes equivalentes. Alguns são ferramentas, alguns são modelos semânticos, alguns são bancos de referência e alguns são infraestruturas públicas. Essa distinção é importante.

| Sistema | Finalidade e escopo | Licença / acesso | API e modelo de dados | Escala e atualização | O que ensina ao projeto |
|---|---|---|---|---|---|
| **[Aleph Pro](https://aleph.occrp.org/)** / Aleph legado | Investigação de pessoas, empresas, ativos, transações, registros públicos e evidências; OCCRP usa a plataforma como memória investigativa global. | Aleph legado: MIT, manutenção do OCCRP encerrada em 31/12/2025. Aleph Pro: nova implementação hospedada; não open source no mesmo sentido; gratuito para jornalismo sem fins lucrativos e licenciado em outros níveis. | Busca documental + entidades + redes; Aleph historicamente usa FollowTheMoney. Novo Pro adiciona confidence em conexões, risk scoring e knowledge graph. | OCCRP informa mais de 4 bilhões de documentos/registros e centenas de fontes; 24 mil+ usuários foram reportados na transição. citeturn21search1turn21search2turn21search3turn21search5 | É o parente funcional mais próximo no mundo investigativo. Também mostra por que depender do produto inteiro de um terceiro cria risco tecnológico. |
| **[OpenAleph](https://github.com/openaleph/openaleph)** | Continuação comunitária do Aleph para investigação e pesquisa. | Open source; módulos novos do ecossistema, como `ftm-lakehouse` e `openaleph-search`, são AGPLv3+. | FollowTheMoney; PostgreSQL, Elasticsearch e Redis no stack de desenvolvimento; módulos independentes de lakehouse e search. | Projeto em desenvolvimento ativo em 2026. citeturn23search0turn23search2turn23search5 | **Melhor candidato atual para reutilização**, em vez de começar novamente o sistema investigativo do zero. |
| **[FollowTheMoney](https://followthemoney.tech/)** | Modelo de dados para investigação financeira e documental. | MIT. | Entidades com `id`, `schema` e propriedades; pessoas, organizações, empresas, órgãos, documentos, contratos etc. Referências entre entidades formam grafo. | É usado em OpenAleph e OpenSanctions e foi desenhado como formato de intercâmbio. citeturn0search2turn0search0turn0search6turn18search2 | Excelente **linguagem franca de entidades**, mas não substitui um modelo bitemporal completo de estado institucional. |
| **[ICIJ Datashare](https://datashare.icij.org/)** | Busca, OCR, extração e investigação em grandes coleções de documentos, imagens, e-mails e planilhas. | AGPL-3.0; self-hostable. | API, pesquisa full-text, OCR, NER; stack historicamente inclui Elasticsearch, PostgreSQL/Redis; extensões possibilitam Neo4j. | ICIJ afirma suportar desde uma coleção pequena até milhões de documentos; foi usado em investigações com milhões de arquivos. citeturn14search8turn14search15turn14search19 | Excelente referência para **document forensics**. Menos adequado como modelo de estado institucional. |
| **[OpenCorporates](https://opencorporates.com/)** | Normalização de registros empresariais de muitas jurisdições. | Dados/API com rota ODbL/share-alike para usos compatíveis e opções comerciais para outros usos. | API de empresas/officers; provenance inclui fonte, URL, agente de coleta, confiança e timestamp; reconciliation para matching. | Mais de 220 milhões de empresas em mais de 140 jurisdições; frescor varia por registro de origem. citeturn6search1turn6search8turn6search15turn6search21 | Referência muito forte para **identidade transjurisdicional + proveniência por dado**. |
| **[OpenSanctions](https://www.opensanctions.org/)** | Sanções, PEPs, watchlists e entidades ligadas, consolidadas e deduplicadas. | Bulk data CC BY-NC 4.0 para uso não comercial; licença comercial exigida para uso empresarial. Componentes como FollowTheMoney/yente são open source. | FollowTheMoney JSON, CSV, API de search/matching/reconciliation, bulk e delta. | Cerca de 2 milhões de entidades em mais de 440 fontes; coleção principal é republicada aproximadamente a cada seis horas. citeturn18search3turn18search8turn18search13 | Provavelmente o melhor exemplo aberto de **ETL → normalização → entity matching → auditabilidade → atualização contínua**. |
| **[Maltego](https://www.maltego.com/)** | Investigação interativa e OSINT via pivôs entre entidades e fontes. | Proprietário; possui camada gratuita e planos comerciais. | “Transforms” recebem entidade e retornam entidades relacionadas; conectam APIs e bancos externos a grafos interativos. | Marketplace/Transform Hub agrega muitas integrações; escala orientada à investigação interativa. citeturn7search5turn7search9turn7search13turn8search0 | Excelente referência de UX investigativa e **pivoting**, não de arquivo histórico autoritativo. |
| **[Quantexa](https://www.quantexa.com/)** | Decision Intelligence, fraude, financial crime, customer intelligence e análise contextual. | Proprietário/comercial. | Ingestão, entity resolution, geração de grafos, batch/streaming, REST APIs e interfaces de dados. | Projetado para ambientes empresariais de grande escala; detalhes completos de implementação são restritos a clientes/parceiros. citeturn7search14turn7search34turn20search2turn20search16 | Mostra a arquitetura que surge quando **ER + grafo + contexto + decisão** se tornam plataforma operacional. |
| **[Palantir Foundry/Gotham](https://www.palantir.com/docs/)** | Integração de dados, ontologia operacional e aplicações de decisão; Gotham é voltado inclusive a defesa/inteligência. | Software comercial proprietário. | Ontology com object types, properties, link types e actions; REST/SDKs e OSDK para Python, Java, TypeScript e OpenAPI; streaming de mudanças via WebSocket. | Escala empresarial/governamental; arquitetura interna completa não é pública. citeturn7search15turn19search1turn19search7turn19search27 | É a referência mais clara de como um **grafo descritivo vira modelo operacional do mundo**. |
| **[GDELT](https://www.gdeltproject.org/)** | Eventos e knowledge graph globais derivados sobretudo de mídia. | Dados descritos pelo projeto como gratuitos e abertos. | CSV, JSON APIs, BigQuery; Event Database e Global Knowledge Graph. | Fluxos de dados são atualizados continuamente; um ano histórico do GKG sozinho chegou a ~2,5 TB. citeturn19search5turn19search8 | Demonstra escala e event extraction global, mas é **contexto secundário**, não memória oficial. |
| **[EUR-Lex / CELLAR](https://eur-lex.europa.eu/)** | Legislação, atos e publicações oficiais da União Europeia. | Infraestrutura pública oficial para reutilização de conteúdo, sujeita às condições da UE. | REST, SPARQL, RDF/OWL, Common Data Model; documentos em PDF, HTML e formatos estruturados. | Repositório institucional multilíngue e longitudinal. citeturn11search0turn11search5turn11search8 | **Melhor exemplo de semântica oficial** encontrado: documentos e relações são tratados como dados vinculados. |
| **[TED](https://docs.ted.europa.eu/api/latest/)** | Compras públicas da UE. | Serviço público oficial. | Search API; eForms estruturados; eProcurement Ontology em OWL; Linked Open Data/SPARQL. | Notices cobrem planejamento, competição, resultado, modificação e conclusão; atualizações regulares. citeturn10search1turn10search2turn10search13 | Oferece algo especialmente valioso para o DODF: **ciclo de vida explícito de um evento administrativo**. |
| **[Federal Register](https://www.federalregister.gov/developers/documentation/api/v1)** + **[GovInfo](https://www.govinfo.gov/developers)** | Regras, propostas, notices e documentos presidenciais + cópia oficial e arquivos governamentais. | Serviços públicos oficiais. | Federal Register: REST/JSON/CSV, desde 1994. GovInfo: API, packages, PDF/texto, MODS/PREMIS e outros metadados. | Atualização contínua ligada à publicação federal. A representação do FederalRegister.gov é informativa; GovInfo contém a publicação oficial. citeturn12search0turn12search4turn12search1turn12search28 | Caso exemplar para distinguir **fonte conveniente de ingestão** de **fonte autoritativa de evidência**. |
| **[USAspending](https://api.usaspending.gov/)** | Gastos federais dos EUA: contratos, grants, recipients, agencies, accounts etc. | API pública; endpoints atualmente não exigem autenticação. | REST API, bulk downloads e arquivo de awards. | Grande base federal, com atualizações periódicas e arquivos históricos. citeturn12search2turn12search6turn12search7 | Permite conectar **ato institucional → entidade → fluxo financeiro**. |
| **[legislation.gov.uk](https://www.legislation.gov.uk/developer/contents)** | Legislação do Reino Unido. | Conteúdo reutilizável sob Open Government Licence nas condições aplicáveis. | XML estruturado e RDF com URIs e relações. | Corpus histórico/legal nacional. citeturn13search0turn13search2turn13search11 | Excelente fonte para testar versionamento legislativo e Linked Data fora da UE. |

Há, portanto, uma divisão relativamente nítida.

**Aleph/OpenAleph/Datashare** respondem: “como investigar grandes volumes de evidência?”

**FollowTheMoney/OpenCorporates/OpenSanctions** respondem: “como representar e reconciliar entidades?”

**EUR-Lex/CELLAR/TED** respondem: “como um Estado pode publicar sua própria estrutura semântica?”

**Federal Register/GovInfo/USAspending** respondem: “como combinar rastros oficiais de naturezas diferentes?”

**Quantexa/Palantir/Maltego** respondem: “o que fazer analiticamente quando as relações já existem?”

**GDELT** responde: “o que acontece quando isso chega a escala global?”

O DODF expandido pode ocupar justamente a intersecção.

## Arquiteturas técnicas e modelos de dados

A arquitetura do Aleph legado é particularmente instrutiva porque sua documentação expõe explicitamente três sistemas persistentes: **blob storage para os arquivos, banco SQL/PostgreSQL para aplicação e entidades FollowTheMoney e Elasticsearch para busca sobre documentos e entidades**. O armazenamento de blobs pode ser local, S3 ou GCS, e workers independentes podem ser escalados para processamento. O índice Elasticsearch pode ser regenerado a partir do armazenamento de entidades, o que indica uma separação saudável entre estado canônico e índice derivado. citeturn4view0turn4view1

O trabalho novo do OpenAleph vai ainda mais na direção que interessa. A especificação FollowTheMoney Data Lake define datasets como unidades de origem; preserva um **archive** com objetos endereçados por hash; permite manter representação textual extraída; armazena mappings, statements e entidades processadas separadamente; e recomenda pensar o filesystem como object storage — S3, GCS ou MinIO. O objetivo declarado é justamente manter estados de origem, intermediários e processados em armazenamento de longo prazo em vez de fazer do banco operacional a única verdade. citeturn23search1turn23search2

Isso é quase exatamente a decisão arquitetural que eu adotaria.

| Camada | OpenAleph/Aleph | Datashare | OpenSanctions | CELLAR/TED | GDELT | Arquitetura recomendada |
|---|---|---|---|---|---|---|
| **Ingestão** | Arquivos + dados estruturados + crawlers | Arquivos, e-mails, imagens, planilhas, arquivos compactados | Crawlers por fonte → normalização | Publicação institucional estruturada | Pipeline global de mídia | Adaptadores independentes por fonte, idempotentes |
| **Original imutável** | Blob/object storage; novo FtM lakehouse enfatiza arquivo por hash | Coleção documental | Preserva origem/metadata, mas foco principal é entidade consolidada | CELLAR é repositório documental oficial | Raw downloads disponíveis | **Obrigatório**: bytes originais + headers + hash + timestamp |
| **Texto/OCR** | ingest pipelines | Forte: OCR/extraction é função central | Não é função principal | Frequentemente conteúdo já estruturado | Extração automatizada em escala | OCR somente quando necessário; resultado é derivado, nunca substitui original |
| **Entidades** | FollowTheMoney | NER + entities | FollowTheMoney | RDF/OWL/CDM/ePO | GKG | FollowTheMoney como interchange + modelo institucional próprio |
| **Entity resolution** | Cross-reference/matching | NER e exploração; menos centrado em identidade canônica global | Função central | Identificadores semânticos oficiais onde existem | Automated extraction/linking | Resolver com score, justificativa e histórico de merges |
| **Busca** | Elasticsearch | Elasticsearch | Search/matching API; self-hosted yente | SPARQL/REST | BigQuery + APIs | OpenSearch/Elasticsearch + SQL analítico |
| **Grafo** | Relações FtM | Neo4j possível via extensão | Relações FtM | RDF graph nativo | Knowledge Graph | Materialização derivada, não única fonte de verdade |
| **Temporalidade** | Entidades/propriedades com datas | Principalmente documental | Histórico de datasets/entidades | Muito forte no ciclo legislativo/procurement | Event time | **Bitemporalidade explícita** + histórico de observação |
| **Proveniência** | Dataset/documento | Documento | Muito forte por source/dataset | Institucional/nativa | URL/source | **Cada afirmação deve ter evidência própria** |
| **Cadência** | Dependente da fonte | Dependente da ingestão | Coleção default ~6 h | Publicação oficial regular | minutos/diário conforme produto | Cadência registrada individualmente por source adapter |

As capacidades acima são documentadas nos projetos correspondentes; em especial, FollowTheMoney representa entidades como registros com schema e propriedades multivaloradas; OpenSanctions publica metadados de origem, cobertura temporal e versões; e CELLAR permite consultar relações semânticas diretamente via SPARQL. citeturn0search16turn18search6turn18search13turn11search0

Há, entretanto, uma peça que eu **não copiaria integralmente de nenhum deles**.

### O fato não deveria ser a unidade atômica

Considere:

```text
Documento A:
"João foi nomeado diretor em 03/02/2025."

Documento B:
"Fica exonerado João ... a contar de 14/08/2025."
```

Uma implementação ingênua cria:

```text
Person(joao)
position = diretor
```

Isso perde quase tudo que é interessante.

Eu faria:

```text
SourceDocument
  id
  source_uri
  retrieved_at
  published_at
  sha256
  media_type
  authority_level
  source_version

Assertion
  id
  subject
  predicate
  object
  source_document
  evidence_span
  extraction_method
  extraction_confidence
  asserted_at

Event
  type = Appointment
  person = João
  office = Diretor
  effective_at = 2025-02-03
  supported_by = Assertion A

Event
  type = Dismissal
  person = João
  office = Diretor
  effective_at = 2025-08-14
  supported_by = Assertion B

InstitutionalState
  person = João
  role = Diretor
  valid_from = 2025-02-03
  valid_until = 2025-08-14
  derived_from = [Event A, Event B]
```

A diferença entre `Assertion`, `Event` e `InstitutionalState` é enorme.

O sistema passa a conseguir responder:

> Quem ocupava determinada função em 1º de junho de 2025?

sem alterar nem apagar os documentos que produziram esse conhecimento.

Além disso, eu adotaria **pelo menos três relógios**:

```text
published_at    quando a fonte publicou
valid_time      quando o fato institucional valia
observed_at     quando seu sistema observou aquela versão
```

Isso permite distinguir:

> “O Estado dizia X naquela data”

de

> “Hoje sabemos que X era válido naquela data.”

Para investigação longitudinal, essa diferença é fundamental.

### Entity resolution não pode apagar incerteza

OpenCorporates e OpenSanctions são particularmente instrutivos porque o processo de normalização não elimina a necessidade de provenance e matching. O OpenCorporates fornece informações de fonte e confiança; o OpenSanctions mantém matching como capacidade explícita e disponibiliza dados consolidados junto às origens. citeturn6search1turn18search8

Eu evitaria:

```text
"ACME LTD"
"ACME LIMITED"
"Acme Holdings Ltd."

→ mesma entidade
```

como mutação irreversível.

Preferiria:

```text
Mention ──candidate_match──> CanonicalEntity
                     score = 0.93
                     method = ...
                     evidence = ...
```

Uma decisão humana pode posteriormente promover o vínculo.

Isso é especialmente importante quando o corpus atravessar países. “João Silva” já é difícil; empresas com subsidiárias, reorganizações e múltiplos registros nacionais são muito piores.

### Full-text, SQL e grafo deveriam coexistir

Um ponto em que sistemas comerciais e investigativos convergem é que **não existe um único banco ideal para todas as perguntas**. Aleph separa SQL, blobs e Elasticsearch; CELLAR expõe grafo semântico; GDELT usa BigQuery para análise de volume; Palantir representa entidades e links na Ontology. citeturn4view0turn11search0turn19search8turn19search7

Eu usaria:

```text
Object store     → verdade documental
PostgreSQL       → entidades, eventos, provenance, controle transacional
OpenSearch       → full-text e descoberta
Columnar/Parquet → analytics de grande volume
Graph projection → exploração de relações
```

E não começaria com Neo4j ou outro graph DB como fonte canônica.

O grafo pode ser materializado a partir do ledger de entidades e relações. Isso reduz o risco de fazer da representação analítica uma verdade ontológica permanente.

## Escala, infraestrutura e custo operacional

A primeira conclusão de capacidade é contraintuitiva: **guardar documentos não é necessariamente a parte cara**.

Na tabela oficial de preços atual, a AWS dá exemplos em que aproximadamente 1 TB de armazenamento S3 fica na ordem de dezenas de dólares por mês. Em contraste, seu exemplo de domínio OpenSearch de produção com três nós de dados, três gerenciadores e dois nós warm, incluindo aproximadamente 1,5 TB hot e 3 TB warm, chega a cerca de **US$ 1.604/mês**. Não devemos usar isso como orçamento do projeto, mas ele mostra a relação estrutural entre object storage barato e pesquisa indexada de alta disponibilidade relativamente cara. citeturn17search0turn17search1

O GDELT fornece outro limite útil: um único ano histórico de seu Global Knowledge Graph chegou a cerca de **2,5 TB**, antes mesmo de considerar que o objetivo do GDELT é muito mais amplo do que documentos administrativos de um único governo. Isso mostra que “escala internacional” pode rapidamente transformar terabytes em dezenas ou centenas de terabytes. citeturn19search8

Por outro lado, o OCCRP informa que Aleph/Aleph Pro opera sobre **bilhões de registros/documentos**, demonstrando que a arquitetura é tecnicamente viável — mas já em regime organizacional, não de um simples projeto rodando em um notebook. citeturn21search3turn21search5

A tabela abaixo é deliberadamente uma **estimativa de engenharia**, não uma afirmação sobre o tamanho real das fontes. Como você pediu, onde ainda não existe medição concreta, eu não vou fingir precisão.

| Escala | Corpus de planejamento | Armazenamento planejado | Compute / RAM | Busca e banco | GPU | Infra estimada |
|---|---|---|---|---|---|---|
| **Protótipo — um país, um ano** | 1–5 fontes oficiais; dezenas/centenas de milhares a poucos milhões de objetos | **0,5–2 TB raw**; reservar **2–8 TB físicos** para raw + texto + índice + snapshots + backup | 16–32 vCPU; 64–128 GB RAM para máquina principal/worker | PostgreSQL + OpenSearch de 1 nó inicialmente | **Não obrigatória.** Útil somente se OCR/transcrição/embeddings locais justificarem | Cloud/self-managed: **US$ 150–800/mês**. Máquina própria razoável: **~US$ 2,5 mil–6 mil CAPEX** |
| **Médio — vários países, cinco anos** | Dezenas de fontes e múltiplos formatos/idiomas | **10–50 TB raw**; **30–150 TB** considerando derivados, hot/warm e redundância | Workers distribuídos; dezenas a centenas de vCPU; 256 GB–1 TB de RAM agregada | 3+ search nodes; PostgreSQL dedicado/replicado; object storage | 1–2 GPUs podem valer a pena para NLP/OCR em lote | **US$ 2 mil–15 mil/mês** em cloud/self-managed; on-prem inicial aproximadamente **US$ 20 mil–80 mil**, dependendo de redundância |
| **Produção — global, contínua** | Centenas/milhares de fontes, histórico + ingestão contínua | **100 TB–1 PB+ raw** é um envelope plausível; **0,3–3 PB** contando índices, derivados, réplicas e snapshots é uma reserva de planejamento, não previsão | Cluster autoscaling; filas; workers especializados; múltiplos tiers | Search hot/warm/cold + lakehouse + SQL operacional + analytics columnar | Pool de GPUs apenas onde workload medido justificar | **US$ 20 mil–250 mil+/mês** pode ser um envelope realista; disponibilidade, tráfego e NLP externo podem elevar muito mais |

Esses intervalos **excluem salários, assessoria jurídica, aquisição de datasets comerciais e licenças empresariais**. São envelopes para orientar experimentos, não propostas comerciais.

O fator multiplicador de armazenamento merece atenção. Um PDF de 100 MB pode originar:

```text
100 MB original
+ texto extraído
+ imagens/renderizações
+ metadados
+ índice invertido
+ entidades
+ embeddings, se houver
+ réplicas de busca
+ snapshots
+ backup
```

Por isso, “tenho 5 TB de documentos” nunca deveria se transformar em “preciso de um disco de 5 TB”.

### O experimento que deve preceder qualquer compra

Antes de comprar hardware, eu faria um **capacity benchmark reproduzível** sobre exatamente 10.000, depois 100.000 e depois 1.000.000 de documentos/objetos.

Registrar:

| Métrica | Por que importa |
|---|---|
| Bytes raw por documento | determina object storage |
| Bytes de texto extraído/raw | mede expansão |
| Índice OpenSearch/raw | mede o multiplicador de busca |
| Entidades/documento | mede crescimento do modelo |
| Relações/documento | aproxima custo do grafo |
| CPU-segundos/documento | transforma corpus em CPU-horas |
| Páginas OCR/segundo | indica se CPU é suficiente |
| RAM pico por worker | determina paralelismo |
| MB/s de ingestão | determina janela de atualização |
| Reprocessamento por mudança de schema | mede dívida arquitetural |
| Precision/recall de entity resolution | impede otimizar infraestrutura para dados ruins |
| Custo por 100 mil documentos | transforma benchmark em orçamento |
| Custo por milhão de afirmações | permite comparar fontes estruturalmente diferentes |

Depois:

```text
custo_anual_estimado =
  armazenamento_raw
+ armazenamento_derivado
+ search_hot
+ banco
+ compute_ingestão
+ compute_reprocessamento
+ backup
+ egress
```

Só então eu escolheria máquina.

E eu começaria **sem GPU**.

OCR tradicional, parsing, crawling, PostgreSQL, Elasticsearch/OpenSearch e boa parte de NER clássico são CPU/RAM/storage intensive. O próprio OpenAleph relatou em seus testes recentes de transcrição que o desempenho de modelos varia enormemente conforme hardware e implementação — inclusive CPU x Apple Silicon — mostrando por que benchmark real deve preceder compra especializada. citeturn23search3

Para o piloto, algo como:

```text
CPU: 16–32 cores
RAM: 128 GB
NVMe: 4–8 TB
backup/object storage separado
```

já seria uma máquina de pesquisa bastante séria.

Se o corpus demonstrar que OCR/NLP é o gargalo, adiciona-se acelerador depois.

## Riscos jurídicos, éticos e de segurança

Aqui está, para mim, uma das descobertas mais importantes desta pesquisa: **o desconforto que apareceu em nossa conversa tem um paralelo institucional real e documentado**.

O Departamento de Justiça americano reconhece há décadas a chamada **mosaic theory**: uma informação que isoladamente não produz dano pode adquirir significado diferente quando combinada com outras informações disponíveis. Em um caso resumido oficialmente pelo DOJ, por exemplo, dados sobre o tamanho de uma equipe de proteção poderiam ajudar terceiros a estimar padrões de proteção em situações comparáveis. citeturn22search3turn22search14turn22search16

Isso não significa:

> “juntar dados públicos é ilegal”.

Nem significa:

> “a sua base se torna classificada”.

Classificação é uma categoria jurídica específica aplicada pelo governo segundo autoridades e critérios próprios. A Executive Order 13526 define quem pode classificar informação nacional-security e sob quais condições. Um pesquisador privado não transforma automaticamente sua análise em documento classificado ao cruzar dados públicos. citeturn15search0

O que significa é muito mais preciso:

> **o valor informacional de uma compilação pode exceder substancialmente o valor de suas partes.**

Para o projeto, eu adotaria cinco classes de risco.

| Risco | Problema concreto | Mitigação recomendada |
|---|---|---|
| **Mosaic / dual-use** | séries públicas combinadas permitem inferências sobre capacidades, dependências, vulnerabilidades ou operações não explicitadas | classificação de consultas por risco; delay temporal para certos domínios; revisão humana antes de publicação de inferências; separar evidência de inferência |
| **Privacidade** | documento público continua podendo conter dados pessoais; agregação e entity resolution aumentam drasticamente descobribilidade | data minimization, purpose limitation, retention policy, redaction where appropriate, direitos de correção/contestação, avaliação de impacto |
| **Licença / ToS** | “público na internet” não significa “livre para redistribuir sem condições” | registry por fonte contendo licença, ToS, rate limit, redistribuição permitida e data da última revisão |
| **Export controls / sanções** | determinadas tecnologias, dados técnicos, usuários finais ou usos finais podem cair em regimes específicos de controle | revisão jurídica antes de oferecer capacidades voltadas a defesa/inteligência, screening de cliente/end-use e separação de distribuição de dados públicos de funcionalidades controladas |
| **Segurança da própria plataforma** | uma base que reúne relações entre pessoas, investigações e documentos privados passa a ser alvo valioso | criptografia, least privilege, segregação por coleção, MFA, logs imutáveis, backup offline, threat model e resposta a incidentes |

### Dados públicos continuam sujeitos a privacidade

O GDPR é particularmente instrutivo. Ele define como processamento não apenas publicação, mas também **coleta, organização, estruturação, armazenamento, consulta, combinação e disseminação** de dados pessoais. A própria legislação europeia trata explicitamente da necessidade de reconciliar acesso público a documentos oficiais com proteção de dados. citeturn16search3turn16search14

E isso ficou ainda mais explícito em julho de **2026**: o European Data Protection Board afirmou que o GDPR se aplica a web scraping quando ele envolve operações como coleta, armazenamento, organização e recuperação de dados pessoais, e destacou purpose limitation e transparência. citeturn16search22

Portanto:

> “estava num diário oficial”

não equivale automaticamente a:

> “posso construir qualquer perfil derivado, indefinidamente, sobre aquela pessoa”.

A Comissão Europeia recomenda proteção de dados by design/default, incluindo processar apenas o necessário, limitar retenção e acesso e usar medidas como pseudonimização e criptografia. citeturn16search2turn16search11turn16search20

Isso é especialmente importante quando a resolução de entidades transforma milhares de pequenas aparições públicas numa biografia institucional longitudinal.

### Licença da fonte precisa ser dado do próprio sistema

OpenSanctions oferece um exemplo excelente de por que isso não pode ser tratado informalmente: seu bulk data é CC BY-NC 4.0 para uso não comercial; empresas precisam de licença. OpenCorporates também possui condições de reutilização/ODbL e licenciamento comercial conforme o modo de uso. citeturn18search3turn18search15turn6search1turn6search8

Eu criaria:

```text
SourcePolicy
  source_id
  jurisdiction
  authoritative_status
  license
  redistributable
  commercial_use_allowed
  derivative_use_allowed
  api_rate_limit
  robots_policy
  personal_data_risk
  national_security_risk
  retention_rule
  last_reviewed_at
```

Ou seja, a política da fonte entra no banco junto com os dados.

### Export control merece cuidado, mas não pânico

Também é importante não transformar “dual-use” numa categoria vaga.

Nos Estados Unidos, o EAR define a abrangência dos controles de exportação; o BIS também estabelece situações em que tecnologia/software publicamente disponível fica fora do EAR, embora itens e usos específicos possam continuar sujeitos a regras próprias. Mesmo um item `EAR99`, que geralmente não exige licença, pode passar a exigir controle conforme destino, usuário final ou uso final. citeturn15search2turn15search13turn15search16

O ITAR possui conceitos diferentes para technical data e public-domain information, sob jurisdição do State Department. citeturn15search3turn15search11

Então eu **não afirmaria que um sistema de análise de documentos públicos está, por natureza, sujeito a ITAR/EAR**. Isso seria juridicamente irresponsável.

Eu afirmaria algo bem mais restrito:

> Se o produto futuramente for adaptado para produzir capacidades específicas de defesa/inteligência, incorporar technical data controlado, ou for entregue a determinados usuários/destinos/end-uses, uma análise jurídica especializada de export-control passa a ser necessária.

Isso é uma mudança importante de postura: governança antes do caso limítrofe, não depois.

### Minha recomendação mais forte: controle de inferência

Eu colocaria a governança **dentro da arquitetura**, não apenas num documento de termos.

Algo assim:

```text
LEVEL 0 — Source
"Documento X diz Y."
→ público

LEVEL 1 — Structured fact
"Empresa A recebeu contrato B."
→ público, com evidência

LEVEL 2 — Historical synthesis
"A participação de A aumentou 300% em cinco anos."
→ público, metodologicamente reproduzível

LEVEL 3 — Analytical inference
"A estrutura sugere dependência crescente de A."
→ rotulado como inferência + confiança + justificativa

LEVEL 4 — Sensitive current-state inference
"Combinando consumo, reposição e contratos, estimamos vulnerabilidade operacional atual..."
→ acesso restrito / revisão / possível bloqueio de publicação automática
```

Não porque o nível quatro seja necessariamente ilegal.

Porque ele é **epistemológica e operacionalmente diferente**.

O sistema deveria saber essa diferença.

## Lacunas e oportunidade real para um novo projeto

Depois de comparar esses sistemas, eu não recomendaria que você se apresentasse como alguém construindo “uma plataforma de OSINT”. Isso é amplo demais e já é um mercado inteiro.

A novidade potencial é mais precisa.

### Memória institucional, e não apenas knowledge graph

Knowledge graphs normalmente respondem bem:

> Quem está relacionado a quem?

Seu objeto pode responder:

> **O que uma instituição era em determinado instante, por quais atos ela se tornou aquilo e quais documentos permitem reconstruir esse estado?**

Essa é uma diferença bastante profunda.

Um grafo:

```text
Pessoa ──ocupou──> Cargo
```

Uma memória institucional:

```text
Pessoa
   │
   ├── nomeada por Ato X
   │       published_at = ...
   │       effective_at = ...
   │
   ├── ocupou Cargo Y
   │       valid_from = ...
   │       valid_to = ...
   │
   └── exonerada por Ato Z
           published_at = ...
           effective_at = ...
```

O segundo consegue explicar a si próprio.

### Proveniência por afirmação

Aleph, OpenSanctions, OpenCorporates e CELLAR demonstram diferentes níveis de provenance, mas há espaço para fazer da **proveniência da afirmação** o elemento central do sistema. citeturn6search1turn18search6turn11search0turn23search1

Eu gostaria que qualquer resposta pudesse virar:

```text
Q: Quem controlava órgão X em 12/05/2024?

A: Fulano.

WHY?
 └─ InstitutionalState #7821
      ├─ AppointmentEvent #192
      │    └─ assertion #551
      │         └─ document SHA256 ...
      │              page 13 / span 441-523
      └─ no termination event observed before 12/05/2024
```

E, crucialmente, essa última linha deveria dizer **“não observamos exoneração anterior”**, não “não houve exoneração”.

A ausência no corpus e a ausência no mundo são coisas diferentes.

Isso conversa diretamente com o rigor epistemológico que você vinha buscando no DODF.

### Multilinguismo como identidade, não apenas tradução

O ecossistema atual é fragmentado entre jurisdições. CELLAR é multilíngue por construção; GDELT opera globalmente; OpenCorporates e OpenSanctions resolvem entidades através de muitos registros; OpenAleph já trabalha com corpora investigativos internacionais e possui inclusive módulos recentes de tradução. citeturn11search12turn19search26turn6search21turn23search8

Mas existe uma oportunidade específica:

```text
United States Department of Justice
U.S. Department of Justice
Department of Justice
DOJ
Departamento de Justiça dos Estados Unidos
Ministère de la Justice des États-Unis

             ↓

Institution[US:DOJ]
```

sem destruir as formas originais.

Uma arquitetura internacional precisa distinguir:

```text
canonical identity
localized label
source-native name
historical name
alias
translation
```

### Interoperabilidade sem ontologia universal prematura

Eu **não criaria inicialmente uma ontologia mundial completa**.

Usaria três níveis:

```text
L0 — source-native
     preserva exatamente o modelo original

L1 — interoperable core
     Person / Organization / PublicBody / Document /
     Contract / Position / Money / Event

L2 — jurisdiction/domain extension
     US Federal Rule
     EU Procurement Notice
     UK Statutory Instrument
     Brazilian Appointment Act
```

FollowTheMoney seria um excelente ponto de partida para L1 porque já é um formato de intercâmbio entre ferramentas investigativas e modela pessoas, empresas, órgãos, documentos e contratos. citeturn0search2turn18search2

TED/eProcurement Ontology e CELLAR seriam exemplos de L2 vindos dos próprios governos. citeturn10search2turn11search0

Isso evita o erro clássico:

> tentar descobrir a ontologia perfeita antes de ter dados.

### A oportunidade mais original: inferência governada

Não encontrei nas plataformas públicas estudadas uma combinação transparente de:

```text
evidence
→ assertion
→ event
→ state
→ inference
```

em que o sistema imponha **limites diferentes a cada estágio**.

Palantir e Quantexa têm governança e auditabilidade em ambientes empresariais, mas são plataformas proprietárias; OCCRP está introduzindo confidence e risk scoring em Aleph Pro; OpenAleph está construindo um lakehouse mais rastreável. citeturn19search1turn20search16turn21search2turn23search1

Uma implementação aberta e research-oriented poderia tratar cada inferência como objeto:

```text
Inference
  proposition
  supporting_assertions[]
  algorithm_version
  generated_at
  confidence
  uncertainty
  sensitivity_class
  publishability
```

Isso seria, na minha avaliação, uma contribuição real.

Não é somente segurança.

É **epistemologia implementada em software**.

## Roteiro prático de prototipagem e orçamento

A pesquisa mudou minha recomendação anterior em um ponto importante: **eu não começaria pelo Aleph legado**. Seu mantenedor original encerrou suporte ao fim de 2025. O caminho aberto agora é investigar **OpenAleph + FollowTheMoney + ftm-lakehouse** como componentes reutilizáveis e tratar Aleph Pro como referência funcional/comercial, não como base de código. citeturn21search1turn21search2turn23search0turn23search2

O primeiro corpus também deveria ser deliberadamente pequeno.

Eu sugiro:

> **EPA dos Estados Unidos, ano-calendário de 2025.**

Consumir:

```text
Federal Register
      +
GovInfo
      +
USAspending
```

O objetivo não é estudar a EPA em si. É criar um laboratório onde a mesma instituição aparece como:

```text
regulador
autor de documentos
comprador
concedente de recursos
parte de relações com empresas e outras organizações
```

A API do Federal Register facilita ingestão estruturada e possui documentos desde 1994; GovInfo fornece o elo com a versão oficial e metadados; USAspending adiciona awards e recipients. citeturn12search0turn12search4turn12search1turn12search2

### Stack inicial

Eu começaria com:

```text
MinIO ou S3-compatible storage
        ↓
ftm-lakehouse / camada própria equivalente
        ↓
Python ingestion workers
        ↓
PostgreSQL
        ↓
FollowTheMoney
        ↓
OpenSearch
        ↓
API própria
        ↓
UI investigativa mínima
```

OpenAleph já oferece uma implementação pronta de grande parte do stack, inclusive pesquisa FollowTheMoney em Elasticsearch, e seu lakehouse suporta backends S3, GCS e Azure. citeturn23search0turn23search2turn23search5

Eu **não adicionaria inicialmente**:

```text
LLM para tudo
Neo4j cluster
Kubernetes
Kafka
GPU cluster
vector DB separado
microservices para cada função
```

Nada disso se justificou ainda.

### Critérios de sucesso do primeiro ano

Ao final do piloto, a pergunta não deveria ser:

> “o site ficou legal?”

Deveria ser:

> “provamos que conseguimos reconstruir estado institucional com rastreabilidade e sabemos quanto isso custa por unidade de evidência?”

Eu mediria cinco famílias de métricas.

**Cobertura:** percentual dos documentos esperados realmente coletados; gaps de data; falhas por fonte.

**Proveniência:** percentual de afirmações que retornam a documento + localização exata + versão.

**Extração:** precision/recall para tipos de evento e campos.

**Entity resolution:** false merge rate é especialmente importante; unir duas pessoas diferentes é muito pior que não uni-las.

**Infraestrutura:** GB por mil documentos, CPU-horas por mil documentos, custo por milhão de assertions, tamanho do índice em relação ao raw e tempo necessário para reprocessar todo o corpus.

### Orçamento do piloto

Minha recomendação financeira inicial seria:

| Item do piloto de 12 meses | Faixa de planejamento |
|---|---:|
| Servidor próprio de pesquisa, se comprado | **US$ 2.500–6.000** |
| Ou infraestrutura cloud/self-managed | **US$ 150–800/mês** inicialmente |
| Object storage/backup | normalmente fração pequena no corpus inicial; medir |
| Domínio, monitoramento, backup externo etc. | **US$ 200–1.000/ano** |
| APIs/datasets primários listados no piloto | **US$ 0** como objetivo inicial |
| OCR/NLP comercial | **US$ 0 no baseline**; somente após benchmark |
| Reserva para expansão de storage/RAM | **20–30% do CAPEX** |
| **Infra total do piloto, sem mão de obra** | aproximadamente **US$ 2.000–8.000 cloud-first**, ou **US$ 3.000–8.000** para um caminho predominantemente local |

Esses valores são deliberadamente conservadores e amplos. Não são cotações. A AWS, por exemplo, mostra que um OpenSearch gerenciado de produção pode sozinho ultrapassar US$ 1.600/mês em configurações multi-node, por isso a faixa baixa pressupõe **self-hosted, single-node/pequeno cluster e sem alta disponibilidade empresarial**. citeturn17search1

A mão de obra é outra ordem de grandeza e não está incluída. Como projeto pessoal/de pesquisa, ela aparece como seu tempo; como produto com equipe, rapidamente supera o custo de discos.

### Cronograma de doze meses

Considerando início técnico em setembro de 2026:

```mermaid
gantt
    title Piloto de memória institucional — setembro de 2026 a agosto de 2027
    dateFormat YYYY-MM-DD
    axisFormat %b/%y

    section Fundação
    Contrato de dados e modelo de provenance   :a1, 2026-09-01, 45d
    Ingestão Federal Register/GovInfo           :a2, 2026-09-20, 55d
    USAspending                                 :a3, 2026-10-15, 45d

    section Corpus
    Arquivo imutável e versionamento            :b1, 2026-09-20, 90d
    Parsing e normalização                       :b2, 2026-11-01, 75d
    Full-text e interface mínima                 :b3, 2026-12-01, 75d

    section Semântica
    FollowTheMoney / entidades                   :c1, 2027-01-01, 75d
    Entity resolution                            :c2, 2027-02-01, 90d
    Eventos e modelo temporal                    :c3, 2027-03-01, 105d

    section Investigação
    Consultas históricas                         :d1, 2027-05-01, 60d
    Grafo e navegação                            :d2, 2027-05-15, 60d

    section Internacionalização
    Piloto CELLAR/TED                            :e1, 2027-06-01, 60d
    Teste multilíngue                            :e2, 2027-06-20, 45d

    section Governança
    Política de inferência e acesso              :f1, 2027-04-15, 120d
    Threat model e revisão de privacidade        :f2, 2027-05-15, 75d

    section Avaliação
    Benchmark 1M objetos                         :g1, 2027-07-01, 40d
    Relatório de capacidade e decisão de escala  :g2, 2027-08-01, 30d
```

O momento para comprar hardware grande seria **depois do benchmark de capacidade**, não antes dele.

## Fontes públicas prioritárias e estratégia de expansão

Eu separaria rigorosamente **fonte de verdade**, **fonte de identidade** e **fonte contextual**.

A ordem de ingestão que considero mais forte é esta:

| Prioridade | Fonte | Tipo | Motivo |
|---:|---|---|---|
| **1** | [Federal Register API](https://www.federalregister.gov/developers/documentation/api/v1) | **Primária/oficial**, porém representação web informativa | API limpa, longitudinal desde 1994, atos e notices; excelente primeira ingestão. citeturn12search0turn12search4 |
| **2** | [GovInfo API](https://www.govinfo.gov/developers) | **Primária/autoritativa** | Estabelece cadeia de custódia documental e oferece packages, conteúdo e metadados oficiais. citeturn12search1turn12search9turn12search28 |
| **3** | [USAspending API](https://api.usaspending.gov/) | **Primária/oficial** | Introduz contratos, grants, agencies e recipients, permitindo reconstruir fluxos institucionais. citeturn12search2turn12search6 |
| **4** | [EUR-Lex/CELLAR](https://eur-lex.europa.eu/content/help/data-reuse/reuse-contents-eurlex-details.html) | **Primária/oficial** | Melhor corpus para testar RDF/OWL, SPARQL, multilinguismo e relações semânticas. citeturn11search0turn11search8 |
| **5** | [TED API](https://docs.ted.europa.eu/api/latest/) | **Primária/oficial** | Procurement com ciclo de vida e ontologia explícitos; muito próximo de `Event → State`. citeturn10search1turn10search2turn10search13 |
| **6** | [legislation.gov.uk](https://www.legislation.gov.uk/developer/contents) | **Primária/oficial** | XML/RDF e licença de reutilização clara; excelente terceiro regime jurídico. citeturn13search0turn13search2turn13search11 |
| **7** | [OpenCorporates](https://api.opencorporates.com/) | **Secundária de identidade, baseada em registros oficiais** | Reconciliação empresarial global e provenance; usar como enrichment, nunca substituir a fonte registral. citeturn6search1turn6search21 |
| **8** | [OpenSanctions](https://www.opensanctions.org/docs/) | **Secundária consolidada** | Excelente modelo de matching, provenance e atualização; atenção ao CC BY-NC/licença comercial. citeturn18search0turn18search3turn18search13 |
| **9** | [GDELT](https://www.gdeltproject.org/) | **Secundária/contextual** | Adicionar somente depois que a memória institucional estiver estável; útil para contextualizar acontecimentos públicos, não para estabelecer fatos administrativos. citeturn19search5turn19search8 |

Eu adotaria como política de verdade:

```text
TIER A — documento oficial autoritativo
GovInfo / CELLAR / TED / legislation.gov.uk
        ↓
TIER B — API oficial derivada/conveniente
Federal Register API / USAspending
        ↓
TIER C — agregador registral
OpenCorporates / OpenSanctions
        ↓
TIER D — fonte contextual
GDELT / mídia / pesquisa externa
```

Uma afirmação de Tier D jamais deveria silenciosamente sobrescrever Tier A.

E quando houver conflito:

```text
não:
canonical_value = "a versão que parece melhor"

mas:
Assertion A says X
Assertion B says Y
authority(A) > authority(B)
current interpretation = X
conflict preserved = true
```

Isso é, na minha avaliação, onde o projeto pode realmente ficar diferente.

Não é só “pegar vários diários oficiais”.

Não é só um grafo.

Não é só busca.

Não é sequer apenas investigação.

O objeto que aparece depois desta pesquisa é algo mais específico:

> **um ledger histórico e navegável das afirmações públicas produzidas por instituições, capaz de reconstruir entidades, eventos e estados sem destruir a cadeia de evidência que permite auditá-los.**

E a pesquisa também responde à sua preocupação financeira de forma relativamente concreta: **há um caminho realista em que você não precisa investir dezenas de milhares de reais imediatamente**. OpenAleph, FollowTheMoney e o novo ftm-lakehouse já absorvem anos de engenharia que você não precisa repetir; Federal Register, GovInfo, USAspending, CELLAR e TED oferecem material estruturado sem você começar por OCR de milhões de PDFs; e um piloto suficientemente pequeno pode rodar numa única máquina séria ou em algumas centenas de dólares mensais de infraestrutura. citeturn23search0turn23search1turn12search0turn12search1turn12search2turn11search0turn10search1

A decisão de investir pesado deveria vir somente depois que esse piloto respondesse empiricamente a três perguntas:

> **Quanto custa transformar um milhão de documentos em evidência navegável?**

> **Com que precisão conseguimos transformar evidência em eventos e estado institucional?**

> **Que perguntas novas se tornam possíveis quando fazemos isso?**

A terceira é justamente a que torna o projeto intelectualmente mais interessante — e, como você percebeu antes mesmo de começarmos esta pesquisa, também a que exige que ele seja tratado como infraestrutura séria, e não mais como uma “ideiazinha legal”.
