# Infraestrutura internacional para investigação documental pública: ecossistema, arquitetura, custos e limites dual-use

## Resumo executivo

O projeto descrito — ingerir publicações oficiais e registros, preservar a evidência original, extrair texto e entidades, resolver identidades, reconstruir eventos ao longo do tempo e disponibilizar busca/grafo/análise — **não é uma ideia isolada nem excêntrica**. Há uma família internacional de sistemas que já implementa partes substanciais dessa arquitetura. O parente conceitualmente mais próximo é o ecossistema **OCCRP Aleph / FollowTheMoney / OpenSanctions**; o **ICIJ Datashare** é especialmente forte na camada documental; **GDELT** demonstra a escala que uma fábrica contínua de eventos e grafos pode atingir; **Maltego** é uma bancada de investigação por grafos; e **Quantexa** e **Palantir** mostram o que a mesma lógica se torna quando transformada em infraestrutura empresarial ou de inteligência operacional. citeturn21search0turn21search1turn18search6turn17search0turn18search12turn18search1

A conclusão mais importante para o seu projeto é que **você não precisa começar inventando nem a plataforma inteira nem a ontologia inteira**. FollowTheMoney já oferece um vocabulário investigativo para pessoas, empresas, contratos, pagamentos e relações; a União Europeia oferece a **eProcurement Ontology**, que modela semanticamente o ciclo completo de contratação pública; e o **CELLAR/CDM** mostra como um governo pode tratar documentos, versões, metadados e relações como um knowledge graph oficial consultável por SPARQL. citeturn18search6turn18search10turn18search11turn19search29

Também não há motivo técnico, neste momento, para começar comprando uma máquina com GPU de alto nível. Para um primeiro corpus como **um ano de DODF**, uma estação com aproximadamente **16–32 GB de RAM, SSD/NVMe e 4–8 núcleos modernos já é suficiente para descobrir os gargalos**; 32–64 GB dá bastante conforto. O DODF oferece PDFs certificados e pesquisa textual oficial, o que sugere que pelo menos parte importante do corpus possui texto digital e não requer OCR integral. OCR deve ser tratado como *fallback*, e não aplicado cegamente a todas as páginas. citeturn20search1turn20search2

O custo muda radicalmente quando o projeto passa de dezenas de milhares para milhões de páginas. O ICIJ registrou que a análise de **715 mil arquivos** do Luanda Leaks teve custo de servidores estimado em **US$ 13,3 mil**, com OCR sendo a etapa mais cara; no Panama Papers, para 2,6 TB de material, chegaram a operar temporariamente **30–40 servidores paralelos para OCR**. O GDELT, em outro extremo, informa que somente o Global Knowledge Graph de 2015 ultrapassa **2,5 TB**. Esses casos indicam que, na escala séria, processamento documental e índices passam a custar mais que simplesmente guardar PDFs. citeturn21search6turn21search8turn17search0

Minha recomendação arquitetural central seria **evidence-first, graph-later**: o objeto primário deve continuar sendo a evidência pública imutável, com hash e proveniência; entidades e eventos devem ser afirmações derivadas e reversíveis; resolução de identidade nunca deve apagar as menções originais; e busca e grafo devem ser projeções reconstruíveis. Isso também cria a melhor defesa contra um dos problemas mais sérios do projeto: confundir **“o documento diz X”**, **“nosso sistema acredita que A e B são a mesma entidade”** e **“a combinação dos dados sugere Y”**.

E existe, sim, um problema dual-use real. O próprio material de treinamento do Department of Justice americano distingue *compilation theory* e *mosaic theory*: peças não classificadas, em certas circunstâncias, podem adquirir significado sensível quando agregadas ou combinadas com informação pública. Isso **não significa que um banco privado de dados públicos automaticamente se torne juridicamente classificado**; a classificação americana obedece a autoridades e procedimentos próprios. Mas demonstra que a preocupação que surgiu na nossa conversa não é imaginária: **agregação altera o conteúdo informacional do conjunto**. citeturn14view3turn15view0

Minha conclusão prática é, portanto:

> **Não compre primeiro a infraestrutura de um sistema multipaís. Construa primeiro um laboratório de medição.**

Um PoC particularmente bom seria **DODF + Federal Register + TED**. Isso força a arquitetura a lidar, desde o início, com três mundos diferentes: PDF administrativo brasileiro, API JSON/XML americana e procurement europeu estruturado/semântico. Ao final, você mede bytes, páginas, tempo de ingestão, OCR necessário, custo por mil páginas, erros de NER, erros de resolução de entidades, crescimento do índice e qualidade da proveniência. Só então o hardware deixa de ser uma suposição e passa a ser uma consequência mensurável do projeto. citeturn20search1turn14view0turn14view1

## Ecossistema internacional comparável

A primeira surpresa da pesquisa é que nenhuma das plataformas analisadas faz **exatamente** tudo que você descreveu de forma aberta e generalista. O espaço é fragmentado: algumas dominam documentos, outras identidade, outras grafos, outras fontes públicas, outras análise operacional. Isso é bom para o projeto, porque significa simultaneamente que existe uma enorme quantidade de engenharia reutilizável **e que ainda há um espaço arquitetural não trivial entre elas**.

| Projeto | O que faz melhor | OCR / NER / ER | Grafo e tempo | Código/licenciamento | Escala demonstrada ou declarada | Limitação principal para o seu caso |
|---|---|---|---|---|---|---|
| **[OCCRP Aleph / Aleph Pro](https://www.occrp.org/en/announcement/occrp-announces-a-new-chapter-for-its-investigative-data-platform-aleph-pro)** | Arquivo investigativo, ingestão de registros/documentos, busca, cruzamento e investigação de entidades | Ingestão documental; modelo enriquecido; integração com ecossistema FtM | Relações, knowledge graph, confiança nas conexões | O Aleph histórico foi open-source; **Aleph Pro não é open-source**, embora OCCRP prometa acesso gratuito a jornalismo nonprofit e licença orientada ao interesse público. O fork **OpenAleph** continua aberto | OCCRP informou >24 mil usuários e >4,5 bilhões de registros em sua instância | Aleph Pro não é mais uma base open-source que você simplesmente instala e modifica como antes; o legado entrou em sunset | citeturn21search0turn7search1 |
| **[ICIJ Datashare](https://github.com/ICIJ/datashare)** | Transformar coleções documentais heterogêneas em corpus pesquisável | **OCR, extração de texto, NER**, metadados; PDFs, e-mail, Office, imagens, arquivos compactados | Relações entre documentos e entidades, mas não é um motor completo de ER/grafo temporal | **AGPL-3.0**, self-hosted | ICIJ afirma que processa milhões de documentos; usado nas grandes investigações do consórcio | Excelente camada de documentos, mas você ainda precisaria construir/ligar canonicalização de entidades, eventos e temporalidade | citeturn21search1turn21search3 |
| **[OpenSanctions](https://www.opensanctions.org/docs/)** | Integração, deduplicação, enriquecimento e matching de pessoas/empresas/relacionamentos | Forte em entity matching/ER; `nomenklatura` e `yente` | FollowTheMoney representa relações como entidades e preserva proveniência | Componentes do ecossistema são abertos; **os dados são gratuitos para uso não comercial e exigem licença para empresas** | Opera sobre grande quantidade de watchlists, PEPs e fontes de referência | Domínio deliberadamente voltado a risco, sanções, PEP/KYB; não é um repositório universal de diários oficiais | citeturn16search9turn16search11turn16search16 |
| **[OpenCorporates](https://api.opencorporates.com/)** | Registro empresarial global normalizado e IDs para empresas | Ótima fonte para enriquecimento/ER empresarial | Relações societárias dependendo da jurisdição | Base aberta sob **ODbL** em modalidades abertas; API e usos empresariais também têm ofertas/licenças comerciais | Mais de 200 milhões de empresas segundo a documentação da API | Fonte de identidade corporativa, não pipeline documental nem plataforma investigativa completa | citeturn0search2turn0search14turn0search17 |
| **[GDELT](https://www.gdeltproject.org/)** | Extração contínua de eventos, pessoas, organizações, lugares e temas em escala global | NLP/extração em notícias multilíngues | Event Database + Global Knowledge Graph + tempo/geografia | Dados declarados **100% gratuitos e abertos**; não é, porém, um pacote equivalente de software self-hosted | Um único ano do GKG pode superar **2,5 TB**; dados vivos são disponibilizados via BigQuery | Fonte é mídia/noticiário, não registro estatal autoritativo; erros da fonte e da extração propagam-se ao grafo | citeturn17search0turn17search2 |
| **[Maltego](https://www.maltego.com/graph/)** | Investigação interativa e *link analysis* por pivôs entre entidades e fontes | “Transforms” consultam APIs/bases e retornam entidades relacionadas | Grafo exploratório excelente; automação de pivôs | Proprietário/comercial, com tiers gratuitos e pagos; várias fontes exigem créditos/licenças próprias | Maltego informa uso por milhares de organizações governamentais e empresas e >100 integrações em planos avançados | É mais uma **bancada do investigador** que um data lake/document warehouse próprio | citeturn17search3turn17search4turn17search9turn17search10 |
| **[Quantexa](https://www.quantexa.com/platform/entity-resolution-software/)** | Entity Resolution empresarial + graph analytics + contextual decision intelligence | ER é o núcleo do produto | Grafos construídos sobre entidades resolvidas, batch e dinâmicos | Proprietário/comercial | Empresa anuncia capacidade de trabalhar com dados empresariais em escala de bilhões/tens de bilhões de pontos/records | Excelente benchmark arquitetural, mas caro/enterprise e sem liberdade para inspecionar/reconstruir todo o stack | citeturn18search0turn18search12turn18search24 |
| **[Palantir Gotham / Foundry](https://www.palantir.com/platforms/gotham/)** | Integração, ontologia operacional, aplicações analíticas e decisão sobre dados heterogêneos | Integra objetos do mundo real sobre datasets/modelos | Ontology com objetos, propriedades, links, ações e controles de segurança | Proprietário/comercial | Utilizado em ambientes empresariais, governamentais e de defesa; Gotham é explicitamente apresentado como sistema para decisão em defesa | É um benchmark do extremo operacional da arquitetura, não uma base open-source de transparência pública | citeturn18search1turn18search5turn18search9turn18search17 |

Há duas comparações especialmente importantes.

A primeira é **Datashare versus Aleph/FtM**. O Datashare começa pelo arquivo: “me dê milhões de documentos e torne-os pesquisáveis”. Aleph/FtM começa mais próximo da investigação: “me dê documentos e dados estruturados e torne entidades e relações interoperáveis”. Eles são complementares, não concorrentes. O Datashare atual exige PostgreSQL, Elasticsearch e Redis e fornece `docker-compose`, o que também é uma boa referência concreta de quão pouco hardware é necessário para começar, comparado com o tamanho conceitual do problema. citeturn21search1

A segunda é **Quantexa/Palantir versus seu projeto**. Tecnicamente, há uma semelhança clara na sequência:

`dados heterogêneos → entidade → relação → contexto → análise`.

Quantexa descreve explicitamente Entity Resolution como transformar referências ambíguas de diversas fontes em entidades reais e depois construir grafos sobre elas; Palantir descreve sua Ontology como a camada que liga datasets, tabelas e modelos às coisas do mundo real representadas por esses dados. A diferença fundamental está no domínio, no regime de acesso e na finalidade: seu ponto de partida são **evidências públicas e auditabilidade**, enquanto essas plataformas podem trabalhar com dados internos, restritos e operacionais. citeturn18search8turn18search12turn18search5

O **GDELT** merece ainda uma leitura diferente. Ele não é uma boa plataforma para copiar, mas é uma excelente demonstração do que acontece quando você transforma continuamente fontes abertas em:

```text
pessoa
organização
lugar
evento
tempo
relação
```

e mantém isso por décadas. O próprio GDELT recomenda BigQuery porque um dataset anual pode ultrapassar a capacidade prática de um computador individual. É a prova de que o limite superior do seu projeto não é “um banco grandinho”: na escala internacional, ele pode efetivamente entrar em território de infraestrutura de dados distribuída. citeturn17search0turn17search2

## Ontologias, portais públicos e interoperabilidade

Para o projeto, eu separaria três perguntas que até agora estavam misturadas:

**Como represento coisas investigáveis?**  
FollowTheMoney.

**Como represento uma contratação pública de maneira semanticamente rigorosa?**  
eProcurement Ontology.

**Como represento documentos oficiais, versões, manifestações e suas relações em um grande repositório estatal?**  
CELLAR/CDM.

### FollowTheMoney como vocabulário investigativo

O **[FollowTheMoney](https://followthemoney.tech/)** é provavelmente a referência mais importante para você estudar antes de escrever uma ontologia própria. Ele é explicitamente um modelo para investigação de crime financeiro e forense documental, mas sua abstração alcança pessoas, empresas, órgãos, ativos, documentos, pagamentos, relações e outras entidades. O modelo padrão atualmente contém dezenas de schemas e oferece ferramentas para gerar, validar, normalizar e trocar essas entidades. citeturn18search6turn18search10

Um aspecto especialmente bom é que uma relação complexa **não precisa ser reduzida a uma simples aresta**. OpenSanctions, usando FtM, dá o exemplo de `Ownership`: uma pessoa e uma empresa podem ser ligadas por uma entidade própria de propriedade que carrega percentual e período temporal. Isso resolve exatamente o problema que aparece quando uma relação tem propriedades próprias. citeturn16search9

Conceitualmente:

```mermaid
graph LR
    P[Person: Ana]
    O[Ownership]
    C[Company: Empresa X]
    D[Source Document]

    P -->|owner| O
    O -->|asset| C
    O -->|startDate / endDate / percentage| O
    D -->|supports assertion| O
```

Isso é melhor do que:

```text
Ana --OWNS--> Empresa X
```

porque a primeira representação consegue dizer:

> Ana possuía 37% da Empresa X **entre duas datas**, e essa afirmação veio **do documento D**, com determinada confiança.

FollowTheMoney também distingue propriedades úteis para matching e cross-reference; `Person`, `Company` e `LegalEntity`, por exemplo, são explicitamente schemas passíveis de matching. O ecossistema inclui ferramentas de comparação e deduplicação de entidades e o `yente`, que consegue importar datasets próprios no formato FtM JSON. citeturn18search18turn18search30turn18search34turn18search38turn16search5

Eu **não adotaria FtM literalmente como toda a ontologia interna**, porém. O próprio projeto se descreve de maneira pragmática e é orientado a investigações financeiras/documentais. Eu o usaria como língua franca de importação/exportação e como fonte de decisões já amadurecidas, mantendo uma camada interna capaz de representar explicitamente proveniência e temporalidade da forma que o DODF exigir.

### eProcurement Ontology como modelo de contratos

A **[eProcurement Ontology](https://docs.ted.europa.eu/epo-home/index.html)** da União Europeia é quase um laboratório pronto para a parte de contratos. O objetivo oficial é representar procurement em OWL de maneira aberta e legível por máquina, cobrindo o processo de ponta a ponta: publicação/notificação, licitação, adjudicação, pedido, faturamento e pagamento. citeturn18search7turn18search11turn18search39

Uma projeção simplificada do modelo é:

```mermaid
graph TD
    BUYER[Public Buyer]
    PROC[Procurement Procedure]
    LOT[Lot]
    NOTICE[Notice]
    BID[Tender]
    EO[Economic Operator]
    AWARD[Award]
    CONTRACT[Contract]
    PAYMENT[Payment]

    BUYER --> PROC
    PROC --> NOTICE
    PROC --> LOT
    EO --> BID
    BID --> LOT
    LOT --> AWARD
    AWARD --> CONTRACT
    CONTRACT --> PAYMENT
```

O valor disso não é só filosófico. A própria documentação da ePO formula perguntas de competência como “quais contratos foram adjudicados num período?”, “qual montante total foi adjudicado por determinado CPV?” e “quais operadores econômicos submeteram propostas?”. Em outras palavras, a ontologia foi desenhada pensando exatamente nas consultas analíticas que um sistema como o seu faria depois. citeturn18search19

Para um DODF internacionalizado, eu mapearia:

```text
AVISO DE LICITAÇÃO       → Notice / Procedure
órgão contratante        → Buyer / PublicBody
CNPJ da contratada       → EconomicOperator / Company
EXTRATO DE CONTRATO      → Contract
valor                    → monetary amount
vigência                 → temporal interval
processo SEI             → Process / external identifier
nota de empenho          → financial commitment / expenditure event
```

e manteria a representação original brasileira lado a lado com o mapeamento internacional. **Não tentaria obrigar a realidade brasileira a caber integralmente na ePO.**

### CELLAR como referência de memória institucional

O caso do **[EUR-Lex/CELLAR](https://eur-lex.europa.eu/content/help/data-reuse/reuse-contents-eurlex-details.html?locale=pt)** é talvez o mais próximo da ideia de “memória institucional navegável”. O CELLAR é o repositório comum de conteúdo e metadados do Publications Office da União Europeia. A documentação oficial diz explicitamente que metadados podem ser consultados por SPARQL, **incluindo relações entre entidades**, enquanto a API REST permite recuperar conjuntos de metadados e conteúdo em formatos como PDF, HTML e Formex. citeturn19search29turn19search2

Isso é uma validação externa forte da arquitetura:

> documento físico não precisa ser o centro lógico do sistema.

O documento pode ser uma manifestação de uma entidade institucional com identidade própria, versões, idiomas, relações, metadados e histórico.

### Fontes oficiais que podem alimentar o sistema

| Ecossistema | Fonte | Valor para o projeto | Interface útil |
|---|---|---|---|
| EUA | **[Federal Register API](https://www.federalregister.gov/developers/documentation/api/v1)** | Regras, notices, documentos presidenciais, atos de agências; ótima fonte de eventos regulatórios | API pública JSON/XML; **não exige chave**. A versão web XML deve ser distinguida da edição oficial hospedada no GovInfo. citeturn14view0 |
| EUA | **[GovInfo API](https://api.govinfo.gov/docs/)** | Conteúdo e metadados oficiais dos três poderes; Federal Register, Congressional Record etc. | REST; exige chave gratuita `api.data.gov`. citeturn19search0turn19search4 |
| EUA | **[USAspending API](https://api.usaspending.gov/)** | Contratos, grants, loans e outros fluxos de gasto federal | REST/JSON; endpoints de busca atualmente não exigem autenticação. citeturn19search5turn19search9 |
| UE | **[EUR-Lex / CELLAR](https://eur-lex.europa.eu/content/help/data-reuse/reuse-contents-eurlex-details.html?locale=pt)** | Legislação, documentos institucionais, metadados e relações | SPARQL + REST + formatos documentais. citeturn19search29 |
| UE | **[TED API](https://docs.ted.europa.eu/api/latest/search.html)** | Licitações e notices de procurement de toda a UE | `POST /v3/notices/search`; busca avançada e download XML; acesso anônimo para notices publicados. citeturn14view1 |
| UE | **TED Open Data** | Mesmos objetos em Linked Open Data | RDF/SPARQL e mapeamentos RML. citeturn18search39 |
| Reino Unido | **[Legislation API](https://www.legislation.gov.uk/developer/formats)** | Legislação estruturada | XML sob schema oficial e RDF/XML. citeturn20search0turn20search4turn20search7 |
| Canadá | **[Open Government API](https://open.canada.ca/en/access-our-application-programming-interface-api)** | Catálogo federal e registros abertos | CKAN API; autenticação necessária para publicação, não para leitura pública. citeturn19search3turn19search7 |
| DF | **[DODF](https://dodf.df.gov.br/)** + **[SINJ](https://www.sinj.df.gov.br/sinj/)** | Fonte brasileira inicial: atos, nomeações, contratos, empenhos, estruturas administrativas etc. | PDFs certificados + busca por texto/data/seção/tipo; **não identifiquei nesta pesquisa uma API pública documentada equivalente ao Federal Register/TED**. citeturn20search1turn20search2 |

Alguns exemplos reais de consumo já mostram como os adaptadores poderiam ser pequenos.

Federal Register:

```bash
curl 'https://www.federalregister.gov/api/v1/documents.json?per_page=20&order=newest'
```

A documentação oficial informa que os endpoints públicos não exigem chave. citeturn14view0

GovInfo:

```bash
curl \
  'https://api.govinfo.gov/packages/FR-2018-08-03/summary?api_key=YOUR_KEY'
```

Esse é o padrão de exemplo publicado pelo próprio GovInfo. citeturn19search8

USAspending:

```bash
curl -X POST \
  'https://api.usaspending.gov/api/v2/search/spending_by_award/' \
  -H 'Content-Type: application/json' \
  -d '{
    "filters": {
      "time_period": [
        {
          "start_date": "2026-01-01",
          "end_date": "2026-12-31"
        }
      ]
    },
    "fields": [
      "Award ID",
      "Recipient Name",
      "Award Amount"
    ],
    "page": 1,
    "limit": 10,
    "subawards": false
  }'
```

`/api/v2/search/spending_by_award/` é o endpoint oficial de Advanced Award Search. Campos e filtros devem ser validados contra a versão corrente da documentação quando o adapter for implementado. citeturn19search1turn19search5

TED:

```http
POST https://api.ted.europa.eu/v3/notices/search
Content-Type: application/json
```

O endpoint `/v3/notices/search` é atualmente documentado como interface de busca e recuperação de notices publicados, inclusive para reutilização e download em massa. citeturn14view1

CELLAR:

```sparql
SELECT ?s ?p ?o
WHERE {
  ?s ?p ?o
}
LIMIT 20
```

enviado ao endpoint SPARQL público do Publications Office:

```text
https://publications.europa.eu/webapi/rdf/sparql
```

Uma consulta trivial dessas não tem valor investigativo por si mesma, mas demonstra algo arquiteturalmente enorme: você pode começar navegando **relações que o próprio Estado europeu já publicou como grafo**, em vez de reconstruir tudo por NER a partir de PDF. citeturn19search2turn19search29

Para `legislation.gov.uk`, o padrão é expor legislação em formatos estruturados, por exemplo conceitualmente:

```text
https://www.legislation.gov.uk/{tipo}/{ano}/{numero}/data.xml
```

e também RDF, conforme a documentação da Legislation API. citeturn20search0turn20search7

Essa diversidade sugere uma decisão importante: **não construa o sistema em torno de PDF**. Construa-o em torno de `SourceRecord`. Um `SourceRecord` pode nascer como PDF, XML, JSON, RDF, CSV ou HTML, e o documento visual é apenas uma de suas representações.

## Arquitetura técnica de referência

Eu faria uma alteração importante em relação ao desenho mais intuitivo: **o grafo não seria o banco mestre**.

O sistema mestre deveria ser um conjunto de evidências, afirmações e identidades versionadas. Busca e grafo seriam projeções desses dados.

```mermaid
flowchart TD
    A[Official sources<br/>PDF / XML / JSON / RDF / CSV]
    B[Source adapters<br/>fetch / API / crawler]
    C[Immutable object store<br/>original bytes + SHA-256]
    D[Metadata & provenance<br/>PostgreSQL]
    E[Parser / text extraction]
    F{Text quality OK?}
    G[OCR fallback]
    H[Document / page / span layer]
    I[NER + structured extractors]
    J[Entity mentions]
    K[Entity resolution]
    L[Canonical entities]
    M[Event & relationship extraction]
    N[Temporal assertions]
    O[Full-text index<br/>OpenSearch/Elasticsearch]
    P[Graph projection<br/>Postgres / RDF / Graph DB]
    Q[Investigation API / UI]
    R[Audit / access / policy engine]

    A --> B
    B --> C
    B --> D
    C --> E
    E --> F
    F -->|yes| H
    F -->|no| G
    G --> H
    H --> I
    I --> J
    J --> K
    K --> L
    H --> M
    L --> M
    M --> N
    H --> O
    L --> O
    N --> P
    L --> P
    O --> Q
    P --> Q
    R --> B
    R --> Q
```

### A camada que eu consideraria não negociável

A unidade fundamental deveria se parecer com:

```text
source
  source_id
  jurisdiction
  publisher
  retrieval_url
  retrieved_at

source_document
  document_id
  source_id
  publication_date
  official_identifier
  sha256
  blob_uri

document_segment
  segment_id
  document_id
  page
  start_offset
  end_offset
  text

entity_mention
  mention_id
  segment_id
  raw_text
  extracted_type

canonical_entity
  entity_id
  schema

resolution_assertion
  mention_id
  entity_id
  method
  confidence
  model_version
  review_status

event
  event_id
  event_type
  valid_from
  valid_to

event_participant
  event_id
  entity_id
  role

assertion_source
  assertion_id
  segment_id
  extractor_version
  confidence
```

O que parece “verboso demais” aqui é justamente o que salvaria o projeto depois.

Suponha que hoje:

```text
JOAO SILVA LTDA
```

e

```text
JOÃO SILVA COMÉRCIO LTDA
```

sejam unidos como uma única empresa com 93% de confiança.

Daqui a três meses você descobre que eram duas pessoas jurídicas diferentes.

Se o seu modelo fez:

```text
UPDATE entity SET name = ...
```

você contaminou retrospectivamente o grafo inteiro.

No modelo de assertions, você simplesmente invalida uma hipótese de resolução e recalcula as projeções. **A evidência original nunca mudou.**

Isso é especialmente importante em um sistema investigativo, porque *entity resolution* não é descoberta de verdade metafísica. É uma inferência probabilística ou determinística baseada em evidências.

### Tempo deveria existir em duas dimensões

Eu colocaria desde o início:

```text
valid_time
```

para “quando isso era verdade no mundo” e:

```text
system_time
```

para “quando o sistema soube disso”.

Assim, uma nomeação publicada em 15 de março, com efeito desde 1º de março, capturada pelo seu crawler em 16 de março, tem três fatos distintos:

```text
effective_from = 2026-03-01
published_at   = 2026-03-15
observed_at    = 2026-03-16
```

Essa diferença parece acadêmica até você começar a perguntar:

> “O que nós poderíamos ter sabido em 10 de março?”

ou:

> “Qual era o estado institucional que os documentos indicavam em 20 de março?”

Sem bitemporalidade, essas perguntas ficam quase impossíveis de responder corretamente.

### Stack inicial que eu realmente usaria

Eu não começaria com Kubernetes, Spark e um cluster Neo4j.

Começaria aproximadamente assim:

```text
Python
↓
PostgreSQL
↓
filesystem/ZFS ou S3-compatible object store
↓
Apache Tika / parser nativo
↓
OCR apenas quando necessário
↓
spaCy / regras / extractors específicos
↓
FollowTheMoney + nomenklatura/yente para experimentos de ER
↓
OpenSearch/Elasticsearch
↓
PostgreSQL edge tables
↓
API simples
```

O histórico do ICIJ reforça esse desenho incremental: seus pipelines usaram Apache Tika para processamento documental, Tesseract para OCR e mecanismos de busca separados; no Datashare atual, PostgreSQL, Elasticsearch e Redis são componentes explícitos do ambiente. citeturn21search1turn21search8

Só colocaria um graph database dedicado quando você conseguir mostrar que perguntas como:

```cypher
MATCH (p:Person)-[:HELD_POSITION]->(o:Office)
      <-[:HELD_POSITION]-(q:Person)
WHERE p <> q
RETURN p, o, q
```

ou travessias multi-hop estiverem se tornando gargalo real.

Antes disso, uma tabela:

```sql
relationship (
    subject_id,
    predicate,
    object_id,
    valid_from,
    valid_to,
    assertion_id
)
```

em PostgreSQL é extraordinariamente poderosa e elimina uma classe inteira de complexidade operacional.

O índice de busca também deve ser **descartável**. OpenSearch/Elasticsearch não deve ser o registro de verdade. Se o cluster morrer, a regra deveria ser:

> reconstruir índice a partir de PostgreSQL + blobs + derivados preservados.

Não:

> restaurar nossa única cópia da realidade de dentro do índice.

## Escala, hardware e custo

Aqui é importante separar **dados medidos** de **estimativas de engenharia**.

Sabemos que o DODF atual disponibiliza edições certificadas em PDF e busca por texto, além de o SINJ permitir pesquisa por data, número, seção e texto. Isso torna plausível que uma fração relevante do material recente dispense OCR integral. citeturn20search1turn20search2

Para planejamento, eu trataria um ano de DODF como algo da ordem de **dezenas de milhares de páginas**, não milhões. Isso é uma hipótese operacional a medir no PoC, e não um número oficial que encontrei publicado. Com PDFs predominantemente textuais, a escala é pequena para hardware moderno; o crescimento fica mais sério quando você mantém páginas renderizadas, embeddings, múltiplos índices, versões e réplicas.

A tabela abaixo é, portanto, **estimativa de ordem de grandeza**, não cotação nem medição do corpus.

| Estágio | Corpus aproximado para planejamento | Armazenamento bruto | Hot data + índices + derivados | CPU/RAM recomendada | GPU | Ordem de custo mensal cloud |
|---|---:|---:|---:|---|---|---:|
| **PoC — 1 ano DODF** | dezenas de milhares de páginas | ~10–50 GB | ~50–250 GB | 4–8 vCPU; 16–32 GB RAM | **Não necessária inicialmente** | **US$ 40–160** de compute; poucos dólares de object storage |
| **DODF histórico amplo** | anos/dezenas de anos | ~0,1–0,5 TB | ~0,5–2 TB | 8–16 vCPU; 32–64 GB RAM | opcional para lotes de OCR/modelos | **US$ 150–600** |
| **Brasil + 2–4 ecossistemas internacionais** | milhões de documentos potencialmente | ~5–20 TB | ~10–40 TB | 32–96 vCPU agregados; 96–256 GB RAM | burst opcional | **US$ 1,5 mil–6 mil** |
| **Plataforma multipaís madura** | dezenas/centenas de milhões de objetos possíveis | 50–200+ TB | 100–500+ TB se houver réplicas, imagens e vetores | 100–500+ vCPU; 256 GB–1 TB+ de RAM agregada | conforme ML/OCR | **US$ 8 mil–40 mil+** |

Essas faixas dependem brutalmente de cinco variáveis: percentual de páginas que realmente precisam de OCR; retenção ou não de imagens renderizadas; quantidade de embeddings; fator de replicação do índice; e quanto do corpus fica em armazenamento “hot”. O histórico do ICIJ fornece um dado particularmente instrutivo: no Luanda Leaks, o custo de processamento de 715 mil arquivos foi estimado em US$ 13,3 mil e **OCR foi apontado como a parte mais cara**. citeturn21search6

No Panama Papers, 2,6 TB de dados exigiram uma abordagem de processamento paralela com 30–40 servidores temporários para OCR. Isso é exatamente o tipo de workload para o qual cloud faz sentido: não comprar 40 máquinas para um processamento que talvez dure alguns dias, mas alugar capacidade temporária e desligá-la depois. citeturn21search8

O GDELT ilustra a outra extremidade. Apenas o GKG de 2015 tem mais de 2,5 TB segundo o projeto, e o GDELT explicitamente recomenda BigQuery porque datasets desse tamanho já ficam desconfortáveis em infraestrutura local comum. citeturn17search0

### O armazenamento é surpreendentemente barato; compute e índices não são

Na região americana de referência usada pela AWS, a própria documentação exemplifica **S3 Standard a US$ 0,023/GB-mês para os primeiros 50 TB**. Isso implica, ignorando requests, tráfego e outras classes de cobrança:

| Dados | S3 Standard a US$ 0,023/GB-mês |
|---:|---:|
| 100 GB | ~US$ 2,30/mês |
| 1 TB | ~US$ 23,55/mês |
| 10 TB | ~US$ 235,52/mês |
| 50 TB | ~US$ 1.177,60/mês |

citeturn22search5turn22search11

Ou seja: **guardar o PDF do DODF não é o problema**.

O que fica caro é:

```text
PDF original
+ imagem de cada página
+ OCR
+ texto segmentado
+ entidades
+ candidatos de ER
+ embeddings
+ índice de busca
+ grafo
+ réplica
+ backup
+ compute permanente
```

e, principalmente, deixar mecanismos de busca/analytics com bastante RAM permanentemente ligados.

Como referência corrente, Lightsail lista, dependendo do bundle e da configuração de rede, instâncias Linux na faixa de cerca de **US$ 80/mês para 4 vCPU/16 GB** em bundles IPv6-only e valores maiores para bundles equivalentes com outras características; 8 vCPU/32 GB aparece em torno de **US$ 160/mês** no mesmo grupo IPv6-only. Os valores variam por configuração e devem ser confirmados na hora da compra. citeturn22search0turn22search4

Isso torna plausível rodar o primeiro sistema inteiro por algo da ordem de **dezenas ou poucas centenas de dólares mensais**, em vez de milhares.

### O primeiro hardware que eu compraria

Caso você queira uma máquina física dedicada, eu priorizaria aproximadamente:

```text
CPU:     muitos núcleos modernos; 12–24 threads já são confortáveis
RAM:     64 GB
NVMe:    2–4 TB
HDD:     opcional para archive/backup local
GPU:     nenhuma inicialmente
UPS:     sim
backup:  externo/off-site obrigatório
```

Não estou recomendando modelos comerciais específicos aqui; estou descrevendo o perfil técnico.

Por quê 64 GB?

Porque a RAM permite manter banco, índice de busca, processamento e ambiente de desenvolvimento juntos sem você precisar começar imediatamente um cluster.

Por quê 2–4 TB NVMe?

Porque o texto original ocupa pouco, mas índices, caches e processamento temporário gostam muito de I/O rápido.

E por que **não GPU**?

Porque você ainda não sabe se seu corpus exige uma. O DODF recente já possui mecanismos oficiais de busca textual e PDFs digitais. Se 90% das páginas forem text-native, uma GPU cara pode passar a maior parte da vida parada. citeturn20search1turn20search2

Só compraria GPU depois de medir:

```text
ocr_pages / total_pages
seconds_per_ocr_page
NER_seconds_per_1000_pages
ER_seconds_per_1000_entities
```

e provar que esse estágio domina o tempo ou o custo.

### Cloud versus on-prem não precisa ser decisão religiosa

Para dados **estritamente públicos**, minha preferência inicial seria híbrida:

```text
originais + banco local
+
backup criptografado em object storage
+
workers cloud temporários quando houver backfill pesado
```

Para coleções não públicas ou material sensível, a história do ICIJ mostra por que self-hosting importa: Datashare foi deliberadamente construído para poder rodar nas próprias máquinas/servidores, mantendo os documentos sob controle do operador; o ICIJ também descreve escolhas de infraestrutura interna justamente para conjuntos sensíveis. citeturn21search1turn21search7

Isso evita dois extremos igualmente ruins:

> comprar um datacenter antes de ter dados;

e

> entregar toda a matéria-prima investigativa a serviços externos por conveniência.

## Governança, dual-use e riscos jurídicos

Aqui eu acho importante não suavizar o problema: **o risco central não é que uma fonte pública seja secretamente confidencial. É que a transformação aumente a capacidade informacional do conjunto.**

O Department of Justice dos EUA ensina explicitamente duas ideias relacionadas em treinamento sobre classificação e FOIA. Em *compilation theory*, informações não classificadas reunidas podem formar uma imagem cuja divulgação produziria dano; em *mosaic theory*, peças não classificadas combinadas com informação já existente no domínio público podem completar uma imagem sensível. citeturn14view3turn15view0

Mas há uma distinção jurídica fundamental:

> **“o agregado tem valor sensível” ≠ “todo particular que agregou dados públicos agora possui um documento classificado”.**

A classificação americana é um processo governamental regido por autoridades e requisitos próprios. O material do DOJ fala, inclusive, em informação controlada por agência que pode ser classificada/protegida. Portanto, o conceito do mosaico deve ser entendido principalmente aqui como **modelo de risco informacional**, e não como uma regra automática que converte pesquisa pública em posse de segredo de Estado. citeturn14view3

Para o seu projeto, eu dividiria o risco em cinco classes.

| Risco | Como aparece no projeto | Controle arquitetural razoável |
|---|---|---|
| **Mosaic / inferência sensível** | Dados banais combinados permitem estimar uma condição que nenhuma fonte declarou | Separar camada de evidência da camada inferencial; políticas específicas para consultas operacionais; revisão humana para outputs de alto risco |
| **Privacidade** | Nomeações, endereços, IDs, relações familiares ou outras informações públicas tornam-se trivialmente pesquisáveis e agregáveis | Minimização, classificação de PII, controles de exportação, retenção proporcional, análise jurídica por jurisdição |
| **Entity resolution falso** | Duas pessoas são fundidas e o sistema cria uma rede falsa | Nunca destruir menções originais; score de confiança; revisão; possibilidade de desfazer clusters |
| **Uso secundário** | Ferramenta de transparência é usada para stalking, targeting, vigilância ou exploração operacional | RBAC/ABAC, limites por query/export, logs, segregação de funcionalidades e políticas de uso |
| **Supply/API/licensing** | Fonte aberta na web não significa reutilização ilimitada em qualquer modalidade | Armazenar termos/licença por dataset; obedecer rate limits; versionar proveniência e condições de uso |

A questão de privacidade também não desaparece simplesmente porque o dado estava público. Autoridades de proteção de dados, como o ICO britânico, deixam claro em suas orientações que usar informação pessoal obtida de fontes publicamente acessíveis continua exigindo análise da base jurídica e das obrigações de transparência previstas na legislação de proteção de dados. Portanto:

> `publicamente acessível ≠ livre de obrigações de tratamento`.

Esse ponto fica ainda mais importante depois de entity resolution, porque o sistema deixa de apenas reproduzir uma página pública e começa a **construir perfis compostos**. citeturn9search14

Em relação a controles de exportação, eu faria uma distinção semelhante. Nos Estados Unidos, o **Export Administration Regulations** define o escopo da informação, software e tecnologia sujeitos às regras; há também exceções/regras específicas para certas informações publicamente disponíveis. Portanto, uma plataforma de análise de documentação pública **não se torna automaticamente produto controlado apenas por fazer OSINT**, mas a inclusão posterior de software, tecnologia, technical data ou serviços regulados pode mudar a análise. Isso é um ponto para counsel especializado antes de distribuição internacional de uma versão sensível, não algo para resolver por heurística de engenharia. citeturn8search2turn8search6

### Uma divisão que eu colocaria literalmente na arquitetura

Eu teria dois grafos lógicos:

```mermaid
flowchart LR
    A[Public source]
    B[Evidence graph]
    C[Canonical entities]
    D[Analytical / inference graph]
    E[Public researcher]
    F[Restricted analyst]
    G[Audit log]

    A --> B
    B --> C
    C --> D

    E --> B
    E --> C

    F --> D

    E --> G
    F --> G
```

O **evidence graph** responde:

> Onde isso foi publicado?  
> Quem aparece no documento?  
> Qual entidade publicadora?  
> Qual contrato é citado?  
> Que relação foi explicitamente declarada?

O **analytical graph** pode responder:

> Quais fornecedores tornaram-se críticos?  
> Que padrão anômalo surgiu?  
> Qual relação é inferida apesar de não declarada?  
> Qual mudança parece estar acontecendo?

Essa separação permite uma decisão extremamente fina: você pode tornar a primeira camada pública e auditável sem necessariamente transformar toda inferência possível em uma API pública anônima.

### Controles que fariam sentido desde o início

Eu implementaria governança como dados, não como documento PDF esquecido numa pasta.

Cada dataset teria algo como:

```yaml
dataset:
  id: us_federal_register
  jurisdiction: US
  classification: public
  contains_personal_data: true
  redistribution: allowed
  bulk_export: allowed
  retention: indefinite
  source_terms_version: "2026-08-12"
```

Cada recurso derivado poderia ter política própria:

```yaml
feature:
  id: operational_capacity_prediction
  access: restricted
  log_queries: true
  bulk_export: false
  human_review_required: true
```

E eu registraria, pelo menos:

```text
quem consultou
quando consultou
qual corpus
qual query
quantos resultados
qual export foi produzido
qual versão dos modelos foi usada
```

Não porque “consulta a documento público é suspeita”, mas porque **um sistema com grande poder de composição deve conseguir auditar o uso de suas próprias capacidades**.

Para red-team, eu testaria explicitamente se uma pessoa mal-intencionada consegue usar o sistema para: construir dossiês pessoais em massa; localizar ou acompanhar indivíduos de maneira indevida; encontrar vulnerabilidades atuais de infraestrutura; transformar sinais administrativos em monitoramento operacional; abusar de bulk exports; ou induzir falsos vínculos por colisão de nomes.

Um princípio útil seria:

> **capacidade de pesquisa histórica por padrão; capacidade de inferência operacional por decisão explícita.**

Isso não mutila o projeto. Apenas impede que uma capacidade altamente diferente apareça silenciosamente como efeito colateral de uma feature chamada “analytics”.

## Caminho prático de implementação

Depois desta pesquisa, eu **não começaria uma nova implementação tomando Aleph legado como base principal**. O Aleph histórico foi extraordinariamente relevante, mas OCCRP migrou sua estratégia para Aleph Pro, que foi anunciado como não open-source, enquanto o fork independente OpenAleph segue a linhagem aberta. Para um projeto que você queira controlar durante anos, é arriscado acoplar o núcleo a uma geração upstream que entrou em sunset. citeturn21search0turn7search1

Eu usaria Aleph/FollowTheMoney como **objeto de estudo e padrão de interoperabilidade**, e Datashare como **atalho experimental para a camada documental**.

A primeira versão poderia ser:

```text
                    ┌────────────────────┐
                    │     DODF PDFs      │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │ archive + SHA-256  │
                    └─────────┬──────────┘
                              │
              ┌───────────────▼────────────────┐
              │ Tika/native text + OCR fallback│
              └───────────────┬────────────────┘
                              │
                    ┌─────────▼──────────┐
                    │ document segments │
                    └─────────┬──────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
    full text            entity mentions      structured acts
  OpenSearch             Person/Org/CNPJ    nomeação/contrato
        │                     │                     │
        │               entity resolution          │
        │                     │                     │
        └─────────────────────┴──────────┬──────────┘
                                         ▼
                               PostgreSQL canonical
                                         │
                                         ▼
                                  graph projection
```

Depois adicionaria **Federal Register** não porque é “mais interessante” que outra fonte, mas porque é tecnicamente muito diferente do DODF: possui API estruturada e não exige chave. Se a sua ontologia só funcionar para DODF, ela não é ainda uma ontologia geral; se sobreviver ao Federal Register, você aprendeu algo. citeturn14view0

A terceira fonte seria **TED**, porque traz procurement e uma ontologia formal. Se você conseguir mapear:

```text
DODF contract
USAspending award
TED contract/award
```

para um núcleo comum **sem perder a semântica específica de cada jurisdição**, você terá começado a testar empiricamente a ideia de uma memória institucional transnacional. citeturn14view1turn18search11turn19search1

Eu faria o projeto evoluir em quatro degraus, sem comprar infraestrutura grande antecipadamente:

```text
PoC documental
      ↓
PoC de entidades
      ↓
PoC temporal
      ↓
PoC multipaís
```

No primeiro, a pergunta é:

> Consigo preservar e encontrar tudo?

No segundo:

> Consigo reconhecer e resolver entidades sem destruir evidência?

No terceiro:

> Consigo reconstruir corretamente alterações de estado?

No quarto:

> Meu modelo sobrevive à troca de sistema administrativo?

E só depois:

> Quanto custa fazer isso em escala?

### As métricas que determinariam a compra de máquinas

Durante o PoC, eu registraria automaticamente:

| Métrica | Por que importa |
|---|---|
| documentos/dia e páginas/dia | volume real da fonte |
| bytes originais/dia | curva de storage bruto |
| bytes do índice / byte de texto | custo real de busca |
| % páginas com texto nativo | determina necessidade de OCR |
| % páginas enviadas a OCR | maior preditor de compute |
| segundos/página de OCR | permite precificar backfills |
| entidades extraídas por 1.000 páginas | tamanho futuro do grafo |
| candidatos de ER por entidade | custo da resolução |
| precisão/recall em amostra manual | impede escala de erro |
| taxa de merges revertidos | mede agressividade do ER |
| ingestão atrasada em horas | mede capacidade near-real-time |
| p50/p95 de queries | mostra quando busca precisa escalar |
| bytes de grafo/entidade | permite extrapolar |
| custo por 1.000 páginas | transforma arquitetura em orçamento |
| % de assertions com fonte/page/span | mede auditabilidade |
| tempo de restore de backup | mede se backup é realmente utilizável |

Depois de três meses disso, você poderia ter algo que hoje não temos:

```text
1 milhão de páginas
≈ X TB
≈ Y CPU-hours
≈ Z GB de índice
≈ N milhões de entidades
≈ M milhões de assertions
≈ US$ K de infraestrutura
```

Nesse momento comprar máquina deixa de ser “acho que esse projeto vai exigir muita coisa” e vira engenharia.

O benchmark histórico do ICIJ também ajuda a manter proporção. Datashare já demonstrou processamento de **milhões de documentos**, e o Panama Papers mostrou uma estratégia sensata para picos: compute temporário e paralelo, em vez de possuir permanentemente todos os servidores necessários para o pior dia do projeto. citeturn21search3turn21search8

A arquitetura mais econômica para os primeiros estágios, portanto, não seria:

```text
GPU cara
+ cluster Kubernetes
+ graph database distribuído
+ vector DB
+ 100 TB
```

Seria:

```text
1 máquina boa
64 GB RAM
2–4 TB NVMe

PostgreSQL
OpenSearch
object storage
Docker Compose

+ cloud temporária para batch
+ backup externo
```

E a decisão mais importante não seria sequer técnica. Seria formalizar desde a primeira versão a diferença entre:

```text
EVIDÊNCIA
“O DODF publicou isto.”

ENTIDADE RESOLVIDA
“Estes dois registros provavelmente representam a mesma organização.”

EVENTO
“O documento constitui evidência de que este evento ocorreu.”

ESTADO
“Segundo os eventos conhecidos, esta era a situação institucional naquele momento.”

INFERÊNCIA
“A combinação destes sinais sugere algo que nenhuma fonte declarou.”
```

Essa separação é simultaneamente uma solução de engenharia, uma defesa epistemológica e um mecanismo de governança.

Ela também responde à tensão que apareceu na conversa anterior: **um sistema desses pode, de fato, tornar-se infraestrutura de inteligência**. Mas isso não é uma propriedade inevitável de armazenar diários oficiais. A mudança acontece quando o sistema passa de recuperar evidências para automatizar inferências sobre estados presentes, capacidades, vulnerabilidades ou comportamentos futuros.

O projeto mais intelectualmente forte, e tecnicamente mais defensável, me parece ser um sistema que torne **o Estado publicamente observável de forma reconstruível e auditável**, mantendo claramente identificada a fronteira na qual observação documental vira inferência analítica.

Isso já é um projeto muito maior — e muito mais sério — do que um parser de DODF.
