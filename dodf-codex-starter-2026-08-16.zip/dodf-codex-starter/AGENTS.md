# Instruções para agentes e Codex

## Princípios inegociáveis

- Documento é evidência.
- Nada existe sem fonte.
- Toda afirmação derivada deve apontar para documento, captura, página, bloco e,
  quando possível, coordenadas e trecho.
- Arquivos brutos são imutáveis; republicações e novas capturas não os
  sobrescrevem.
- Texto original e texto normalizado são campos diferentes.
- Transformações são reproduzíveis, versionadas e auditáveis.
- Evidência, afirmação, inferência e interpretação são camadas distintas.
- Ausência de dado não é evidência de ausência.
- Conflitos entre fontes são preservados, não silenciosamente resolvidos.
- Busca e grafo são projeções; não são o banco mestre.

## Regras para retomar o código

1. Antes de implementar, leia `docs/PROJECT_STATE.md`, os três documentos em
   `recovered/` e as pesquisas em `research/`.
2. Não afirme que o código histórico foi recuperado. Reconstrua cada componente
   a partir do contrato documentado e acrescente testes.
3. Comece reproduzindo o piloto de uma edição antes de iniciar coleta histórica.
4. Prefira extratores determinísticos no MVP. IA generativa e inferências sem
   regra explícita permanecem fora do MVP inicial.
5. Mantenha o sistema mestre em evidências, capturas, afirmações e identidades
   versionadas. Índices de texto e grafos devem poder ser refeitos.
6. OCR é fallback para páginas sem texto utilizável, não etapa obrigatória para
   todo documento.
7. Não descarte dados anteriores quando a ontologia ou um extrator mudar.
8. Qualquer desvio de arquitetura deve ser registrado em uma ADR.

## Escopo do MVP registrado

- Cobertura pretendida: DODF de 2019 a 2026.
- Entidades/referências iniciais: processos, atos administrativos, órgãos,
  empresas, pessoas e normas.
- Fora do MVP: explicações causais, classificação generativa, inferências sem
  regra explícita, interface pública definitiva e ingestão simultânea de todas
  as fontes.

## Primeira missão recomendada

Reconstruir o pipeline mínimo para uma edição:

```text
PDF -> manifesto -> JSON estrutural -> Markdown -> menções SEI -> PostgreSQL
```

Critério mínimo: testes automatizados, dry-run, contagens auditáveis e ligação
de toda menção ao bloco de origem.

