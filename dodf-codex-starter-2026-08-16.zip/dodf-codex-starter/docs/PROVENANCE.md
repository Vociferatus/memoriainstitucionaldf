# Proveniência deste pacote

Este pacote combina duas classes de material:

1. arquivos preservados e recuperados de armazenamento persistente;
2. uma consolidação escrita em 2026-08-16 a partir desses arquivos e do
   histórico de decisões do projeto.

Arquivos com sufixo `_original` e os conteúdos de `samples/` e
`research/original/` pertencem à primeira classe. Os demais documentos deste
pacote pertencem à segunda.

Nenhum script ausente foi recriado silenciosamente. Nenhuma contagem do piloto
foi reexecutada durante a recuperação. Os números apresentados são registros
históricos que deverão ser reproduzidos experimentalmente.

