# Estado consolidado do projeto

Atualizado para a retomada em 2026-08-16.

## 1. Formulação do projeto

O projeto começou como um parser para transformar matérias do DODF em dados
estruturados. Foi então reformulado como uma camada de interoperabilidade e
memória institucional: uma infraestrutura capaz de preservar documentos
oficiais, extrair observações verificáveis, resolver identidades, reconstruir
eventos e consultar estados institucionais ao longo do tempo.

O nome conceitual usado passou a ser **Memória Institucional Navegável do
Distrito Federal**.

## 2. Distinções conceituais fixadas

- O domínio é a Administração Pública do DF.
- O DODF é uma fonte de observação do domínio.
- Veículo de publicação, instrumento jurídico/administrativo e registro
  material não devem ser confundidos.
- Documento, evidência, afirmação, entidade, evento, relação, estado e projeção
  são camadas diferentes.
- Resolução de identidade pode começar como hipótese; uma colisão de nomes não
  prova identidade.
- Temporalidade do fato, da publicação, da vigência, da captura e do registro
  no sistema podem divergir.

## 3. Piloto anteriormente registrado como executado

Edição: `DODF 112 22-06-2026 INTEGRA.pdf`.

Pipeline registrado:

```text
PDF -> manifesto -> JSON estrutural -> Markdown -> menções SEI -> PostgreSQL
```

Resultados registrados:

| Medida | Resultado |
|---|---:|
| Páginas | 85 |
| Blocos estruturais | 2.553 |
| Menções de processos SEI | 1.140 |
| Processos SEI únicos | 1.096 |
| Menções sem bloco correspondente | 0 |

Contagens registradas no PostgreSQL:

| Tabela | Linhas |
|---|---:|
| sources | 1 |
| documents | 1 |
| document_captures | 1 |
| document_pages | 85 |
| document_blocks | 2.553 |
| extraction_runs | 1 |
| mentions | 1.140 |

Essas contagens estão documentadas nos arquivos recuperados, mas o banco e os
artefatos que as produziram não foram recuperados neste pacote.

## 4. Componentes históricos citados, mas ausentes

- `scripts/dodf_to_markdown.py`
- `scripts/extract_mentions.py`
- `scripts/load_to_postgres.py`
- `scripts/db_up.ps1`
- `scripts/db_migrate.ps1`
- `scripts/db_load_pilot.ps1`
- `scripts/db_counts.ps1`
- `db/migrations/001_initial_schema.sql`
- `data/raw/DODF 112 22-06-2026 INTEGRA.pdf`
- manifesto SHA-256 da edição piloto
- JSON estrutural da edição piloto
- JSON de menções da edição piloto
- banco PostgreSQL do piloto
- entregas antes descritas como `02_ARCHITECTURE`, `07_ENGINEERING` e
  `07_SPECIFICATIONS`

O pacote contém duas representações textuais da edição piloto em `samples/`.

## 5. Contrato reconstruído dos componentes ausentes

### Conversor documental

Entrada: PDF do DODF.

Saídas esperadas:

- manifesto com nome, tamanho, páginas, origem, instante de captura e SHA-256;
- JSON estrutural com página, blocos, ordem de leitura, colunas, coordenadas,
  texto original e texto normalizado;
- Markdown somente como projeção de leitura humana.

### Extrator determinístico

Entrada: JSON estrutural.

Saída: menções objetivas com tipo, valor literal, valor normalizado, página,
bloco, contexto, regra e versão da regra.

Primeira regra registrada: números de processo SEI.

### Persistência

O esquema inicial deve representar ao menos fontes, documentos lógicos,
capturas, páginas, blocos, rodadas de extração e menções. Uma captura não deve
ser confundida com o documento lógico.

## 6. Fontes mapeadas

### Distrito Federal

- Portal oficial do DODF e DODF-e.
- SINJ e acervo histórico.
- Dados Abertos DF/CKAN.
- Transparência, contratos, convênios e licitações.
- Processos e normas, conforme acesso público disponível.

### Referências brasileiras

- Querido Diário/API.
- Diário Oficial da União e diários estaduais.
- Inteligov, e-DOU e Mais Jurídico como referências privadas de produto.

### Referências internacionais

- OpenAleph e FollowTheMoney.
- ICIJ Datashare.
- OpenCorporates e OpenSanctions.
- CELLAR/CDM e EUR-Lex.
- TED e eProcurement Ontology.
- Federal Register, GovInfo e USAspending.
- legislation.gov.uk.
- GDELT, Maltego, Quantexa e Palantir como referências parciais, não como
  equivalentes integrais.

As duas pesquisas completas estão em `research/`.

## 7. Arquitetura recomendada nas pesquisas

- armazenamento de objetos para brutos e derivados imutáveis;
- PostgreSQL como ledger operacional de evidência, afirmações e temporalidade;
- índice de busca como projeção reconstruível;
- grafo como projeção reconstruível;
- adapters por fonte/jurisdição;
- proveniência por afirmação;
- política explícita de autoridade e conflito entre fontes;
- FollowTheMoney como língua franca de intercâmbio, sem obrigação de adotá-lo
  como ontologia interna completa;
- OCR somente como fallback.

## 8. Escala e custo estimados nas pesquisas

Para uma prova de conceito de aproximadamente um ano de DODF, foi estimado:

- 10–50 GB de dados brutos;
- 4–8 vCPU;
- 16–32 GB de RAM;
- sem GPU inicialmente;
- aproximadamente US$ 40–160/mês em infraestrutura, dependendo das escolhas.

Esses números são estimativas de engenharia, não medições do corpus completo.
OCR foi identificado como principal fator potencial de custo.

## 9. Limites e risco dual-use discutidos

A agregação de dados públicos pode produzir efeito mosaico. Foi proposta a
distinção entre documentar ações institucionais e inferir capacidades
operacionais presentes. A formulação sugerida foi:

> capacidade de pesquisa histórica por padrão; capacidade de inferência
> operacional por decisão explícita.

Essa camada de controles foi introduzida nas pesquisas posteriores; ela não
fazia parte da formulação inicial do parser.

## 10. Próximo passo verificável

Reconstruir apenas o pipeline mínimo da edição piloto, escrever testes e tentar
reproduzir as contagens registradas. Divergências devem ser registradas; não se
deve ajustar a implementação apenas para forçar os números históricos.

