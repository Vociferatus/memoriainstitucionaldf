# Manifesto de recuperação

## Recuperado integralmente

- `recovered/readme_original.md`
- `recovered/DOMAIN_original.md`
- `recovered/ROADMAP_original.md`
- `samples/DODF_112_2026_extracted.md`
- `samples/DODF_112_2026_pasted_text.txt`
- os dois relatórios originais em JSON em `research/original/`
- o texto dos dois relatórios extraído para Markdown em `research/`

## Reconstruído do histórico e dos documentos recuperados

- `README.md`
- `AGENTS.md`
- `docs/PROJECT_STATE.md`
- `docs/PROVENANCE.md`

## Não recuperado

O código, banco, PDF bruto, manifesto, JSON estrutural, extrações e migração SQL
listados em `docs/PROJECT_STATE.md` não foram encontrados. As pastas vazias no
pacote são pontos de reconstrução, não prova de que os arquivos existiam nelas.

