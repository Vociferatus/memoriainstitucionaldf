# Domínio

O domínio principal é a Administração Pública do Distrito Federal.

O Diário Oficial do Distrito Federal é tratado como uma fonte
privilegiada de observação, não como o domínio em si.

## Objetos principais

-   Pessoas
-   Organizações
-   Cargos
-   Normas
-   Atos administrativos
-   Processos
-   Publicações
